"""
authentication.py

Módulo para gestionar la autenticación de usuarios (colaboradores, administradores)
contra el backend API de BitnariApp.
"""

import logging
import requests # Usaremos requests por simplicidad, httpx para asíncrono sería otra opción
from typing import Optional, Dict, Tuple

# Asumimos que la URL base del backend API está definida en constantes o configuración
# Por ahora, la definiremos aquí. En una app real, esto vendría de una config.
# Si el backend corre en Docker, y la app Qt localmente, la URL sería algo como http://localhost:8000
# Si ambos corren en la misma máquina sin Docker para el backend, también.
BACKEND_API_URL = "http://localhost:8000" # Ajustar si es necesario

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class AuthenticationError(Exception):
    """Excepción personalizada para errores de autenticación."""
    pass

class AuthService:
    """
    Servicio para interactuar con los endpoints de autenticación del backend API.
    """
    def __init__(self, base_api_url: str = BACKEND_API_URL):
        self.base_url = base_api_url
        self.token_endpoint = f"{self.base_url}/token"
        self.user_info_endpoint = f"{self.base_url}/users/me" # Asumiendo que existe este endpoint protegido
        
        self.current_user_token: Optional[str] = None
        self.current_user_info: Optional[Dict[str, Any]] = None
        self.session = requests.Session() # Usar una sesión para persistir cookies si el backend las usa

    def login(self, dni_username: str, password: str) -> Tuple[bool, str]:
        """
        Intenta iniciar sesión en el backend API.

        Args:
            dni_username (str): DNI del usuario (usado como username).
            password (str): Contraseña del usuario.

        Returns:
            Tuple[bool, str]: (éxito, mensaje_o_token_si_exito)
        """
        try:
            payload = {
                "username": dni_username, # FastAPI OAuth2PasswordRequestForm espera 'username'
                "password": password
            }
            # FastAPI espera datos de formulario para el endpoint de token OAuth2
            response = self.session.post(self.token_endpoint, data=payload, timeout=10) # timeout de 10s

            if response.status_code == 200:
                token_data = response.json()
                self.current_user_token = token_data.get("access_token")
                if not self.current_user_token:
                    logger.error("Respuesta de login exitosa pero sin access_token.")
                    return False, "Error interno: No se recibió token."
                
                # Guardar el token en el header de la sesión para futuras solicitudes
                self.session.headers.update({"Authorization": f"Bearer {self.current_user_token}"})
                
                logger.info(f"Login exitoso para usuario DNI: {dni_username}. Token obtenido.")
                # Opcional: Obtener información del usuario después del login
                # self.fetch_current_user_info()
                return True, self.current_user_token
            elif response.status_code == 401:
                logger.warning(f"Intento de login fallido para DNI {dni_username}: Credenciales inválidas.")
                return False, "DNI o contraseña incorrectos."
            else:
                error_detail = "Error desconocido."
                try:
                    error_detail = response.json().get("detail", error_detail)
                except requests.exceptions.JSONDecodeError:
                    error_detail = response.text[:200] # Primeros 200 chars si no es JSON
                logger.error(f"Error en login para DNI {dni_username}. Status: {response.status_code}, Detalle: {error_detail}")
                return False, f"Error del servidor ({response.status_code}): {error_detail}"

        except requests.exceptions.ConnectionError:
            logger.error(f"Error de conexión al intentar login en {self.token_endpoint}.")
            return False, "No se pudo conectar al servidor de autenticación."
        except requests.exceptions.Timeout:
            logger.error(f"Timeout durante el login en {self.token_endpoint}.")
            return False, "La solicitud de login tardó demasiado en responder."
        except Exception as e:
            logger.error(f"Excepción inesperada durante el login: {e}", exc_info=True)
            return False, f"Error inesperado: {e}"

    def fetch_current_user_info(self) -> Optional[Dict[str, Any]]:
        """
        Obtiene información del usuario actualmente autenticado usando el token.
        Requiere un endpoint como /users/me en el backend que devuelva info del usuario.
        """
        if not self.current_user_token:
            logger.warning("No hay token de usuario para obtener información.")
            return None
        
        # El token ya debería estar en self.session.headers
        # headers = {"Authorization": f"Bearer {self.current_user_token}"}
        try:
            response = self.session.get(self.user_info_endpoint, timeout=5) # Asumiendo que /users/me es GET
            if response.status_code == 200:
                self.current_user_info = response.json()
                logger.info(f"Información del usuario obtenida: {self.current_user_info.get('dni')}")
                return self.current_user_info
            else:
                logger.warning(f"No se pudo obtener información del usuario. Status: {response.status_code}, "
                               f"Respuesta: {response.text[:200]}")
                self.logout() # Si el token no es válido, desloguear
                return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Error de red al obtener información del usuario: {e}")
            return None

    def logout(self):
        """Cierra la sesión del usuario actual."""
        logger.info(f"Cerrando sesión para el token actual (DNI: {self.current_user_info.get('dni') if self.current_user_info else 'N/A'}).")
        self.current_user_token = None
        self.current_user_info = None
        self.session.headers.pop("Authorization", None) # Limpiar header de autorización
        # Opcional: llamar a un endpoint /logout en el backend si invalida tokens del lado del servidor.

    def get_current_user_token(self) -> Optional[str]:
        return self.current_user_token

    def get_current_user_data(self) -> Optional[Dict[str, Any]]:
        return self.current_user_info

    def is_authenticated(self) -> bool:
        # Podría ser más robusto validando el token contra el backend si ha pasado tiempo
        return self.current_user_token is not None

# Instancia global del servicio de autenticación (Singleton-like para la app Qt)
# Esto es una forma simple de tener una instancia compartida.
# En arquitecturas más complejas, se usaría inyección de dependencias.
_auth_service_instance: Optional[AuthService] = None

def get_auth_service() -> AuthService:
    """Retorna la instancia global del servicio de autenticación."""
    global _auth_service_instance
    if _auth_service_instance is None:
        _auth_service_instance = AuthService(base_api_url=BACKEND_API_URL) # Usar la URL definida
    return _auth_service_instance


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    auth_service = get_auth_service()

    # --- Prueba de Login ---
    # Para que esto funcione, el backend FastAPI (gestor_datos_completo.py) debe estar corriendo
    # y debe tener un colaborador/admin con DNI "ADMIN001" y contraseña "admin123".
    test_dni = "ADMIN001" # DNI del admin creado por init_admin() en gestor_datos_completo.py
    test_password = "admin123"

    logger.info(f"Intentando login para DNI: {test_dni}...")
    success, result = auth_service.login(test_dni, test_password)

    if success:
        logger.info(f"Login exitoso. Token: {result[:30]}...") # Mostrar solo parte del token
        
        # Intentar obtener información del usuario
        # Esto requiere que el backend tenga un endpoint /users/me protegido
        # y que gestor_datos_completo.py lo implemente.
        # Si no, esta parte fallará o devolverá None.
        user_info = auth_service.fetch_current_user_info()
        if user_info:
            logger.info(f"Información del usuario obtenida: Nombre='{user_info.get('nombre')}', Rol='{user_info.get('role')}'")
        else:
            logger.warning("No se pudo obtener información del usuario después del login.")
        
        logger.info(f"Está autenticado: {auth_service.is_authenticated()}")
        auth_service.logout()
        logger.info(f"Después del logout, está autenticado: {auth_service.is_authenticated()}")
    else:
        logger.error(f"Login fallido. Mensaje: {result}")

    logger.info("\nIntentando login con credenciales incorrectas...")
    success_fail, result_fail = auth_service.login("DNI_INCORRECTO", "pass_incorrecto")
    if not success_fail:
        logger.info(f"Login fallido como se esperaba. Mensaje: {result_fail}")
    else:
        logger.error("Login con credenciales incorrectas tuvo éxito, lo cual es un error.")
    
