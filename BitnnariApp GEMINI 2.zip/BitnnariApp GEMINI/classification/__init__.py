"""
BitnnariApp.classification.__init__.py

Este paquete contiene los m�dulos responsables de la clasificaci�n
de se�ales EMG, incluyendo la l�gica principal del clasificador,
las estrategias de modelo, la f�brica de modelos y las configuraciones.
"""

from .emg_classification import EMGClassifier
from .model_factory import ModelFactory
from .DEFAULT_CONFIG import (
   TRAINING_CONFIG,
   SVM_CONFIG,
   RF_CONFIG,
   XGBOOST_CONFIG,
   MLP_CONFIG,
   DNN_TORCH_CONFIG,
   ALL_MODEL_CONFIGS,
   GRID_SEARCH_PARAMS
)

# Cargar movimientos al importar el paquete para que est�n disponibles
# (aunque EMGClassifier tambi�n lo hace internamente)
import json
import os
MOVEMENTS_MAP: dict = {}
try:
   config_path = os.path.join(os.path.dirname(__file__), "movements_config.json")
   if os.path.exists(config_path):
       with open(config_path, "r", encoding="utf-8") as f:
           data = json.load(f)
       MOVEMENTS_MAP = {int(k): str(v) for k, v in data.items()}
except Exception as e:
   print(f"ADVERTENCIA: No se pudo cargar 'movements_config.json' desde classification/__init__.py: {e}")


__all__ = [
   "EMGClassifier",
   "ModelFactory",
   "TRAINING_CONFIG",
   "SVM_CONFIG",
   "RF_CONFIG",
   "XGBOOST_CONFIG",
   "MLP_CONFIG",
   "DNN_TORCH_CONFIG",
   "ALL_MODEL_CONFIGS",
   "GRID_SEARCH_PARAMS",
   "MOVEMENTS_MAP"
]

# Importar estrategias para que est�n disponibles a trav�s del paquete si es necesario,
# aunque ModelFactory es la forma preferida de acceder a ellas.
from .strategies import SvmStrategy, RfStrategy, XgboostStrategy, MlpStrategy, DnnTorchStrategy
   
