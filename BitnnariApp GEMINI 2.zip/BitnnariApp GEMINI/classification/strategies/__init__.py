"""
BitnnariApp.classification.strategies.__init__.py

Este paquete contiene las diferentes estrategias de clasificaci�n de Machine Learning
implementadas para el sistema EMG. Cada estrategia encapsula un algoritmo espec�fico
(e.g., SVM, Random Forest, CNN) y provee una interfaz com�n para entrenamiento,
predicci�n, y guardado/carga de modelos.
"""

from .svm_strategy import SvmStrategy
from .rf_strategy import RfStrategy
from .xgboost_strategy import XgboostStrategy
from .mlp_strategy import MlpStrategy
from .dnn_torch_strategy import DnnTorchStrategy

__all__ = [
   "SvmStrategy",
   "RfStrategy",
   "XgboostStrategy",
   "MlpStrategy",
   "DnnTorchStrategy"
]
   
