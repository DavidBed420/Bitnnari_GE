"""
svm_strategy.py

Implementa la estrategia de clasificaci�n utilizando Support Vector Machine (SVM)
de scikit-learn.
"""
import joblib
import logging
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import numpy as np
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class SvmStrategy:
   """
   Estrategia de clasificaci�n basada en Support Vector Machine (SVC).
   """
   def __init__(self, apply_scaling: bool = True, **kwargs: Any):
       """
       Inicializa la estrategia SVM.

       Args:
           apply_scaling (bool): Si es True, se aplicar� StandardScaler a los datos.
           **kwargs: Hiperpar�metros para el clasificador SVC.
                     Consulte la documentaci�n de scikit-learn.SVC para ver opciones.
                     Ejemplos: kernel, C, gamma, probability, class_weight, random_state.
       """
       self.apply_scaling = apply_scaling
       self.params = kwargs
       self.model: Optional[Pipeline] = None
       self._build_pipeline()
       logger.info(f"Estrategia SVM inicializada con par�metros: {self.params}, Escalado: {self.apply_scaling}")

   def _build_pipeline(self):
       """Construye el pipeline de scikit-learn (escalador + clasificador)."""
       steps = []
       if self.apply_scaling:
           steps.append(('scaler', StandardScaler()))
       steps.append(('svc', SVC(**self.params)))
       self.model = Pipeline(steps)

   def fit(self, X_train: np.ndarray, y_train: np.ndarray) -> None:
       """
       Entrena el modelo SVM.

       Args:
           X_train (np.ndarray): Datos de entrenamiento (caracter�sticas).
           y_train (np.ndarray): Etiquetas de entrenamiento.
       """
       if self.model is None:
           self._build_pipeline() # Asegurar que el pipeline est� construido
           if self.model is None: # Doble chequeo por si _build_pipeline falla silenciosamente
               logger.error("Fallo al construir el pipeline del modelo SVM. No se puede entrenar.")
               raise RuntimeError("Pipeline del modelo SVM no construido.")


       if X_train.ndim == 1:
           X_train = X_train.reshape(-1, 1)
       
       try:
           logger.info(f"Iniciando entrenamiento SVM con {X_train.shape[0]} muestras y {X_train.shape[1]} caracter�sticas.")
           self.model.fit(X_train, y_train)
           logger.info("Entrenamiento SVM completado.")
       except Exception as e:
           logger.error(f"Error durante el entrenamiento SVM: {e}", exc_info=True)
           raise

   def predict(self, X_test: np.ndarray) -> np.ndarray:
       """
       Realiza predicciones sobre nuevos datos.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           np.ndarray: Etiquetas predichas.
       """
       if self.model is None:
           logger.error("Modelo SVM no entrenado o no cargado. No se puede predecir.")
           raise RuntimeError("Modelo SVM no disponible para predicci�n.")
       
       if X_test.ndim == 1: # Si es una sola muestra
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1: # Array 1D de features para una muestra
            X_test = X_test.reshape(1, -1)


       try:
           predictions = self.model.predict(X_test)
           return predictions
       except Exception as e:
           logger.error(f"Error durante la predicci�n SVM: {e}", exc_info=True)
           raise

   def predict_proba(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       """
       Realiza predicciones de probabilidad sobre nuevos datos.
       Solo funciona si el SVC fue inicializado con probability=True.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           Optional[np.ndarray]: Probabilidades predichas por clase, o None si no est� soportado.
       """
       if self.model is None:
           logger.error("Modelo SVM no entrenado o no cargado.")
           return None
       
       svc_model = self.model.named_steps.get('svc')
       if not (svc_model and hasattr(svc_model, 'probability') and svc_model.probability):
           logger.warning("Predicci�n de probabilidad no habilitada para este modelo SVM (probability=False).")
           return None

       if X_test.ndim == 1:
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)

       try:
           probabilities = self.model.predict_proba(X_test)
           return probabilities
       except Exception as e:
           logger.error(f"Error durante la predicci�n de probabilidad SVM: {e}", exc_info=True)
           raise

   def save_model(self, path: str) -> None:
       """
       Guarda el modelo SVM entrenado en un archivo.

       Args:
           path (str): Ruta donde guardar el modelo (generalmente .pkl).
       """
       if self.model is None:
           logger.error("No hay modelo SVM para guardar.")
           raise RuntimeError("Modelo SVM no disponible para guardar.")
       try:
           # Crear directorio si no existe
           os.makedirs(os.path.dirname(path), exist_ok=True)
           joblib.dump(self.model, path)
           logger.info(f"Modelo SVM guardado en: {path}")
       except Exception as e:
           logger.error(f"Error al guardar el modelo SVM en {path}: {e}", exc_info=True)
           raise

   def load_model(self, path: str) -> None:
       """
       Carga un modelo SVM desde un archivo.

       Args:
           path (str): Ruta del archivo del modelo (generalmente .pkl).
       """
       try:
           self.model = joblib.load(path)
           # Actualizar par�metros si es posible (requerir�a guardar params con el modelo)
           loaded_svc_params = self.model.named_steps['svc'].get_params()
           self.params.update(loaded_svc_params)
           if 'scaler' not in self.model.named_steps:
               self.apply_scaling = False
           logger.info(f"Modelo SVM cargado desde: {path} con par�metros: {self.params}")
       except FileNotFoundError:
           logger.error(f"Archivo de modelo SVM no encontrado en: {path}")
           raise
       except Exception as e:
           logger.error(f"Error al cargar el modelo SVM desde {path}: {e}", exc_info=True)
           raise

   def get_params(self) -> Dict[str, Any]:
       """Retorna los par�metros actuales del clasificador SVC dentro del pipeline."""
       if self.model and 'svc' in self.model.named_steps:
           return self.model.named_steps['svc'].get_params()
       return self.params # Devuelve los params iniciales si el pipeline no est� construido

   @property
   def clf(self) -> Optional[SVC]: # Para compatibilidad con GridSearchCV si se usa fuera de pipeline
       if self.model and 'svc' in self.model.named_steps:
           return self.model.named_steps['svc'] # type: ignore
       return None
   
