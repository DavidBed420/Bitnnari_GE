"""
dnn_torch_strategy.py

Implementa la estrategia de clasificaci�n utilizando una Red Neuronal Profunda (DNN)
construida con PyTorch.
"""
import os
import logging
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
from typing import Dict, Any, Optional, Callable, List, Tuple

logger = logging.getLogger(__name__)

class TorchSimpleDNN(nn.Module):
   """
   Red neuronal simple para clasificaci�n de caracter�sticas EMG.
   """
   def __init__(self,
                input_dim: int,
                num_classes: int,
                hidden_dims: List[int] = [128, 64],
                dropout_rate: float = 0.3,
                use_batch_norm: bool = True,
                activation_function_name: str = "ReLU"):
       super().__init__()
       self.input_dim = input_dim
       self.num_classes = num_classes
       self.hidden_dims = hidden_dims
       self.dropout_rate = dropout_rate
       self.use_batch_norm = use_batch_norm

       if activation_function_name.lower() == "relu":
           self.activation_fn = nn.ReLU()
       elif activation_function_name.lower() == "tanh":
           self.activation_fn = nn.Tanh()
       elif activation_function_name.lower() == "sigmoid":
           self.activation_fn = nn.Sigmoid()
       elif activation_function_name.lower() == "leakyrelu":
           self.activation_fn = nn.LeakyReLU()
       else:
           logger.warning(f"Funci�n de activaci�n '{activation_function_name}' no reconocida. Usando ReLU por defecto.")
           self.activation_fn = nn.ReLU()

       layers = []
       current_dim = input_dim
       for h_dim in hidden_dims:
           layers.append(nn.Linear(current_dim, h_dim))
           if self.use_batch_norm:
               layers.append(nn.BatchNorm1d(h_dim))
           layers.append(self.activation_fn)
           layers.append(nn.Dropout(self.dropout_rate))
           current_dim = h_dim
       
       layers.append(nn.Linear(current_dim, num_classes))
       # La funci�n de p�rdida (CrossEntropyLoss) incluye Softmax, por lo que no se a�ade aqu�.
       
       self.network = nn.Sequential(*layers)

   def forward(self, x: torch.Tensor) -> torch.Tensor:
       return self.network(x)


class DnnTorchStrategy:
   """
   Estrategia de clasificaci�n basada en una DNN con PyTorch.
   """
   def __init__(self,
                num_classes: int,
                hidden_dims: List[int] = [128, 64],
                dropout_rate: float = 0.3,
                learning_rate: float = 0.001,
                batch_size: int = 32,
                num_epochs: int = 50,
                optimizer_name: str = "Adam",
                criterion_name: str = "CrossEntropyLoss",
                early_stopping_patience: int = 10,
                use_batch_norm: bool = True,
                activation_function: str = "ReLU",
                device: str = "cpu",
                weight_decay: float = 1e-5,
                **kwargs: Any): # kwargs para input_dim que se define en fit
       
       self.device = torch.device(device if torch.cuda.is_available() and device.lower() == "cuda" else "cpu")
       logger.info(f"DNN Torch Strategy utilizando dispositivo: {self.device}")

       self.num_classes = num_classes
       self.hidden_dims = hidden_dims
       self.dropout_rate = dropout_rate
       self.learning_rate = learning_rate
       self.batch_size = batch_size
       self.num_epochs = num_epochs
       self.optimizer_name = optimizer_name
       self.criterion_name = criterion_name
       self.early_stopping_patience = early_stopping_patience
       self.use_batch_norm = use_batch_norm
       self.activation_function = activation_function
       self.weight_decay = weight_decay
       
       self.model: Optional[TorchSimpleDNN] = None
       self.optimizer: Optional[optim.Optimizer] = None
       self.criterion: Optional[nn.Module] = None
       self.input_dim: Optional[int] = None # Se determinar� en fit()

   def _initialize_model_components(self, input_dim: int):
       """Inicializa el modelo, optimizador y funci�n de p�rdida."""
       self.input_dim = input_dim
       self.model = TorchSimpleDNN(
           input_dim=self.input_dim,
           num_classes=self.num_classes,
           hidden_dims=self.hidden_dims,
           dropout_rate=self.dropout_rate,
           use_batch_norm=self.use_batch_norm,
           activation_function_name=self.activation_function
       ).to(self.device)

       if self.optimizer_name.lower() == "adam":
           self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
       elif self.optimizer_name.lower() == "sgd":
           self.optimizer = optim.SGD(self.model.parameters(), lr=self.learning_rate, momentum=0.9, weight_decay=self.weight_decay)
       elif self.optimizer_name.lower() == "rmsprop":
           self.optimizer = optim.RMSprop(self.model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
       else:
           logger.warning(f"Optimizador '{self.optimizer_name}' no reconocido. Usando Adam por defecto.")
           self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)

       if self.criterion_name.lower() == "crossentropy": # Abreviatura com�n
            self.criterion_name = "CrossEntropyLoss"

       if self.criterion_name == "CrossEntropyLoss":
           self.criterion = nn.CrossEntropyLoss()
       # A�adir m�s funciones de p�rdida si es necesario (e.g., NLLLoss si el modelo ya tiene LogSoftmax)
       else:
           logger.warning(f"Funci�n de p�rdida '{self.criterion_name}' no reconocida. Usando CrossEntropyLoss por defecto.")
           self.criterion = nn.CrossEntropyLoss()

   def fit(self, X_train: np.ndarray, y_train: np.ndarray,
           X_val: Optional[np.ndarray] = None, y_val: Optional[np.ndarray] = None,
           progress_callback: Optional[Callable[[int, Dict[str, float]], None]] = None) -> Dict[str, Any]:
       """
       Entrena la red neuronal.

       Args:
           X_train: Datos de entrenamiento.
           y_train: Etiquetas de entrenamiento.
           X_val: Datos de validaci�n (opcional, para early stopping).
           y_val: Etiquetas de validaci�n (opcional).
           progress_callback: Funci�n para reportar progreso (epoch, metrics_dict).

       Returns:
           Dict[str, Any]: Historial de entrenamiento (p�rdidas, precisiones).
       """
       if X_train.ndim == 1: X_train = X_train.reshape(-1, 1)
       
       current_input_dim = X_train.shape[1]
       if self.model is None or self.input_dim != current_input_dim:
           self._initialize_model_components(current_input_dim)
       
       if self.model is None or self.optimizer is None or self.criterion is None:
           logger.error("Componentes del modelo no inicializados. No se puede entrenar.")
           raise RuntimeError("Fallo en la inicializaci�n de componentes del modelo PyTorch.")

       X_train_tensor = torch.tensor(X_train, dtype=torch.float32).to(self.device)
       y_train_tensor = torch.tensor(y_train, dtype=torch.long).to(self.device)
       train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
       train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)

       val_loader: Optional[DataLoader] = None
       if X_val is not None and y_val is not None:
           if X_val.ndim == 1: X_val = X_val.reshape(-1, 1)
           X_val_tensor = torch.tensor(X_val, dtype=torch.float32).to(self.device)
           y_val_tensor = torch.tensor(y_val, dtype=torch.long).to(self.device)
           val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
           val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False)

       best_val_loss = float('inf')
       epochs_no_improve = 0
       training_history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}

       logger.info(f"Iniciando entrenamiento DNN PyTorch para {self.num_epochs} �pocas.")
       for epoch in range(self.num_epochs):
           self.model.train()
           running_loss = 0.0
           correct_train = 0
           total_train = 0

           for inputs, labels in train_loader:
               self.optimizer.zero_grad()
               outputs = self.model(inputs)
               loss = self.criterion(outputs, labels)
               loss.backward()
               self.optimizer.step()

               running_loss += loss.item() * inputs.size(0)
               _, predicted = torch.max(outputs.data, 1)
               total_train += labels.size(0)
               correct_train += (predicted == labels).sum().item()

           epoch_train_loss = running_loss / total_train
           epoch_train_acc = correct_train / total_train
           training_history["train_loss"].append(epoch_train_loss)
           training_history["train_acc"].append(epoch_train_acc)

           log_msg = f"Epoch [{epoch+1}/{self.num_epochs}] | Train Loss: {epoch_train_loss:.4f} | Train Acc: {epoch_train_acc:.4f}"

           if val_loader:
               self.model.eval()
               val_loss = 0.0
               correct_val = 0
               total_val = 0
               with torch.no_grad():
                   for inputs_val, labels_val in val_loader:
                       outputs_val = self.model(inputs_val)
                       loss_val = self.criterion(outputs_val, labels_val)
                       val_loss += loss_val.item() * inputs_val.size(0)
                       _, predicted_val = torch.max(outputs_val.data, 1)
                       total_val += labels_val.size(0)
                       correct_val += (predicted_val == labels_val).sum().item()
               
               epoch_val_loss = val_loss / total_val
               epoch_val_acc = correct_val / total_val
               training_history["val_loss"].append(epoch_val_loss)
               training_history["val_acc"].append(epoch_val_acc)
               log_msg += f" | Val Loss: {epoch_val_loss:.4f} | Val Acc: {epoch_val_acc:.4f}"

               if epoch_val_loss < best_val_loss:
                   best_val_loss = epoch_val_loss
                   epochs_no_improve = 0
                   # Guardar el mejor modelo (opcional, o hacerlo al final)
                   # torch.save(self.model.state_dict(), "best_model_temp.pth")
               else:
                   epochs_no_improve += 1
               
               if epochs_no_improve >= self.early_stopping_patience:
                   logger.info(f"Early stopping activado en epoch {epoch+1}.")
                   # self.model.load_state_dict(torch.load("best_model_temp.pth")) # Cargar el mejor
                   break
           
           logger.info(log_msg)
           if progress_callback:
               metrics_cb = {"train_loss": epoch_train_loss, "train_acc": epoch_train_acc}
               if val_loader:
                   metrics_cb.update({"val_loss": epoch_val_loss, "val_acc": epoch_val_acc})
               progress_callback(int(((epoch + 1) / self.num_epochs) * 100), metrics_cb)
       
       logger.info("Entrenamiento DNN PyTorch completado.")
       return training_history

   def predict(self, X_test: np.ndarray) -> np.ndarray:
       if self.model is None:
           logger.error("Modelo DNN no entrenado o no cargado. No se puede predecir.")
           raise RuntimeError("Modelo DNN no disponible para predicci�n.")
       
       self.model.eval()
       if X_test.ndim == 1: X_test = X_test.reshape(1, -1) # Una sola muestra
       
       X_test_tensor = torch.tensor(X_test, dtype=torch.float32).to(self.device)
       with torch.no_grad():
           outputs = self.model(X_test_tensor)
           probabilities = torch.softmax(outputs, dim=1) # Obtener probabilidades
           _, predicted_labels = torch.max(probabilities, 1)
       return predicted_labels.cpu().numpy()

   def predict_proba(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       if self.model is None:
           logger.error("Modelo DNN no entrenado o no cargado.")
           return None
       
       self.model.eval()
       if X_test.ndim == 1: X_test = X_test.reshape(1, -1)

       X_test_tensor = torch.tensor(X_test, dtype=torch.float32).to(self.device)
       with torch.no_grad():
           outputs = self.model(X_test_tensor)
           probabilities = torch.softmax(outputs, dim=1)
       return probabilities.cpu().numpy()

   def save_model(self, path: str) -> None:
       if self.model is None or self.input_dim is None:
           logger.error("No hay modelo DNN para guardar o input_dim no est� definido.")
           raise RuntimeError("Modelo DNN no disponible o incompleto para guardar.")
       try:
           os.makedirs(os.path.dirname(path), exist_ok=True)
           checkpoint = {
               'input_dim': self.input_dim,
               'num_classes': self.num_classes,
               'hidden_dims': self.hidden_dims,
               'dropout_rate': self.dropout_rate,
               'use_batch_norm': self.use_batch_norm,
               'activation_function': self.activation_function,
               'model_state_dict': self.model.state_dict(),
               'optimizer_state_dict': self.optimizer.state_dict() if self.optimizer else None,
               # Podr�as guardar m�s hiperpar�metros si es necesario para la recarga
           }
           torch.save(checkpoint, path)
           logger.info(f"Modelo DNN PyTorch guardado en: {path}")
       except Exception as e:
           logger.error(f"Error al guardar el modelo DNN en {path}: {e}", exc_info=True)
           raise

   def load_model(self, path: str) -> None:
       try:
           checkpoint = torch.load(path, map_location=self.device)
           
           self.input_dim = checkpoint['input_dim']
           self.num_classes = checkpoint['num_classes']
           self.hidden_dims = checkpoint.get('hidden_dims', self.hidden_dims) # Compatibilidad con modelos m�s antiguos
           self.dropout_rate = checkpoint.get('dropout_rate', self.dropout_rate)
           self.use_batch_norm = checkpoint.get('use_batch_norm', self.use_batch_norm)
           self.activation_function = checkpoint.get('activation_function', self.activation_function)

           self._initialize_model_components(self.input_dim) # Reconstruye el modelo con los params cargados
           if self.model:
               self.model.load_state_dict(checkpoint['model_state_dict'])
           if self.optimizer and 'optimizer_state_dict' in checkpoint and checkpoint['optimizer_state_dict']:
               self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
           
           self.model.to(self.device) # type: ignore
           logger.info(f"Modelo DNN PyTorch cargado desde: {path}")
       except FileNotFoundError:
           logger.error(f"Archivo de modelo DNN no encontrado en: {path}")
           raise
       except Exception as e:
           logger.error(f"Error al cargar el modelo DNN desde {path}: {e}", exc_info=True)
           raise

   def get_params(self) -> Dict[str, Any]:
       """Retorna los hiperpar�metros de la estrategia."""
       return {
           "num_classes": self.num_classes,
           "hidden_dims": self.hidden_dims,
           "dropout_rate": self.dropout_rate,
           "learning_rate": self.learning_rate,
           "batch_size": self.batch_size,
           "num_epochs": self.num_epochs,
           "optimizer_name": self.optimizer_name,
           "criterion_name": self.criterion_name,
           "early_stopping_patience": self.early_stopping_patience,
           "use_batch_norm": self.use_batch_norm,
           "activation_function": self.activation_function,
           "device": str(self.device),
           "weight_decay": self.weight_decay,
           "input_dim": self.input_dim
       }

   @property
   def clf(self) -> Optional[TorchSimpleDNN]: # Para una posible compatibilidad conceptual
       return self.model
   
