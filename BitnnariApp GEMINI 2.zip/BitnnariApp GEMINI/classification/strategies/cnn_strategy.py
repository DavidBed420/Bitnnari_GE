min_lr=0.00001, verbose=1)
       ]

       logger.info(f"Entrenando CNN por {epochs} �pocas con tama�o de batch {batch_size}...")
       self.history = self.model.fit(
           X_train, y_train_cat,
           epochs=epochs,
           batch_size=batch_size,
           validation_data=validation_data,
           callbacks=callbacks,
           verbose=2 # 0 = silent, 1 = progress bar, 2 = one line per epoch
       )

       # Evaluaci�n
       train_loss, train_accuracy = self.model.evaluate(X_train, y_train_cat, verbose=0)
       metrics = {"train_accuracy": float(train_accuracy), "train_loss": float(train_loss)}
       
       # Generar reporte de clasificaci�n y matriz de confusi�n para entrenamiento
       y_train_pred_probs = self.model.predict(X_train)
       if self.num_classes == 2: # Binario
           y_train_pred_classes = (y_train_pred_probs > 0.5).astype(int).flatten()
       else: # Multiclase
           y_train_pred_classes = np.argmax(y_train_pred_probs, axis=1)
       
       metrics["train_classification_report"] = classification_report(y_train_encoded, y_train_pred_classes, output_dict=True, zero_division=0, labels=np.arange(self.num_classes))
       metrics["train_confusion_matrix"] = confusion_matrix(y_train_encoded, y_train_pred_classes, labels=np.arange(self.num_classes)).tolist()


       if validation_data:
           val_loss, val_accuracy = self.model.evaluate(X_val, y_val_cat, verbose=0)
           metrics["val_accuracy"] = float(val_accuracy)
           metrics["val_loss"] = float(val_loss)
           
           y_val_pred_probs = self.model.predict(X_val)
           if self.num_classes == 2:
               y_val_pred_classes = (y_val_pred_probs > 0.5).astype(int).flatten()
           else:
               y_val_pred_classes = np.argmax(y_val_pred_probs, axis=1)

           metrics["val_classification_report"] = classification_report(y_val_encoded, y_val_pred_classes, output_dict=True, zero_division=0, labels=np.arange(self.num_classes))
           metrics["val_confusion_matrix"] = confusion_matrix(y_val_encoded, y_val_pred_classes, labels=np.arange(self.num_classes)).tolist()
           logger.info(f"CNN Entrenado. Train Acc: {train_accuracy:.4f}, Val Acc: {val_accuracy:.4f}")
       else:
           logger.info(f"CNN Entrenado. Train Acc: {train_accuracy:.4f}")
           
       # Keras no tiene "best_params_" como scikit-learn. Los par�metros son los definidos.
       # Se podr�a guardar el historial de entrenamiento si es �til.
       if self.history:
           metrics['training_history'] = self.history.history
           # Convertir valores de historial a tipos nativos de Python para serializaci�n JSON
           for key, value_list in metrics['training_history'].items():
               metrics['training_history'][key] = [float(v) for v in value_list]


       return metrics, self.model_params # Devolver los params usados

   def predict(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       """Realiza predicciones de clase."""
       if self.model is None:
           logger.error("El modelo CNN no ha sido entrenado o cargado.")
           return None

       # Escalar y reformatear X_test de la misma manera que X_train
       if X_test.ndim == 2:
           if self.input_shape and (X_test.shape[1] == self.input_shape[0] * self.input_shape[1]):
                X_test = X_test.reshape((X_test.shape[0], self.input_shape[0], self.input_shape[1]))
           else: # Si es (samples, features_flat) o (samples, timesteps)
                X_test_scaled = self.scaler.transform(X_test)
                if self.input_shape and X_test_scaled.shape[1] == self.input_shape[0] * self.input_shape[1] and self.input_shape[1] > 1: # (samples, timesteps*features)
                    X_test = X_test_scaled.reshape((X_test_scaled.shape[0], self.input_shape[0], self.input_shape[1]))
                elif self.input_shape and X_test_scaled.shape[1] == self.input_shape[0] and self.input_shape[1] == 1: # (samples, timesteps)
                    X_test = X_test_scaled.reshape((X_test_scaled.shape[0], self.input_shape[0], 1))
                else: # No se puede reformatear autom�ticamente, asumir que ya tiene la forma correcta o fallar
                    logger.warning(f"Forma de X_test ({X_test.shape}) no se pudo reformatear autom�ticamente a 3D. Se usar� como est� si es 3D.")
                    if X_test.ndim != 3:
                        logger.error("X_test no es 3D y no se pudo reformatear.")
                        return None
       elif X_test.ndim == 3: # (samples, timesteps, features)
           original_shape_test = X_test.shape
           X_test_reshaped = X_test.reshape(-1, original_shape_test[-1])
           X_test_scaled_reshaped = self.scaler.transform(X_test_reshaped)
           X_test = X_test_scaled_reshaped.reshape(original_shape_test)
       else:
           logger.error(f"X_test debe ser 2D o 3D. Recibido: {X_test.ndim}D")
           return None


       logger.debug(f"Realizando predicci�n CNN sobre datos con forma: {X_test.shape}")
       try:
           probabilities = self.model.predict(X_test)
           if self.num_classes == 2: # Binario
               predictions = (probabilities > 0.5).astype(int).flatten()
           else: # Multiclase
               predictions = np.argmax(probabilities, axis=1)
           # Devolver etiquetas originales si es posible
           return self.label_encoder.inverse_transform(predictions)
       except Exception as e:
           logger.error(f"Error durante la predicci�n CNN: {e}")
           return None

   def predict_proba(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       """Realiza predicciones de probabilidad."""
       if self.model is None:
           logger.error("El modelo CNN no ha sido entrenado o cargado.")
           return None
       
       # Escalar y reformatear X_test (similar a predict)
       if X_test.ndim == 2:
           if self.input_shape and (X_test.shape[1] == self.input_shape[0] * self.input_shape[1]):
                X_test = X_test.reshape((X_test.shape[0], self.input_shape[0], self.input_shape[1]))
           else:
                X_test_scaled = self.scaler.transform(X_test)
                if self.input_shape and X_test_scaled.shape[1] == self.input_shape[0] * self.input_shape[1] and self.input_shape[1] > 1:
                    X_test = X_test_scaled.reshape((X_test_scaled.shape[0], self.input_shape[0], self.input_shape[1]))
                elif self.input_shape and X_test_scaled.shape[1] == self.input_shape[0] and self.input_shape[1] == 1:
                    X_test = X_test_scaled.reshape((X_test_scaled.shape[0], self.input_shape[0], 1))
                else:
                    if X_test.ndim != 3: return None
       elif X_test.ndim == 3:
           original_shape_test = X_test.shape
           X_test_reshaped = X_test.reshape(-1, original_shape_test[-1])
           X_test_scaled_reshaped = self.scaler.transform(X_test_reshaped)
           X_test = X_test_scaled_reshaped.reshape(original_shape_test)
       else:
           return None

       logger.debug(f"Realizando predicci�n de probabilidad CNN sobre datos con forma: {X_test.shape}")
       try:
           return self.model.predict(X_test) # Keras predict ya da probabilidades para softmax/sigmoid
       except Exception as e:
           logger.error(f"Error durante la predicci�n de probabilidad CNN: {e}")
           return None

   def save_model(self, filepath: str) -> bool:
       """Guarda el modelo Keras entrenado y sus metadatos asociados."""
       if self.model is None:
           logger.error("No hay modelo CNN entrenado para guardar.")
           return False
       
       # Keras guarda en formato HDF5 (.h5) o SavedModel (directorio)
       # Usaremos .h5 por simplicidad aqu�.
       model_filepath = filepath
       if not model_filepath.endswith(".h5"):
            model_filepath += ".h5" # Asegurar extensi�n

       metadata_filepath = filepath.replace(".h5", "_metadata.joblib")

       try:
           keras_save_model(self.model, model_filepath, save_format='h5')
           
           # Guardar metadatos (scaler, label_encoder, input_shape, num_classes, history)
           metadata = {
               'input_shape': self.input_shape,
               'num_classes': self.num_classes,
               'label_encoder_classes': self.label_encoder.classes_.tolist() if hasattr(self.label_encoder, 'classes_') else None,
               'scaler_mean': self.scaler.mean_.tolist() if hasattr(self.scaler, 'mean_') else None,
               'scaler_scale': self.scaler.scale_.tolist() if hasattr(self.scaler, 'scale_') else None,
               'training_history': self.history.history if self.history else None,
               'model_params': self.model_params
           }
           if metadata['training_history']: # Convertir floats de numpy a python
                for key, value_list in metadata['training_history'].items():
                   metadata['training_history'][key] = [float(v) for v in value_list]

           joblib.dump(metadata, metadata_filepath)
           logger.info(f"Modelo CNN guardado en: {model_filepath}")
           logger.info(f"Metadatos del modelo CNN guardados en: {metadata_filepath}")
           return True
       except Exception as e:
           logger.error(f"Error al guardar el modelo CNN en {model_filepath}: {e}")
           return False

   def load_model(self, filepath: str) -> bool:
       """Carga un modelo Keras entrenado y sus metadatos."""
       model_filepath = filepath
       if not model_filepath.endswith(".h5"):
            model_filepath += ".h5"

       metadata_filepath = filepath.replace(".h5", "_metadata.joblib")
       if not os.path.exists(model_filepath):
           logger.error(f"Archivo de modelo CNN no encontrado en: {model_filepath}")
           return False
       if not os.path.exists(metadata_filepath):
           logger.error(f"Archivo de metadatos CNN no encontrado en: {metadata_filepath}")
           return False
           
       try:
           self.model = keras_load_model(model_filepath)
           
           metadata = joblib.load(metadata_filepath)
           self.input_shape = metadata.get('input_shape')
           self.num_classes = metadata.get('num_classes')
           self.model_params = metadata.get('model_params', {})
           
           if metadata.get('label_encoder_classes'):
               self.label_encoder = LabelEncoder()
               self.label_encoder.classes_ = np.array(metadata['label_encoder_classes'])
           
           self.scaler = StandardScaler()
           if metadata.get('scaler_mean') is not None and metadata.get('scaler_scale') is not None:
               self.scaler.mean_ = np.array(metadata['scaler_mean'])
               self.scaler.scale_ = np.array(metadata['scaler_scale'])
           
           history_data = metadata.get('training_history')
           if history_data:
               self.history = keras.callbacks.History()
               self.history.history = history_data
           
           logger.info(f"Modelo CNN cargado desde: {model_filepath}")
           logger.info(f"Metadatos cargados: input_shape={self.input_shape}, num_classes={self.num_classes}")
           self.model.summary(print_fn=logger.info)
           return True
       except Exception as e:
           logger.error(f"Error al cargar el modelo CNN desde {model_filepath} o sus metadatos: {e}")
           return False

# Ejemplo de uso
if __name__ == '__main__':
   logging.basicConfig(level=logging.INFO)

   # Generar datos de ejemplo para CNN 1D
   # (n_samples, timesteps, features_per_timestep)
   # features_per_timestep podr�a ser el n�mero de canales EMG
   n_samples = 200
   timesteps = 100
   n_channels_emg = 2 # Ejemplo: 2 canales EMG
   n_classes_emg = 3

   X_cnn = np.random.rand(n_samples, timesteps, n_channels_emg)
   y_cnn_int = np.random.randint(0, n_classes_emg, n_samples)
   # Convertir etiquetas a strings para probar LabelEncoder
   label_map = {0: "reposo", 1: "pu�o", 2: "pinza"}
   y_cnn_str = np.array([label_map[i] for i in y_cnn_int])


   X_train_cnn, X_test_cnn, y_train_cnn, y_test_cnn = train_test_split(
       X_cnn, y_cnn_str, test_size=0.25, random_state=42, stratify=y_cnn_str
   )

   logger.info(f"\n--- Probando entrenamiento CNN ---")
   cnn_params = {
       'filters': [16, 32], 'kernel_size': 5, 'dense_units': 32, 'dropout_rate': 0.3,
       'learning_rate': 0.005, 'epochs': 10, 'batch_size': 16 # Pocas �pocas para prueba r�pida
   }
   # input_shape y num_classes se pueden inferir en fit o pasar aqu�
   cnn_strategy = CNNStrategy(model_params=cnn_params, 
                              input_shape=(timesteps, n_channels_emg), 
                              num_classes=n_classes_emg)
   
   # Si no se pasan input_shape y num_classes al constructor, se inferir�n en fit:
   # cnn_strategy = CNNStrategy(model_params=cnn_params)

   metrics_cnn, _ = cnn_strategy.fit(X_train_cnn, y_train_cnn, X_val=X_test_cnn, y_val=y_test_cnn)
   
   if cnn_strategy.model:
       logger.info(f"M�tricas CNN: Val Accuracy: {metrics_cnn.get('val_accuracy', 'N/A'):.4f}")

       preds_cnn_labels = cnn_strategy.predict(X_test_cnn)
       if preds_cnn_labels is not None:
           logger.info(f"Predicciones CNN (etiquetas): {preds_cnn_labels[:5]}")
           # Calcular accuracy con etiquetas originales
           y_test_cnn_encoded = cnn_strategy.label_encoder.transform(y_test_cnn)
           preds_cnn_encoded = cnn_strategy.label_encoder.transform(preds_cnn_labels)
           logger.info(f"Accuracy en test (etiquetas): {accuracy_score(y_test_cnn_encoded, preds_cnn_encoded):.4f}")


       probs_cnn = cnn_strategy.predict_proba(X_test_cnn)
       if probs_cnn is not None:
           logger.info(f"Probabilidades CNN (primeras 2): {probs_cnn[:2]}")

       model_path_cnn = "temp_cnn_model" # No necesita .h5 aqu�, se a�ade en save_model
       cnn_strategy.save_model(model_path_cnn)
       
       cnn_loaded = CNNStrategy() # No necesita params aqu�, se cargan de metadata
       cnn_loaded.load_model(model_path_cnn)
       
       if cnn_loaded.model:
           preds_cnn_loaded_labels = cnn_loaded.predict(X_test_cnn)
           if preds_cnn_loaded_labels is not None:
               y_test_cnn_enc_l = cnn_loaded.label_encoder.transform(y_test_cnn)
               preds_cnn_enc_l = cnn_loaded.label_encoder.transform(preds_cnn_loaded_labels)
               acc_cnn_loaded = accuracy_score(y_test_cnn_enc_l, preds_cnn_enc_l)
               logger.info(f"Accuracy del modelo CNN cargado: {acc_cnn_loaded:.4f}")
       
       if os.path.exists(model_path_cnn + ".h5"):
           os.remove(model_path_cnn + ".h5")
       if os.path.exists(model_path_cnn + "_metadata.joblib"):
           os.remove(model_path_cnn + "_metadata.joblib")
   
