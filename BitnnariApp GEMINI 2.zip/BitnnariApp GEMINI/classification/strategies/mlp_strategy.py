     """
mlp_strategy.py

Implementa la estrategia de clasificaci�n utilizando Multi-layer Perceptron (MLP)
de scikit-learn.
"""
import joblib
import logging
import os
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import numpy as np
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class MlpStrategy:
   """
   Estrategia de clasificaci�n basada en Multi-layer Perceptron (MLP).
   """
   def __init__(self, apply_scaling: bool = True, **kwargs: Any):
       """
       Inicializa la estrategia MLP.

       Args:
           apply_scaling (bool): Si es True, se aplicar� StandardScaler a los datos.
           **kwargs: Hiperpar�metros para el clasificador MLPClassifier.
                     Consulte la documentaci�n de scikit-learn.MLPClassifier.
                     Ejemplos: hidden_layer_sizes, activation, solver, alpha, random_state.
       """
       self.apply_scaling = apply_scaling
       self.params = kwargs
       self.model: Optional[Pipeline] = None
       self._build_pipeline()
       logger.info(f"Estrategia MLP inicializada con par�metros: {self.params}, Escalado: {self.apply_scaling}")

   def _build_pipeline(self):
       """Construye el pipeline de scikit-learn (escalador + clasificador)."""
       steps = []
       if self.apply_scaling:
           steps.append(('scaler', StandardScaler()))
       steps.append(('mlp', MLPClassifier(**self.params)))
       self.model = Pipeline(steps)

   def fit(self, X_train: np.ndarray, y_train: np.ndarray) -> None:
       """
       Entrena el modelo MLP.

       Args:
           X_train (np.ndarray): Datos de entrenamiento (caracter�sticas).
           y_train (np.ndarray): Etiquetas de entrenamiento.
       """
       if self.model is None:
           self._build_pipeline()
           if self.model is None:
               logger.error("Fallo al construir el pipeline del modelo MLP. No se puede entrenar.")
               raise RuntimeError("Pipeline del modelo MLP no construido.")

       if X_train.ndim == 1:
           X_train = X_train.reshape(-1, 1)
       
       try:
           logger.info(f"Iniciando entrenamiento MLP con {X_train.shape[0]} muestras y {X_train.shape[1]} caracter�sticas.")
           self.model.fit(X_train, y_train)
           logger.info("Entrenamiento MLP completado.")
       except Exception as e:
           logger.error(f"Error durante el entrenamiento MLP: {e}", exc_info=True)
           raise

   def predict(self, X_test: np.ndarray) -> np.ndarray:
       """
       Realiza predicciones sobre nuevos datos.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           np.ndarray: Etiquetas predichas.
       """
       if self.model is None:
           logger.error("Modelo MLP no entrenado o no cargado. No se puede predecir.")
           raise RuntimeError("Modelo MLP no disponible para predicci�n.")

       if X_test.ndim == 1:
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)

       try:
           predictions = self.model.predict(X_test)
           return predictions
       except Exception as e:
           logger.error(f"Error durante la predicci�n MLP: {e}", exc_info=True)
           raise

   def predict_proba(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       """
       Realiza predicciones de probabilidad sobre nuevos datos.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           Optional[np.ndarray]: Probabilidades predichas por clase.
       """
       if self.model is None:
           logger.error("Modelo MLP no entrenado o no cargado.")
           return None
       
       if X_test.ndim == 1:
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)

       try:
           probabilities = self.model.predict_proba(X_test)
           return probabilities
       except Exception as e:
           logger.error(f"Error durante la predicci�n de probabilidad MLP: {e}", exc_info=True)
           raise

   def save_model(self, path: str) -> None:
       """
       Guarda el modelo MLP entrenado en un archivo.

       Args:
           path (str): Ruta donde guardar el modelo (generalmente .pkl).
       """
       if self.model is None:
           logger.error("No hay modelo MLP para guardar.")
           raise RuntimeError("Modelo MLP no disponible para guardar.")
       try:
           os.makedirs(os.path.dirname(path), exist_ok=True)
           joblib.dump(self.model, path)
           logger.info(f"Modelo MLP guardado en: {path}")
       except Exception as e:
           logger.error(f"Error al guardar el modelo MLP en {path}: {e}", exc_info=True)
           raise

   def load_model(self, path: str) -> None:
       """
       Carga un modelo MLP desde un archivo.

       Args:
           path (str): Ruta del archivo del modelo (generalmente .pkl).
       """
       try:
           self.model = joblib.load(path)
           loaded_mlp_params = self.model.named_steps['mlp'].get_params()
           self.params.update(loaded_mlp_params)
           if 'scaler' not in self.model.named_steps:
               self.apply_scaling = False
           logger.info(f"Modelo MLP cargado desde: {path} con par�metros: {self.params}")
       except FileNotFoundError:
           logger.error(f"Archivo de modelo MLP no encontrado en: {path}")
           raise
       except Exception as e:
           logger.error(f"Error al cargar el modelo MLP desde {path}: {e}", exc_info=True)
           raise

   def get_params(self) -> Dict[str, Any]:
       """Retorna los par�metros actuales del clasificador MLPClassifier."""
       if self.model and 'mlp' in self.model.named_steps:
           return self.model.named_steps['mlp'].get_params()
       return self.params

   @property
   def clf(self) -> Optional[MLPClassifier]: # Para compatibilidad con GridSearchCV
       if self.model and 'mlp' in self.model.named_steps:
           return self.model.named_steps['mlp'] # type: ignore
       return None
