"""
rf_strategy.py

Implementa la estrategia de clasificaci�n utilizando Random Forest
de scikit-learn.
"""
import joblib
import logging
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import numpy as np
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class RfStrategy:
   """
   Estrategia de clasificaci�n basada en Random Forest.
   """
   def __init__(self, apply_scaling: bool = True, **kwargs: Any):
       """
       Inicializa la estrategia Random Forest.

       Args:
           apply_scaling (bool): Si es True, se aplicar� StandardScaler a los datos.
           **kwargs: Hiperpar�metros para el clasificador RandomForestClassifier.
                     Consulte la documentaci�n de scikit-learn.RandomForestClassifier.
                     Ejemplos: n_estimators, max_depth, min_samples_split, random_state.
       """
       self.apply_scaling = apply_scaling
       self.params = kwargs
       self.model: Optional[Pipeline] = None
       self._build_pipeline()
       logger.info(f"Estrategia Random Forest inicializada con par�metros: {self.params}, Escalado: {self.apply_scaling}")

   def _build_pipeline(self):
       """Construye el pipeline de scikit-learn (escalador + clasificador)."""
       steps = []
       if self.apply_scaling:
           steps.append(('scaler', StandardScaler()))
       steps.append(('rf', RandomForestClassifier(**self.params)))
       self.model = Pipeline(steps)

   def fit(self, X_train: np.ndarray, y_train: np.ndarray) -> None:
       """
       Entrena el modelo Random Forest.

       Args:
           X_train (np.ndarray): Datos de entrenamiento (caracter�sticas).
           y_train (np.ndarray): Etiquetas de entrenamiento.
       """
       if self.model is None:
           self._build_pipeline()
           if self.model is None:
               logger.error("Fallo al construir el pipeline del modelo RF. No se puede entrenar.")
               raise RuntimeError("Pipeline del modelo RF no construido.")

       if X_train.ndim == 1:
           X_train = X_train.reshape(-1, 1)
       
       try:
           logger.info(f"Iniciando entrenamiento Random Forest con {X_train.shape[0]} muestras y {X_train.shape[1]} caracter�sticas.")
           self.model.fit(X_train, y_train)
           logger.info("Entrenamiento Random Forest completado.")
       except Exception as e:
           logger.error(f"Error durante el entrenamiento Random Forest: {e}", exc_info=True)
           raise

   def predict(self, X_test: np.ndarray) -> np.ndarray:
       """
       Realiza predicciones sobre nuevos datos.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           np.ndarray: Etiquetas predichas.
       """
       if self.model is None:
           logger.error("Modelo Random Forest no entrenado o no cargado. No se puede predecir.")
           raise RuntimeError("Modelo Random Forest no disponible para predicci�n.")

       if X_test.ndim == 1:
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)

       try:
           predictions = self.model.predict(X_test)
           return predictions
       except Exception as e:
           logger.error(f"Error durante la predicci�n Random Forest: {e}", exc_info=True)
           raise

   def predict_proba(self, X_test: np.ndarray) -> Optional[np.ndarray]:
       """
       Realiza predicciones de probabilidad sobre nuevos datos.

       Args:
           X_test (np.ndarray): Datos de prueba (caracter�sticas).

       Returns:
           Optional[np.ndarray]: Probabilidades predichas por clase.
       """
       if self.model is None:
           logger.error("Modelo Random Forest no entrenado o no cargado.")
           return None
       
       if X_test.ndim == 1:
           X_test = X_test.reshape(1, -1)
       elif X_test.shape[0] > 0 and X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)

       try:
           probabilities = self.model.predict_proba(X_test)
           return probabilities
       except Exception as e:
           logger.error(f"Error durante la predicci�n de probabilidad RF: {e}", exc_info=True)
           raise

   def save_model(self, path: str) -> None:
       """
       Guarda el modelo Random Forest entrenado en un archivo.

       Args:
           path (str): Ruta donde guardar el modelo (generalmente .pkl).
       """
       if self.model is None:
           logger.error("No hay modelo Random Forest para guardar.")
           raise RuntimeError("Modelo Random Forest no disponible para guardar.")
       try:
           os.makedirs(os.path.dirname(path), exist_ok=True)
           joblib.dump(self.model, path)
           logger.info(f"Modelo Random Forest guardado en: {path}")
       except Exception as e:
           logger.error(f"Error al guardar el modelo Random Forest en {path}: {e}", exc_info=True)
           raise

   def load_model(self, path: str) -> None:
       """
       Carga un modelo Random Forest desde un archivo.

       Args:
           path (str): Ruta del archivo del modelo (generalmente .pkl).
       """
       try:
           self.model = joblib.load(path)
           loaded_rf_params = self.model.named_steps['rf'].get_params()
           self.params.update(loaded_rf_params)
           if 'scaler' not in self.model.named_steps:
               self.apply_scaling = False
           logger.info(f"Modelo Random Forest cargado desde: {path} con par�metros: {self.params}")
       except FileNotFoundError:
           logger.error(f"Archivo de modelo Random Forest no encontrado en: {path}")
           raise
       except Exception as e:
           logger.error(f"Error al cargar el modelo Random Forest desde {path}: {e}", exc_info=True)
           raise

   def get_params(self) -> Dict[str, Any]:
       """Retorna los par�metros actuales del clasificador RandomForestClassifier."""
       if self.model and 'rf' in self.model.named_steps:
           return self.model.named_steps['rf'].get_params()
       return self.params

   @property
   def feature_importances_(self) -> Optional[np.ndarray]:
       """Retorna la importancia de las caracter�sticas si el modelo est� entrenado."""
       if self.model and 'rf' in self.model.named_steps and hasattr(self.model.named_steps['rf'], 'feature_importances_'):
           return self.model.named_steps['rf'].feature_importances_
       logger.warning("Importancia de caracter�sticas no disponible. Modelo no entrenado o no es RF.")
       return None

   @property
   def clf(self) -> Optional[RandomForestClassifier]: # Para compatibilidad con GridSearchCV
       if self.model and 'rf' in self.model.named_steps:
           return self.model.named_steps['rf'] # type: ignore
       return None
