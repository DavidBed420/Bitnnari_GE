"""
DEFAULT_CONFIG.py

Configuraci�n por defecto para los modelos de clasificaci�n y el proceso de entrenamiento.
Aqu� se especifican hiperpar�metros iniciales para cada tipo de modelo y
par�metros generales para el entrenamiento.
"""
import torch

# Configuraci�n General de Entrenamiento
TRAINING_CONFIG = {
   "test_size": 0.2,               # Proporci�n del dataset para el conjunto de prueba
   "validation_split": 0.2,        # Proporci�n del conjunto de entrenamiento para validaci�n (usado en DNN)
   "cv_folds": 5,                  # N�mero de folds para validaci�n cruzada (modelos cl�sicos)
   "shuffle_data": True,           # Si barajar los datos antes de dividir/entrenar
   "stratify_split": True,         # Si usar muestreo estratificado en train_test_split y CV
   "use_smote": True,              # Si aplicar SMOTE para balanceo de clases
   "smote_random_state": 42,
   "apply_feature_scaling": True,  # Si aplicar StandardScaler a las features
   "random_state_global": 42,      # Semilla aleatoria global para reproducibilidad
}

# SVM (Support Vector Machine)
SVM_CONFIG = {
   "kernel": "rbf",                # Tipos comunes: 'linear', 'poly', 'rbf', 'sigmoid'
   "C": 1.0,                       # Par�metro de regularizaci�n
   "gamma": "scale",               # Coeficiente de kernel para 'rbf', 'poly', 'sigmoid'
                                   # 'scale' (1 / (n_features * X.var())) o 'auto' (1 / n_features)
   "degree": 3,                    # Grado para kernel 'poly'
   "probability": True,            # Habilitar estimaci�n de probabilidad (necesario para ROC AUC en algunos casos)
   "class_weight": None,           # 'balanced' o un diccionario {class_label: weight}
   "random_state": TRAINING_CONFIG["random_state_global"]
}

# Random Forest
RF_CONFIG = {
   "n_estimators": 100,            # N�mero de �rboles en el bosque
   "criterion": "gini",            # Funci�n para medir la calidad de una divisi�n ('gini' o 'entropy')
   "max_depth": None,              # Profundidad m�xima de los �rboles (None para expandir hasta hojas puras)
   "min_samples_split": 2,         # N�mero m�nimo de muestras para dividir un nodo interno
   "min_samples_leaf": 1,          # N�mero m�nimo de muestras en un nodo hoja
   "max_features": "sqrt",       # N�mero de caracter�sticas a considerar para la mejor divisi�n ('sqrt', 'log2', None)
   "bootstrap": True,              # Si usar muestras bootstrap al construir �rboles
   "class_weight": None,           # 'balanced', 'balanced_subsample' o dict
   "random_state": TRAINING_CONFIG["random_state_global"]
}

# XGBoost
XGBOOST_CONFIG = {
   "n_estimators": 100,            # N�mero de �rboles (boosting rounds)
   "max_depth": 6,                 # Profundidad m�xima de un �rbol (valores t�picos 3-10)
   "learning_rate": 0.1,           # Tasa de aprendizaje (eta)
   "objective": "multi:softprob",  # Para clasificaci�n multiclase, devuelve probabilidades
                                   # "binary:logistic" para binaria
   "eval_metric": "mlogloss",      # M�trica de evaluaci�n para clasificaci�n multiclase
                                   # "logloss" para binaria, "auc", "error"
   "use_label_encoder": False,     # Desactivar para evitar warnings con versiones recientes de sklearn/xgboost
   "subsample": 0.8,               # Proporci�n de muestras de entrenamiento para cada �rbol
   "colsample_bytree": 0.8,        # Proporci�n de caracter�sticas al construir cada �rbol
   "gamma": 0,                     # M�nima reducci�n de p�rdida para hacer una partici�n (regularizaci�n)
   "reg_alpha": 0,                 # Regularizaci�n L1 (Lasso)
   "reg_lambda": 1,                # Regularizaci�n L2 (Ridge)
   "random_state": TRAINING_CONFIG["random_state_global"]
}

# MLP (Multi-layer Perceptron de scikit-learn)
MLP_CONFIG = {
   "hidden_layer_sizes": (100, 50), # Arquitectura de capas ocultas (e.g., dos capas con 100 y 50 neuronas)
   "activation": "relu",           # Funci�n de activaci�n para capas ocultas ('identity', 'logistic', 'tanh', 'relu')
   "solver": "adam",               # Optimizador ('lbfgs', 'sgd', 'adam')
   "alpha": 0.0001,                # Par�metro de regularizaci�n L2
   "batch_size": "auto",           # Tama�o de minibatches para optimizadores estoc�sticos
   "learning_rate": "constant",    # Tasa de aprendizaje ('constant', 'invscaling', 'adaptive')
   "learning_rate_init": 0.001,    # Tasa de aprendizaje inicial
   "max_iter": 300,                # N�mero m�ximo de iteraciones (�pocas)
   "shuffle": True,                # Si barajar muestras en cada iteraci�n (solo con 'sgd' o 'adam')
   "early_stopping": True,         # Si usar early stopping para terminar el entrenamiento
   "validation_fraction": 0.1,     # Proporci�n de datos de entrenamiento para validaci�n en early stopping
   "n_iter_no_change": 10,         # N�mero de iteraciones sin mejora para activar early stopping
   "random_state": TRAINING_CONFIG["random_state_global"]
}

# DNN (Deep Neural Network con PyTorch) - Configuraci�n para DnnTorchStrategy
DNN_TORCH_CONFIG = {
   # input_dim se determinar� a partir de los datos en la estrategia
   "num_classes": 24,              # Debe coincidir con movements_config.json (0-23 son 24 clases)
   "hidden_dims": [128, 64],       # Lista de dimensiones para capas ocultas
   "dropout_rate": 0.3,            # Tasa de dropout para regularizaci�n
   "learning_rate": 0.001,
   "batch_size": 32,
   "num_epochs": 50,
   "optimizer_name": "Adam",       # 'Adam', 'SGD', 'RMSprop'
   "criterion_name": "CrossEntropyLoss",
   "early_stopping_patience": 10,
   "use_batch_norm": True,
   "activation_function": "ReLU",  # 'ReLU', 'Tanh', 'Sigmoid', 'LeakyReLU'
   "device": "cuda" if torch.cuda.is_available() else "cpu",
   "weight_decay": 1e-5            # Regularizaci�n L2 para el optimizador
}

# Hiperpar�metros para GridSearchCV (ejemplos, pueden ser mucho m�s extensos)
GRID_SEARCH_PARAMS = {
   "svm": {
       "model__C": [0.1, 1, 10, 100],
       "model__gamma": [1, 0.1, 0.01, 0.001, 'scale', 'auto'],
       "model__kernel": ['rbf', 'linear', 'poly']
   },
   "rf": {
       "model__n_estimators": [50, 100, 200, 300],
       "model__max_depth": [None, 10, 20, 30],
       "model__min_samples_split": [2, 5, 10],
       "model__min_samples_leaf": [1, 2, 4]
   },
   "xgboost": {
       "model__n_estimators": [50, 100, 200],
       "model__max_depth": [3, 5, 7],
       "model__learning_rate": [0.01, 0.1, 0.2],
       "model__subsample": [0.7, 0.8, 0.9]
   },
   "mlp": {
       "model__hidden_layer_sizes": [(50,), (100,), (50,50), (100,50)],
       "model__activation": ['relu', 'tanh'],
       "model__alpha": [0.0001, 0.001, 0.01],
       "model__learning_rate_init": [0.001, 0.01]
   },
   "dnn_torch": { # Para DNN, GridSearchCV es menos com�n; se prefiere Optuna/Ray Tune o manual.
                  # Esto es un ejemplo si se quisiera adaptar.
       "hidden_dims": [[64], [128], [64, 32]],
       "learning_rate": [0.001, 0.0005],
       "dropout_rate": [0.2, 0.3, 0.4]
   }
}

# Unificar todas las configuraciones de modelo en un diccionario
ALL_MODEL_CONFIGS = {
   "svm": SVM_CONFIG,
   "rf": RF_CONFIG,
   "xgboost": XGBOOST_CONFIG,
   "mlp": MLP_CONFIG,
   "dnn_torch": DNN_TORCH_CONFIG
}
