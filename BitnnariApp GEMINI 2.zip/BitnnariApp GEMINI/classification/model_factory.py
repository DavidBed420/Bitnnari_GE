"""
model_factory.py

Implementa el patr�n Factory para la creaci�n y carga de estrategias de
clasificaci�n de Machine Learning. Permite instanciar diferentes modelos
(SVM, Random Forest, XGBoost, MLP, DNN con PyTorch) de manera centralizada
y cargar modelos serializados desde archivos.
"""
import os
import logging
from typing import Any, Dict, Optional, Type

# Importar configuraciones por defecto y estrategias
from BitnnariApp.classification.DEFAULT_CONFIG import ALL_MODEL_CONFIGS, DNN_TORCH_CONFIG
from BitnnariApp.classification.strategies.svm_strategy import SvmStrategy
from BitnnariApp.classification.strategies.rf_strategy import RfStrategy
from BitnnariApp.classification.strategies.xgboost_strategy import XgboostStrategy
from BitnnariApp.classification.strategies.mlp_strategy import MlpStrategy
from BitnnariApp.classification.strategies.dnn_torch_strategy import DnnTorchStrategy
from BitnnariApp.data.repository import LocalFileRepository # Para obtener rutas de modelos

logger = logging.getLogger(__name__)

class ModelFactory:
   """
   F�brica para crear y cargar instancias de estrategias de clasificaci�n.
   """
   STRATEGY_MAP: Dict[str, Type[Any]] = {
       "svm": SvmStrategy,
       "rf": RfStrategy,
       "randomforest": RfStrategy, # Alias
       "xgboost": XgboostStrategy,
       "xgb": XgboostStrategy, # Alias
       "mlp": MlpStrategy,
       "nn": MlpStrategy, # Alias para MLP de scikit-learn
       "dnn_torch": DnnTorchStrategy,
       "torch_dnn": DnnTorchStrategy, # Alias
       "cnn": DnnTorchStrategy # Usando DNNStrategy para "cnn" por ahora, podr�a ser una estrategia CNN separada
   }

   @staticmethod
   def create_strategy(model_name: str, **user_params: Any) -> Any:
       """
       Crea una instancia de la estrategia de ML especificada, fusionando
       par�metros de usuario con la configuraci�n por defecto.

       Args:
           model_name (str): Nombre de la estrategia (e.g., 'svm', 'rf', 'dnn_torch').
           **user_params: Par�metros proporcionados por el usuario que sobreescribir�n
                          los valores por defecto.

       Returns:
           Any: Una instancia de la estrategia de clasificaci�n solicitada.

       Raises:
           ValueError: Si el model_name no es reconocido.
       """
       normalized_model_name = model_name.lower().strip()
       
       strategy_class = ModelFactory.STRATEGY_MAP.get(normalized_model_name)
       if not strategy_class:
           logger.error(f"Estrategia de ML desconocida: {model_name}. Modelos disponibles: {list(ModelFactory.STRATEGY_MAP.keys())}")
           raise ValueError(f"Estrategia de ML desconocida: {model_name}")

       # Obtener configuraci�n por defecto para este tipo de modelo
       default_config = ALL_MODEL_CONFIGS.get(normalized_model_name, {})
       # Para alias, buscar la configuraci�n del nombre principal
       if not default_config:
           if normalized_model_name in ["randomforest", "rf"]: default_config = ALL_MODEL_CONFIGS.get("rf", {})
           elif normalized_model_name in ["xgboost", "xgb"]: default_config = ALL_MODEL_CONFIGS.get("xgboost", {})
           elif normalized_model_name in ["mlp", "nn"]: default_config = ALL_MODEL_CONFIGS.get("mlp", {})
           elif normalized_model_name in ["dnn_torch", "torch_dnn", "cnn"]: default_config = ALL_MODEL_CONFIGS.get("dnn_torch", {})
       
       # Fusionar configuraciones: los user_params tienen prioridad
       final_params = {**default_config, **user_params} # Python 3.5+
       # Para versiones anteriores:
       # final_params = default_config.copy()
       # final_params.update(user_params)

       logger.info(f"Creando estrategia '{normalized_model_name}' con par�metros finales: {final_params}")
       try:
           return strategy_class(**final_params)
       except TypeError as e:
           logger.error(f"Error de tipo al instanciar la estrategia '{normalized_model_name}' con par�metros {final_params}: {e}. "
                        "Verifique que los par�metros coincidan con el constructor de la estrategia.")
           raise
       except Exception as e:
           logger.error(f"Error inesperado al crear la estrategia '{normalized_model_name}': {e}", exc_info=True)
           raise

   @staticmethod
   def load_strategy_from_file(model_filepath: str) -> Any:
       """
       Carga una estrategia de modelo serializada desde un archivo.
       Intenta deducir el tipo de estrategia a partir de la extensi�n del archivo
       o de metadatos guardados dentro del archivo (si es posible y est� implementado).

       Args:
           model_filepath (str): Ruta completa al archivo del modelo.

       Returns:
           Any: Una instancia de la estrategia de clasificaci�n cargada.

       Raises:
           ValueError: Si el tipo de archivo no es soportado o no se puede determinar la estrategia.
           FileNotFoundError: Si el archivo no existe.
       """
       if not os.path.exists(model_filepath):
           logger.error(f"Archivo de modelo no encontrado en: {model_filepath}")
           raise FileNotFoundError(f"Archivo de modelo no encontrado: {model_filepath}")

       filename_lower = os.path.basename(model_filepath).lower()
       strategy_instance: Optional[Any] = None

       # L�gica para determinar el tipo de estrategia y cargarla
       # Para modelos .pkl (scikit-learn), no podemos saber el tipo exacto sin cargarlo
       # o sin metadatos adicionales. Una convenci�n en el nombre de archivo es �til.
       # Para .h5 o .pth (PyTorch), podr�amos tener metadatos dentro del checkpoint.

       if model_filepath.endswith((".pkl", ".joblib")):
           # Intentar deducir por nombre si es posible, sino cargar gen�ricamente y esperar que funcione
           # Esta parte es la m�s heur�stica. Idealmente, el archivo .pkl contendr�a
           # el pipeline completo, y el tipo de clasificador se podr�a inspeccionar despu�s de cargar.
           # O, se podr�a guardar un archivo .meta junto con el .pkl.
           
           # Ejemplo de heur�stica basada en el nombre del archivo:
           if "_svm" in filename_lower: strategy_instance = SvmStrategy()
           elif "_rf" in filename_lower or "_randomforest" in filename_lower: strategy_instance = RfStrategy()
           elif "_xgb" in filename_lower or "_xgboost" in filename_lower: strategy_instance = XgboostStrategy()
           elif "_mlp" in filename_lower: strategy_instance = MlpStrategy()
           else:
               # Si no se puede deducir, se podr�a intentar cargar con una estrategia por defecto o fallar.
               # Por ahora, asumimos que el EMGClassifier que llama a esto sabr� qu� esperar o
               # que el usuario selecciona el tipo de modelo al cargar.
               # Aqu�, como fallback, podr�amos intentar cargar como un pipeline gen�rico de sklearn.
               logger.warning(f"No se pudo determinar el tipo de estrategia scikit-learn para '{model_filepath}' solo por el nombre. "
                              "Se intentar� cargar gen�ricamente. Aseg�rese de que el modelo sea compatible.")
               # Esta es una limitaci�n: joblib.load() devuelve el objeto tal cual fue guardado.
               # No podemos instanciar una "Strategy" vac�a y luego llenarla sin saber su tipo.
               # La clase EMGClassifier deber�a manejar esto, pidiendo al usuario el tipo de modelo.
               # O, el `save_model` de cada estrategia podr�a guardar el pipeline y los params.
               # La estrategia cargar�a su `self.model` directamente.
               
               # Soluci�n: Las estrategias scikit-learn cargan directamente el pipeline.
               # El problema es cu�l estrategia instanciar aqu�.
               # Si el nombre no da pistas, es dif�cil.
               # Por ahora, si no hay pista en el nombre, lanzamos error.
               # En una app real, el usuario seleccionar�a el tipo de modelo al cargar.
               raise ValueError(f"No se pudo determinar el tipo de estrategia para el archivo .pkl: {model_filepath}. "
                                "Considere nombrar el archivo con '_svm_', '_rf_', etc.")
           
           strategy_instance.load_model(model_filepath) # Cada estrategia .pkl maneja su carga

       elif model_filepath.endswith((".h5", ".pth", ".pt")): # Formatos comunes de PyTorch
           # Asumimos que es un modelo DnnTorchStrategy
           # La DnnTorchStrategy.load_model reconstruye la arquitectura a partir del checkpoint.
           # Usamos los par�metros por defecto de DNN_TORCH_CONFIG para la inicializaci�n,
           # ya que los par�metros de arquitectura se leer�n del archivo.
           strategy_instance = DnnTorchStrategy(**DNN_TORCH_CONFIG)
           strategy_instance.load_model(model_filepath)
       else:
           logger.error(f"Formato de archivo de modelo no soportado: {model_filepath}. Debe ser .pkl, .joblib, .h5, .pth, o .pt.")
           raise ValueError(f"Formato de archivo de modelo no soportado: {os.path.splitext(model_filepath)[1]}")

       if strategy_instance is None: # Doble chequeo
            raise ValueError(f"No se pudo instanciar una estrategia para el archivo: {model_filepath}")

       logger.info(f"Estrategia cargada desde {model_filepath} como tipo {type(strategy_instance).__name__}.")
       return strategy_instance

   @staticmethod
   def get_model_save_path(repository: LocalFileRepository,
                             patient_dni: str,
                             model_name: str,
                             version: Optional[str] = None,
                             timestamp: bool = True) -> str:
       """
       Genera una ruta de guardado estandarizada para un modelo.

       Args:
           repository (LocalFileRepository): Instancia del repositorio para obtener la base de modelos.
           patient_dni (str): DNI del paciente.
           model_name (str): Nombre base del modelo (e.g., "svm_activity").
           version (Optional[str]): Versi�n del modelo (e.g., "1.0").
           timestamp (bool): Si a�adir un timestamp al nombre del archivo.

       Returns:
           str: Ruta completa para guardar el modelo.
       """
       model_base_name = f"{patient_dni}_{model_name.lower()}"
       if version:
           model_base_name += f"_v{version}"
       if timestamp:
           ts = datetime.now().strftime("%Y%m%d_%H%M%S")
           model_base_name += f"_{ts}"

       # Determinar extensi�n basada en el tipo de modelo
       # (esto es una simplificaci�n, la estrategia real determinar� su extensi�n)
       if "dnn_torch" in model_name.lower() or "cnn" in model_name.lower():
           ext = ".pth" # O .h5 si se prefiere
       else:
           ext = ".pkl"
           
       filename_with_ext = model_base_name + ext
       
       # Usar el m�todo del repositorio para obtener la ruta dentro de la estructura correcta
       # Asumimos que get_ml_model_path construye el nombre de archivo basado en sus argumentos.
       # Aqu�, estamos construyendo el nombre de archivo completo y luego pidiendo al repo
       # que nos d� la carpeta base.
       
       # Correcci�n: el repositorio ya tiene un m�todo para esto.
       # Le pasamos el nombre sin extensi�n y �l a�ade la extensi�n si es necesario
       # o simplemente construye la ruta.
       # Por ahora, vamos a construir el nombre completo aqu� y pedir al repo la carpeta.
       
       model_dir: Path
       if patient_dni: # Modelo espec�fico del paciente
           model_dir = repository._get_patient_dir(patient_dni) / LocalFileRepository.MODELS_DIR_NAME
       else: # Modelo global
           model_dir = repository._ml_models_path
       
       model_dir.mkdir(parents=True, exist_ok=True)
       
       return str(model_dir / filename_with_ext)


# Ejemplo de uso (principalmente para pruebas internas)
if __name__ == "__main__":
   # Crear estrategias
   try:
       svm_strat = ModelFactory.create_strategy("svm", C=0.5, kernel="linear")
       logger.info(f"SVM Strategy creado: {type(svm_strat).__name__}, Params: {svm_strat.get_params()}")

       rf_strat = ModelFactory.create_strategy("rf", n_estimators=50, max_depth=10)
       logger.info(f"RF Strategy creado: {type(rf_strat).__name__}, Params: {rf_strat.get_params()}")

       dnn_strat = ModelFactory.create_strategy("dnn_torch", num_epochs=5, hidden_dims=[32])
       logger.info(f"DNN Torch Strategy creado: {type(dnn_strat).__name__}, Params: {dnn_strat.get_params()}")

       # Simular guardado y carga (requerir�a datos y entrenamiento para ser completo)
       # Esto es solo para probar la l�gica de la factory, no el entrenamiento real.
       
       # Crear un directorio temporal para modelos
       temp_models_dir = Path("./temp_test_models")
       temp_models_dir.mkdir(exist_ok=True)
       
       # --- Simular guardado y carga de SVM ---
       # Necesitar�amos un modelo SVM entrenado para guardarlo.
       # Aqu� solo probamos la ruta.
       class DummyRepo: # Dummy para la prueba de rutas
           _patients_path = temp_models_dir / "patients"
           _ml_models_path = temp_models_dir / "global_models"
           MODELS_DIR_NAME = "ml_models"
           def _get_patient_dir(self, patient_dni, ensure_exists=True):
               path = self._patients_path / patient_dni
               if ensure_exists: path.mkdir(parents=True, exist_ok=True)
               return path
       
       dummy_repo = DummyRepo()
       svm_save_path = ModelFactory.get_model_save_path(dummy_repo, "test_patient", "svm_gestures") # type: ignore
       logger.info(f"Ruta de guardado para SVM: {svm_save_path}")
       
       # Para probar load_strategy_from_file, necesitar�amos un archivo .pkl o .pth real.
       # Ejemplo (requiere que el archivo exista y sea un modelo v�lido):
       # try:
       #     # Crear un archivo .pkl dummy (no un modelo real)
       #     dummy_svm_path = temp_models_dir / "test_patient_svm_dummy.pkl"
       #     with open(dummy_svm_path, "wb") as f:
       #         import pickle
       #         pickle.dump({"dummy": "data"}, f) # Esto no es un modelo sklearn
       #     # loaded_svm = ModelFactory.load_strategy_from_file(str(dummy_svm_path)) # Esto fallar�a
       # except Exception as e:
       #     logger.error(f"Error en simulaci�n de carga: {e}")

   except ValueError as ve:
       logger.error(f"Error en Factory: {ve}")
   except Exception as ex:
       logger.error(f"Error inesperado en ejemplo de Factory: {ex}", exc_info=True)
   finally:
       if temp_models_dir.exists():
           import shutil
           shutil.rmtree(temp_models_dir)
           logger.info(f"Directorio temporal de modelos {temp_models_dir} eliminado.")
   

