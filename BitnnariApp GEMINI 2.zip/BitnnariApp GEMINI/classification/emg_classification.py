"""
emg_classification.py

Clase principal para la clasificaci�n de se�ales EMG.
Integra adquisici�n (simulada o real), preprocesamiento (calibraci�n, extracci�n de caracter�sticas),
entrenamiento de modelos de Machine Learning (cl�sicos y DNN con PyTorch),
y predicci�n. Incluye manejo de datos de dedos (finger_data) y configuraci�n de movimientos.
"""
import os
import json
import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Callable, Union

import numpy as np
from sklearn.model_selection import StratifiedKFold, GridSearchCV, train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
from imblearn.over_sampling import SMOTE # Para balanceo de clases

# Importaciones del proyecto
from BitnnariApp.classification.model_factory import ModelFactory
from BitnnariApp.classification.DEFAULT_CONFIG import TRAINING_CONFIG, ALL_MODEL_CONFIGS
from BitnnariApp.processing.emg_processing import EMGProcessingEngine # Asumimos que extrae features
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition # Para adquisici�n en tiempo real
from BitnnariApp.data.gestor_datos import GestorDatos # Para cargar datos de paciente/sesiones
from BitnnariApp.data.models.emg_record import EmgRecordModel # Para tipar datos de sesi�n

logger = logging.getLogger(__name__)
if not logger.handlers:
   handler = logging.StreamHandler()
   handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
   logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Definici�n de dedos est�ndar para finger_data
FINGER_ORDER = ["pulgar", "indice", "medio", "anular", "menique"]

class EMGClassifier:
   """
   Orquesta el proceso de clasificaci�n de se�ales EMG, desde la carga de datos
   hasta el entrenamiento y la predicci�n, con soporte para datos de dedos.
   """
   MOVEMENTS_CONFIG_FILENAME = "movements_config.json"
   MODELS_SUBDIR = "ml_models_classified" # Subdirectorio para modelos de esta clase

   def __init__(self,
                patient_dni: Optional[str] = None,
                data_manager: Optional[GestorDatos] = None,
                processing_engine: Optional[EMGProcessingEngine] = None,
                calibration_manager: Optional[EMGCalibrationManager] = None,
                emg_acquirer: Optional[EMGAcquisition] = None):
       """
       Inicializa el clasificador EMG.

       Args:
           patient_dni (Optional[str]): DNI del paciente actual.
           data_manager (Optional[GestorDatos]): Gestor para acceder a datos guardados.
           processing_engine (Optional[EMGProcessingEngine]): Motor para extraer caracter�sticas EMG.
           calibration_manager (Optional[EMGCalibrationManager]): Gestor para aplicar calibraci�n.
           emg_acquirer (Optional[EMGAcquisition]): Sistema de adquisici�n para datos en tiempo real.
       """
       self.patient_dni = patient_dni
       self.data_manager = data_manager
       self.processing_engine = processing_engine if processing_engine else EMGProcessingEngine(sampling_rate=1000) # Default
       self.calibration_manager = calibration_manager
       self.emg_acquirer = emg_acquirer

       self.movements_map: Dict[int, str] = self._load_movements_config()
       self.num_defined_classes = len(self.movements_map)
       
       self.label_encoder = LabelEncoder() # Se ajustar� con las etiquetas reales del dataset
       self.current_trained_strategy: Optional[Any] = None # Instancia de la estrategia entrenada
       self.current_model_name: Optional[str] = None
       self.feature_scaler: Optional[StandardScaler] = None # Escalador ajustado en datos de entrenamiento

       logger.info(f"EMGClassifier inicializado. Movimientos definidos: {self.num_defined_classes}")

   def _load_movements_config(self) -> Dict[int, str]:
       """Carga el mapeo de etiquetas num�ricas a nombres de movimiento."""
       # Priorizar classification/movements_config.json, luego data/movements_config.json
       config_path_options = [
           Path(__file__).parent / self.MOVEMENTS_CONFIG_FILENAME,
           Path(__file__).parent.parent / "data" / self.MOVEMENTS_CONFIG_FILENAME 
       ]
       
       for config_path in config_path_options:
           if config_path.exists():
               try:
                   with open(config_path, "r", encoding="utf-8") as f:
                       data = json.load(f)
                   # Convertir claves a int y asegurar que los valores sean strings
                   return {int(k): str(v) for k, v in data.items()}
               except (json.JSONDecodeError, ValueError) as e:
                   logger.error(f"Error al cargar o parsear {config_path}: {e}")
           else:
               logger.debug(f"Archivo de configuraci�n de movimientos no encontrado en: {config_path}")

       logger.warning("No se pudo cargar 'movements_config.json'. Usando un mapeo vac�o.")
       return {}

   def get_movement_name(self, label_id: int) -> str:
       """Devuelve el nombre descriptivo de un movimiento a partir de su etiqueta num�rica."""
       return self.movements_map.get(label_id, f"movimiento_desconocido_{label_id}")

   def get_all_movement_labels(self) -> List[int]:
       """Devuelve una lista de todas las etiquetas num�ricas de movimiento definidas."""
       return sorted(list(self.movements_map.keys()))

   def validate_and_normalize_finger_data(self, finger_data_raw: Dict[str, Dict[str, Optional[float]]]) -> Optional[List[float]]:
       """
       Valida y normaliza los datos de los dedos.
       El �ngulo se normaliza a [0, 1] (0-180 grados).
       La fuerza se normaliza a [0, 1] (0-100%).

       Args:
           finger_data_raw (Dict): Diccionario crudo con datos de dedos.
                                   Ej: {"pulgar": {"angulo": 30.0, "fuerza": 80.0}, ...}

       Returns:
           Optional[List[float]]: Lista aplanada de datos de dedos normalizados
                                  [ang_pulgar_norm, fuer_pulgar_norm, ..., ang_menique_norm, fuer_menique_norm],
                                  o None si los datos son inv�lidos.
       """
       if not isinstance(finger_data_raw, dict):
           logger.warning("finger_data_raw no es un diccionario.")
           return None

       normalized_finger_features: List[float] = []
       valid = True
       for finger_name in FINGER_ORDER:
           data = finger_data_raw.get(finger_name)
           if not isinstance(data, dict):
               logger.warning(f"Datos para el dedo '{finger_name}' faltantes o en formato incorrecto en finger_data.")
               valid = False; break
           
           angle_raw = data.get("angulo")
           force_raw = data.get("fuerza")

           if not isinstance(angle_raw, (int, float)) or not (0 <= angle_raw <= 180):
               logger.warning(f"�ngulo para '{finger_name}' inv�lido ({angle_raw}). Debe estar entre 0 y 180.")
               valid = False; break
           if not isinstance(force_raw, (int, float)) or not (0 <= force_raw <= 100):
               logger.warning(f"Fuerza para '{finger_name}' inv�lida ({force_raw}). Debe estar entre 0 y 100.")
               valid = False; break
           
           normalized_finger_features.append(angle_raw / 180.0) # Normalizar �ngulo
           normalized_finger_features.append(force_raw / 100.0) # Normalizar fuerza
       
       return normalized_finger_features if valid else None

   def _extract_and_combine_features(self,
                                     raw_emg_signal: np.ndarray,
                                     finger_data_dict: Optional[Dict[str, Dict[str, Optional[float]]]] = None
                                    ) -> Optional[np.ndarray]:
       """
       Extrae caracter�sticas EMG y las combina con datos de dedos normalizados.
       Aplica calibraci�n si est� configurada.

       Args:
           raw_emg_signal (np.ndarray): Se�al EMG cruda [n_samples, n_channels].
           finger_data_dict (Optional[Dict]): Datos crudos de los dedos.

       Returns:
           Optional[np.ndarray]: Vector de caracter�sticas combinado, o None si falla.
       """
       # 1. Calibrar se�al EMG si es necesario
       calibrated_emg = raw_emg_signal
       if self.calibration_manager:
           try:
               calibrated_emg = self.calibration_manager.apply_calibration(raw_emg_signal)
           except Exception as e:
               logger.error(f"Error aplicando calibraci�n durante extracci�n de features: {e}")
               # Continuar con datos no calibrados o manejar el error m�s estrictamente

       # 2. Extraer caracter�sticas EMG
       # El processing_engine deber�a manejar m�ltiples canales y devolver un vector aplanado o un dict.
       # Asumimos que devuelve un dict de features por canal, o un vector aplanado.
       # Aqu�, para simplificar, asumimos que devuelve un array 1D de features globales de la se�al multicanal.
       # En una implementaci�n real, EMGProcessingEngine.extract_all_features ser�a m�s sofisticado.
       try:
           # Ejemplo simple: tomar RMS de cada canal y concatenar
           if calibrated_emg.ndim == 1: calibrated_emg = calibrated_emg[:, np.newaxis]
           emg_features_list: List[float] = []
           for i in range(calibrated_emg.shape[1]):
               # Usar un subconjunto de features del processing_engine
               temp_features = self.processing_engine.extract_temporal_features(calibrated_emg[:, i])
               emg_features_list.extend([temp_features.get("RMS",0.0), temp_features.get("MAV",0.0)])
           
           emg_features_vector = np.array(emg_features_list, dtype=float)

       except Exception as e:
           logger.error(f"Error extrayendo caracter�sticas EMG: {e}")
           return None
       
       if emg_features_vector.size == 0:
           logger.warning("No se extrajeron caracter�sticas EMG.")
           return None

       # 3. Validar y normalizar datos de dedos
       if finger_data_dict:
           normalized_finger_features = self.validate_and_normalize_finger_data(finger_data_dict)
           if normalized_finger_features is None:
               logger.warning("Datos de dedos inv�lidos, no se combinar�n.")
               return emg_features_vector # Devolver solo features EMG
           
           # 4. Combinar caracter�sticas
           combined_features = np.concatenate([emg_features_vector, np.array(normalized_finger_features, dtype=float)])
           return combined_features
       else:
           return emg_features_vector


   def _load_dataset_from_records(self, records: List[EmgRecordModel]) -> Tuple[np.ndarray, np.ndarray, List[Optional[Dict]]]:
       """Procesa una lista de EmgRecordModel para obtener X, y, y finger_data."""
       X_list, y_list, finger_data_list_raw = [], [], []

       for record in records:
           raw_data_array = record.get_raw_data_as_array(orientation='samples_x_channels') # [n_samples, n_channels]
           if raw_data_array is None or raw_data_array.size == 0:
               logger.warning(f"Registro {record.record_id} sin datos crudos, omitiendo.")
               continue
           if record.label is None:
               logger.warning(f"Registro {record.record_id} sin etiqueta, omitiendo.")
               continue
           
           # Aqu�, en lugar de procesar toda la se�al del registro como una feature,
           # podr�amos segmentarla y extraer features por segmento si la tarea lo requiere.
           # Por ahora, asumimos que cada EmgRecord es una "muestra" y extraemos features globales.
           
           # finger_data_dict se espera que est� en el record si es relevante para esa muestra
           finger_data_for_record = record.features_extracted.get("finger_data_snapshot") if record.features_extracted else None
           
           combined_features = self._extract_and_combine_features(raw_data_array, finger_data_for_record)
           
           if combined_features is not None:
               X_list.append(combined_features)
               y_list.append(record.label) # La etiqueta debe ser num�rica o convertible
               finger_data_list_raw.append(finger_data_for_record)
       
       if not X_list:
           return np.array([]), np.array([]), []
           
       return np.array(X_list, dtype=float), np.array(y_list), finger_data_list_raw


   def _acquire_realtime_data_for_training(self, duration_s: float, label_for_data: Union[int, str]) -> List[EmgRecordModel]:
       """Adquiere datos en tiempo real para entrenamiento."""
       if not self.emg_acquirer or not self.patient_dni:
           logger.error("EMGAcquirer o Patient DNI no configurados para adquisici�n en tiempo real.")
           return []

       if not self.emg_acquirer.is_connected():
           if not self.emg_acquirer.connect():
               logger.error("No se pudo conectar al dispositivo EMG para adquisici�n.")
               return []
       
       logger.info(f"Iniciando adquisici�n en tiempo real para entrenamiento ({duration_s}s, etiqueta: {label_for_data})...")
       
       # Configurar el modo del Arduino
       original_mode = self.emg_acquirer.acq_config.mode
       self.emg_acquirer.set_mode('continuous')

       start_time = time.time()
       collected_samples_for_record: List[List[float]] = [[] for _ in range(self.emg_acquirer.acq_config.num_channels_active)]
       
       num_total_samples_to_collect = int(duration_s * self.emg_acquirer.serial_config.baud_rate) # Estimaci�n muy burda
       # Mejor: basarse en el delay del Arduino o la tasa de paquetes esperada
       # Si delay_ms es 10ms, esperamos 100 paquetes/s.
       expected_packets = int(duration_s * (1000.0 / self.emg_acquirer.acq_config.delay_ms))
       packets_collected = 0

       while time.time() - start_time < duration_s and packets_collected < expected_packets:
           packet = self.emg_acquirer.read_data()
           if packet and 'raw_data' in packet:
               for i, val in enumerate(packet['raw_data']):
                   if i < len(collected_samples_for_record):
                       collected_samples_for_record[i].append(val)
               packets_collected += 1
           time.sleep(0.001) # Peque�a pausa

       self.emg_acquirer.set_mode(original_mode) # Restaurar
       logger.info(f"Adquisici�n en tiempo real finalizada. {packets_collected} paquetes recibidos.")

       if not any(collected_samples_for_record):
           return []
           
       # Crear un EmgRecordModel con los datos adquiridos
       record_id = f"rt_{self.patient_dni}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
       
       # Finger data (si se est� capturando simult�neamente, aqu� se a�adir�a)
       # Por ahora, asumimos que no se captura finger_data durante esta adquisici�n espec�fica.
       # finger_data_snapshot = self.capture_current_finger_data_somehow()

       record = EmgRecordModel(
           record_id=record_id,
           patient_dni=self.patient_dni,
           duration_s=duration_s,
           sampling_rate_hz= (1000.0 / self.emg_acquirer.acq_config.delay_ms),
           num_channels=self.emg_acquirer.acq_config.num_channels_active,
           raw_data=collected_samples_for_record, # Formato [canales, muestras]
           label=str(label_for_data) # Asegurar que la etiqueta sea string
           # features_extracted={"finger_data_snapshot": finger_data_snapshot} si aplica
       )
       return [record]


   def train_model(self,
                   model_name: str,
                   acquisition_mode: str = "saved", # "saved", "real_time_fixed"
                   real_time_duration_s: float = 5.0,
                   real_time_label: Union[int, str] = "real_time_capture",
                   user_hyperparams: Optional[Dict[str, Any]] = None,
                   use_smote: bool = TRAINING_CONFIG["use_smote"],
                   cv_folds: int = TRAINING_CONFIG["cv_folds"],
                   perform_grid_search: bool = False,
                   grid_search_params_override: Optional[Dict[str, Any]] = None,
                   apply_feature_scaling: bool = TRAINING_CONFIG["apply_feature_scaling"],
                   progress_callback: Optional[Callable[[int, Dict[str, float]], None]] = None
                  ) -> Tuple[Optional[Any], Optional[Dict[str, Any]]]:
       """
       Entrena un modelo de clasificaci�n.

       Args:
           model_name: Nombre de la estrategia (e.g., "svm", "dnn_torch").
           acquisition_mode: "saved" para usar datos existentes, "real_time_fixed" para adquirir nuevos.
           real_time_duration_s: Duraci�n si acquisition_mode es "real_time_fixed".
           real_time_label: Etiqueta para los datos adquiridos en tiempo real.
           user_hyperparams: Hiperpar�metros espec�ficos para el modelo.
           use_smote: Si aplicar SMOTE para balanceo.
           cv_folds: N�mero de folds para validaci�n cruzada.
           perform_grid_search: Si realizar GridSearchCV.
           grid_search_params_override: Par�metros para GridSearchCV.
           apply_feature_scaling: Si aplicar StandardScaler.
           progress_callback: Callback para el progreso del entrenamiento.

       Returns:
           Tuple[Optional[Any], Optional[Dict[str, Any]]]: (estrategia_entrenada, reporte_metricas)
       """
       logger.info(f"Iniciando proceso de entrenamiento para modelo: {model_name}")
       if progress_callback: progress_callback(5, {"status": "Cargando datos..."})

       all_records: List[EmgRecordModel] = []
       if acquisition_mode == "saved":
           if self.data_manager and self.patient_dni:
               all_records = self.data_manager.listar_sesiones_emg(self.patient_dni)
           else:
               logger.error("DataManager o Patient DNI no disponibles para cargar datos guardados.")
               if progress_callback: progress_callback(100, {"status": "Error: Faltan DataManager o DNI."})
               return None, None
       elif acquisition_mode == "real_time_fixed":
           new_records = self._acquire_realtime_data_for_training(real_time_duration_s, real_time_label)
           all_records.extend(new_records)
           # Opcional: guardar estos nuevos registros inmediatamente
           if self.data_manager and self.patient_dni:
               for rec in new_records:
                   self.data_manager.guardar_sesion_emg(rec)
       else:
           logger.error(f"Modo de adquisici�n '{acquisition_mode}' no soportado para entrenamiento.")
           if progress_callback: progress_callback(100, {"status": f"Error: Modo '{acquisition_mode}' no soportado."})
           return None, None

       if not all_records:
           logger.warning("No hay registros EMG disponibles para entrenar.")
           if progress_callback: progress_callback(100, {"status": "Error: No hay datos."})
           return None, None

       X, y_str, _ = self._load_dataset_from_records(all_records)

       if X.shape[0] < cv_folds * 2 : # Necesitamos suficientes muestras
           logger.error(f"Dataset demasiado peque�o ({X.shape[0]} muestras) para {cv_folds} folds. Se requieren al menos {cv_folds*2}.")
           if progress_callback: progress_callback(100, {"status": "Error: Dataset peque�o."})
           return None, None
       
       # Codificar etiquetas a num�ricas si son strings
       self.label_encoder.fit(y_str)
       y_encoded = self.label_encoder.transform(y_str)
       
       # Guardar las clases aprendidas por el LabelEncoder para referencia futura
       self.learned_classes_ = self.label_encoder.classes_
       logger.info(f"Clases aprendidas por LabelEncoder: {self.learned_classes_}")


       if progress_callback: progress_callback(20, {"status": "Preprocesando datos..."})

       # Dividir en entrenamiento y prueba (para evaluaci�n final del mejor modelo)
       # La validaci�n cruzada se har� sobre X_train_full, y_train_full_encoded
       try:
           X_train_full, X_test, y_train_full_encoded, y_test_encoded = train_test_split(
               X, y_encoded,
               test_size=TRAINING_CONFIG["test_size"],
               shuffle=TRAINING_CONFIG["shuffle_data"],
               stratify=y_encoded if TRAINING_CONFIG["stratify_split"] and len(np.unique(y_encoded)) > 1 else None,
               random_state=TRAINING_CONFIG["random_state_global"]
           )
       except ValueError as e:
           if "The least populated class" in str(e):
                logger.warning(f"No se puede estratificar debido a clases con pocas muestras: {e}. Intentando sin estratificaci�n.")
                X_train_full, X_test, y_train_full_encoded, y_test_encoded = train_test_split(
                   X, y_encoded,
                   test_size=TRAINING_CONFIG["test_size"],
                   shuffle=TRAINING_CONFIG["shuffle_data"],
                   random_state=TRAINING_CONFIG["random_state_global"]
               )
           else:
               raise e


       # Balanceo con SMOTE (solo en el conjunto de entrenamiento completo)
       if use_smote and len(np.unique(y_train_full_encoded)) > 1:
           try:
               smote = SMOTE(random_state=TRAINING_CONFIG["smote_random_state"], k_neighbors=min(5, np.min(np.unique(y_train_full_encoded, return_counts=True)[1])-1) )
               X_train_full, y_train_full_encoded = smote.fit_resample(X_train_full, y_train_full_encoded)
               logger.info(f"SMOTE aplicado. Nuevo tama�o del conjunto de entrenamiento: {X_train_full.shape}")
           except ValueError as e:
               logger.warning(f"No se pudo aplicar SMOTE (probablemente por clases con muy pocas muestras): {e}. Continuando sin SMOTE.")


       # Escalado de caracter�sticas (ajustar solo en entrenamiento, aplicar a test)
       if apply_feature_scaling:
           self.feature_scaler = StandardScaler()
           X_train_full = self.feature_scaler.fit_transform(X_train_full)
           X_test = self.feature_scaler.transform(X_test) # Usar el mismo scaler
           logger.info("StandardScaler aplicado a las caracter�sticas.")

       if progress_callback: progress_callback(40, {"status": "Entrenando modelo..."})

       # Crear y entrenar la estrategia
       self.current_model_name = model_name
       strategy_params = user_hyperparams if user_hyperparams is not None else {}
       
       # Para DNN, pasar num_classes si no est� en params
       if "dnn_torch" in model_name.lower() or "cnn" in model_name.lower():
           if 'num_classes' not in strategy_params:
               strategy_params['num_classes'] = len(self.label_encoder.classes_)
       
       self.current_trained_strategy = ModelFactory.create_strategy(model_name, **strategy_params)

       final_report = {}

       if perform_grid_search and model_name not in ["dnn_torch", "cnn"]: # GridSearchCV no es ideal para DNNs profundas
           grid_params = grid_search_params_override or TRAINING_CONFIG.get("GRID_SEARCH_PARAMS", {}).get(model_name, {})
           if not grid_params:
               logger.warning(f"No se definieron par�metros para GridSearchCV para el modelo {model_name}. Omitiendo GridSearch.")
               perform_grid_search = False # Volver a CV normal

       if perform_grid_search and model_name not in ["dnn_torch", "cnn"]:
           logger.info(f"Iniciando GridSearchCV para {model_name} con par�metros: {grid_params}")
           # El pipeline de la estrategia ya incluye el escalador si apply_feature_scaling=False en la estrategia
           # y EMGClassifier aplica su propio escalador. Para GridSearchCV, pasamos X_train_full ya escalado.
           # Las estrategias deben ser instanciadas con apply_scaling=False si el escalado se hace aqu�.
           
           # Recrear la estrategia sin escalador interno para GridSearchCV
           # ya que X_train_full ya est� escalado.
           temp_strategy_params = strategy_params.copy()
           temp_strategy_params['apply_scaling'] = False 
           temp_strategy_no_scale = ModelFactory.create_strategy(model_name, **temp_strategy_params)

           cv_splitter = StratifiedKFold(n_splits=cv_folds, shuffle=TRAINING_CONFIG["shuffle_data"], random_state=TRAINING_CONFIG["random_state_global"])
           
           # Asegurarse que los nombres de par�metros en grid_params coincidan con los del estimador
           # Si el estimador es un pipeline, los params son 'nombrepaso__parametro'
           # Si es el clasificador directo, es solo 'parametro'
           # Nuestras estrategias scikit-learn tienen un pipeline, el clasificador es el �ltimo paso (e.g., 'svc', 'rf')
           estimator_name_in_pipeline = list(temp_strategy_no_scale.model.named_steps.keys())[-1]
           
           # Ajustar grid_params para que apunten al estimador dentro del pipeline
           pipeline_grid_params = {}
           for k, v in grid_params.items():
               if not k.startswith(f"{estimator_name_in_pipeline}__"):
                   pipeline_grid_params[f"{estimator_name_in_pipeline}__{k}"] = v
               else:
                   pipeline_grid_params[k] = v

           grid_search_cv = GridSearchCV(temp_strategy_no_scale.model, pipeline_grid_params, cv=cv_splitter, scoring='accuracy', n_jobs=-1, verbose=1)
           grid_search_cv.fit(X_train_full, y_train_full_encoded)
           
           self.current_trained_strategy.model = grid_search_cv.best_estimator_ # Asignar el mejor pipeline
           logger.info(f"GridSearchCV completado. Mejores par�metros: {grid_search_cv.best_params_}")
           logger.info(f"Mejor puntuaci�n CV (accuracy): {grid_search_cv.best_score_:.4f}")
           
           final_report["best_cv_params"] = grid_search_cv.best_params_
           final_report["best_cv_score"] = grid_search_cv.best_score_
           final_report["cv_results"] = grid_search_cv.cv_results_ # Contiene muchos detalles

       elif model_name in ["dnn_torch", "cnn"]: # Entrenamiento espec�fico para PyTorch DNN
           # Dividir X_train_full para tener un conjunto de validaci�n para early stopping
           X_train_dnn, X_val_dnn, y_train_dnn, y_val_dnn = train_test_split(
               X_train_full, y_train_full_encoded,
               test_size=TRAINING_CONFIG["validation_split"],
               shuffle=TRAINING_CONFIG["shuffle_data"],
               stratify=y_train_full_encoded if TRAINING_CONFIG["stratify_split"] and len(np.unique(y_train_full_encoded)) > 1 else None,
               random_state=TRAINING_CONFIG["random_state_global"]
           )
           logger.info(f"Entrenando DNN: Train {X_train_dnn.shape}, Val {X_val_dnn.shape}")
           history = self.current_trained_strategy.fit(X_train_dnn, y_train_dnn, X_val_dnn, y_val_dnn, progress_callback)
           final_report["training_history"] = history
           # La "mejor" puntuaci�n ser�a la de la �ltima �poca o la mejor de validaci�n
           if history.get("val_acc"):
               final_report["best_val_accuracy"] = max(history["val_acc"]) if history["val_acc"] else 0.0
           final_report["final_train_accuracy"] = history["train_acc"][-1] if history.get("train_acc") else 0.0
       else: # Validaci�n cruzada manual para otros modelos cl�sicos
           cv_splitter = StratifiedKFold(n_splits=cv_folds, shuffle=TRAINING_CONFIG["shuffle_data"], random_state=TRAINING_CONFIG["random_state_global"])
           fold_accuracies = []
           
           # Aqu� tambi�n, si la estrategia tiene su propio escalador, y X_train_full ya est� escalado,
           # la estrategia deber�a ser instanciada con apply_scaling=False.
           temp_strategy_params = strategy_params.copy()
           temp_strategy_params['apply_scaling'] = False # Asumimos que X_train_full ya est� escalado
           
           for i, (train_idx, val_idx) in enumerate(cv_splitter.split(X_train_full, y_train_full_encoded)):
               if progress_callback: progress_callback(40 + int(i/cv_folds * 30) , {"status": f"Fold {i+1}/{cv_folds}"})
               
               X_fold_train, X_fold_val = X_train_full[train_idx], X_train_full[val_idx]
               y_fold_train, y_fold_val = y_train_full_encoded[train_idx], y_train_full_encoded[val_idx]
               
               fold_strategy = ModelFactory.create_strategy(model_name, **temp_strategy_params)
               fold_strategy.fit(X_fold_train, y_fold_train)
               y_fold_pred = fold_strategy.predict(X_fold_val)
               fold_accuracies.append(accuracy_score(y_fold_val, y_fold_pred))
           
           final_report["cv_fold_accuracies"] = fold_accuracies
           final_report["mean_cv_accuracy"] = np.mean(fold_accuracies)
           logger.info(f"Validaci�n cruzada manual completada. Mean CV Accuracy: {final_report['mean_cv_accuracy']:.4f}")
           
           # Re-entrenar el modelo principal con todos los datos de entrenamiento (X_train_full)
           logger.info("Re-entrenando modelo final con todos los datos de entrenamiento...")
           self.current_trained_strategy = ModelFactory.create_strategy(model_name, **temp_strategy_params)
           self.current_trained_strategy.fit(X_train_full, y_train_full_encoded)

       if progress_callback: progress_callback(80, {"status": "Evaluando modelo..."})
       
       # Evaluar en el conjunto de prueba (X_test)
       y_pred_test = self.current_trained_strategy.predict(X_test)
       test_accuracy = accuracy_score(y_test_encoded, y_pred_test)
       
       # Convertir y_test_encoded y y_pred_test a etiquetas string para classification_report
       y_test_str_labels = self.label_encoder.inverse_transform(y_test_encoded)
       y_pred_test_str_labels = self.label_encoder.inverse_transform(y_pred_test)
       
       # Asegurarse que las etiquetas para classification_report sean las originales (strings)
       # y que target_names tambi�n use las etiquetas string originales.
       unique_str_labels = np.unique(np.concatenate((y_test_str_labels, y_pred_test_str_labels))).tolist()

       class_report = classification_report(y_test_str_labels, y_pred_test_str_labels, labels=unique_str_labels, target_names=unique_str_labels, output_dict=True, zero_division=0)
       conf_matrix = confusion_matrix(y_test_str_labels, y_pred_test_str_labels, labels=unique_str_labels).tolist()

       final_report["test_set_accuracy"] = test_accuracy
       final_report["test_set_classification_report"] = class_report
       final_report["test_set_confusion_matrix"] = conf_matrix
       
       # ROC AUC (si es aplicable y el modelo lo soporta)
       if len(self.label_encoder.classes_) == 2: # Binaria
           if hasattr(self.current_trained_strategy, 'predict_proba'):
               y_pred_proba_test = self.current_trained_strategy.predict_proba(X_test)
               if y_pred_proba_test is not None and y_pred_proba_test.shape[1] == 2:
                   final_report["test_set_roc_auc"] = roc_auc_score(y_test_encoded, y_pred_proba_test[:, 1])
       elif len(self.label_encoder.classes_) > 2: # Multiclase
            if hasattr(self.current_trained_strategy, 'predict_proba'):
               y_pred_proba_test = self.current_trained_strategy.predict_proba(X_test)
               if y_pred_proba_test is not None:
                   try:
                       final_report["test_set_roc_auc_ovr"] = roc_auc_score(y_test_encoded, y_pred_proba_test, multi_class='ovr', average='weighted', labels=np.arange(len(self.label_encoder.classes_)))
                       final_report["test_set_roc_auc_ovo"] = roc_auc_score(y_test_encoded, y_pred_proba_test, multi_class='ovo', average='weighted', labels=np.arange(len(self.label_encoder.classes_)))
                   except ValueError as e_auc: # Puede fallar si alguna clase no est� en y_pred_proba_test
                       logger.warning(f"No se pudo calcular ROC AUC multiclase: {e_auc}")


       logger.info(f"Evaluaci�n en conjunto de prueba: Accuracy = {test_accuracy:.4f}")
       if progress_callback: progress_callback(90, {"status": "Guardando modelo..."})

       # Guardar el modelo entrenado
       if self.data_manager and self.patient_dni:
           model_save_path = ModelFactory.get_model_save_path(
               self.data_manager.repo, # Pasar la instancia del repositorio
               self.patient_dni,
               self.current_model_name
           )
           self.current_trained_strategy.save_model(model_save_path)
           final_report["model_save_path"] = model_save_path
           logger.info(f"Modelo entrenado guardado en: {model_save_path}")
           
           # Guardar m�tricas en GestorDatos
           metrics_to_save = {
               "model_name": self.current_model_name,
               "timestamp": datetime.now().isoformat(),
               **final_report 
           }
           self.data_manager.guardar_datos(self.patient_dni, f"training_metrics_{self.current_model_name}", metrics_to_save)

       if progress_callback: progress_callback(100, {"status": "Entrenamiento completado."})
       return self.current_trained_strategy, final_report


   def predict_single_instance(self,
                               raw_emg_signal: np.ndarray,
                               finger_data_dict: Optional[Dict[str, Dict[str, Optional[float]]]] = None
                              ) -> Optional[Tuple[Union[int, str], Optional[np.ndarray]]]:
       """
       Realiza una predicci�n para una �nica instancia de datos EMG (y opcionalmente finger_data).
       Aplica calibraci�n y extracci�n de caracter�sticas.

       Args:
           raw_emg_signal: Array de la se�al EMG cruda para una instancia.
           finger_data_dict: Datos de dedos para esta instancia.

       Returns:
           Tuple[Union[int, str], Optional[np.ndarray]]: (etiqueta_predicha, probabilidades_predichas) o None si falla.
                                                         La etiqueta puede ser el ID num�rico o el nombre del movimiento.
       """
       if self.current_trained_strategy is None:
           logger.error("No hay un modelo entrenado cargado para realizar predicciones.")
           return None

       features_vector = self._extract_and_combine_features(raw_emg_signal, finger_data_dict)
       if features_vector is None:
           logger.error("Fallo al extraer/combinar caracter�sticas para la predicci�n.")
           return None

       # Escalar caracter�sticas si el modelo fue entrenado con escalado
       if self.feature_scaler:
           features_vector_scaled = self.feature_scaler.transform(features_vector.reshape(1, -1))
       else:
           features_vector_scaled = features_vector.reshape(1, -1)

       try:
           predicted_label_encoded = self.current_trained_strategy.predict(features_vector_scaled)
           predicted_label_str = self.label_encoder.inverse_transform(predicted_label_encoded)[0]
           
           probabilities: Optional[np.ndarray] = None
           if hasattr(self.current_trained_strategy, 'predict_proba'):
               probs_result = self.current_trained_strategy.predict_proba(features_vector_scaled)
               if probs_result is not None:
                   probabilities = probs_result[0] # Probabilidades para la primera (y �nica) muestra

           logger.info(f"Predicci�n: Etiqueta = {predicted_label_str} (Codificada: {predicted_label_encoded[0]}), Probs: {probabilities}")
           return predicted_label_str, probabilities

       except Exception as e:
           logger.error(f"Error durante la predicci�n de instancia �nica: {e}", exc_info=True)
           return None

   def load_trained_model(self, model_filepath: str) -> bool:
       """Carga un modelo entrenado previamente desde un archivo."""
       try:
           self.current_trained_strategy = ModelFactory.load_strategy_from_file(model_filepath)
           # Extraer nombre del modelo del path para current_model_name
           basename = os.path.basename(model_filepath)
           parts = basename.split('_')
           if len(parts) > 1: # Asumir formato DNI_MODELNAME_TIMESTAMP.ext
               self.current_model_name = parts[1] 
           else: # Nombre simple
               self.current_model_name = os.path.splitext(basename)[0]
           
           # Importante: Si el modelo fue entrenado con escalado, necesitar�amos cargar
           # el escalador tambi�n. Esto se complica si el pipeline no se guard� completo.
           # Las estrategias scikit-learn ahora guardan el pipeline, que incluye el escalador.
           # Para PyTorch, el escalado se maneja externamente (aqu� en EMGClassifier).
           # Se podr�a guardar el scaler junto al modelo PyTorch o re-ajustarlo con datos de referencia.
           # Por ahora, asumimos que si se carga un modelo, el `feature_scaler` debe estar
           # disponible o ser re-ajustado si el modelo lo requiere.
           # Si el pipeline de sklearn se carga, ya tiene el scaler.
           if isinstance(self.current_trained_strategy, (SvmStrategy, RfStrategy, XgboostStrategy, MlpStrategy)):
               if 'scaler' in self.current_trained_strategy.model.named_steps: # type: ignore
                   self.feature_scaler = self.current_trained_strategy.model.named_steps['scaler'] # type: ignore
                   logger.info("Escalador cargado desde el pipeline del modelo.")
               else:
                   self.feature_scaler = None # El modelo cargado no us� escalador en su pipeline
           # Para DNN, el escalador es externo y debe manejarse (e.g. cargarlo si se guard� por separado)
           # o el usuario debe ser consciente de re-escalar los datos de entrada.

           logger.info(f"Modelo '{self.current_model_name}' cargado desde {model_filepath}")
           return True
       except Exception as e:
           logger.error(f"Error al cargar modelo desde {model_filepath}: {e}", exc_info=True)
           self.current_trained_strategy = None
           self.current_model_name = None
           return False
           
   def get_model_metrics_summary(self, metrics_report: Dict[str, Any]) -> str:
       """Genera un string resumen de las m�tricas del modelo."""
       summary = []
       summary.append(f"Modelo: {self.current_model_name}")
       
       if "test_set_accuracy" in metrics_report:
           summary.append(f"  Accuracy (Test Set): {metrics_report['test_set_accuracy']:.4f}")
       if "mean_cv_accuracy" in metrics_report:
           summary.append(f"  Mean CV Accuracy: {metrics_report['mean_cv_accuracy']:.4f}")
       if "best_cv_score" in metrics_report: # GridSearchCV
           summary.append(f"  Best CV Score (GridSearch): {metrics_report['best_cv_score']:.4f}")
       if "best_val_accuracy" in metrics_report: # DNN
           summary.append(f"  Best Validation Accuracy (DNN): {metrics_report['best_val_accuracy']:.4f}")

       if "test_set_classification_report" in metrics_report:
           report_dict = metrics_report["test_set_classification_report"]
           if isinstance(report_dict, dict):
               summary.append("  M�tricas por clase (Test Set):")
               for label, scores in report_dict.items():
                   if isinstance(scores, dict) and 'f1-score' in scores:
                       summary.append(f"    {label}: F1={scores['f1-score']:.2f}, P={scores['precision']:.2f}, R={scores['recall']:.2f}, S={scores['support']}")
       return "\n".join(summary)

# Ejemplo de uso
if __name__ == "__main__":
   # --- Configuraci�n para el ejemplo ---
   test_patient_dni = "CLASSIFY_TEST_001"
   
   # Crear GestorDatos y otros managers dummy/reales
   # Usar un directorio temporal para los datos del repositorio
   test_repo_dir = Path("./temp_bitnari_classifier_data")
   if test_repo_dir.exists():
       shutil.rmtree(test_repo_dir) # Limpiar de ejecuciones anteriores
   
   dm = GestorDatos(local_repo_base_dir=test_repo_dir)
   pe = EMGProcessingEngine(sampling_rate=1000, data_manager=dm, patient_id=test_patient_dni)
   # cm = EMGCalibrationManager(data_manager=dm, patient_id=test_patient_dni) # Opcional
   # emg_acq = EMGAcquisition(...) # Opcional, para modo real_time

   classifier = EMGClassifier(patient_dni=test_patient_dni, data_manager=dm, processing_engine=pe)

   # 1. Simular algunos EmgRecordModel y guardarlos con GestorDatos
   logger.info("Generando y guardando datos de ejemplo...")
   num_records = 20
   num_samples_per_record = 500 # 0.5s a 1000Hz
   
   # Crear el archivo movements_config.json si no existe para el ejemplo
   movements_example_path = Path(__file__).parent / EMGClassifier.MOVEMENTS_CONFIG_FILENAME
   if not movements_example_path.exists():
       default_movements = {str(i): f"movimiento_{i}" for i in range(5)}
       with open(movements_example_path, 'w') as f_mov:
           json.dump(default_movements, f_mov)
       classifier.movements_map = classifier._load_movements_config() # Recargar
       classifier.num_defined_classes = len(classifier.movements_map)


   for i in range(num_records):
       record_id = f"example_rec_{i}_{datetime.now().strftime('%f')}"
       # Datos EMG simulados (2 canales)
       raw_ch1 = np.random.randn(num_samples_per_record) + np.sin(np.linspace(0, (i%5+1)*np.pi, num_samples_per_record))
       raw_ch2 = np.random.randn(num_samples_per_record) + np.cos(np.linspace(0, (i%3+1)*np.pi, num_samples_per_record))
       
       # Finger data simulado
       finger_sim_data = {}
       for finger in FINGER_ORDER:
           finger_sim_data[finger] = {"angulo": np.random.uniform(0,180), "fuerza": np.random.uniform(0,100)}

       rec_model = EmgRecordModel(
           record_id=record_id,
           patient_dni=test_patient_dni,
           timestamp=datetime.now() - timedelta(minutes=num_records - i),
           duration_s=num_samples_per_record / 1000.0,
           sampling_rate_hz=1000.0,
           num_channels=2,
           raw_data=[raw_ch1.tolist(), raw_ch2.tolist()], # [[ch1_samples], [ch2_samples]]
           label=str(i % classifier.num_defined_classes), # Etiqueta c�clica
           features_extracted={"finger_data_snapshot": finger_sim_data} # Guardar finger data con el record
       )
       dm.guardar_sesion_emg(rec_model)
   logger.info(f"{num_records} registros EMG de ejemplo guardados.")

   # 2. Entrenar un modelo (ej. Random Forest)
   logger.info("\n--- Entrenando Modelo Random Forest ---")
   
   def print_progress(percentage: int, metrics: Dict[str, float]):
       status = metrics.get("status", "")
       logger.info(f"Progreso Entrenamiento: {percentage}% - {status} {metrics}")

   rf_strategy, rf_report = classifier.train_model(
       model_name="rf",
       acquisition_mode="saved", # Usar los datos que acabamos de guardar
       user_hyperparams={"n_estimators": 50, "max_depth": 5}, # Params para RF
       perform_grid_search=False, # Probar con False primero
       progress_callback=print_progress
   )

   if rf_strategy and rf_report:
       logger.info("\n--- Resumen M�tricas Random Forest ---")
       logger.info(classifier.get_model_metrics_summary(rf_report))
       logger.info(f"Modelo guardado en: {rf_report.get('model_save_path', 'N/A')}")

       # 3. Realizar una predicci�n con el modelo entrenado
       logger.info("\n--- Realizando Predicci�n de Ejemplo ---")
       # Tomar una muestra de los datos originales para predecir (o simular una nueva)
       example_records = dm.listar_sesiones_emg(test_patient_dni)
       if example_records:
           test_record = example_records[0]
           test_raw_emg = test_record.get_raw_data_as_array(orientation='samples_x_channels')
           test_finger_data = test_record.features_extracted.get("finger_data_snapshot") if test_record.features_extracted else None
           
           if test_raw_emg is not None:
               # Para predecir una instancia, _extract_and_combine_features espera una se�al completa
               # y extrae features globales. Si el modelo se entren� con features de segmentos,
               # aqu� se deber�a segmentar test_raw_emg y predecir por segmento.
               # Asumiendo que el modelo usa features globales de la muestra:
               prediction_result = classifier.predict_single_instance(test_raw_emg, test_finger_data)
               if prediction_result:
                   pred_label, pred_probs = prediction_result
                   logger.info(f"Predicci�n para muestra de test: Etiqueta='{pred_label}', Probs (si aplica)={pred_probs}")
                   logger.info(f"Etiqueta real (para comparaci�n): {test_record.label} ({classifier.get_movement_name(int(test_record.label))})")

   # Limpiar directorio temporal
   if test_repo_dir.exists():
       shutil.rmtree(test_repo_dir)
       logger.info(f"Directorio de prueba {test_repo_dir} eliminado.")
   

