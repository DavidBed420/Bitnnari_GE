"""
EmgAppFacade.py

Proporciona una interfaz unificada y simplificada (Fachada) para interactuar
con los diversos subsistemas de la aplicación EMG (adquisición, procesamiento,
calibración, clasificación, gestión de datos).

La GUI y otros componentes de alto nivel interactuarán principalmente con esta fachada,
desacoplándolos de la complejidad interna de cada módulo.
"""
import logging
import os
from typing import Optional, List, Dict, Any, Callable, Union
from pathlib import Path
import numpy as np
import joblib # Para cargar/guardar modelos de ML (ej. scikit-learn)
# import torch # Descomentar si se usan modelos PyTorch directamente en la fachada

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos, DATA_TYPE_PATIENT_INFO, DATA_TYPE_CALIBRATION_PARAMS, DATA_TYPE_EMG_SESSION, DATA_TYPE_ACQUISITION_CONFIG, DATA_TYPE_PROCESSING_CONFIG, DATA_TYPE_TRAINING_CONFIG
from BitnnariApp.data.models.patient import PatientModel
from BitnnariApp.data.models.calibration_params import CalibrationParamsModel
from BitnnariApp.data.models.emg_record import EmgRecordModel

from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition, SerialConfig, AcquisitionConfig as DeviceAcqConfig, FilterConfig as DeviceFilterConfig, LogConfig as DeviceLogConfig, AcquisitionWorker, QThread # Asumiendo que QThread está en emg_adquisition para el worker
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager, CalibrationRunConfig
from BitnnariApp.processing.emg_processing import EMGProcessingEngine
from BitnnariApp.classification.emg_classification import EMGClassifier # Asume que tiene ModelFactory integrado o accesible
# from BitnnariApp.classification.model_factory import ModelFactory # Si ModelFactory es una clase separada

# PyQtSignal para comunicación asíncrona (si la fachada se usa en un contexto Qt)
try:
    from PyQt6.QtCore import QObject, pyqtSignal
    HAS_QT = True
except ImportError:
    HAS_QT = False
    class QObject: pass
    class pyqtSignal:
        def __init__(self, *args, **kwargs): pass
        def emit(self, *args, **kwargs): pass

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


class EmgAppFacade(QObject if HAS_QT else object):
    """
    Fachada para la aplicación EMG. Orquesta las interacciones entre la GUI,
    la gestión de datos y los módulos de procesamiento/análisis.
    """
    if HAS_QT:
        # Señales para la GUI
        raw_data_acquired = pyqtSignal(object) # Emite np.ndarray o List[float]
        processed_data_ready = pyqtSignal(object) # Emite np.ndarray o List[float]
        calibration_status_update = pyqtSignal(str, int) # Mensaje, progreso
        training_progress_update = pyqtSignal(str, int) # Mensaje, progreso
        prediction_ready = pyqtSignal(object) # Resultado de la predicción
        error_occurred = pyqtSignal(str, str) # Título del error, mensaje
        patient_data_changed = pyqtSignal(str) # DNI del paciente cuyos datos cambiaron

    def __init__(self, data_manager: GestorDatos):
        super().__init__()
        self.data_manager = data_manager
        
        # Instancias de los módulos principales (se inicializan según necesidad)
        self.emg_acquirer: Optional[EMGAcquisition] = None
        self.acquisition_worker: Optional[AcquisitionWorker] = None
        self.acquisition_thread_qt: Optional[QThread] = None # Para el worker de Qt

        self.calibration_manager: Optional[EMGCalibrationManager] = None
        self.processing_engine: Optional[EMGProcessingEngine] = None
        self.classification_engine: Optional[EMGClassifier] = None
        # self.model_factory = ModelFactory() # Si es una clase separada

        self.current_patient_dni: Optional[str] = None
        self.active_ml_model: Optional[Any] = None # El modelo de ML cargado
        self.active_ml_model_name: Optional[str] = None

        # Conectar señales del GestorDatos si existen
        if HAS_QT and hasattr(self.data_manager, 'datos_paciente_actualizados'):
            self.data_manager.datos_paciente_actualizados.connect(self._handle_patient_data_change)

    def _handle_patient_data_change(self, dni: str):
        """Maneja la señal de cambio de datos del paciente desde GestorDatos."""
        if HAS_QT:
            self.patient_data_changed.emit(dni)

    def _emit_error(self, title: str, message: str):
        logger.error(f"{title}: {message}")
        if HAS_QT:
            self.error_occurred.emit(title, message)
        else: # Fallback para entornos no-Qt
            print(f"ERROR - {title}: {message}")

    # --- Gestión de Pacientes ---
    def set_current_patient(self, dni: str) -> bool:
        """Establece el paciente activo y carga sus configuraciones y datos relevantes."""
        if self.data_manager.seleccionar_paciente_actual(dni):
            self.current_patient_dni = dni
            logger.info(f"Paciente actual establecido en la fachada: {dni}")
            # Cargar configuraciones específicas del paciente para los módulos
            self._load_patient_specific_configurations(dni)
            if HAS_QT: self.patient_data_changed.emit(dni)
            return True
        self._emit_error("Error de Paciente", f"No se pudo establecer el paciente con DNI {dni}.")
        return False

    def get_current_patient(self) -> Optional[PatientModel]:
        """Obtiene el modelo del paciente actualmente activo."""
        return self.data_manager.paciente_actual

    def register_patient(self, patient_data: Dict[str, Any]) -> Optional[PatientModel]:
        """Registra un nuevo paciente."""
        patient = self.data_manager.registrar_nuevo_paciente(patient_data)
        if patient:
            logger.info(f"Paciente {patient.dni} registrado a través de la fachada.")
            # Opcionalmente, establecer como paciente actual
            # self.set_current_patient(patient.dni)
        else:
            self._emit_error("Error de Registro", "No se pudo registrar el paciente.")
        return patient

    def update_patient_info(self, dni: str, data_to_update: Dict[str, Any]) -> Optional[PatientModel]:
        """Actualiza la información de un paciente existente."""
        patient = self.data_manager.actualizar_paciente(dni, data_to_update)
        if patient:
            logger.info(f"Información del paciente {dni} actualizada.")
            if self.current_patient_dni == dni and HAS_QT:
                self.patient_data_changed.emit(dni)
        else:
            self._emit_error("Error de Actualización", f"No se pudo actualizar el paciente {dni}.")
        return patient

    def list_all_patients(self) -> List[PatientModel]:
        """Lista todos los pacientes disponibles."""
        return self.data_manager.listar_todos_pacientes()

    def _load_patient_specific_configurations(self, patient_dni: str):
        """Carga configuraciones de adquisición, procesamiento, etc., para el paciente actual."""
        # Adquisición
        acq_conf_dict = self.data_manager.cargar_datos_paciente(patient_dni, DATA_TYPE_ACQUISITION_CONFIG)
        if acq_conf_dict:
            try:
                # Asumimos que acq_conf_dict contiene claves para SerialConfig, DeviceAcqConfig, etc.
                serial_c = SerialConfig(**acq_conf_dict.get("serial_config", {}))
                device_acq_c = DeviceAcqConfig(**acq_conf_dict.get("device_config", {}))
                device_filter_c = DeviceFilterConfig(**acq_conf_dict.get("device_filter_config", {}))
                device_log_c = DeviceLogConfig(**acq_conf_dict.get("device_log_config", {}))
                
                if self.emg_acquirer:
                    self.emg_acquirer.update_configs(serial_config=serial_c, acq_config=device_acq_c, 
                                                     filter_config=device_filter_c, log_config=device_log_c)
                else: # Crear si no existe
                    self.emg_acquirer = EMGAcquisition(serial_c, device_acq_c, device_filter_c, device_log_c)
                logger.info(f"Configuración de adquisición cargada/actualizada para {patient_dni}.")
            except Exception as e: # Captura ValidationError de Pydantic
                logger.error(f"Error al cargar/parsear configuración de adquisición para {patient_dni}: {e}")

        # Procesamiento
        proc_conf_dict = self.data_manager.cargar_datos_paciente(patient_dni, DATA_TYPE_PROCESSING_CONFIG)
        if proc_conf_dict:
            if not self.processing_engine:
                # Asumir una tasa de muestreo por defecto si no está en la config de adquisición
                sr = self.emg_acquirer.processor.config.sample_rate if self.emg_acquirer else 1000.0
                self.processing_engine = EMGProcessingEngine(sampling_rate=sr, data_manager=self.data_manager, patient_id=patient_dni)
            # EMGProcessingEngine carga su config en su __init__ o con un método load_config
            self.processing_engine.load_processing_config(patient_dni) # Llama al método del engine
            logger.info(f"Configuración de procesamiento cargada para {patient_dni}.")

        # Calibración (los parámetros se cargan al instanciar EMGCalibrationManager con patient_id)
        if not self.calibration_manager:
            self.calibration_manager = EMGCalibrationManager(data_manager=self.data_manager, 
                                                             emg_acquirer=self.emg_acquirer, 
                                                             patient_id=patient_dni)
        else:
            self.calibration_manager.set_patient_id(patient_dni)
            if self.emg_acquirer:
                 self.calibration_manager.set_emg_acquirer(self.emg_acquirer)
        logger.info(f"Gestor de calibración configurado para {patient_dni}.")

        # Clasificación (el motor se instancia al necesitarlo)
        if not self.classification_engine:
            self.classification_engine = EMGClassifier() # Asume que EMGClassifier puede acceder a GestorDatos o se le pasa
            # Si EMGClassifier necesita GestorDatos: self.classification_engine = EMGClassifier(data_manager=self.data_manager)
        # Cargar modelo preferido si existe
        patient_model = self.data_manager.obtener_paciente(patient_dni)
        if patient_model and patient_model.modelo_ml_preferido:
            self.load_ml_model(patient_model.modelo_ml_preferido, patient_dni=patient_dni)


    # --- Operaciones de Adquisición EMG ---
    def initialize_acquisition_system(self, serial_config_dict: Dict, device_acq_config_dict: Dict, 
                                      device_filter_config_dict: Dict, device_log_config_dict: Dict, 
                                      simulate: bool = False) -> bool:
        """Inicializa o reconfigura el sistema de adquisición."""
        try:
            serial_c = SerialConfig(**serial_config_dict)
            device_acq_c = DeviceAcqConfig(**device_acq_config_dict)
            device_filter_c = DeviceFilterConfig(**device_filter_config_dict)
            device_log_c = DeviceLogConfig(**device_log_config_dict)

            if self.emg_acquirer:
                self.emg_acquirer.close() # Cerrar instancia anterior si existe
            
            self.emg_acquirer = EMGAcquisition(serial_c, device_acq_c, device_filter_c, device_log_c, simulate=simulate)
            
            # Si hay un paciente actual, guardar esta config para él
            if self.current_patient_dni:
                full_acq_config = {
                    "serial_config": serial_config_dict,
                    "device_config": device_acq_config_dict,
                    "device_filter_config": device_filter_config_dict,
                    "device_log_config": device_log_config_dict
                }
                self.data_manager.guardar_datos_paciente(self.current_patient_dni, DATA_TYPE_ACQUISITION_CONFIG, full_acq_config)

            logger.info("Sistema de adquisición EMG inicializado/reconfigurado.")
            return True
        except Exception as e: # Captura ValidationError
            self._emit_error("Error de Configuración de Adquisición", f"Datos de configuración inválidos: {e}")
            return False

    def connect_acquisition_device(self) -> bool:
        """Conecta el dispositivo de adquisición."""
        if not self.emg_acquirer:
            self._emit_error("Error de Adquisición", "El sistema de adquisición no ha sido inicializado.")
            return False
        if self.emg_acquirer.connect():
            logger.info("Dispositivo EMG conectado.")
            # Actualizar el procesador y calibrador con la instancia de adquisición
            if self.processing_engine and hasattr(self.processing_engine, 'update_sampling_rate'): # Método no existe en la clase original
                 self.processing_engine.update_sampling_rate(self.emg_acquirer.processor.config.sample_rate)
            if self.calibration_manager:
                self.calibration_manager.set_emg_acquirer(self.emg_acquirer)
            return True
        self._emit_error("Error de Conexión", f"No se pudo conectar al dispositivo EMG en el puerto {self.emg_acquirer.serial_config.port}.")
        return False

    def disconnect_acquisition_device(self):
        """Desconecta el dispositivo de adquisición."""
        if self.emg_acquirer:
            self.emg_acquirer.disconnect()
            logger.info("Dispositivo EMG desconectado.")
        else:
            logger.warning("Intento de desconectar un sistema de adquisición no inicializado.")

    def start_acquisition_stream(self, use_qt_thread: bool = True):
        """Inicia el stream de datos EMG en un hilo."""
        if not self.emg_acquirer or not self.emg_acquirer.is_connected():
            self._emit_error("Error de Adquisición", "Dispositivo EMG no conectado o no inicializado.")
            return

        if self.acquisition_thread_qt and self.acquisition_thread_qt.isRunning():
            logger.warning("El hilo de adquisición ya está en ejecución.")
            return

        if use_qt_thread and HAS_QT:
            self.acquisition_worker = AcquisitionWorker(self.emg_acquirer)
            self.acquisition_thread_qt = QThread()
            self.acquisition_worker.moveToThread(self.acquisition_thread_qt)

            self.acquisition_worker.data_signal.connect(self._on_raw_data_received)
            self.acquisition_worker.finished_signal.connect(self.acquisition_thread_qt.quit)
            # self.acquisition_worker.finished_signal.connect(self.acquisition_worker.deleteLater) # Cuidado con deleteLater si el worker se reutiliza
            # self.acquisition_thread_qt.finished.connect(self.acquisition_thread_qt.deleteLater)
            self.acquisition_thread_qt.started.connect(self.acquisition_worker.run)
            
            self.acquisition_thread_qt.start()
            logger.info("Stream de adquisición EMG iniciado en hilo Qt.")
        else:
            # Implementación de hilo Python estándar (si no se usa Qt o se prefiere)
            # Esto requeriría un mecanismo de callback diferente a pyqtSignal
            self._emit_error("Error de Hilo", "Modo de hilo no Qt no implementado completamente en esta fachada.")
            logger.warning("Modo de hilo no Qt para adquisición no implementado en fachada.")


    def _on_raw_data_received(self, data_packet: Dict[str, Any]):
        """Callback interno para cuando se reciben datos del hilo de adquisición."""
        if HAS_QT:
            self.raw_data_acquired.emit(data_packet) # Emitir para la GUI
        
        # Procesar los datos si el engine está configurado
        if self.processing_engine and 'raw_data' in data_packet:
            raw_signal_np = np.array(data_packet['raw_data'])
            # Asumir que el calibration_manager ya está configurado para el paciente actual
            processed_signal_np = self.processing_engine.process_signal(raw_signal_np, self.calibration_manager)
            if HAS_QT:
                self.processed_data_ready.emit(processed_signal_np.tolist()) # Emitir procesados

    def stop_acquisition_stream(self):
        """Detiene el stream de datos EMG."""
        if self.acquisition_worker and self.acquisition_thread_qt and self.acquisition_thread_qt.isRunning():
            self.acquisition_worker.stop()
            # self.acquisition_thread_qt.quit() # Ya se conecta a finished_signal
            self.acquisition_thread_qt.wait(2000) # Esperar un tiempo prudencial
            if self.acquisition_thread_qt.isRunning():
                logger.warning("El hilo de adquisición no se detuvo limpiamente, forzando terminación.")
                self.acquisition_thread_qt.terminate() # Como último recurso
                self.acquisition_thread_qt.wait()
            logger.info("Stream de adquisición EMG detenido.")
        elif self.emg_acquirer: # Si no se usó hilo Qt pero hay acquirer
             self.emg_acquirer.close() # Asegurar que se cierre
        else:
            logger.warning("No hay stream de adquisición activo para detener.")
        
        self.acquisition_thread_qt = None
        self.acquisition_worker = None


    # --- Operaciones de Calibración ---
    def run_offset_calibration(self, duration_s: float, apply_filter: bool, filter_config_dict: Optional[Dict] = None) -> Optional[np.ndarray]:
        """Ejecuta la calibración de offset."""
        if not self.calibration_manager:
            self._emit_error("Error de Calibración", "Módulo de calibración no inicializado.")
            return None
        if not self.emg_acquirer:
            self._emit_error("Error de Calibración", "Módulo de adquisición no disponible para calibración.")
            return None
        
        self.calibration_manager.set_emg_acquirer(self.emg_acquirer) # Asegurar que tenga el acquirer actual

        filter_c = DeviceFilterConfig(**filter_config_dict) if filter_config_dict else None
        run_config = CalibrationRunConfig(duration_s=duration_s, apply_filter_during_offset_cal=apply_filter, filter_config=filter_c)
        
        if HAS_QT: self.calibration_status_update.emit("Iniciando calibración de offset...", 0)
        
        success = self.calibration_manager.calibrate_offset(run_config)
        
        if success and self.calibration_manager.offset_params is not None:
            if HAS_QT: self.calibration_status_update.emit("Calibración de offset completada.", 100)
            logger.info(f"Calibración de offset exitosa. Offset: {self.calibration_manager.offset_params.tolist()}")
            return self.calibration_manager.offset_params
        else:
            if HAS_QT: self.calibration_status_update.emit("Fallo en calibración de offset.", 100)
            self._emit_error("Error de Calibración", "No se pudo completar la calibración de offset.")
            return None

    def apply_current_calibration(self, raw_signal: np.ndarray) -> np.ndarray:
        """Aplica la calibración actual (cargada o recién calculada) a una señal."""
        if not self.calibration_manager:
            logger.warning("Módulo de calibración no inicializado. Devolviendo señal sin calibrar.")
            return raw_signal
        if self.calibration_manager.offset_params is None and self.calibration_manager.gain_params is None:
            logger.warning("No hay parámetros de calibración cargados/calculados. Devolviendo señal sin calibrar.")
            return raw_signal
        return self.calibration_manager.apply_calibration(raw_signal)

    # --- Operaciones de Procesamiento ---
    def configure_processing_filters(self, patient_dni: str, filter_configs: Dict[str, Dict[str, Any]]):
        """Configura los filtros en el EMGProcessingEngine y guarda la configuración."""
        if not self.processing_engine:
            # Asumir una tasa de muestreo por defecto si no está en la config de adquisición
            sr = self.emg_acquirer.processor.config.sample_rate if self.emg_acquirer else 1000.0
            self.processing_engine = EMGProcessingEngine(sampling_rate=sr, data_manager=self.data_manager, patient_id=patient_dni)
        
        for filter_name, config_values in filter_configs.items():
            self.processing_engine.configure_filter(filter_name, config_values)
        
        self.processing_engine.save_processing_config(patient_dni)
        logger.info(f"Filtros de procesamiento configurados y guardados para paciente {patient_dni}.")

    def process_acquired_signal(self, raw_signal: np.ndarray) -> Optional[np.ndarray]:
        """Procesa una señal cruda usando el EMGProcessingEngine configurado."""
        if not self.processing_engine:
            self._emit_error("Error de Procesamiento", "Motor de procesamiento no inicializado.")
            return None
        
        # La calibración se pasa al método process_signal del engine
        processed = self.processing_engine.process_signal(raw_signal, self.calibration_manager)
        
        # Guardar la sesión procesada (opcional, o manejarlo en un nivel superior)
        if self.current_patient_dni and self.data_manager:
             self.processing_engine.save_processed_data(self.current_patient_dni, raw_signal, processed)

        return processed

    # --- Operaciones de Clasificación y Entrenamiento ---
    def _ensure_classification_engine(self):
        if not self.classification_engine:
            self.classification_engine = EMGClassifier()
            # Si EMGClassifier necesita GestorDatos:
            # self.classification_engine.gestor_datos = self.data_manager
            # Si EMGClassifier necesita el paciente actual:
            if self.current_patient_dni and self.data_manager.paciente_actual:
                 self.classification_engine.gestor_datos.paciente_actual = self.data_manager.paciente_actual.model_dump()


    def start_ml_training(self, model_name: str, training_data_source: Union[str, Tuple[np.ndarray, np.ndarray]], 
                          hyperparams: Dict[str, Any], custom_training_params: Optional[Dict[str, Any]] = None):
        """
        Inicia el entrenamiento de un modelo de Machine Learning.
        
        Args:
            model_name (str): Nombre del modelo a entrenar (e.g., "svm", "random_forest").
            training_data_source (Union[str, Tuple[np.ndarray, np.ndarray]]): 
                - Si es str: DNI del paciente para cargar sus EmgRecordModel.
                - Si es Tuple: (X_features, y_labels) directamente.
            hyperparams (Dict[str, Any]): Hiperparámetros para el modelo.
            custom_training_params (Optional[Dict[str, Any]]): Parámetros adicionales para EMGClassifier.train
                                                               (e.g., apply_calibration, acquisition_mode).
        """
        self._ensure_classification_engine()
        if not self.classification_engine: return # No debería pasar si _ensure_classification_engine funciona

        if HAS_QT: self.training_progress_update.emit(f"Iniciando entrenamiento para modelo {model_name}...", 0)

        X_train, y_train = None, None
        if isinstance(training_data_source, str): # Es un DNI
            patient_dni_source = training_data_source
            if not self.current_patient_dni or self.current_patient_dni != patient_dni_source:
                if not self.set_current_patient(patient_dni_source): # Carga configs y datos del paciente
                    self._emit_error("Error de Entrenamiento", f"No se pudo establecer el paciente {patient_dni_source} para entrenamiento.")
                    if HAS_QT: self.training_progress_update.emit("Error: Paciente no encontrado.", 100)
                    return
            
            # Cargar todos los EmgRecordModel para el paciente
            emg_records = self.data_manager.listar_sesiones_emg_paciente(patient_dni_source)
            if not emg_records:
                self._emit_error("Error de Entrenamiento", f"No hay sesiones EMG guardadas para el paciente {patient_dni_source}.")
                if HAS_QT: self.training_progress_update.emit("Error: No hay datos de entrenamiento.", 100)
                return

            # Extraer características y etiquetas
            # Esta parte es compleja: se necesita una estrategia para extraer features de raw_data
            # y asegurar que las etiquetas ('label') estén presentes y sean correctas.
            # Asumimos que EMGClassifier.train() puede manejar esto o que se le pasan X, y ya procesados.
            # Por ahora, simulamos que EMGClassifier.train() puede tomar los EmgRecords o un path.
            # Aquí, vamos a pasar X, y vacíos y dejar que EMGClassifier.train() los cargue si está diseñado así.
            # O, idealmente, preparamos X, y aquí.
            
            # Ejemplo de preparación de X, y (simplificado):
            features_list = []
            labels_list = []
            if not self.processing_engine: # Asegurar que exista
                self.processing_engine = EMGProcessingEngine(1000.0) # Usar FS por defecto o de config

            for record in emg_records:
                if record.raw_data and record.label:
                    raw_np = record.get_raw_data_as_array(orientation='samples_x_channels')
                    if raw_np is not None and raw_np.size > 0:
                        # Aplicar calibración y procesamiento
                        calibrated_np = self.apply_current_calibration(raw_np)
                        processed_np = self.processing_engine.process_signal(calibrated_np, self.calibration_manager)
                        
                        # Extraer características (asumimos que devuelve un array plano o un dict que se puede aplanar)
                        # Esto es una simplificación. La extracción de features puede ser más compleja.
                        # Y debería ser consistente para todos los registros.
                        # Aquí, tomamos la media de las características de todos los canales como un ejemplo.
                        channel_features_list = self.processing_engine.extract_all_features(processed_np)
                        if channel_features_list:
                             # Promediar o concatenar features de canales. Aquí promediamos.
                            aggregated_features = np.mean([list(cf.values()) for cf in channel_features_list], axis=0)
                            features_list.append(aggregated_features)
                            labels_list.append(record.label)
            
            if not features_list or not labels_list:
                self._emit_error("Error de Entrenamiento", "No se pudieron extraer características o etiquetas de las sesiones.")
                if HAS_QT: self.training_progress_update.emit("Error: Fallo en preparación de datos.", 100)
                return
            X_train = np.array(features_list)
            y_train = np.array(labels_list)

        elif isinstance(training_data_source, tuple) and len(training_data_source) == 2:
            X_train, y_train = training_data_source
        else:
            self._emit_error("Error de Entrenamiento", "Fuente de datos de entrenamiento no válida.")
            if HAS_QT: self.training_progress_update.emit("Error: Fuente de datos inválida.", 100)
            return

        # Aquí se podría lanzar un QThread para el entrenamiento si es largo
        # Por ahora, llamada síncrona para simplificar, pero EMGClassifier.train debería ser no bloqueante
        # o la fachada debería manejar el hilo.
        # EMGClassifier.train ya tiene un placeholder para update_progress.
        # self.classification_engine.update_progress_signal = self.training_progress_update # Si EMGClassifier tiene una señal
        
        final_custom_params = {**hyperparams, **(custom_training_params or {})}

        # Simular progreso si no se usa un hilo real en EMGClassifier
        if HAS_QT: self.training_progress_update.emit("Procesando datos...", 30)

        model, best_params, metrics = self.classification_engine.train(X_train, y_train, model_name, final_custom_params)
        
        if HAS_QT: self.training_progress_update.emit("Entrenamiento finalizado.", 100)

        if model:
            self.active_ml_model = model
            self.active_ml_model_name = model_name
            logger.info(f"Modelo {model_name} entrenado. Métricas: {metrics}, Mejores Params: {best_params}")
            # Guardar información del modelo (metadatos, no el objeto modelo en sí)
            if self.current_patient_dni:
                model_info = {
                    "model_name": model_name,
                    "timestamp": datetime.now().isoformat(),
                    "metrics": metrics,
                    "best_params": best_params,
                    "model_filepath": f"modelos/{model_name}_emg_model_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pkl" # Path relativo donde se guardó
                }
                self.data_manager.guardar_datos_paciente(self.current_patient_dni, DATA_TYPE_ML_MODEL_INFO, model_info)
                # Actualizar el modelo preferido del paciente
                self.update_patient_info(self.current_patient_dni, {"modelo_ml_preferido": model_name})
            if HAS_QT: self.training_progress_update.emit(f"Modelo {model_name} entrenado. Acc: {metrics.get('accuracy', 0):.2f}", 100)
        else:
            self._emit_error("Error de Entrenamiento", f"No se pudo entrenar el modelo {model_name}.")
            if HAS_QT: self.training_progress_update.emit(f"Error entrenando {model_name}.", 100)


    def load_ml_model(self, model_name_or_path: str, patient_dni: Optional[str] = None, version: Optional[str] = None) -> bool:
        """Carga un modelo de ML entrenado."""
        self._ensure_classification_engine()
        if not self.classification_engine: return False

        model_path: Path
        if Path(model_name_or_path).is_file(): # Si es una ruta completa
            model_path = Path(model_name_or_path)
            self.active_ml_model_name = model_path.stem.split('_emg_model')[0] # Extraer nombre base
        else: # Es un nombre de modelo, construir ruta
            # Usar el DNI del paciente actual si no se especifica otro
            dni_to_use = patient_dni or self.current_patient_dni
            if not dni_to_use:
                self._emit_error("Error al Cargar Modelo", "No se especificó DNI del paciente para el modelo.")
                return False
            model_path = self.data_manager.repo.get_ml_model_path(model_name_or_path, dni_to_use, version)
            self.active_ml_model_name = model_name_or_path

        if not model_path.exists():
            self._emit_error("Error al Cargar Modelo", f"Archivo de modelo no encontrado en: {model_path}")
            return False
        
        try:
            # EMGClassifier debería tener un método para cargar, o usamos joblib aquí
            # self.active_ml_model = self.classification_engine.load_model(str(model_path)) # Si EMGClassifier lo maneja
            self.active_ml_model = joblib.load(model_path) # Carga directa con joblib
            logger.info(f"Modelo {self.active_ml_model_name} cargado desde {model_path}.")
            return True
        except Exception as e:
            self._emit_error("Error al Cargar Modelo", f"No se pudo cargar el modelo desde {model_path}: {e}")
            self.active_ml_model = None
            self.active_ml_model_name = None
            return False

    def predict_emg_signal(self, raw_signal_segment: np.ndarray) -> Optional[Any]:
        """Realiza una predicción usando el modelo de ML activo."""
        if not self.active_ml_model:
            self._emit_error("Error de Predicción", "No hay un modelo de ML activo cargado.")
            return None
        if not self.classification_engine:
            self._emit_error("Error de Predicción", "Motor de clasificación no inicializado.")
            return None
        if not self.processing_engine:
            self._emit_error("Error de Predicción", "Motor de procesamiento no inicializado para extraer características.")
            return None

        # Aplicar calibración y procesamiento para obtener características
        calibrated_signal = self.apply_current_calibration(raw_signal_segment)
        processed_signal = self.processing_engine.process_signal(calibrated_signal, self.calibration_manager)
        
        # Extraer características (asumiendo que devuelve un array 1D de features para una muestra/segmento)
        # Esto necesita ser consistente con cómo se entrenó el modelo.
        # Si el modelo fue entrenado con características de múltiples canales agregadas:
        channel_features_list = self.processing_engine.extract_all_features(processed_signal)
        if not channel_features_list:
            self._emit_error("Error de Predicción", "No se pudieron extraer características de la señal.")
            return None
        
        # Agregar features: aquí promediamos, pero podría ser concatenación u otra estrategia
        # Debe coincidir con la forma en que se prepararon los datos para el entrenamiento.
        features_vector = np.mean([list(cf.values()) for cf in channel_features_list], axis=0)
        
        if features_vector.ndim == 1:
            features_vector = features_vector.reshape(1, -1) # Para predicción de una sola muestra

        try:
            prediction = self.classification_engine.predict(features_vector, model_name=self.active_ml_model_name) # O pasar self.active_ml_model
            logger.info(f"Predicción realizada con modelo {self.active_ml_model_name}: {prediction}")
            if HAS_QT: self.prediction_ready.emit(prediction)
            return prediction
        except Exception as e:
            self._emit_error("Error de Predicción", f"Fallo al realizar la predicción: {e}")
            return None

    # --- Exportación ---
    def export_patient_all_data(self, patient_dni: str, filepath: str) -> bool:
        """Exporta todos los datos de un paciente a un archivo."""
        return self.data_manager.export_all_patient_data(patient_dni, filepath)

    def close_app(self):
        """Operaciones de limpieza al cerrar la aplicación."""
        logger.info("Cerrando EmgAppFacade...")
        self.stop_acquisition_stream() # Detener hilos si están activos
        if self.emg_acquirer:
            self.emg_acquirer.close()
        logger.info("Fachada cerrada.")

# Ejemplo de uso (básico, sin GUI)
if __name__ == "__main__":
    # Crear un directorio de datos de prueba para el repositorio
    test_repo_dir = Path("./temp_facade_repo_data")
    if test_repo_dir.exists():
        shutil.rmtree(test_repo_dir)

    data_manager_instance = GestorDatos(local_repo_base_dir=str(test_repo_dir))
    facade = EmgAppFacade(data_manager_instance)

    # Registrar un paciente
    paciente_nuevo_data = {"dni": "FACADE001", "nombre": "Paciente Fachada", "fecha_nacimiento": "1995-03-10"}
    paciente_obj = facade.register_patient(paciente_nuevo_data)

    if paciente_obj:
        facade.set_current_patient(paciente_obj.dni)
        logger.info(f"Paciente actual en fachada: {facade.get_current_patient().nombre if facade.get_current_patient() else 'Ninguno'}")

        # Simular inicialización de adquisición
        s_conf = {"port": None, "baud_rate": 115200, "auto_connect": False} # None para autodetect o simulación
        da_conf = {"delay_ms": 20, "num_channels_active": 1}
        df_conf = {"sample_rate": 50.0}
        dl_conf = {"enabled": False}
        facade.initialize_acquisition_system(s_conf, da_conf, df_conf, dl_conf, simulate=True)
        
        if facade.emg_acquirer: # Verificar que se inicializó
            facade.connect_acquisition_device() # Conectar (simulado)

            # Simular calibración de offset
            if facade.current_patient_dni:
                 filter_c_dict = {"sample_rate": 50.0, "notch_freq": None, "bandpass_low_freq": 5, "bandpass_high_freq": 20}
                 facade.run_offset_calibration(duration_s=1.0, apply_filter=True, filter_config_dict=filter_c_dict)
            
            # Iniciar stream (sin Qt, el callback directo no funcionará como señal)
            # facade.start_acquisition_stream(use_qt_thread=False) 
            # time.sleep(2) # Dejar que adquiera algunos datos
            # facade.stop_acquisition_stream()

    # Limpiar
    facade.close_app()
    if test_repo_dir.exists():
        shutil.rmtree(test_repo_dir)
    