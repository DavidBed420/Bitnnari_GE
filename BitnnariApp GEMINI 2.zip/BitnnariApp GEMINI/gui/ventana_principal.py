      """
ventana_principal.py

Ventana principal de la aplicación EMG después de la selección/registro de un paciente.
Actúa como un contenedor y gestor de navegación para las diferentes funcionalidades
(Tratamiento, Adquisición, Calibración, Entrenamiento, Procesamiento, Predicción, Paciente).

Características Principales:
- Diseño de QMainWindow: Permite menús, barras de herramientas y barra de estado.
- Menú Lateral Deslizante (Sidebar): Para una navegación clara e intuitiva entre
  las principales secciones funcionales de la aplicación.
- Contenedor Central (QStackedWidget): Aloja las instancias de cada página funcional.
- Panel Inferior con Pestañas (QTabWidget):
    - Pestaña "Opciones Avanzadas": Acciones globales o específicas del paciente
      (e.g., exportar todos los datos, configuraciones globales).
    - Pestaña "Ayuda General": Instrucciones sobre el uso de la aplicación.
- Barra de Estado Dinámica: Muestra información contextual relevante como el
  paciente activo, el modelo ML seleccionado, y estado de operaciones.
- Gestión de Paciente Activo: Mantiene la referencia al DNI del paciente actual
  y lo propaga a las sub-páginas que lo requieran.
- Integración con GestorDatos: Para cargar datos del paciente y configuraciones.
- Estilo: Diseñado para ser compatible con un QSS global y un tema oscuro.
"""

import os
import sys
import logging
from typing import Optional, Dict, Any

from PyQt6.QtCore import Qt, QPropertyAnimation, QSize, pyqtSignal, QEasingCurve
from PyQt6.QtGui import QIcon, QPixmap, QAction
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QStackedWidget, QFrame, QStatusBar, QToolBar,
    QMessageBox, QFileDialog, QTextEdit, QTabWidget, QSplitter
)

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.gui.pagina_adquisicion import PaginaAdquisicion
from BitnnariApp.gui.pagina_calibracion import PaginaCalibracion # Asumiendo que es QWidget
from BitnnariApp.gui.pagina_entrenamiento import TrainingPage
from BitnnariApp.gui.pagina_procesamiento import PaginaProcesamiento
from BitnnariApp.gui.pagina_prediccion import PredictionPage
from BitnnariApp.gui.pagina_paciente import PaginaPaciente
# PaginaTratamiento (si es distinta de las otras)
# from BitnnariApp.gui.pagina_tratamiento import PaginaTratamiento

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Placeholder para PaginaTratamiento si no existe un archivo específico aún
class PaginaTratamiento(QWidget):
    def __init__(self, patient_id: str, data_manager: GestorDatos, parent: Optional[QWidget]=None):
        super().__init__(parent)
        self.patient_id = patient_id
        self.data_manager = data_manager
        layout = QVBoxLayout(self)
        label = QLabel(f"Página de Tratamiento para Paciente: {patient_id}\n(Contenido en desarrollo)")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("font-size: 18pt; color: #cccccc;")
        layout.addWidget(label)
    def update_for_patient(self, patient_id: str, model_name: str): # Método esperado
        logger.info(f"PaginaTratamiento actualizada para paciente {patient_id}, modelo {model_name}")


class VentanaPrincipal(QMainWindow):
    """Ventana principal que contiene las diferentes secciones funcionales."""
    
    # Señal para cuando el paciente activo cambia (podría ser útil para otras partes)
    active_patient_changed = pyqtSignal(str) 

    def __init__(self, patient_id: str, selected_model: str, data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("ventanaPrincipal") # Para QSS
        self.patient_id = patient_id
        self.selected_model_ml = selected_model
        self.data_manager = data_manager
        self.current_patient_data: Dict[str, Any] = {}

        self.setWindowTitle(f"BitnariApp - Paciente: {self.patient_id}")
        self.setMinimumSize(1200, 800)
        self.resize(1400, 900)
        self._center_on_screen()

        self._init_ui()
        self._connect_signals()
        
        self.update_for_patient(patient_id, selected_model) # Cargar datos iniciales
        
        # Cargar el estilo QSS global (asumiendo que se hace en run_app.py)
        # Si no, se puede cargar aquí también.
        logger.info(f"Ventana Principal inicializada para paciente {self.patient_id}, modelo {self.selected_model_ml}.")

    def _center_on_screen(self):
        screen_geo = self.screen().availableGeometry() # Usar self.screen()
        self.move(screen_geo.center() - self.rect().center())

    def _init_ui(self):
        # --- Widget Central Principal ---
        self.main_central_widget = QWidget()
        self.setCentralWidget(self.main_central_widget)
        main_layout = QHBoxLayout(self.main_central_widget) # Layout horizontal para Sidebar + Contenido
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0,0,0,0)

        # --- Sidebar de Navegación ---
        self._setup_sidebar(main_layout)

        # --- Área de Contenido Principal (Derecha del Sidebar) ---
        content_area_widget = QWidget()
        content_area_layout = QVBoxLayout(content_area_widget)
        content_area_layout.setSpacing(10)
        content_area_layout.setContentsMargins(10,10,10,10) # Margen alrededor del contenido

        # Contenedor de Páginas (QStackedWidget)
        self.stacked_pages_content = QStackedWidget()
        self.stacked_pages_content.setObjectName("stackedPagesContent")
        self._create_and_add_pages() # Crear e instanciar páginas
        content_area_layout.addWidget(self.stacked_pages_content, stretch=3) # Más espacio para las páginas

        # Panel Inferior con Pestañas (QTabWidget)
        self.bottom_tab_widget = QTabWidget()
        self.bottom_tab_widget.setObjectName("bottomTabWidget")
        self.bottom_tab_widget.setFixedHeight(200) # Altura fija para el panel inferior
        self._create_bottom_tabs()
        content_area_layout.addWidget(self.bottom_tab_widget, stretch=1) # Menos espacio

        main_layout.addWidget(content_area_widget, stretch=1)

        # --- Barra de Estado ---
        self.status_bar = QStatusBar()
        self.status_bar.setObjectName("mainStatusBar")
        self.setStatusBar(self.status_bar)
        self.label_status_patient = QLabel("Paciente: N/A")
        self.label_status_model = QLabel("Modelo ML: N/A")
        self.label_status_system = QLabel("Sistema: Listo")
        self.status_bar.addPermanentWidget(self.label_status_patient, stretch=1)
        self.status_bar.addPermanentWidget(self.label_status_model, stretch=1)
        self.status_bar.addPermanentWidget(self.label_status_system, stretch=2)
        
        # --- Barra de Herramientas (Opcional, para acciones comunes) ---
        # self._create_toolbar()

    def _setup_sidebar(self, main_layout: QHBoxLayout):
        """Crea el panel lateral (sidebar) para navegación."""
        self.sidebar_frame = QFrame()
        self.sidebar_frame.setObjectName("mainSidebar")
        self.sidebar_frame.setFixedWidth(200) # Ancho inicial del sidebar
        
        sidebar_layout_internal = QVBoxLayout(self.sidebar_frame)
        sidebar_layout_internal.setContentsMargins(5, 10, 5, 10)
        sidebar_layout_internal.setSpacing(8)

        # Botón para ocultar/mostrar sidebar (opcional, si se quiere dinámico)
        self.btn_toggle_sidebar = QPushButton("☰") # O un icono
        self.btn_toggle_sidebar.setObjectName("toggleSidebarButton")
        self.btn_toggle_sidebar.setCheckable(True)
        self.btn_toggle_sidebar.setChecked(True) # Empezar visible
        self.btn_toggle_sidebar.setToolTip("Mostrar/Ocultar Panel de Navegación")
        # sidebar_layout_internal.addWidget(self.btn_toggle_sidebar) # Añadir si se implementa toggle

        # Título del Sidebar
        sidebar_title = QLabel("Navegación")
        sidebar_title.setObjectName("sidebarTitle")
        sidebar_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sidebar_layout_internal.addWidget(sidebar_title)

        # Acciones de navegación
        self.nav_actions_map: Dict[str, Tuple[str, Optional[str], int]] = {
            "Tratamiento": ("Tratamiento", ":/icons/treatment.png", 0), # (Texto, RutaIcono, IndiceStack)
            "Adquisición": ("Adquisición EMG", ":/icons/acquisition.png", 1),
            "Calibración": ("Calibración", ":/icons/calibration.png", 2),
            "Entrenamiento": ("Entrenamiento Modelo", ":/icons/training.png", 3),
            "Procesamiento": ("Procesamiento Señal", ":/icons/processing.png", 4),
            "Predicción": ("Predicción Movimiento", ":/icons/prediction.png", 5),
            "Info Paciente": ("Datos del Paciente", ":/icons/patient_info.png", 6),
        }
        
        for key, (text, icon_path, stack_index) in self.nav_actions_map.items():
            btn = QPushButton(text)
            btn.setObjectName("sidebarNavButton")
            btn.setFixedHeight(35)
            btn.setIconSize(QSize(20,20))
            if icon_path and os.path.exists(icon_path.replace(":/icons/", "resources/icons/")): # Chequear si el recurso existe
                 btn.setIcon(QIcon(icon_path))
            btn.clicked.connect(lambda checked=False, idx=stack_index: self.stacked_pages_content.setCurrentIndex(idx))
            sidebar_layout_internal.addWidget(btn)
        
        sidebar_layout_internal.addStretch()
        main_layout.addWidget(self.sidebar_frame)

        # Animación para ocultar/mostrar (si se implementa btn_toggle_sidebar)
        # self.sidebar_animation = QPropertyAnimation(self.sidebar_frame, b"minimumWidth")
        # self.sidebar_animation.setDuration(300)
        # self.sidebar_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        # self.btn_toggle_sidebar.toggled.connect(self._animate_sidebar)

    # def _animate_sidebar(self, checked: bool):
    #     start_width = self.sidebar_frame.width()
    #     end_width = 200 if checked else 50 # Ancho visible vs colapsado
    #     self.sidebar_animation.setStartValue(start_width)
    #     self.sidebar_animation.setEndValue(end_width)
    #     self.sidebar_animation.start()
    #     self.btn_toggle_sidebar.setText("☰" if checked else "<")


    def _create_and_add_pages(self):
        """Crea instancias de todas las páginas funcionales y las añade al QStackedWidget."""
        # Los IDs de paciente y modelo se pasan a las páginas que los necesitan.
        # El DataManager se pasa a todas.
        self.page_tratamiento = PaginaTratamiento(self.patient_id, self.data_manager)
        self.page_adquisicion = PaginaAdquisicion(self.data_manager, self.patient_id)
        self.page_calibracion = PaginaCalibracion(self.data_manager, self.patient_id) # Asumiendo que es QWidget
        self.page_entrenamiento = TrainingPage(self.data_manager, self.patient_id)
        self.page_procesamiento = PaginaProcesamiento(self.data_manager, self.patient_id)
        self.page_prediccion = PredictionPage(self.patient_id, self.data_manager) # Pasar DM
        self.page_paciente_info = PaginaPaciente(self.stacked_pages_content, self.patient_id, self.data_manager)

        self.pages_instances = [
            self.page_tratamiento, self.page_adquisicion, self.page_calibracion,
            self.page_entrenamiento, self.page_procesamiento, self.page_prediccion,
            self.page_paciente_info
        ]
        for page in self.pages_instances:
            self.stacked_pages_content.addWidget(page)

    def _create_bottom_tabs(self):
        """Crea las pestañas del panel inferior."""
        # Pestaña de Opciones Avanzadas
        options_widget = QWidget()
        options_layout = QVBoxLayout(options_widget)
        options_layout.setContentsMargins(10,10,10,10); options_layout.setSpacing(10)
        
        btn_export_all_patient_data = QPushButton("📤 Exportar Todos los Datos del Paciente")
        btn_export_all_patient_data.clicked.connect(self._action_export_all_patient_data)
        options_layout.addWidget(btn_export_all_patient_data)
        
        btn_app_settings = QPushButton("⚙️ Configuración General de la Aplicación")
        btn_app_settings.clicked.connect(self._action_open_app_settings) # Placeholder
        options_layout.addWidget(btn_app_settings)
        options_layout.addStretch()
        self.bottom_tab_widget.addTab(options_widget, "🛠️ Opciones Avanzadas")

        # Pestaña de Ayuda General
        help_widget = QWidget()
        help_layout = QVBoxLayout(help_widget)
        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setHtml("""
            <h2>Ayuda General - BitnariApp</h2>
            <p>Bienvenido a la aplicación de análisis EMG.</p>
            <ul>
                <li>Use el <b>panel de navegación</b> a la izquierda para acceder a las diferentes secciones: Tratamiento, Adquisición, Calibración, etc.</li>
                <li>El <b>paciente activo</b> y el <b>modelo ML</b> seleccionado se muestran en la barra de estado inferior.</li>
                <li>En la pestaña <b>"Opciones Avanzadas"</b> (aquí abajo) encontrará herramientas globales.</li>
                <li>Cada sección tiene sus propias instrucciones y controles. Explore cada una para familiarizarse.</li>
            </ul>
            <p>Para soporte técnico, contacte a soporte@bitnariapp.com.</p>
        """)
        help_layout.addWidget(help_text)
        self.bottom_tab_widget.addTab(help_widget, "❓ Ayuda General")

    def _connect_signals(self):
        # Conectar cambio de página en QStackedWidget para actualizar título o estado
        self.stacked_pages_content.currentChanged.connect(self._on_current_page_changed)
        # Conectar señal de PaginaPaciente si los datos se actualizan allí
        if hasattr(self.page_paciente_info, 'paciente_actualizado'):
            self.page_paciente_info.paciente_actualizado.connect(lambda: self.update_for_patient(self.patient_id, self.selected_model_ml))


    def update_for_patient(self, patient_id: str, selected_model: str):
        """Actualiza la ventana y sus sub-páginas para un nuevo paciente/modelo."""
        self.patient_id = patient_id
        self.selected_model_ml = selected_model
        self.current_patient_data = self.data_manager.cargar_paciente(patient_id) or {}
        
        self.setWindowTitle(f"BitnariApp - Paciente: {self.current_patient_data.get('nombre', self.patient_id)}")
        self._update_status_bar()

        # Notificar a todas las páginas que el paciente/modelo ha cambiado
        # Cada página debe tener un método `update_for_patient(patient_id, model_name, patient_data)`
        for page in self.pages_instances:
            if hasattr(page, "update_for_patient_context"): # Usar un nombre de método específico
                try:
                    page.update_for_patient_context(self.patient_id, self.selected_model_ml, self.current_patient_data)
                except Exception as e:
                    logger.error(f"Error actualizando página {type(page).__name__} para paciente: {e}")
            # Algunas páginas pueden necesitar solo el ID o el data_manager ya lo tiene
            elif hasattr(page, "patient_id"): # Si solo necesitan el ID
                page.patient_id = self.patient_id
                if hasattr(page, "load_patient_data"): # Como PaginaPaciente
                    page.load_patient_data()
            if hasattr(page, "selected_model_ml"): # Para TrainingPage
                page.selected_model_ml = self.selected_model_ml


        logger.info(f"Contexto de VentanaPrincipal actualizado para paciente {self.patient_id}, modelo {self.selected_model_ml}.")
        self.active_patient_changed.emit(self.patient_id)


    def _update_status_bar(self):
        """Actualiza la información mostrada en la barra de estado."""
        patient_name = self.current_patient_data.get("nombre", "N/A")
        self.label_status_patient.setText(f"Paciente: {patient_name} (DNI: {self.patient_id})")
        self.label_status_model.setText(f"Modelo ML Activo: {self.selected_model_ml}")
        # self.label_status_system podría actualizarse con estado de adquisición, etc.

    def _on_current_page_changed(self, index: int):
        """Slot para cuando la página actual del QStackedWidget cambia."""
        # Podría usarse para actualizar la barra de estado o realizar acciones específicas de la página.
        page_object_name = self.stacked_pages_content.widget(index).objectName()
        logger.info(f"Navegando a página: {page_object_name} (Índice: {index})")
        self.label_status_system.setText(f"Sección: {self.nav_actions_map.get(self._get_key_by_stack_index(index), ('Desconocida',None,None))[0]}")


    def _get_key_by_stack_index(self, index_to_find: int) -> Optional[str]:
        for key, (_, _, stack_idx) in self.nav_actions_map.items():
            if stack_idx == index_to_find:
                return key
        return None

    # --- Acciones del Panel Inferior ---
    def _action_export_all_patient_data(self):
        if not self.patient_id:
            QMessageBox.warning(self, "Sin Paciente", "No hay un paciente activo seleccionado.")
            return
        
        filepath, _ = QFileDialog.getSaveFileName(self, "Exportar Todos los Datos del Paciente",
                                                  f"{self.patient_id}_completo_{datetime.now().strftime('%Y%m%d')}.json",
                                                  "JSON Files (*.json)")
        if filepath:
            # DataManager debería tener un método para exportar todos los datos de un paciente
            if self.data_manager.exportar_datos_paciente_a_json(self.patient_id, filepath): # Asumir este método
                QMessageBox.information(self, "Exportación Exitosa", f"Todos los datos del paciente {self.patient_id} exportados a:\n{filepath}")
                logger.info(f"Datos completos del paciente {self.patient_id} exportados a {filepath}.")
            else:
                QMessageBox.critical(self, "Error de Exportación", "No se pudieron exportar los datos del paciente.")

    def _action_open_app_settings(self):
        # Placeholder para un futuro diálogo de configuración general de la aplicación
        QMessageBox.information(self, "Configuración", "Diálogo de configuración general de la aplicación (en desarrollo).")


    def closeEvent(self, event):
        logger.info("Cerrando Ventana Principal...")
        # Aquí se podrían añadir confirmaciones o guardados finales.
        # Asegurarse que los hilos de las sub-páginas se detengan.
        for page in self.pages_instances:
            if hasattr(page, "stop_running_threads"): # Método hipotético
                page.stop_running_threads()
            if hasattr(page, "closeEvent"): # Llamar al closeEvent de las páginas si es necesario
                 # Crear un QCloseEvent dummy si es necesario para llamar a page.closeEvent(dummy_event)
                 pass
        super().closeEvent(event)


# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Cargar estilos QSS
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss") # Ajustar ruta
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f:
            app.setStyleSheet(f.read())
            logger.info(f"Estilo QSS cargado desde: {qss_path}")

    class DummyDataManager: # Para prueba
        def __init__(self): self.pacientes = {"P001": {"dni": "P001", "nombre": "Paciente de Prueba Principal"}}
        def cargar_paciente(self, dni): return self.pacientes.get(dni)
        def guardar_datos(self, patient_id, data_type, data): pass
        def cargar_datos(self, patient_id, data_type): return None
        def exportar_datos_paciente_a_json(self, patient_id, filepath):
            if patient_id in self.pacientes:
                with open(filepath, 'w') as f: json.dump(self.pacientes[patient_id], f, indent=4); return True
            return False
        # Añadir otros métodos que las páginas puedan necesitar
        def actualizar_campo_paciente(self, patient_id, field_name, field_value): return True
        def eliminar_paciente_completo(self, patient_id): return True
        def registrar_nuevo_paciente(self, dni, data): return True
        def guardar_datos_sesion(self, patient_id, session_type, filename, data): pass
        def listar_sesiones(self, patient_id, session_type): return []
        def cargar_datos_sesion(self, patient_id, session_type, filename): return None


    dummy_dm = DummyDataManager() # type: ignore
    
    main_window = VentanaPrincipal(patient_id="P001", selected_model="random_forest", data_manager=dummy_dm)
    main_window.show()
    
    sys.exit(app.exec())
    
