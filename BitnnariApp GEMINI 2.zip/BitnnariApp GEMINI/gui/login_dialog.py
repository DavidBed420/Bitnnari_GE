"""
login_dialog.py

Módulo que define el QDialog para el inicio de sesión de usuarios (colaboradores).
Interactúa con AuthService para validar credenciales contra el backend API.
"""

import os
import sys
import logging
from typing import Optional

from PyQt6 import uic
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint
from PyQt6.QtGui import QColor, QPalette, QMovie, QPainter, QGuiApplication
from PyQt6.QtWidgets import (
    QDialog, QLineEdit, QPushButton, QLabel, QMessageBox, QApplication,
    QFrame, QVBoxLayout, QHBoxLayout, QGraphicsDropShadowEffect
)

# Importaciones de módulos del proyecto
from BitnnariApp.auth.authentication import get_auth_service, AuthService, AuthenticationError
# Reutilizar CustomTitleBar de ventana_inicio o ventana_registro si es idéntica
# o definir una específica para diálogos sin bordes.
# Por ahora, asumiré que se puede reutilizar o que el diálogo tendrá bordes estándar.
# Si se quiere sin bordes, se necesita una barra de título personalizada.
from BitnnariApp.gui.ventana_inicio import CustomTitleBarInicio # Reutilizando la de VentanaInicio

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# Ruta al archivo .ui
UI_LOGIN_DIALOG_PATH = os.path.join(os.path.dirname(__file__), "ui", "ui_login_dialog.ui")

class LoginDialog(QDialog):
    """
    Diálogo modal para el inicio de sesión de usuarios.
    """
    WINDOW_TITLE = "Iniciar Sesión - BitnariApp"

    def __init__(self, parent: Optional[QWidget] = None, use_frameless_window: bool = True):
        super().__init__(parent)
        
        self.auth_service = get_auth_service()
        self.use_frameless = use_frameless_window
        self.loading_movie: Optional[QMovie] = None
        self.original_button_text: str = ""

        if self.use_frameless:
            self._init_frameless_window_style()
            # Layout principal para ventana sin bordes
            self.base_layout = QVBoxLayout(self)
            self.base_layout.setContentsMargins(1,1,1,1) # Para el efecto de sombra
            self.base_layout.setSpacing(0)

            self.title_bar = CustomTitleBarInicio(self, self.WINDOW_TITLE) # Reutilizar o crear una específica
            self.base_layout.addWidget(self.title_bar)

            self.content_frame_login = QFrame() # Frame para el contenido y la sombra
            self.content_frame_login.setObjectName("contentFrameLoginDialog")
            uic.loadUi(UI_LOGIN_DIALOG_PATH, self.content_frame_login) # Cargar UI en el content_frame
            self.base_layout.addWidget(self.content_frame_login)
            
            self._apply_dialog_drop_shadow()
            self._setup_dialog_fade_in_animation()
        else:
            uic.loadUi(UI_LOGIN_DIALOG_PATH, self) # Cargar UI directamente en el QDialog
            self.setWindowTitle(self.WINDOW_TITLE)
            self.setModal(True)
        
        self._connect_signals()
        self._apply_styles() # Aplicar estilos adicionales si es necesario

        self.input_dni_user: QLineEdit = self.findChild(QLineEdit, "input_dni_user_login")
        self.input_password: QLineEdit = self.findChild(QLineEdit, "input_password_login")
        self.btn_login: QPushButton = self.findChild(QPushButton, "btn_login_dialog")
        self.btn_cancel: QPushButton = self.findChild(QPushButton, "btn_cancel_login_dialog")
        self.label_status_message: QLabel = self.findChild(QLabel, "label_status_message_login")

        # Foco inicial
        if self.input_dni_user:
            self.input_dni_user.setFocus()
        
        logger.info("LoginDialog inicializado.")

    def _init_frameless_window_style(self):
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        # El tamaño se define en el .ui, pero podemos reconfirmar aquí
        # self.setFixedSize(420, 320) # O usar min/max del .ui
        self._center_on_screen_dialog()

    def _center_on_screen_dialog(self):
        if self.parent():
            parent_geo = self.parent().geometry()
            self.move(parent_geo.center() - self.rect().center())
        else:
            screen_geo = QGuiApplication.primaryScreen().availableGeometry()
            self.move(screen_geo.center() - self.rect().center())
            
    def _apply_dialog_drop_shadow(self):
        if hasattr(self, 'content_frame_login'):
            shadow = QGraphicsDropShadowEffect(self)
            shadow.setBlurRadius(20)
            shadow.setXOffset(0)
            shadow.setYOffset(3)
            shadow.setColor(QColor(0,0,0,80))
            self.content_frame_login.setGraphicsEffect(shadow)

    def _setup_dialog_fade_in_animation(self):
        self.setWindowOpacity(0.0)
        self.fade_animation_dialog = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade_animation_dialog.setDuration(500)
        self.fade_animation_dialog.setStartValue(0.0)
        self.fade_animation_dialog.setEndValue(1.0)
        self.fade_animation_dialog.setEasingCurve(QEasingCurve.Type.InOutQuad)

    def showEvent(self, event):
        super().showEvent(event)
        if self.use_frameless and hasattr(self, 'fade_animation_dialog'):
             if self.windowOpacity() < 0.1: # Evitar re-animar
                self.fade_animation_dialog.start()
        elif not self.use_frameless: # Para diálogo estándar, asegurar que esté centrado
            self._center_on_screen_dialog()


    def _connect_signals(self):
        btn_login = self.findChild(QPushButton, "btn_login_dialog")
        if btn_login:
            btn_login.clicked.connect(self._attempt_login)
        
        btn_cancel = self.findChild(QPushButton, "btn_cancel_login_dialog")
        if btn_cancel:
            btn_cancel.clicked.connect(self.reject) # QDialog.reject() cierra y retorna QDialog.DialogCode.Rejected

        input_password = self.findChild(QLineEdit, "input_password_login")
        if input_password:
            input_password.returnPressed.connect(self._attempt_login)
        
        input_dni = self.findChild(QLineEdit, "input_dni_user_login")
        if input_dni:
            input_dni.returnPressed.connect(lambda: self.input_password.setFocus() if self.input_password else None)


    def _apply_styles(self):
        """Aplica estilos QSS específicos si no se manejan globalmente o para fine-tuning."""
        # Ejemplo de estilo para el mensaje de error
        status_label = self.findChild(QLabel, "label_status_message_login")
        if status_label:
            # El objectName "statusMessageLabel" puede ser usado en el QSS global
            # Pero aquí podemos asegurar un estilo base:
            status_label.setStyleSheet("color: red; font-weight: bold;")
            status_label.setText("") # Limpiar al inicio
            
        # Estilo para botones si no se usa QSS global o para sobrescribir
        # for btn_name in ["btn_login_dialog", "btn_cancel_login_dialog"]:
        #     btn = self.findChild(QPushButton, btn_name)
        #     if btn:
        #         btn.setFixedHeight(35)

    def _show_loading_state(self, loading: bool):
        """Muestra/oculta un indicador de carga en el botón de login."""
        if not self.btn_login: return

        if loading:
            self.original_button_text = self.btn_login.text()
            self.btn_login.setText("Autenticando...")
            # Podríamos añadir un QMovie (GIF animado) al botón
            # if self.loading_movie is None:
            #     # Asumiendo que tienes un GIF de carga en resources/icons
            #     movie_path = os.path.join(os.path.dirname(__file__), "..", "resources", "icons", "loading_spinner.gif")
            #     if os.path.exists(movie_path):
            #         self.loading_movie = QMovie(movie_path)
            #         self.loading_movie.setScaledSize(QSize(20,20)) # Ajustar tamaño
            #         # Necesitaríamos un QLabel para el movie dentro del botón o al lado.
            #         # Esto complica el layout del botón.
            #         # Por ahora, solo cambiar texto.
            self.btn_login.setEnabled(False)
            self.btn_cancel.setEnabled(False)
            self.input_dni_user.setEnabled(False)
            self.input_password.setEnabled(False)
        else:
            if self.original_button_text:
                self.btn_login.setText(self.original_button_text)
            self.btn_login.setEnabled(True)
            self.btn_cancel.setEnabled(True)
            self.input_dni_user.setEnabled(True)
            self.input_password.setEnabled(True)


    def _attempt_login(self):
        if not self.input_dni_user or not self.input_password or not self.label_status_message or not self.btn_login:
            logger.error("Widgets de login no encontrados. UI no cargada correctamente.")
            QMessageBox.critical(self, "Error Interno", "La interfaz de login no se cargó correctamente.")
            return

        dni = self.input_dni_user.text().strip().upper() # El backend espera DNI en mayúsculas
        password = self.input_password.text()

        if not dni or not password:
            self.label_status_message.setText("Por favor, ingrese DNI y contraseña.")
            return

        self.label_status_message.setText("") # Limpiar mensajes anteriores
        self._show_loading_state(True)

        # Usar un QTimer para realizar la llamada de red en el hilo principal pero
        # permitiendo que la UI se actualice (para el estado de carga).
        # Una solución más robusta para llamadas de red largas sería un QThread.
        # Pero para un login, un QTimer que llame a una función que hace la request
        # y luego procesa el resultado es a menudo suficiente si la request es rápida.
        # Aquí, como AuthService.login es síncrono, el QTimer solo retrasa la llamada.
        # La UI se bloqueará durante la llamada de red.
        # Para una mejor UX, AuthService.login debería ser asíncrono o ejecutarse en un QThread.
        
        # Por ahora, llamada síncrona simple:
        QApplication.processEvents() # Procesar eventos para mostrar "Autenticando..."
        
        success, result_or_message = self.auth_service.login(dni, password)
        
        self._show_loading_state(False)

        if success:
            logger.info(f"Login exitoso para {dni} desde LoginDialog.")
            self.accept() # Cierra el diálogo y retorna QDialog.DialogCode.Accepted
        else:
            self.label_status_message.setText(result_or_message)
            self.input_password.clear() # Limpiar contraseña en caso de fallo
            self.input_password.setFocus()
            logger.warning(f"Login fallido para {dni} desde LoginDialog: {result_or_message}")
            
    def keyPressEvent(self, event: QEvent.Type.KeyPress): # Corrección de tipo de evento
        if event.key() == Qt.Key.Key_Escape:
            self.reject() # Cancelar con Escape
        else:
            super().keyPressEvent(event)

# Ejemplo de Uso (para probar el diálogo standalone)
if __name__ == "__main__":
    # Necesario para que QMovie funcione correctamente si se usa
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)
    app = QApplication(sys.argv)

    # Cargar estilos QSS (si existe)
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
            logger.info(f"Estilo QSS cargado desde: {qss_path}")

    # Para probar, el backend FastAPI debe estar corriendo en BACKEND_API_URL
    # y tener un usuario ADMIN001 con contraseña admin123
    dialog = LoginDialog(use_frameless_window=True) # Probar con y sin ventana sin bordes
    
    # Conectar la señal accepted para saber si el login fue exitoso
    def handle_login_success():
        print("LoginDialog aceptado (login exitoso).")
        token = get_auth_service().get_current_user_token()
        print(f"Token obtenido: {token[:30]}...")
        # Aquí, la MainApplicationWindow procedería a mostrar la siguiente pantalla.
        app.quit() # Salir de la app de prueba

    def handle_login_rejected():
        print("LoginDialog rechazado (cancelado o cerrado).")
        app.quit()

    dialog.accepted.connect(handle_login_success)
    dialog.rejected.connect(handle_login_rejected)
    
    dialog.show()
    sys.exit(app.exec())
    