      """
ventana_inicio.py

Pantalla de inicio y búsqueda de pacientes para la aplicación EMG.
Presenta una interfaz moderna para que el usuario ingrese el DNI de un paciente
o acceda al formulario de registro.

Características Principales:
- Diseño Moderno: Ventana sin bordes, fondo translúcido, efecto drop shadow.
- Barra de Título Personalizada: Incluye título y botones de minimizar/cerrar,
  y permite mover la ventana.
- Búsqueda de Paciente:
    - Campo de entrada para DNI con formateo automático (puntos y guion).
    - Al buscar, consulta GestorDatos.
- Diálogo de Selección de Modelo: Si se encuentra un paciente, se presenta un
  diálogo para seleccionar el modelo de ML a utilizar con ese paciente.
- Navegación:
    - Si el paciente se encuentra, navega a la VentanaPrincipal (tratamiento).
    - Opción para navegar a VentanaRegistro.
- Experiencia de Usuario:
    - Animación de "fade in".
    - Atajos de teclado: Esc (Cerrar), Ctrl+F (Buscar), Ctrl+R (Registrar).
    - Tooltips informativos.
- Integración con GestorDatos: Para buscar pacientes y actualizar su modelo ML.
- Logging: Registro de acciones y errores.
- Estilo: Diseñado para ser compatible con un QSS global.
"""

import os
import sys
import logging
from datetime import datetime
from typing import Optional, Dict, Any

from PyQt6.QtCore import (
    Qt, QRegularExpression, QTimer, QEvent, QPoint,
    QPropertyAnimation, QSize, QEasingCurve
)
from PyQt6.QtGui import (
    QRegularExpressionValidator, QFont, QColor, QPainter, QGuiApplication,
    QShortcut, QKeySequence, QIcon, QPixmap
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QFormLayout,
    QMessageBox, QComboBox, QLineEdit, QHBoxLayout,
    QStackedWidget, QSizePolicy, QGraphicsDropShadowEffect, QGroupBox,
    QDialog, QDialogButtonBox
)

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos
# Las ventanas a las que navega se importarán dinámicamente o se asumirá que
# el QStackedWidget las gestiona por índice o nombre de objeto.
# from BitnnariApp.gui.ventana_registro import VentanaRegistro # Evitar importación circular si es posible
# from BitnnariApp.gui.ventana_principal import VentanaPrincipal

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Reutilizar CustomTitleBar de ventana_registro o definirla aquí si es independiente
# Por simplicidad, la redefiniré aquí con pequeñas adaptaciones si es necesario.
class CustomTitleBarInicio(QFrame): # Renombrada para evitar colisión si se importan ambas
    """Barra de título personalizada para la ventana de inicio."""
    def __init__(self, parent_window: QWidget, title: str = "Bienvenido"):
        super().__init__(parent_window)
        self.parent_window = parent_window
        self.setObjectName("customTitleBar")
        self.setFixedHeight(40)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 5, 0)
        layout.setSpacing(5)

        # Icono de la app (opcional)
        # app_icon_path = os.path.join(os.path.dirname(__file__), "..", "resources", "icons", "app_logo_simple.png") # Ajustar ruta
        # if os.path.exists(app_icon_path):
        #     app_icon_label = QLabel()
        #     app_icon_label.setPixmap(QPixmap(app_icon_path).scaled(24, 24, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        #     layout.addWidget(app_icon_label)

        self.title_label = QLabel(title)
        self.title_label.setObjectName("titleBarLabel")
        layout.addWidget(self.title_label)
        layout.addStretch()

        self.btn_minimize = QPushButton("—")
        self.btn_minimize.setObjectName("minimizeButton")
        self.btn_minimize.setFixedSize(30, 30); self.btn_minimize.setToolTip("Minimizar")
        self.btn_minimize.clicked.connect(self.parent_window.showMinimized)
        layout.addWidget(self.btn_minimize)

        self.btn_close = QPushButton("✕")
        self.btn_close.setObjectName("closeButton")
        self.btn_close.setFixedSize(30, 30); self.btn_close.setToolTip("Cerrar")
        self.btn_close.clicked.connect(self.parent_window.close)
        layout.addWidget(self.btn_close)

        self._mouse_press_pos: Optional[QPoint] = None
        self._mouse_move_pos: Optional[QPoint] = None

    def mousePressEvent(self, event: QEvent.Type.MouseButtonPress):
        if event.button() == Qt.MouseButton.LeftButton:
            self._mouse_press_pos = event.globalPosition().toPoint()
            self._mouse_move_pos = self.parent_window.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QEvent.Type.MouseMove):
        if self._mouse_press_pos is not None and event.buttons() & Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._mouse_press_pos
            self.parent_window.move(self._mouse_move_pos + diff)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QEvent.Type.MouseButtonRelease):
        self._mouse_press_pos = None; self._mouse_move_pos = None
        super().mouseReleaseEvent(event)


class ModeloSeleccionDialog(QDialog):
    """Diálogo para seleccionar el modelo de ML para un paciente."""
    def __init__(self, paciente_nombre: str, modelos_disponibles: List[str], modelo_actual: Optional[str] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle(f"Seleccionar Modelo para {paciente_nombre}")
        self.setMinimumWidth(350)
        self.setModal(True) # Bloquea la ventana principal

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Paciente: {paciente_nombre}"))
        
        form_layout = QFormLayout()
        self.combo_modelo = QComboBox()
        self.combo_modelo.addItems(modelos_disponibles)
        if modelo_actual and modelo_actual in modelos_disponibles:
            self.combo_modelo.setCurrentText(modelo_actual)
        form_layout.addRow("Modelo de Clasificación:", self.combo_modelo)
        layout.addLayout(form_layout)

        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)
        
        self.setStyleSheet("""
            QDialog { background-color: #2a2a38; color: #e0e0e0; border-radius: 8px; }
            QLabel { color: #c0c0c0; font-size: 10pt; margin-bottom: 3px;}
            QComboBox { background-color: #353545; color: #e0e0e0; border: 1px solid #4a4a5a; padding: 6px; border-radius: 4px; font-size: 10pt;}
            QComboBox QAbstractItemView { background-color: #353545; color: #e0e0e0; selection-background-color: #5a6578; }
            QPushButton { background-color: #4a5568; color: white; padding: 8px 15px; border-radius: 4px; font-size: 10pt;}
            QPushButton:hover { background-color: #5a6578; }
        """)

    def get_selected_model(self) -> str:
        return self.combo_modelo.currentText()


class VentanaInicio(QWidget):
    """Pantalla de inicio de la aplicación."""
    WINDOW_TITLE = "BitnariApp - Inicio"

    # Índices o nombres de objeto de las páginas en el QStackedWidget principal
    # Estos deben coincidir con cómo se añaden en la ventana contenedora (e.g., run_app.py)
    PAGINA_REGISTRO_KEY = "Registro" # O un índice numérico
    PAGINA_TRATAMIENTO_KEY = "Tratamiento" # O un índice numérico

    def __init__(self, stacked_widget: QStackedWidget, data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.stacked_widget = stacked_widget
        self.data_manager = data_manager

        self._init_window_style()
        
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(1,1,1,1) # Para sombra
        self.main_layout.setSpacing(0)

        self.title_bar = CustomTitleBarInicio(self, self.WINDOW_TITLE)
        self.main_layout.addWidget(self.title_bar)

        self.content_frame = QFrame()
        self.content_frame.setObjectName("contentFrameInicio")
        content_layout_internal = QVBoxLayout(self.content_frame)
        content_layout_internal.setContentsMargins(30, 25, 30, 30)
        content_layout_internal.setSpacing(20)
        self.main_layout.addWidget(self.content_frame)

        self._init_ui_content(content_layout_internal)
        self._apply_drop_shadow()
        self._setup_fade_in_animation()
        self._setup_shortcuts()

        logger.info("Ventana de Inicio inicializada.")

    def _init_window_style(self):
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setMinimumSize(500, 350)
        self.resize(600, 400)
        self._center_on_screen()

    def _center_on_screen(self):
        screen_geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(screen_geo.center() - self.rect().center())

    def _apply_drop_shadow(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(30); shadow.setXOffset(0); shadow.setYOffset(5)
        shadow.setColor(QColor(0,0,0,90)); self.content_frame.setGraphicsEffect(shadow)

    def _setup_fade_in_animation(self):
        self.setWindowOpacity(0.0)
        self.fade_animation = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade_animation.setDuration(700); self.fade_animation.setStartValue(0.0)
        self.fade_animation.setEndValue(1.0); self.fade_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

    def showEvent(self, event):
        super().showEvent(event)
        if self.windowOpacity() < 0.1: self.fade_animation.start()

    def _setup_shortcuts(self):
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, self.close)
        QShortcut(QKeySequence("Ctrl+F"), self, lambda: self.input_dni_inicio.setFocus())
        QShortcut(QKeySequence("Ctrl+R"), self, self._go_to_registration_page)

    def _init_ui_content(self, parent_layout: QVBoxLayout):
        """Inicializa el contenido de la ventana de inicio."""
        
        # Título y Logo (Opcional)
        header_layout = QHBoxLayout()
        # logo_path = os.path.join(os.path.dirname(__file__), "..", "resources", "icons", "app_logo_large.png")
        # if os.path.exists(logo_path):
        #     logo_label = QLabel(); logo_label.setPixmap(QPixmap(logo_path).scaled(80,80, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        #     header_layout.addWidget(logo_label)
        
        title_label = QLabel("Bienvenido a BitnariApp")
        title_label.setObjectName("mainTitleInicio")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title_label, stretch=1)
        parent_layout.addLayout(header_layout)
        parent_layout.addSpacing(15)

        # Grupo de Búsqueda de Paciente
        search_group = QGroupBox("Acceder a Paciente")
        search_form = QFormLayout(search_group)
        self.input_dni_inicio = QLineEdit()
        self.input_dni_inicio.setPlaceholderText("Ingrese DNI del paciente")
        self.input_dni_inicio.setToolTip("Formato: números, opcionalmente con puntos y guion final.")
        self.input_dni_inicio.textChanged.connect(self._format_dni_text_inicio)
        self.input_dni_inicio.returnPressed.connect(self._search_patient_action) # Enter para buscar
        search_form.addRow("🔍 DNI:", self.input_dni_inicio)
        
        self.btn_search_patient = QPushButton("Buscar Paciente")
        self.btn_search_patient.setObjectName("primaryButton")
        self.btn_search_patient.clicked.connect(self._search_patient_action)
        search_form.addRow(self.btn_search_patient)
        parent_layout.addWidget(search_group)
        
        parent_layout.addStretch(1) # Espacio flexible

        # Botón para Registrar Nuevo Paciente
        self.btn_go_to_register = QPushButton("➕ Registrar Nuevo Paciente")
        self.btn_go_to_register.setObjectName("secondaryButton")
        self.btn_go_to_register.setFixedHeight(40)
        self.btn_go_to_register.clicked.connect(self._go_to_registration_page)
        parent_layout.addWidget(self.btn_go_to_register)

    def _format_dni_text_inicio(self):
        # Reutilizar la lógica de formateo de VentanaRegistro si es idéntica
        # o adaptarla si hay diferencias.
        dni_input = self.input_dni_inicio
        current_text = dni_input.text()
        original_cursor_pos = dni_input.cursorPosition()
        
        clean_dni = "".join(filter(str.isdigit, current_text.split('-')[0]))
        verifier = current_text.split('-')[-1] if '-' in current_text and current_text.split('-')[-1] else ""

        formatted_dni = ""
        if clean_dni:
            if len(clean_dni) > 3:
                parts = [clean_dni[max(0, i-3):i] for i in range(len(clean_dni), 0, -3)]
                formatted_dni = ".".join(reversed(parts))
            else:
                formatted_dni = clean_dni
        
        if verifier and (verifier.isdigit() or verifier.upper() == 'K'):
            formatted_dni += "-" + verifier.upper()
        elif '-' in current_text and not verifier:
             formatted_dni += "-"

        dni_input.blockSignals(True)
        dni_input.setText(formatted_dni)
        dni_input.blockSignals(False)
        dni_input.setCursorPosition(len(formatted_dni)) # Simplificado


    def _search_patient_action(self):
        dni_raw = self.input_dni_inicio.text().strip()
        if not dni_raw:
            QMessageBox.warning(self, "DNI Requerido", "Por favor, ingrese un DNI para buscar.")
            return

        dni_db = dni_raw.replace(".", "") # DNI limpio para búsqueda
        
        logger.info(f"Buscando paciente con DNI: {dni_db}")
        patient_data = self.data_manager.cargar_paciente(dni_db)

        if patient_data:
            logger.info(f"Paciente encontrado: {patient_data.get('nombre', dni_db)}")
            self.data_manager.set_active_patient(patient_data) # Establecer paciente activo en GestorDatos

            # Diálogo para seleccionar modelo ML
            modelos_disponibles = list(DEFAULT_CLASSIFICATION_CONFIG["model_hyperparameters"].keys())
            modelo_actual = patient_data.get("modelo_ml_preferido", modelos_disponibles[0])
            
            dialog = ModeloSeleccionDialog(patient_data.get('nombre', dni_db), modelos_disponibles, modelo_actual, self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                selected_model = dialog.get_selected_model()
                # Guardar el modelo seleccionado para el paciente
                if self.data_manager.actualizar_campo_paciente(dni_db, "modelo_ml_preferido", selected_model):
                    logger.info(f"Modelo ML '{selected_model}' seleccionado para paciente {dni_db}.")
                else:
                    logger.warning(f"No se pudo guardar el modelo ML seleccionado para {dni_db}.")
                
                self._go_to_main_treatment_page(dni_db, selected_model)
            else:
                logger.info("Selección de modelo cancelada por el usuario.")
        else:
            logger.warning(f"Paciente con DNI {dni_db} no encontrado.")
            confirm_register = QMessageBox.question(self, "Paciente No Encontrado",
                                                  f"El paciente con DNI '{dni_raw}' no está registrado.\n"
                                                  "¿Desea registrarlo ahora?",
                                                  QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                                  QMessageBox.StandardButton.Yes)
            if confirm_register == QMessageBox.StandardButton.Yes:
                self._go_to_registration_page(dni_to_prefill=dni_raw)


    def _go_to_registration_page(self, dni_to_prefill: Optional[str] = None):
        logger.info("Navegando a la página de registro.")
        if self.stacked_widget:
            # Encontrar la instancia de VentanaRegistro en el stack
            for i in range(self.stacked_widget.count()):
                widget = self.stacked_widget.widget(i)
                # Asumir que VentanaRegistro es importada y se puede chequear su tipo
                # from BitnnariApp.gui.ventana_registro import VentanaRegistro
                # if isinstance(widget, VentanaRegistro):
                # Necesitamos una forma más genérica si no queremos importación directa aquí
                if widget.objectName() == "ventanaRegistro": # Asumir que se le puso objectName
                    if dni_to_prefill:
                        widget.input_dni.setText(dni_to_prefill) # Pre-llenar DNI
                        widget.paciente_dni_para_edicion = None # Asegurar modo nuevo registro
                        widget.title_bar.setTitle(widget.WINDOW_TITLE)
                    self.stacked_widget.setCurrentWidget(widget)
                    return
            logger.warning("No se encontró la instancia de VentanaRegistro en el QStackedWidget.")
            # Como fallback, si no se encuentra, podría intentar crear una nueva, pero es mejor que esté pre-cargada.
        else:
            # Si no hay QStackedWidget, podría abrirse como diálogo modal (menos ideal para flujo principal)
            # from BitnnariApp.gui.ventana_registro import VentanaRegistro
            # self.registro_window = VentanaRegistro(None, self.data_manager) # No stack
            # if dni_to_prefill: self.registro_window.input_dni.setText(dni_to_prefill)
            # self.registro_window.show()
            pass


    def _go_to_main_treatment_page(self, patient_dni: str, selected_model: str):
        logger.info(f"Navegando a la página principal de tratamiento para {patient_dni} con modelo {selected_model}.")
        if self.stacked_widget:
            # Encontrar la instancia de VentanaPrincipal
            for i in range(self.stacked_widget.count()):
                widget = self.stacked_widget.widget(i)
                # from BitnnariApp.gui.ventana_principal import VentanaPrincipal
                # if isinstance(widget, VentanaPrincipal):
                if widget.objectName() == "ventanaPrincipal": # Asumir objectName
                    widget.update_for_patient(patient_dni, selected_model) # Método para actualizarla
                    self.stacked_widget.setCurrentWidget(widget)
                    return
            logger.warning("No se encontró la instancia de VentanaPrincipal en el QStackedWidget.")
        else:
            # from BitnnariApp.gui.ventana_principal import VentanaPrincipal
            # self.main_window = VentanaPrincipal(patient_dni, selected_model) # No stack
            # self.main_window.show()
            # self.close() # Cerrar ventana de inicio
            pass

# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f: app.setStyleSheet(f.read())

    class DummyDataManager: # Para prueba
        def __init__(self): self.pacientes = {"12345678-9": {"dni": "12345678-9", "nombre": "Paciente Prueba"}}
        def cargar_paciente(self, dni): return self.pacientes.get(dni)
        def set_active_patient(self, data): pass
        def actualizar_campo_paciente(self, dni, campo, valor): self.pacientes[dni][campo] = valor; return True

    dummy_dm = DummyDataManager() # type: ignore
    
    # Simular el QStackedWidget de la aplicación principal
    main_stack = QStackedWidget()
    
    # Crear e añadir las páginas que VentanaInicio necesita para navegar
    # (esto normalmente se haría en run_app.py o similar)
    # from BitnnariApp.gui.ventana_registro import VentanaRegistro
    # from BitnnariApp.gui.ventana_principal import VentanaPrincipal
    
    # Para evitar importaciones circulares en el ejemplo, creamos dummies rápidos
    class DummyRegistro(QWidget): 
        objectName = "ventanaRegistro"
        def __init__(self, s, d): super().__init__(); self.input_dni = QLineEdit() # Dummy
    class DummyPrincipal(QWidget): 
        objectName = "ventanaPrincipal"
        def __init__(self, p, m): super().__init__() # Dummy
        def update_for_patient(self, p, m): pass

    ventana_inicio = VentanaInicio(stacked_widget=main_stack, data_manager=dummy_dm)
    # ventana_registro_dummy = DummyRegistro(main_stack, dummy_dm)
    # ventana_principal_dummy = DummyPrincipal("dummy_id", "dummy_model")
    
    # main_stack.addWidget(ventana_inicio)
    # main_stack.addWidget(ventana_registro_dummy)
    # main_stack.addWidget(ventana_principal_dummy)
    # main_stack.setCurrentWidget(ventana_inicio)
    # main_stack.show() # Mostrar el stack si es la ventana principal
    
    # O mostrar VentanaInicio directamente si se prueba aislada y el stack no es el principal
    ventana_inicio.show()
    
    sys.exit(app.exec())
    
