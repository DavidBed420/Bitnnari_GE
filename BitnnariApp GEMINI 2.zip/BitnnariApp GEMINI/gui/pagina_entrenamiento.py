"""
pagina_entrenamiento.py

Módulo de la interfaz gráfica para el entrenamiento de modelos de clasificación EMG.
Permite configurar el modelo, adquirir datos de entrenamiento (incluyendo tiempo real),
entrenar el modelo y visualizar los resultados.

Características Principales:
- Selección de Modelo: Permite elegir entre varios algoritmos (Random Forest, SVM, MLP, XGBoost, DNN PyTorch).
- Configuración de Parámetros: Editor JSON para hiperparámetros del modelo y opciones de entrenamiento.
- Adquisición de Datos de Entrenamiento:
    - Carga de datos existentes (asociados al paciente).
    - Adquisición en tiempo real de nuevas muestras con etiquetado manual.
- Integración de "Finger Data": Campos para ingresar datos de ángulo y fuerza de los dedos.
- Preprocesamiento Configurable: Opciones para aplicar calibración y procesamiento de características.
- Entrenamiento Asíncrono: El proceso de entrenamiento se ejecuta en un QThread.
- Visualización de Señal en Tiempo Real: Gráfico para mostrar la señal EMG durante la adquisición.
- Visualización de Resultados:
    - Métricas de rendimiento (accuracy, F1, etc.).
    - Matriz de confusión.
    - Curva ROC (para clasificadores binarios).
- Persistencia:
    - Guarda la configuración de entrenamiento.
    - Los modelos y métricas se guardan a través de EMGClassificationEngine.
- Estilo: Compatible con QSS global (objeto principal nombrado "paginaEntrenamiento").
"""

import os
import sys
import json
import logging
from typing import Optional, Dict, Any, List, Tuple

import numpy as np
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QColor
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar,
    QComboBox, QFileDialog, QTextEdit, QGroupBox, QGridLayout, QLineEdit,
    QFormLayout, QTabWidget, QMessageBox, QDoubleSpinBox, QSpinBox,
    QSizePolicy
)
import pyqtgraph as pg

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.acquisition.emg_adquisition import (
    EMGAcquisition, SerialConfig as EMGSerialConfig,
    AcquisitionConfig as EMGDeviceAcqConfig, FilterConfig as EMGFilterConfig,
    LogConfig as EMGLogConfig
)
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager, CalibrationRunConfig
from BitnnariApp.processing.emg_processing import EMGProcessingEngine
from BitnnariApp.classification.emg_classification import EMGClassificationEngine, DEFAULT_CLASSIFICATION_CONFIG

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


# Hilo para adquisición en tiempo real durante el entrenamiento
class TrainingDataAcquisitionThread(QThread):
    """Hilo para adquirir datos EMG en tiempo real para etiquetado y entrenamiento."""
    new_sample_acquired = pyqtSignal(np.ndarray) # Emite la muestra cruda adquirida
    acquisition_finished = pyqtSignal(list)     # Emite la lista de todas las muestras recolectadas
    progress_update = pyqtSignal(int, int)      # Emite (muestras_actuales, muestras_totales)

    def __init__(self,
                 emg_acquirer: EMGAcquisition,
                 duration_s: float,
                 samples_per_second: float, # Frecuencia de muestreo efectiva
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.emg_acquirer = emg_acquirer
        self.duration_s = duration_s
        self.samples_per_second = samples_per_second # Puede ser diferente al sample_rate del HW si se hace downsampling
        self.total_samples_to_acquire = int(duration_s * samples_per_second)
        self._is_running = False
        self.collected_samples: List[np.ndarray] = []

    def run(self):
        self._is_running = True
        self.collected_samples = []
        samples_collected_count = 0
        
        if not self.emg_acquirer.is_connected():
            if not self.emg_acquirer.connect():
                logger.error("No se pudo conectar al dispositivo EMG para adquirir datos de entrenamiento.")
                self.acquisition_finished.emit([])
                return

        # Asegurar modo continuo
        original_mode = self.emg_acquirer.acq_config.mode
        self.emg_acquirer.set_mode('continuous')

        start_time = time.time()
        next_sample_time = time.time()

        while self._is_running and samples_collected_count < self.total_samples_to_acquire:
            if time.time() < next_sample_time:
                time.sleep(max(0, next_sample_time - time.time())) # Espera precisa
            
            packet = self.emg_acquirer.read_data() # Esto ya maneja el buffer y el protocolo
            if packet and 'raw_data' in packet:
                raw_sample = np.array(packet['raw_data'])
                self.collected_samples.append(raw_sample)
                self.new_sample_acquired.emit(raw_sample)
                samples_collected_count += 1
                self.progress_update.emit(samples_collected_count, self.total_samples_to_acquire)
            
            next_sample_time += (1.0 / self.samples_per_second)
            
            # Check de duración total por si el bucle de tiempo es más lento
            if (time.time() - start_time) >= self.duration_s:
                break
        
        self.emg_acquirer.set_mode(original_mode) # Restaurar modo
        self.acquisition_finished.emit(self.collected_samples)
        self._is_running = False

    def stop(self):
        self._is_running = False


# Hilo para el proceso de entrenamiento del modelo
class ModelTrainingThread(QThread):
    """Hilo para ejecutar el entrenamiento del modelo sin bloquear la UI."""
    training_progress = pyqtSignal(int, str) # progreso (0-100), mensaje
    training_finished = pyqtSignal(bool, str, dict, dict) # success, message, metrics, best_params

    def __init__(self,
                 classification_engine: EMGClassificationEngine,
                 model_name: str,
                 training_options: Dict[str, Any],
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine = classification_engine
        self.model_name = model_name
        self.training_options = training_options

    def run(self):
        try:
            self.training_progress.emit(5, f"Iniciando entrenamiento para {self.model_name}...")
            
            # Simular progreso durante el entrenamiento
            # En una implementación real, EMGClassificationEngine.train_model podría tener un callback de progreso
            # o se podría estimar basado en etapas.
            # Aquí, solo actualizamos en puntos clave.
            
            # Placeholder para simular que _get_training_data toma tiempo
            # self.training_progress.emit(15, "Obteniendo datos de entrenamiento...")
            # time.sleep(0.5) 
            
            # Placeholder para simular que _preprocess_data_for_training toma tiempo
            # self.training_progress.emit(30, "Preprocesando datos...")
            # time.sleep(0.5)

            # El entrenamiento real
            success, msg, metrics, best_params = self.engine.train_model(self.model_name, self.training_options)
            
            if success:
                self.training_progress.emit(100, "Entrenamiento completado.")
            else:
                self.training_progress.emit(0, f"Fallo en entrenamiento: {msg}")

            self.training_finished.emit(success, msg, metrics or {}, best_params or {})

        except Exception as e:
            logger.error(f"Excepción en ModelTrainingThread: {e}", exc_info=True)
            self.training_finished.emit(False, f"Error crítico durante el entrenamiento: {e}", {}, {})


class TrainingPage(QWidget):
    """Página de la GUI para el entrenamiento de modelos de clasificación EMG."""

    def __init__(self,
                 data_manager: GestorDatos,
                 patient_id: str, # Modelo no se pasa aquí, se selecciona en la UI
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("paginaEntrenamiento")

        self.data_manager = data_manager
        self.patient_id = patient_id
        
        # Cargar configuración específica de la página de entrenamiento
        self.page_config = self._load_or_default_page_config()

        # Instancias de los motores y managers
        # EMG Acquirer se inicializará cuando sea necesario para la adquisición de datos de entrenamiento
        self.emg_acquirer: Optional[EMGAcquisition] = None
        self.calibration_manager = EMGCalibrationManager(data_manager=self.data_manager, patient_id=self.patient_id)
        
        # El sampling rate para el processing engine se tomará de la config de adquisición
        # o de la config de la página si no hay adquisición activa.
        fs_initial = self.page_config.get("acquisition_config", {}).get("sampling_rate_hz", 1000.0)
        self.processing_engine = EMGProcessingEngine(sampling_rate=fs_initial, data_manager=self.data_manager, patient_id=self.patient_id)
        
        self.classification_engine = EMGClassificationEngine(data_manager=self.data_manager, patient_id=self.patient_id)
        self.classification_engine.set_dependencies(
            calibration_manager=self.calibration_manager,
            processing_engine=self.processing_engine
        ) # EMGAcquirer se setea dinámicamente si se usa RT

        # Atributos para hilos y datos
        self.training_data_acq_thread: Optional[TrainingDataAcquisitionThread] = None
        self.model_training_thread: Optional[ModelTrainingThread] = None
        self.current_training_samples: List[np.ndarray] = []
        self.current_training_label: int = 0

        self._plot_curves_rt_acq: Dict[int, pg.PlotDataItem] = {}

        self._init_ui()
        self._connect_signals()
        self._apply_initial_page_config()
        self._load_patient_training_data_summary() # Mostrar info de datos existentes

        logger.info(f"Página de Entrenamiento inicializada para paciente: {self.patient_id}")

    def _load_or_default_page_config(self) -> Dict[str, Any]:
        page_conf_key = "training_page_config"
        conf = self.data_manager.cargar_datos(self.patient_id, page_conf_key)
        
        # Crear una copia profunda de los defaults para evitar modificar el original
        default_conf = json.loads(json.dumps(DEFAULT_CLASSIFICATION_CONFIG))
        default_conf.update({ # Añadir parámetros específicos de la página de entrenamiento
            "acquisition_config": { # Config para cuando se adquieren datos desde esta página
                "serial_port": None, "baud_rate": 115200, "num_channels": 2,
                "sampling_rate_hz": 1000, "delay_ms": 10, # delay_ms = 1000/sampling_rate
                "duration_s_per_label": 5.0,
                "current_label_for_rt_acq": 0
            },
            "training_options": { # Opciones que se pasarán a EMGClassificationEngine.train_model
                "apply_calibration": True,
                "apply_feature_processing": True, # Asume que los datos adquiridos son crudos
                "apply_smote": True,
                "finger_data_enabled": False
            },
            "selected_model_name": "random_forest"
        })

        if conf and isinstance(conf, dict):
            # Fusión cuidadosa para mantener la estructura de los defaults
            for key, default_value in default_conf.items():
                if key in conf:
                    if isinstance(default_value, dict) and isinstance(conf[key], dict):
                        default_value.update(conf[key]) # Fusionar sub-diccionarios
                    else:
                        default_conf[key] = conf[key] # Sobrescribir si no es dict o tipos no coinciden
            logger.info(f"Configuración de página de entrenamiento cargada para {self.patient_id}.")
            return default_conf
        else:
            logger.info(f"Usando config por defecto para página de entrenamiento (paciente {self.patient_id}).")
            self.data_manager.guardar_datos(self.patient_id, page_conf_key, default_conf)
            return default_conf

    def _save_page_config(self):
        self._update_page_config_from_ui()
        page_conf_key = "training_page_config"
        self.data_manager.guardar_datos(self.patient_id, page_conf_key, self.page_config)
        logger.info(f"Configuración de página de entrenamiento guardada para {self.patient_id}.")

    def _update_page_config_from_ui(self):
        """Actualiza self.page_config con los valores de la UI."""
        # Adquisición
        acq_conf = self.page_config["acquisition_config"]
        acq_conf["serial_port"] = self.findChild(QComboBox, "combo_serial_port_train").currentData()
        acq_conf["baud_rate"] = int(self.findChild(QComboBox, "combo_baud_rate_train").currentText())
        acq_conf["num_channels"] = self.findChild(QSpinBox, "spin_num_channels_train").value()
        acq_conf["sampling_rate_hz"] = self.findChild(QSpinBox, "spin_sampling_rate_train").value()
        acq_conf["delay_ms"] = int(1000.0 / acq_conf["sampling_rate_hz"]) if acq_conf["sampling_rate_hz"] > 0 else 10
        acq_conf["duration_s_per_label"] = self.findChild(QDoubleSpinBox, "spin_duration_rt_acq").value()
        acq_conf["current_label_for_rt_acq"] = self.findChild(QSpinBox, "spin_current_label_rt_acq").value()

        # Opciones de Entrenamiento
        train_opts = self.page_config["training_options"]
        train_opts["apply_calibration"] = self.findChild(QCheckBox, "check_apply_calibration_train").isChecked()
        train_opts["apply_feature_processing"] = self.findChild(QCheckBox, "check_apply_processing_train").isChecked()
        train_opts["apply_smote"] = self.findChild(QCheckBox, "check_apply_smote_train").isChecked()
        train_opts["finger_data_enabled"] = self.findChild(QCheckBox, "check_use_finger_data").isChecked()
        
        # Modelo y Parámetros
        self.page_config["selected_model_name"] = self.findChild(QComboBox, "model_selector_train").currentText()
        try:
            # Guardar los parámetros del modelo que están en el editor de texto
            # Estos son los que usa EMGClassificationEngine, no los de la página.
            self.page_config["model_hyperparameters"] = json.loads(self.findChild(QTextEdit, "params_editor_train").toPlainText())
        except json.JSONDecodeError:
            logger.warning("Contenido del editor de parámetros no es JSON válido. No se guardó esa parte.")
            # Mantener los params anteriores o defaults si es la primera vez.
            if "model_hyperparameters" not in self.page_config:
                 self.page_config["model_hyperparameters"] = DEFAULT_CLASSIFICATION_CONFIG["model_hyperparameters"]


    def _apply_initial_page_config(self):
        """Aplica la configuración cargada a los widgets de la UI."""
        # Adquisición
        acq_conf = self.page_config["acquisition_config"]
        self._update_serial_ports_train()
        if acq_conf["serial_port"]:
            idx = self.findChild(QComboBox, "combo_serial_port_train").findData(acq_conf["serial_port"])
            if idx != -1: self.findChild(QComboBox, "combo_serial_port_train").setCurrentIndex(idx)
        self.findChild(QComboBox, "combo_baud_rate_train").setCurrentText(str(acq_conf["baud_rate"]))
        self.findChild(QSpinBox, "spin_num_channels_train").setValue(acq_conf["num_channels"])
        self.findChild(QSpinBox, "spin_sampling_rate_train").setValue(acq_conf["sampling_rate_hz"])
        self.findChild(QDoubleSpinBox, "spin_duration_rt_acq").setValue(acq_conf["duration_s_per_label"])
        self.findChild(QSpinBox, "spin_current_label_rt_acq").setValue(acq_conf["current_label_for_rt_acq"])

        # Opciones de Entrenamiento
        train_opts = self.page_config["training_options"]
        self.findChild(QCheckBox, "check_apply_calibration_train").setChecked(train_opts["apply_calibration"])
        self.findChild(QCheckBox, "check_apply_processing_train").setChecked(train_opts["apply_feature_processing"])
        self.findChild(QCheckBox, "check_apply_smote_train").setChecked(train_opts["apply_smote"])
        self.findChild(QCheckBox, "check_use_finger_data").setChecked(train_opts["finger_data_enabled"])
        self._toggle_finger_data_inputs(train_opts["finger_data_enabled"])


        # Modelo y Parámetros
        self.findChild(QComboBox, "model_selector_train").setCurrentText(self.page_config["selected_model_name"])
        # Cargar los hiperparámetros del modelo seleccionado en el editor
        self._update_params_editor_for_selected_model()
        
        # Inicializar plots de adquisición RT
        self._setup_rt_acquisition_plots(acq_conf["num_channels"])


    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        self.tab_widget_train = QTabWidget()
        
        # Pestaña 1: Configuración y Entrenamiento
        train_config_tab = QWidget()
        train_config_layout = QVBoxLayout(train_config_tab)
        
        # Grupo: Configuración de Adquisición para Entrenamiento
        group_acq_train = QGroupBox("Configuración de Adquisición (para nuevas muestras)")
        form_acq_train = QFormLayout()
        self.combo_serial_port_train = QComboBox()
        self.btn_refresh_ports_train = QPushButton("Refrescar Puertos")
        port_layout = QHBoxLayout(); port_layout.addWidget(self.combo_serial_port_train); port_layout.addWidget(self.btn_refresh_ports_train)
        form_acq_train.addRow("Puerto Serial:", port_layout)
        self.combo_baud_rate_train = QComboBox(); self.combo_baud_rate_train.addItems(["9600", "57600", "115200", "250000"])
        form_acq_train.addRow("Baud Rate:", self.combo_baud_rate_train)
        self.spin_num_channels_train = QSpinBox(); self.spin_num_channels_train.setRange(1, 8)
        form_acq_train.addRow("Núm. Canales:", self.spin_num_channels_train)
        self.spin_sampling_rate_train = QSpinBox(); self.spin_sampling_rate_train.setRange(100, 2000); self.spin_sampling_rate_train.setSuffix(" Hz")
        form_acq_train.addRow("Frec. Muestreo:", self.spin_sampling_rate_train)
        group_acq_train.setLayout(form_acq_train)
        train_config_layout.addWidget(group_acq_train)

        # Grupo: Adquisición en Tiempo Real para Entrenamiento
        group_rt_acq = QGroupBox("Adquisición en Tiempo Real de Muestras")
        rt_acq_layout = QGridLayout()
        self.spin_duration_rt_acq = QDoubleSpinBox(); self.spin_duration_rt_acq.setRange(1.0, 60.0); self.spin_duration_rt_acq.setSuffix(" s")
        rt_acq_layout.addWidget(QLabel("Duración por Etiqueta:"), 0, 0)
        rt_acq_layout.addWidget(self.spin_duration_rt_acq, 0, 1)
        self.spin_current_label_rt_acq = QSpinBox(); self.spin_current_label_rt_acq.setRange(0, 99) # Asumir máx 100 clases
        rt_acq_layout.addWidget(QLabel("Etiqueta Actual:"), 0, 2)
        rt_acq_layout.addWidget(self.spin_current_label_rt_acq, 0, 3)
        self.btn_start_rt_acq_sample = QPushButton("Iniciar Adquisición de Muestra")
        rt_acq_layout.addWidget(self.btn_start_rt_acq_sample, 1, 0, 1, 2)
        self.btn_stop_rt_acq_sample = QPushButton("Detener Adquisición"); self.btn_stop_rt_acq_sample.setEnabled(False)
        rt_acq_layout.addWidget(self.btn_stop_rt_acq_sample, 1, 2, 1, 2)
        self.progress_rt_acq = QProgressBar(); self.progress_rt_acq.setTextVisible(True)
        rt_acq_layout.addWidget(self.progress_rt_acq, 2, 0, 1, 4)
        self.label_rt_acq_info = QLabel("Muestras recolectadas: 0")
        rt_acq_layout.addWidget(self.label_rt_acq_info, 3, 0, 1, 4)
        group_rt_acq.setLayout(rt_acq_layout)
        train_config_layout.addWidget(group_rt_acq)
        
        # Grupo: Opciones de Entrenamiento
        group_train_opts = QGroupBox("Opciones de Preprocesamiento y Entrenamiento")
        form_train_opts = QFormLayout()
        self.check_apply_calibration_train = QCheckBox("Aplicar Calibración Guardada"); self.check_apply_calibration_train.setChecked(True)
        form_train_opts.addRow(self.check_apply_calibration_train)
        self.check_apply_processing_train = QCheckBox("Aplicar Extracción de Características"); self.check_apply_processing_train.setChecked(True)
        form_train_opts.addRow(self.check_apply_processing_train)
        self.check_apply_smote_train = QCheckBox("Aplicar SMOTE (Balanceo de Clases)"); self.check_apply_smote_train.setChecked(True)
        form_train_opts.addRow(self.check_apply_smote_train)
        self.check_use_finger_data = QCheckBox("Incluir Datos de Dedos como Características"); self.check_use_finger_data.setChecked(False)
        form_train_opts.addRow(self.check_use_finger_data)
        group_train_opts.setLayout(form_train_opts)
        train_config_layout.addWidget(group_train_opts)

        # Grupo: Datos de Dedos (si check_use_finger_data está activo)
        self.group_finger_data_train = QGroupBox("Datos de Dedos (Ángulo °, Fuerza %)")
        finger_layout = QGridLayout()
        self.finger_fields_train: Dict[str, Dict[str, QLineEdit]] = {}
        dedos = ["Pulgar", "Índice", "Medio", "Anular", "Meñique"]
        for i, dedo_name in enumerate(dedos):
            finger_layout.addWidget(QLabel(f"{dedo_name}:"), i, 0)
            angulo_edit = QLineEdit(); angulo_edit.setPlaceholderText("Ángulo"); angulo_edit.setValidator(pg.QtGui.QDoubleValidator())
            fuerza_edit = QLineEdit(); fuerza_edit.setPlaceholderText("Fuerza"); fuerza_edit.setValidator(pg.QtGui.QDoubleValidator(0,100,2))
            finger_layout.addWidget(angulo_edit, i, 1); finger_layout.addWidget(fuerza_edit, i, 2)
            self.finger_fields_train[dedo_name.lower()] = {"angulo": angulo_edit, "fuerza": fuerza_edit}
        self.group_finger_data_train.setLayout(finger_layout)
        train_config_layout.addWidget(self.group_finger_data_train)
        self.group_finger_data_train.setVisible(False) # Oculto por defecto

        # Selección de Modelo y Parámetros
        group_model_config = QGroupBox("Configuración del Modelo de Clasificación")
        model_config_layout = QFormLayout()
        self.model_selector_train = QComboBox()
        self.model_selector_train.addItems(list(DEFAULT_CLASSIFICATION_CONFIG["model_hyperparameters"].keys()))
        model_config_layout.addRow("Seleccionar Modelo:", self.model_selector_train)
        self.params_editor_train = QTextEdit()
        self.params_editor_train.setPlaceholderText("Hiperparámetros del modelo en formato JSON...")
        self.params_editor_train.setMinimumHeight(100)
        model_config_layout.addRow("Hiperparámetros (JSON):", self.params_editor_train)
        group_model_config.setLayout(model_config_layout)
        train_config_layout.addWidget(group_model_config)

        # Botón de Entrenamiento y Progreso
        self.btn_start_training = QPushButton("🚀 Iniciar Entrenamiento del Modelo")
        train_config_layout.addWidget(self.btn_start_training)
        self.progress_bar_train = QProgressBar()
        train_config_layout.addWidget(self.progress_bar_train)
        self.label_training_status = QLabel("Estado: Listo para entrenar.")
        train_config_layout.addWidget(self.label_training_status)
        
        train_config_layout.addStretch()
        self.tab_widget_train.addTab(train_config_tab, "Configurar y Entrenar")

        # Pestaña 2: Visualización de Datos de Entrenamiento (RT)
        rt_vis_tab = QWidget()
        rt_vis_layout = QVBoxLayout(rt_vis_tab)
        self.plot_rt_acq_train = pg.PlotWidget(title="Señal EMG en Tiempo Real (Adquisición para Entrenamiento)")
        self.plot_rt_acq_train.setBackground(QColor("#1e1e1e"))
        self.plot_rt_acq_train.showGrid(x=True, y=True, alpha=0.3)
        self.plot_rt_acq_train.addLegend(offset=(10,10))
        rt_vis_layout.addWidget(self.plot_rt_acq_train)
        self.tab_widget_train.addTab(rt_vis_tab, "Visualización Adquisición RT")

        # Pestaña 3: Resultados del Entrenamiento
        results_tab = QWidget()
        results_layout = QVBoxLayout(results_tab)
        self.text_training_results = QTextEdit(); self.text_training_results.setReadOnly(True)
        results_layout.addWidget(QLabel("Métricas y Resultados del Entrenamiento:"))
        results_layout.addWidget(self.text_training_results)
        
        self.plot_confusion_matrix_container = QWidget() # Placeholder para Matplotlib/Seaborn
        # Se podría usar un QGraphicsView si se guarda la imagen y se muestra.
        # O integrar Matplotlib con Qt. Por simplicidad, un placeholder.
        cm_layout = QVBoxLayout(self.plot_confusion_matrix_container)
        cm_layout.addWidget(QLabel("Matriz de Confusión (se mostrará en ventana separada si Matplotlib está disponible)"))
        results_layout.addWidget(self.plot_confusion_matrix_container)

        self.btn_show_roc_curve = QPushButton("Mostrar Curva ROC (si aplica)")
        results_layout.addWidget(self.btn_show_roc_curve)
        self.btn_save_trained_model = QPushButton("Guardar Modelo Entrenado Manualmente")
        results_layout.addWidget(self.btn_save_trained_model)

        self.tab_widget_train.addTab(results_tab, "Resultados del Entrenamiento")
        
        main_layout.addWidget(self.tab_widget_train)
        self.setLayout(main_layout)

    def _connect_signals(self):
        # Configuración de Adquisición
        self.btn_refresh_ports_train.clicked.connect(self._update_serial_ports_train)
        self.spin_num_channels_train.valueChanged.connect(lambda val: self._setup_rt_acquisition_plots(val))

        # Adquisición en Tiempo Real para Entrenamiento
        self.btn_start_rt_acq_sample.clicked.connect(self._start_rt_data_collection)
        self.btn_stop_rt_acq_sample.clicked.connect(self._stop_rt_data_collection)

        # Opciones de Entrenamiento
        self.check_use_finger_data.stateChanged.connect(self._toggle_finger_data_inputs)

        # Modelo y Parámetros
        self.model_selector_train.currentTextChanged.connect(self._update_params_editor_for_selected_model)
        
        # Entrenamiento
        self.btn_start_training.clicked.connect(self._initiate_model_training)

        # Resultados
        self.btn_show_roc_curve.clicked.connect(self._display_roc_curve_action)
        self.btn_save_trained_model.clicked.connect(self._manually_save_model_action)


    # --- Métodos de UI y Configuración ---
    def _update_serial_ports_train(self):
        combo = self.findChild(QComboBox, "combo_serial_port_train")
        combo.clear()
        ports = serial.tools.list_ports.comports()
        if ports:
            for port_info in ports:
                combo.addItem(f"{port_info.device} ({port_info.description})", port_info.device)
        else:
            combo.addItem("No hay puertos")

    def _toggle_finger_data_inputs(self, state: int):
        self.group_finger_data_train.setVisible(state == Qt.CheckState.Checked.value)

    def _update_params_editor_for_selected_model(self):
        """Actualiza el QTextEdit de parámetros con los defaults para el modelo seleccionado."""
        model_name = self.model_selector_train.currentText()
        # Cargar hiperparámetros desde la config general de EMGClassificationEngine
        # Asegurarse que la config del engine esté actualizada o cargarla aquí.
        # Por ahora, usamos los defaults definidos en este archivo o en la config de la página.
        model_specific_hyperparams = self.page_config.get("model_hyperparameters", {}).get(model_name, {})
        # Si queremos incluir parámetros comunes de entrenamiento en el editor:
        # combined_params = {**self.page_config.get("common_training_params",{}), **model_specific_hyperparams}
        # self.params_editor_train.setText(json.dumps(combined_params, indent=4))
        self.params_editor_train.setText(json.dumps(model_specific_hyperparams, indent=4))


    def _setup_rt_acquisition_plots(self, num_channels: int):
        """Configura las curvas para el plot de adquisición en tiempo real."""
        self.plot_rt_acq_train.clear()
        self._plot_curves_rt_acq.clear()
        # Usar colores por defecto o de la config de la página de adquisición si está disponible
        default_colors = ["#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF", "#00FFFF", "#FFA500", "#800080"]
        
        for i in range(num_channels):
            color = default_colors[i % len(default_colors)]
            curve = self.plot_rt_acq_train.plot(pen=pg.mkPen(color, width=2), name=f"Canal {i+1}")
            self._plot_curves_rt_acq[i] = curve
        
        # Ajustar rango inicial del plot
        self.plot_rt_acq_train.setXRange(0, 200) # Mostrar N puntos iniciales
        self.plot_rt_acq_train.setYRange(-1, 1) # Rango Y típico para EMG normalizado/escalado


    # --- Adquisición de Datos para Entrenamiento ---
    def _initialize_rt_acquirer(self) -> bool:
        """Inicializa EMGAcquisition para la recolección de datos de entrenamiento."""
        acq_conf_ui = self.page_config["acquisition_config"]
        
        serial_cfg = EMGSerialConfig(port=acq_conf_ui["serial_port"], baud_rate=acq_conf_ui["baud_rate"], auto_connect=False)
        device_cfg = EMGDeviceAcqConfig(delay_ms=acq_conf_ui["delay_ms"], num_channels_active=acq_conf_ui["num_channels"], mode='continuous')
        # Filtros y logs no son críticos para la adquisición aquí, pero se necesitan para la instancia
        filter_cfg = EMGFilterConfig(sample_rate=acq_conf_ui["sampling_rate_hz"])
        log_cfg = EMGLogConfig(enabled=False)

        try:
            self.emg_acquirer = EMGAcquisition(serial_cfg, device_cfg, filter_cfg, log_cfg, simulate=False)
            # Pasar la instancia al motor de clasificación para que pueda usarla si es necesario
            self.classification_engine.set_dependencies(emg_acquirer=self.emg_acquirer,
                                                        calibration_manager=self.calibration_manager,
                                                        processing_engine=self.processing_engine)
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error Adquisición", f"No se pudo inicializar el sistema de adquisición: {e}")
            logger.error(f"Error inicializando EMGAcquisition para entrenamiento: {e}")
            self.emg_acquirer = None
            return False

    def _start_rt_data_collection(self):
        if not self._initialize_rt_acquirer() or not self.emg_acquirer:
            return

        duration = self.page_config["acquisition_config"]["duration_s_per_label"]
        fs = self.page_config["acquisition_config"]["sampling_rate_hz"]
        self.current_training_label = self.page_config["acquisition_config"]["current_label_for_rt_acq"]

        self.training_data_acq_thread = TrainingDataAcquisitionThread(self.emg_acquirer, duration, fs, self)
        self.training_data_acq_thread.new_sample_acquired.connect(self._update_rt_acquisition_plot)
        self.training_data_acq_thread.acquisition_finished.connect(self._on_rt_data_collection_finished)
        self.training_data_acq_thread.progress_update.connect(self._update_rt_acquisition_progress)
        
        self.training_data_acq_thread.start()
        self.btn_start_rt_acq_sample.setEnabled(False)
        self.btn_stop_rt_acq_sample.setEnabled(True)
        self.label_rt_acq_info.setText(f"Adquiriendo para etiqueta {self.current_training_label}...")

    def _stop_rt_data_collection(self):
        if self.training_data_acq_thread and self.training_data_acq_thread.isRunning():
            self.training_data_acq_thread.stop()
            # El hilo emitirá acquisition_finished al detenerse.
        self.btn_start_rt_acq_sample.setEnabled(True)
        self.btn_stop_rt_acq_sample.setEnabled(False)

    def _update_rt_acquisition_plot(self, raw_sample: np.ndarray):
        """Actualiza el gráfico de adquisición en tiempo real con la nueva muestra."""
        # raw_sample es [n_channels]
        num_channels_to_plot = min(len(raw_sample), len(self._plot_curves_rt_acq))
        
        for i in range(num_channels_to_plot):
            curve = self._plot_curves_rt_acq.get(i)
            if curve:
                # Desplazar datos existentes y añadir el nuevo
                if hasattr(curve, 'yData') and curve.yData is not None and len(curve.yData) > 0:
                    new_y_data = np.roll(curve.yData, -1)
                    new_y_data[-1] = raw_sample[i]
                else: # Primera muestra
                    new_y_data = np.full(200, raw_sample[i]) # Inicializar buffer de plot
                
                if not hasattr(curve, 'xData') or len(curve.xData) != len(new_y_data):
                    curve.xData = np.arange(len(new_y_data))
                
                curve.setData(x=curve.xData, y=new_y_data)

    def _update_rt_acquisition_progress(self, current: int, total: int):
        self.progress_rt_acq.setMaximum(total)
        self.progress_rt_acq.setValue(current)
        self.label_rt_acq_info.setText(f"Adquiriendo para etiqueta {self.current_training_label}: {current}/{total} muestras.")

    def _on_rt_data_collection_finished(self, collected_samples: List[np.ndarray]):
        self.btn_start_rt_acq_sample.setEnabled(True)
        self.btn_stop_rt_acq_sample.setEnabled(False)
        self.progress_rt_acq.setValue(0)

        if not collected_samples:
            logger.warning("No se recolectaron muestras en la adquisición RT.")
            self.label_rt_acq_info.setText("Adquisición RT finalizada (sin muestras).")
            return

        # Guardar los datos recolectados con su etiqueta
        # Formato: lista de diccionarios {"features": muestra_array, "label": etiqueta}
        # "features" aquí son las señales crudas, el preprocesamiento se hará después.
        new_training_data = [{"features": sample.tolist(), "label": self.current_training_label} for sample in collected_samples]
        
        if self.patient_id:
            # Cargar datos existentes, añadir nuevos, y guardar
            existing_data = self.data_manager.cargar_datos(self.patient_id, "training_data_sessions") or []
            # Asumimos que training_data_sessions es una lista de sesiones, y cada sesión es una lista de muestras.
            # Para simplificar, añadimos las nuevas muestras como una nueva "sesión" o lote.
            # O, si es una lista plana de muestras:
            # existing_data.extend(new_training_data)
            # self.data_manager.guardar_datos(self.patient_id, "training_data", existing_data)
            
            # Si guardamos por "sesiones" de adquisición:
            session_name = f"rt_acq_{datetime.now().strftime('%Y%m%d_%H%M%S')}_label{self.current_training_label}"
            # El formato de guardado debe ser consistente con cómo _get_training_data lo espera.
            # Si _get_training_data espera una lista de dicts con "features_array" y "labels_array":
            features_array = np.array([d["features"] for d in new_training_data])
            labels_array = np.array([d["label"] for d in new_training_data])
            session_to_save = {"session_id": session_name, "features_array": features_array.tolist(), "labels_array": labels_array.tolist()}
            
            # Guardar como una nueva sesión
            # Necesitamos un método en GestorDatos para añadir una sesión de entrenamiento
            # self.data_manager.guardar_datos_sesion_entrenamiento(self.patient_id, session_name, session_to_save)
            # O si "training_data_sessions" es una lista de estas sesiones:
            all_sessions = self.data_manager.cargar_datos(self.patient_id, "training_data_sessions") or []
            all_sessions.append(session_to_save)
            self.data_manager.guardar_datos(self.patient_id, "training_data_sessions", all_sessions)

            logger.info(f"{len(collected_samples)} muestras para etiqueta {self.current_training_label} guardadas para paciente {self.patient_id}.")
            self.label_rt_acq_info.setText(f"{len(collected_samples)} muestras para etiqueta {self.current_training_label} guardadas. Listo para nueva adquisición o entrenamiento.")
            self._load_patient_training_data_summary() # Actualizar info de datos
        else:
            logger.warning("Patient ID no definido. Datos de RT no guardados permanentemente.")
            self.label_rt_acq_info.setText(f"{len(collected_samples)} muestras recolectadas (no guardadas).")


    # --- Entrenamiento del Modelo ---
    def _initiate_model_training(self):
        if not self.patient_id:
            QMessageBox.warning(self, "Error", "Seleccione un paciente primero.")
            return

        self._update_page_config_from_ui() # Asegurar que la config de la página esté actualizada

        model_name = self.page_config["selected_model_name"]
        
        # Preparar training_options para EMGClassificationEngine
        training_options = self.page_config["training_options"].copy()
        training_options["acquisition_mode"] = "saved_data" # Para el entrenamiento, siempre usamos datos ya guardados/recolectados
        
        # Finger data (si está habilitado)
        if training_options.get("finger_data_enabled", False):
            finger_data_ui = {}
            for dedo, fields in self.finger_fields_train.items():
                try: angulo = float(fields["angulo"].text()) if fields["angulo"].text() else 0.0
                except ValueError: angulo = 0.0
                try: fuerza = float(fields["fuerza"].text()) if fields["fuerza"].text() else 0.0
                except ValueError: fuerza = 0.0
                finger_data_ui[dedo] = {"angulo": angulo, "fuerza": fuerza}
            training_options["finger_data"] = finger_data_ui
        
        # Hiperparámetros del modelo desde el editor de texto
        try:
            model_hyperparams_from_editor = json.loads(self.params_editor_train.toPlainText())
            # Actualizar la sección de hiperparámetros en la config del engine
            # Esto es un poco redundante si _update_page_config_from_ui ya lo hizo,
            # pero asegura que se usen los del editor.
            self.classification_engine.config["model_hyperparameters"][model_name] = model_hyperparams_from_editor
        except json.JSONDecodeError:
            QMessageBox.warning(self, "Error de Formato", "Los hiperparámetros en el editor no son JSON válido. Se usarán los defaults.")
            # Los defaults ya están en self.classification_engine.config

        self.btn_start_training.setEnabled(False)
        self.progress_bar_train.setValue(0)
        self.label_training_status.setText(f"Iniciando entrenamiento del modelo {model_name}...")

        self.model_training_thread = ModelTrainingThread(
            self.classification_engine, model_name, training_options, self
        )
        self.model_training_thread.training_progress.connect(self._update_training_progress_ui)
        self.model_training_thread.training_finished.connect(self._on_model_training_finished)
        self.model_training_thread.start()

    def _update_training_progress_ui(self, value: int, message: str):
        self.progress_bar_train.setValue(value)
        self.label_training_status.setText(message)

    def _on_model_training_finished(self, success: bool, message: str, metrics: Dict, best_params: Dict):
        self.btn_start_training.setEnabled(True)
        self.label_training_status.setText(message)
        if success:
            QMessageBox.information(self, "Entrenamiento Completado", message)
            self.text_training_results.setPlainText(
                f"Modelo: {self.page_config['selected_model_name']}\n\n"
                f"Mejores Hiperparámetros:\n{json.dumps(best_params, indent=2)}\n\n"
                f"Métricas de Evaluación:\n{json.dumps(metrics, indent=2)}"
            )
            # Guardar referencia al modelo entrenado (opcional, ya se guarda en engine)
            # self.trained_model_instance = self.classification_engine.trained_models.get(self.page_config["selected_model_name"])
            
            if PLOTTING_AVAILABLE and "confusion_matrix" in metrics:
                self.classification_engine.plot_confusion_matrix(metrics["confusion_matrix"], self.page_config["selected_model_name"])
        else:
            QMessageBox.critical(self, "Error de Entrenamiento", message)
            self.text_training_results.setPlainText(f"Error: {message}")


    # --- Acciones de Resultados ---
    def _display_roc_curve_action(self):
        if not PLOTTING_AVAILABLE:
            QMessageBox.information(self, "Info", "Matplotlib no está disponible para mostrar la curva ROC.")
            return
        
        model_name = self.page_config["selected_model_name"]
        model_instance = self.classification_engine.trained_models.get(model_name)
        if not model_instance:
            QMessageBox.warning(self, "Error", f"Modelo '{model_name}' no entrenado o no cargado.")
            return

        # Necesitamos datos de test para la curva ROC.
        # Podríamos re-dividir los datos originales o usar un conjunto de validación guardado.
        # Por simplicidad, si no tenemos X_test, y_test guardados de la última ejecución, no podemos hacerlo.
        # Esto debería mejorarse guardando X_test, y_test después del split en train_model.
        # Placeholder:
        # if hasattr(self.classification_engine, "_last_X_test") and hasattr(self.classification_engine, "_last_y_test"):
        #    self.classification_engine.plot_roc_curve(model_instance, self.classification_engine._last_X_test, self.classification_engine._last_y_test, model_name)
        # else:
        QMessageBox.information(self, "Info", "Datos de prueba no disponibles para generar curva ROC en esta interfaz. Se muestra si se generó durante el entrenamiento.")


    def _manually_save_model_action(self):
        model_name = self.page_config["selected_model_name"]
        model_instance = self.classification_engine.trained_models.get(model_name)
        if model_instance:
            self.classification_engine._save_model(model_instance, model_name) # Llama al método privado para forzar guardado
            QMessageBox.information(self, "Guardado", f"Modelo '{model_name}' guardado manualmente.")
        else:
            QMessageBox.warning(self, "Error", f"No hay un modelo '{model_name}' entrenado para guardar.")


    # --- Carga de Datos del Paciente ---
    def _load_patient_training_data_summary(self):
        """Muestra un resumen de los datos de entrenamiento existentes para el paciente."""
        if self.patient_id:
            # Asumimos que training_data_sessions es una lista de dicts con 'features_array' y 'labels_array'
            sessions = self.data_manager.cargar_datos(self.patient_id, "training_data_sessions") or []
            total_samples = 0
            labels_summary = {}
            for session_data in sessions:
                if isinstance(session_data, dict) and "labels_array" in session_data:
                    labels = np.array(session_data["labels_array"])
                    total_samples += len(labels)
                    unique_labels, counts = np.unique(labels, return_counts=True)
                    for label, count in zip(unique_labels, counts):
                        labels_summary[label] = labels_summary.get(label, 0) + count
            
            summary_text = f"Total de muestras de entrenamiento guardadas: {total_samples}\n"
            summary_text += "Distribución de etiquetas:\n"
            for label, count in sorted(labels_summary.items()):
                summary_text += f"  Etiqueta {label}: {count} muestras\n"
            
            # Mostrar en algún QLabel, por ejemplo, self.label_training_data_summary
            # (Asumiendo que existe un QLabel con este nombre de objeto en la UI)
            info_label = self.findChild(QLabel, "label_existing_data_info")
            if info_label:
                info_label.setText(summary_text)
            else: # Si no, loguearlo
                logger.info(summary_text)
        else:
            info_label = self.findChild(QLabel, "label_existing_data_info")
            if info_label: info_label.setText("No hay paciente seleccionado.")


    def closeEvent(self, event):
        logger.info("Cerrando Página de Entrenamiento...")
        if self.training_data_acq_thread and self.training_data_acq_thread.isRunning():
            self.training_data_acq_thread.stop()
            self.training_data_acq_thread.wait(1000)
        if self.model_training_thread and self.model_training_thread.isRunning():
            # No se puede detener un entrenamiento abruptamente sin corromper,
            # pero se puede intentar con quit() y esperar un poco.
            self.model_training_thread.quit()
            self.model_training_thread.wait(1000)
        if self.emg_acquirer:
            self.emg_acquirer.close()
        
        self._save_page_config()
        super().closeEvent(event)

# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    class DummyDataManager:
        def __init__(self): self.db = {}
        def guardar_datos(self, patient_id, data_type, data): self.db[f"{patient_id}_{data_type}"] = data
        def cargar_datos(self, patient_id, data_type): return self.db.get(f"{patient_id}_{data_type}")

    dummy_dm = DummyDataManager() # type: ignore
    
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f: app.setStyleSheet(f.read())

    main_window = TrainingPage(data_manager=dummy_dm, patient_id="patient_train_gui")
    main_window.show()
    sys.exit(app.exec())
    