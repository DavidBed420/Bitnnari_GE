"""
pagina_calibracion.py

Interfaz gráfica (PyQt6) para la calibración de señales EMG.
Este módulo permite al usuario configurar y ejecutar el proceso de calibración,
visualizar los resultados y gestionar el historial de calibraciones.

Características Principales:
- Carga de UI: Utiliza un archivo .ui para la definición de la interfaz.
- Configuración de Calibración:
    - Parámetros del dispositivo (puerto, baud rate, canales, etc., compartidos
      o cargados desde la configuración de adquisición).
    - Parámetros específicos de la ejecución de calibración (duración, tipo de músculo).
- Ejecución de Calibración:
    - Calibración de offset (línea base).
    - (Opcional) Calibración de ganancia (e.g., mediante MVC).
    - Proceso de adquisición y cálculo en un hilo separado para no bloquear la UI.
- Visualización de Resultados:
    - Gráficos (pyqtgraph) para mostrar la señal durante la calibración (opcional),
      el offset calculado, y comparaciones con señales de referencia.
    - Visualización de espectro FFT de la señal de offset (opcional).
- Comparación con Referencia:
    - Carga de una señal de calibración de referencia.
    - Cálculo de MSE y similitud con la calibración actual.
- Gestión de Historial:
    - Tabla para mostrar el historial de calibraciones guardadas.
    - Filtros por fecha y búsqueda en el historial.
    - Exportación e impresión del historial.
- Persistencia:
    - Guarda y carga parámetros de calibración (offset, ganancia) usando GestorDatos.
    - Guarda y carga la configuración de la página de calibración.
- Modo Experto (Opcional): Podría habilitar configuraciones avanzadas (orden de filtro, etc.).
- Estilo: Diseñado para ser compatible con un QSS global.
"""

import os
import sys
import json
import logging
from typing import Optional, Dict, Any, List, Tuple

import numpy as np
import serial.tools.list_ports
from PyQt6 import uic
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QDateTime, QSize
from PyQt6.QtGui import QColor, QTextDocument, QIcon, QFont, QPainter, QPen
from PyQt6.QtWidgets import (
    QWidget, QComboBox, QPushButton, QSpinBox, QDoubleSpinBox,
    QMessageBox, QLineEdit, QTableWidget, QTableWidgetItem, QDateEdit,
    QTextEdit, QCheckBox, QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QFileDialog, QLabel, QProgressBar, QDialog
)
from PyQt6.QtPrintSupport import QPrinter, QPrintDialog
import pyqtgraph as pg

# Importaciones de módulos del proyecto
from BitnnariApp.acquisition.emg_adquisition import (
    EMGAcquisition, SerialConfig as EMGSerialConfig,
    AcquisitionConfig as EMGDeviceAcqConfig, FilterConfig as EMGFilterConfig,
    LogConfig as EMGLogConfig
)
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager, CalibrationRunConfig
from BitnnariApp.data.gestor_datos import GestorDatos

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Ruta al archivo .ui (ajustar según el nombre real del archivo UI para calibración)
# El prompt menciona "ui_pagina_calibracion.ui" y "ui_calibracion_prueba.ui". Usaré el primero.
UI_FILE_PATH = os.path.join(os.path.dirname(__file__), "ui", "ui_pagina_calibracion.ui")
# Si el archivo es ui_calibracion_prueba.ui, cambiar la línea anterior.

DEFAULT_CALIBRATION_PAGE_CONFIG = {
    "serial_port": None,
    "baud_rate": 115200,
    "num_channels": 2, # Canales a calibrar
    "sampling_rate_hz": 1000, # Frecuencia de muestreo esperada
    "offset_cal_duration_s": 5.0,
    "mvc_cal_duration_s": 3.0,
    "mvc_trials": 3,
    "mvc_rest_s": 10.0,
    "apply_filter_during_cal": True,
    "cal_filter_lp_hz": 5.0, # Filtro suave para offset
    "cal_filter_hp_hz": 0.5,
    "cal_filter_notch_hz": 50.0,
    "muscle_type": "general", # 'general', 'grande', 'pequeno'
    "expert_mode_enabled": False,
    "expert_filter_order": 4,
    "expert_show_fft_offset": False,
    "reference_file_path": None
}

# Hilo para ejecutar la calibración
class CalibrationProcessThread(QThread):
    """Hilo para ejecutar el proceso de calibración sin bloquear la UI."""
    calibration_step_update = pyqtSignal(str, int) # mensaje, progreso (0-100)
    calibration_finished = pyqtSignal(bool, str, object)  # success, message, result_params (e.g., offset)

    def __init__(self,
                 calibration_manager: EMGCalibrationManager,
                 run_config: CalibrationRunConfig,
                 calibrate_offset: bool = True,
                 calibrate_gain_mvc: bool = False,
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.cal_manager = calibration_manager
        self.run_config = run_config
        self.do_offset = calibrate_offset
        self.do_gain_mvc = calibrate_gain_mvc

    def run(self):
        try:
            if self.do_offset:
                self.calibration_step_update.emit("Iniciando calibración de offset...", 10)
                # Simular progreso durante la adquisición de offset
                # En una implementación real, EMGAcquisition podría emitir progreso
                for i in range(int(self.run_config.duration_s)):
                    time.sleep(1)
                    self.calibration_step_update.emit(f"Adquiriendo datos para offset... {i+1}s", 10 + int(70 * (i+1)/self.run_config.duration_s))
                
                if not self.cal_manager.calibrate_offset(self.run_config):
                    self.calibration_finished.emit(False, "Fallo en la calibración de offset.", None)
                    return
                self.calibration_step_update.emit("Calibración de offset completada.", 80)
            
            if self.do_gain_mvc:
                # La calibración MVC es interactiva, el progreso es más difícil de estimar aquí
                # Se podría emitir un mensaje antes de cada trial MVC
                self.calibration_step_update.emit("Iniciando calibración de ganancia MVC...", 85)
                if not self.cal_manager.calibrate_gain_mvc(self.run_config):
                    self.calibration_finished.emit(False, "Fallo en la calibración de ganancia MVC.", None)
                    return
                self.calibration_step_update.emit("Calibración de ganancia MVC completada.", 95)

            self.calibration_finished.emit(True, "Calibración completada exitosamente.", self.cal_manager.offset_params) # o un dict con offset y gain
            self.calibration_step_update.emit("Finalizado.", 100)

        except Exception as e:
            logger.error(f"Excepción en CalibrationProcessThread: {e}", exc_info=True)
            self.calibration_finished.emit(False, f"Error durante la calibración: {e}", None)


class SignalViewerDialog(QDialog):
    """Diálogo para visualización detallada de una señal con controles de plot."""
    def __init__(self, signal_data: np.ndarray, title: str = "Visualizador de Señal", parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(800, 600)
        self.signal_data = signal_data

        layout = QVBoxLayout(self)
        self.plot_widget = pg.PlotWidget(title=title)
        self.plot_widget.setBackground(QColor("#1e1e1e")) # Fondo oscuro
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        layout.addWidget(self.plot_widget)

        if signal_data.ndim == 1:
            self.plot_widget.plot(signal_data, pen=pg.mkPen(color='y', width=2))
        elif signal_data.ndim == 2:
            for i in range(signal_data.shape[1]):
                self.plot_widget.plot(signal_data[:, i], pen=pg.mkPen(color=pg.intColor(i, hues=signal_data.shape[1]), width=2), name=f"Canal {i+1}")
            if signal_data.shape[1] > 1: self.plot_widget.addLegend()

        # Controles de zoom y pan (PyQtGraph los tiene por defecto con el ratón)
        # Se pueden añadir botones si se desea
        btn_layout = QHBoxLayout()
        btn_autorange = QPushButton("Auto Rango")
        btn_autorange.clicked.connect(self.plot_widget.autoRange)
        btn_layout.addWidget(btn_autorange)
        layout.addLayout(btn_layout)
        self.setLayout(layout)


class PaginaCalibracion(QWidget): # Cambiado de QMainWindow a QWidget para mejor integración en StackedWidget
    """Página de la GUI para la calibración de señales EMG."""

    def __init__(self, data_manager: GestorDatos, patient_id: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        uic.loadUi(UI_FILE_PATH, self)
        self.setObjectName("paginaCalibracion")

        self.data_manager = data_manager
        self.patient_id = patient_id
        self.config = self._load_or_default_page_config()

        self.emg_acquirer: Optional[EMGAcquisition] = None # Se inicializará al conectar
        self.calibration_manager = EMGCalibrationManager(data_manager=self.data_manager, patient_id=self.patient_id)
        
        self.calibration_thread: Optional[CalibrationProcessThread] = None
        self.calibration_history: List[Dict[str, Any]] = [] # Para la tabla de historial

        self._setup_internal_widgets()
        self._connect_signals()
        self._apply_initial_config()
        self._load_calibration_history()

        logger.info(f"Página de Calibración inicializada para paciente: {self.patient_id}")

    def _load_or_default_page_config(self) -> Dict[str, Any]:
        page_conf_key = "calibration_page_config"
        conf = self.data_manager.cargar_datos(self.patient_id, page_conf_key)
        if conf and isinstance(conf, dict):
            merged_conf = DEFAULT_CALIBRATION_PAGE_CONFIG.copy()
            merged_conf.update(conf) # Fusión simple, podría ser profunda si es necesario
            logger.info(f"Configuración de página de calibración cargada para {self.patient_id}.")
            return merged_conf
        else:
            logger.info(f"Usando config por defecto para página de calibración (paciente {self.patient_id}).")
            self.data_manager.guardar_datos(self.patient_id, page_conf_key, DEFAULT_CALIBRATION_PAGE_CONFIG)
            return DEFAULT_CALIBRATION_PAGE_CONFIG.copy()

    def _save_page_config(self):
        self._update_config_from_ui()
        page_conf_key = "calibration_page_config"
        self.data_manager.guardar_datos(self.patient_id, page_conf_key, self.config)
        logger.info(f"Configuración de página de calibración guardada para {self.patient_id}.")

    def _setup_internal_widgets(self):
        # Plot de Calibración (Offset)
        self.calib_plot_widget = pg.PlotWidget(title="Resultado Calibración Offset")
        self.calib_plot_widget.setBackground(QColor("#1e1e1e"))
        self.calib_plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.calib_plot_widget.addLegend(offset=(10,10))
        placeholder_calib = self.findChild(QFrame, "calib_plot") # Asumiendo que el .ui tiene un QFrame placeholder
        if placeholder_calib:
            layout = QVBoxLayout(placeholder_calib); layout.setContentsMargins(0,0,0,0); layout.addWidget(self.calib_plot_widget)
        else: self.findChild(QVBoxLayout, "verticalLayout_calib_display").insertWidget(2, self.calib_plot_widget) # Fallback

        # Plot FFT (del offset o señal)
        self.fft_plot_widget = pg.PlotWidget(title="Análisis FFT")
        self.fft_plot_widget.setBackground(QColor("#1e1e1e"))
        self.fft_plot_widget.showGrid(x=True, y=True, alpha=0.3)
        placeholder_fft = self.findChild(QFrame, "fft_plot")
        if placeholder_fft:
            layout_fft = QVBoxLayout(placeholder_fft); layout_fft.setContentsMargins(0,0,0,0); layout_fft.addWidget(self.fft_plot_widget)
            placeholder_fft.setVisible(self.config.get("expert_show_fft_offset", False))
        else: self.findChild(QVBoxLayout, "verticalLayout_calib_display").addWidget(self.fft_plot_widget)


        # Plot de Comparación
        self.comp_plot_widget = pg.PlotWidget(title="Comparación con Referencia")
        self.comp_plot_widget.setBackground(QColor("#1e1e1e"))
        self.comp_plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.comp_plot_widget.addLegend(offset=(10,10))
        placeholder_comp = self.findChild(QFrame, "comp_plot") # Asumiendo placeholder en tab de comparación
        if placeholder_comp:
             layout_comp = QVBoxLayout(placeholder_comp); layout_comp.setContentsMargins(0,0,0,0); layout_comp.addWidget(self.comp_plot_widget)
        # else: self.tabs_calibracion.widget(1).layout().addWidget(self.comp_plot_widget) # Si no hay placeholder, añadir al layout del tab

    def _connect_signals(self):
        # Pestaña Calibración
        self.findChild(QPushButton, "refresh_ports_btn").clicked.connect(self._update_serial_ports)
        self.findChild(QPushButton, "start_calib_btn").clicked.connect(self._start_calibration_process)
        self.findChild(QPushButton, "save_calib_params_btn").clicked.connect(lambda: self.calibration_manager.save_calibration_params(self.patient_id) if self.patient_id else None)
        self.findChild(QPushButton, "load_calib_params_btn").clicked.connect(lambda: self._load_and_apply_calib_params() if self.patient_id else None)
        
        # Pestaña Comparación
        self.findChild(QPushButton, "load_ref_btn").clicked.connect(self._load_reference_signal_dialog)
        self.findChild(QPushButton, "compare_btn").clicked.connect(self._compare_current_with_reference)
        self.findChild(QPushButton, "save_current_as_ref_btn").clicked.connect(self._save_current_signal_as_reference_dialog)

        # Pestaña Historial
        self.findChild(QLineEdit, "search_edit").textChanged.connect(self._filter_calibration_history)
        self.findChild(QDateEdit, "date_filter").dateChanged.connect(self._filter_calibration_history)
        self.findChild(QPushButton, "export_history_btn").clicked.connect(self._export_calibration_history)
        self.findChild(QPushButton, "print_history_btn").clicked.connect(self._print_calibration_history)
        
        # Configuración Avanzada (Expert Mode)
        # self.findChild(QCheckBox, "expert_mode_checkbox").stateChanged.connect(self._toggle_expert_mode_ui)
        # self.findChild(QComboBox, "fft_checkbox").currentIndexChanged.connect(self._toggle_fft_plot_visibility)


    def _apply_initial_config(self):
        self._update_serial_ports()
        if self.config["serial_port"] and self.findChild(QComboBox, "port_combo").findText(self.config["serial_port"]) != -1:
            self.findChild(QComboBox, "port_combo").setCurrentText(self.config["serial_port"])
        self.findChild(QComboBox, "baud_combo").setCurrentText(str(self.config["baud_rate"]))
        self.findChild(QSpinBox, "num_channels_spin").setValue(self.config["num_channels"])
        self.findChild(QSpinBox, "sampling_spin").setValue(self.config["sampling_rate_hz"])
        
        self.findChild(QDoubleSpinBox, "offset_duration_spin").setValue(self.config["offset_cal_duration_s"])
        self.findChild(QCheckBox, "filter_during_cal_checkbox").setChecked(self.config["apply_filter_during_cal"])
        self.findChild(QComboBox, "muscle_type_combo").addItems(["general", "grande", "pequeno"]) # Poblar
        self.findChild(QComboBox, "muscle_type_combo").setCurrentText(self.config["muscle_type"])

        # Expert mode UI (si existe el checkbox)
        # expert_cb = self.findChild(QCheckBox, "expert_mode_checkbox")
        # if expert_cb: expert_cb.setChecked(self.config["expert_mode_enabled"])
        # self._toggle_expert_mode_ui(Qt.CheckState.Checked.value if self.config["expert_mode_enabled"] else Qt.CheckState.Unchecked.value)
        # self.findChild(QSpinBox, "filter_order_spin").setValue(self.config["expert_filter_order"])
        # fft_combo = self.findChild(QComboBox, "fft_checkbox")
        # if fft_combo: fft_combo.setCurrentIndex(1 if self.config["expert_show_fft_offset"] else 0)
        
        self.findChild(QDateEdit, "date_filter").setDate(QDateTime.currentDateTime().date())

        # Cargar parámetros de calibración si existen para el paciente
        self._load_and_apply_calib_params()


    def _update_config_from_ui(self):
        """Actualiza self.config con los valores de la UI."""
        self.config["serial_port"] = self.findChild(QComboBox, "port_combo").currentText()
        self.config["baud_rate"] = int(self.findChild(QComboBox, "baud_combo").currentText())
        self.config["num_channels"] = self.findChild(QSpinBox, "num_channels_spin").value()
        self.config["sampling_rate_hz"] = self.findChild(QSpinBox, "sampling_spin").value()
        
        self.config["offset_cal_duration_s"] = self.findChild(QDoubleSpinBox, "offset_duration_spin").value()
        self.config["apply_filter_during_cal"] = self.findChild(QCheckBox, "filter_during_cal_checkbox").isChecked()
        self.config["muscle_type"] = self.findChild(QComboBox, "muscle_type_combo").currentText()

        # expert_cb = self.findChild(QCheckBox, "expert_mode_checkbox")
        # if expert_cb: self.config["expert_mode_enabled"] = expert_cb.isChecked()
        # self.config["expert_filter_order"] = self.findChild(QSpinBox, "filter_order_spin").value()
        # fft_combo = self.findChild(QComboBox, "fft_checkbox")
        # if fft_combo: self.config["expert_show_fft_offset"] = (fft_combo.currentIndex() == 1)


    # --- Conexión y Adquisición ---
    def _update_serial_ports(self):
        combo = self.findChild(QComboBox, "port_combo")
        combo.clear()
        ports = serial.tools.list_ports.comports()
        if ports:
            for port_info in ports:
                combo.addItem(f"{port_info.device} ({port_info.description})", port_info.device)
        else:
            combo.addItem("No hay puertos disponibles")

    def _initialize_emg_acquirer(self) -> bool:
        """Inicializa o actualiza EMGAcquisition basado en la UI."""
        self._update_config_from_ui() # Asegurar que self.config esté al día

        serial_conf = EMGSerialConfig(
            port=self.config["serial_port"],
            baud_rate=self.config["baud_rate"],
            auto_connect=False # La conexión se maneja explícitamente
        )
        # Para calibración, el delay y modo del Arduino son menos críticos que la tasa de muestreo de la app
        device_acq_conf = EMGDeviceAcqConfig(
            delay_ms=int(1000.0 / self.config["sampling_rate_hz"]) if self.config["sampling_rate_hz"] > 0 else 10,
            num_channels_active=self.config["num_channels"],
            mode='continuous' # Calibración usualmente necesita flujo continuo
        )
        # Filtros del dispositivo (si los tuviera configurables) - para este ejemplo, simples
        device_filter_conf = EMGFilterConfig(sample_rate=self.config["sampling_rate_hz"])
        device_log_conf = EMGLogConfig(enabled=False) # No loguear desde EMGAcquisition durante calibración

        try:
            self.emg_acquirer = EMGAcquisition(
                serial_conf, device_acq_conf, device_filter_conf, device_log_conf, simulate=False # No simular para calibración real
            )
            self.calibration_manager.set_emg_acquirer(self.emg_acquirer)
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error de Configuración", f"No se pudo inicializar el sistema de adquisición: {e}")
            logger.error(f"Error inicializando EMGAcquisition: {e}")
            self.emg_acquirer = None
            return False

    # --- Proceso de Calibración ---
    def _start_calibration_process(self):
        if not self._initialize_emg_acquirer():
            return
        
        if not self.emg_acquirer or not self.emg_acquirer.connect():
            QMessageBox.critical(self, "Error de Conexión", "No se pudo conectar al dispositivo EMG para calibración.")
            return

        self._update_config_from_ui() # Actualizar self.config con valores de la UI

        # Configuración para la ejecución de calibración
        cal_run_filter_conf = None
        if self.config["apply_filter_during_cal"]:
            cal_run_filter_conf = EMGFilterConfig(
                sample_rate=self.config["sampling_rate_hz"],
                notch_freq=self.config["cal_filter_notch_hz"],
                bandpass_low_freq=self.config["cal_filter_hp_hz"],
                bandpass_high_freq=self.config["cal_filter_lp_hz"],
                bandpass_order=self.config.get("expert_filter_order", 4) # Usar orden experto si está
            )

        run_config = CalibrationRunConfig(
            duration_s=self.config["offset_cal_duration_s"],
            mvc_duration_s=self.config["mvc_cal_duration_s"],
            num_mvc_trials=self.config["mvc_trials"],
            rest_between_mvc_s=self.config["mvc_rest_s"],
            apply_filter_during_offset_cal=self.config["apply_filter_during_cal"],
            filter_config=cal_run_filter_conf
        )

        self.findChild(QPushButton, "start_calib_btn").setEnabled(False)
        self.findChild(QProgressBar, "progress_bar").setValue(0)
        
        # Crear y empezar el hilo de calibración
        self.calibration_thread = CalibrationProcessThread(
            self.calibration_manager, run_config,
            calibrate_offset=True, # Por ahora solo offset
            calibrate_gain_mvc=False # Se podría añadir un checkbox para esto
        )
        self.calibration_thread.calibration_step_update.connect(self._on_calibration_step_update)
        self.calibration_thread.calibration_finished.connect(self._on_calibration_process_finished)
        self.calibration_thread.start()

    def _on_calibration_step_update(self, message: str, progress: int):
        self.findChild(QLabel, "status_label").setText(message) # Asumiendo un QLabel 'status_label'
        self.findChild(QProgressBar, "progress_bar").setValue(progress)

    def _on_calibration_process_finished(self, success: bool, message: str, result_params: Optional[np.ndarray]):
        self.findChild(QPushButton, "start_calib_btn").setEnabled(True)
        self.findChild(QLabel, "status_label").setText(message)
        
        if self.emg_acquirer: # Desconectar después de calibrar
            self.emg_acquirer.disconnect()

        if success and result_params is not None:
            self.findChild(QProgressBar, "progress_bar").setValue(100)
            QMessageBox.information(self, "Calibración Completada", message)
            self._display_calibration_results(result_params)
            self._add_to_calibration_history(result_params, "Offset Calibrated")
            # Guardar automáticamente si hay paciente
            if self.patient_id:
                self.calibration_manager.save_calibration_params(self.patient_id)
        else:
            self.findChild(QProgressBar, "progress_bar").setValue(0) # O un valor de error
            QMessageBox.critical(self, "Error de Calibración", message)

    def _display_calibration_results(self, offset_values: np.ndarray):
        self.findChild(QLabel, "offset_label").setText(f"Offset Calculado: {np.array2string(offset_values, precision=3)}")
        
        self.calib_plot_widget.clear()
        num_ch = len(offset_values)
        for i in range(num_ch):
            # Mostrar el offset como una línea horizontal
            # Necesitamos un eje X, podemos simularlo o usar datos reales si se guardaron
            x_axis = np.array([0, 1]) # Simplemente dos puntos para la línea
            y_axis = np.array([offset_values[i], offset_values[i]])
            self.calib_plot_widget.plot(x_axis, y_axis, pen=pg.mkPen(color=pg.intColor(i, hues=num_ch), width=2), name=f"Offset Ch {i+1}")
        
        # Mostrar FFT del offset (si está habilitado y hay datos)
        # fft_combo = self.findChild(QComboBox, "fft_checkbox")
        # show_fft = self.config.get("expert_show_fft_offset", False) # (fft_combo and fft_combo.currentIndex() == 1)
        
        # if show_fft:
        #     self.fft_plot_widget.clear()
        #     self.fft_plot_widget.setVisible(True)
        #     # La FFT del offset (un solo valor por canal) no es muy informativa.
        #     # Sería más útil la FFT de la señal de reposo usada para calcular el offset.
        #     # Placeholder:
        #     for i in range(num_ch):
        #         # Simular una señal de ruido centrada en el offset para FFT
        #         dummy_signal_for_fft = np.random.normal(offset_values[i], 0.1, 256)
        #         fs = self.config["sampling_rate_hz"]
        #         freqs, amps = signal.periodogram(dummy_signal_for_fft, fs=fs)
        #         self.fft_plot_widget.plot(freqs, amps, pen=pg.mkPen(color=pg.intColor(i, hues=num_ch)), name=f"FFT Offset Ch {i+1}")
        # else:
        #     self.fft_plot_widget.setVisible(False)
        
        # Abrir ventana detallada (opcional)
        # viewer = SignalViewerDialog(offset_values.reshape(1,-1), title="Valores de Offset por Canal", parent=self)
        # viewer.exec()


    def _load_and_apply_calib_params(self):
        if self.calibration_manager.load_calibration_params(self.patient_id):
            offset = self.calibration_manager.offset_params
            gain = self.calibration_manager.gain_params
            if offset is not None:
                self.findChild(QLabel, "offset_label").setText(f"Offset Cargado: {np.array2string(offset, precision=3)}")
                self._display_calibration_results(offset) # Reutilizar para mostrar
            # Actualizar UI con ganancia si existe un campo para ello
            QMessageBox.information(self, "Carga Exitosa", "Parámetros de calibración cargados.")
        else:
            QMessageBox.information(self, "Info", "No hay parámetros de calibración guardados para este paciente.")
            self.findChild(QLabel, "offset_label").setText("Offset: N/A")


    # --- Comparación con Referencia ---
    def _load_reference_signal_dialog(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Cargar Señal de Referencia", "", "JSON files (*.json)")
        if filepath:
            self.config["reference_file_path"] = filepath
            self._save_page_config() # Guardar la ruta en la config de la página
            # Cargar y mostrar la señal de referencia en el plot de comparación
            ref_signal = self.calibration_manager.load_reference_signal(os.path.splitext(os.path.basename(filepath))[0]) # Usar ID del nombre de archivo
            if ref_signal is not None:
                self.comp_plot_widget.clear()
                if ref_signal.ndim == 1:
                    self.comp_plot_widget.plot(ref_signal, pen=pg.mkPen('c', width=2), name="Referencia")
                elif ref_signal.ndim == 2:
                    for i in range(ref_signal.shape[1]):
                         self.comp_plot_widget.plot(ref_signal[:,i], pen=pg.mkPen(pg.intColor(i, hues=ref_signal.shape[1]), width=2), name=f"Ref Ch {i+1}")
                QMessageBox.information(self, "Referencia Cargada", f"Señal de referencia '{os.path.basename(filepath)}' cargada.")
            else:
                QMessageBox.warning(self, "Error", "No se pudo cargar la señal de referencia del archivo.")


    def _compare_current_with_reference(self):
        if not self.config.get("reference_file_path"):
            QMessageBox.warning(self, "Advertencia", "Primero cargue una señal de referencia.")
            return
        if self.calibration_manager.offset_params is None: # Asumimos que comparamos contra el offset actual
            QMessageBox.warning(self, "Advertencia", "No hay una calibración de offset actual para comparar.")
            return

        reference_id = os.path.splitext(os.path.basename(self.config["reference_file_path"]))[0]
        
        # Para comparar, necesitamos una "nueva señal". Podríamos usar el offset actual como una señal constante.
        # O, si se adquirieron datos para el offset, usar esos datos *después* de aplicar el offset.
        # Aquí, vamos a comparar el vector de offset directamente con una referencia que también debería ser un vector de offset.
        # Si la referencia es una señal temporal, esta comparación no es directa.
        # Asumamos que la referencia es un vector de offset guardado.
        
        ref_offset_vector = self.calibration_manager.load_reference_signal(reference_id) # Asumimos que esto carga un vector de offset
        if ref_offset_vector is None or ref_offset_vector.ndim != 1:
            QMessageBox.warning(self, "Error", "La referencia cargada no parece ser un vector de offset válido.")
            return

        current_offset = self.calibration_manager.offset_params
        
        try:
            results = self.calibration_manager.compare_with_reference(current_offset, reference_id) # Esto usa el método de la clase
            if results:
                self.findChild(QLabel, "mse_label").setText(f"MSE: {results['mse']:.4f}")
                self.findChild(QLabel, "similarity_label").setText(f"Similitud: {results['similarity_percent']:.2f}%")
                
                # Plot en comp_plot_widget
                self.comp_plot_widget.clear()
                num_ch = len(current_offset)
                x_axis = np.arange(1, num_ch + 1)
                self.comp_plot_widget.plot(x_axis, current_offset, pen=pg.mkPen('m', width=2), symbol='o', name="Offset Actual")
                if len(ref_offset_vector) == num_ch:
                    self.comp_plot_widget.plot(x_axis, ref_offset_vector, pen=pg.mkPen('c', width=2), symbol='x', name="Offset Referencia")
                else:
                    logger.warning("Número de canales en referencia no coincide con actual.")
            else:
                QMessageBox.warning(self, "Error", "No se pudo realizar la comparación.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error durante la comparación: {e}")
            logger.error(f"Error comparando con referencia: {e}")


    def _save_current_signal_as_reference_dialog(self):
        # Esta función guardaría la señal *actualmente visualizada* o *recién calibrada* como referencia.
        # Necesita una forma de obtener esa "señal actual".
        # Si es el offset, se guarda el vector de offset.
        if self.calibration_manager.offset_params is None:
            QMessageBox.warning(self, "Advertencia", "No hay datos de calibración (offset) actuales para guardar como referencia.")
            return

        reference_id, ok = QInputDialog.getText(self, "Guardar Referencia", "Ingrese un ID para esta referencia (e.g., paciente_reposo_dia1):")
        if ok and reference_id:
            # Guardar el vector de offset como "datos" de la referencia
            self.calibration_manager.save_signal_as_reference(self.calibration_manager.offset_params, reference_id)
            QMessageBox.information(self, "Referencia Guardada", f"Offset actual guardado como referencia '{reference_id}'.")
        else:
            QMessageBox.information(self, "Cancelado", "Guardado de referencia cancelado.")


    # --- Historial de Calibración ---
    def _load_calibration_history(self):
        """Carga el historial de calibraciones del DataManager."""
        if self.patient_id:
            # Asumimos que DataManager guarda cada calibración como una entrada separada
            # o que hay una lista de historiales.
            # Ejemplo: self.data_manager.cargar_datos(self.patient_id, "calibration_history_list")
            # Por ahora, el historial es en memoria de esta sesión.
            self.calibration_history = self.data_manager.cargar_datos(self.patient_id, "calibration_history") or []
            self._update_history_table_display()

    def _add_to_calibration_history(self, params: np.ndarray, details: str):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "patient_id": self.patient_id,
            "offset_values": params.tolist(),
            "details": details,
            "config_snapshot": self.config.copy() # Guardar config usada para esta calibración
        }
        self.calibration_history.append(entry)
        if self.patient_id:
            self.data_manager.guardar_datos(self.patient_id, "calibration_history", self.calibration_history)
        self._update_history_table_display()

    def _update_history_table_display(self, filtered_history: Optional[List[Dict]] = None):
        table = self.findChild(QTableWidget, "history_table")
        if not table: return

        history_to_show = filtered_history if filtered_history is not None else self.calibration_history
        table.setRowCount(len(history_to_show))
        table.setColumnCount(4) # Timestamp, Patient, Offset (resumen), Detalles
        table.setHorizontalHeaderLabels(["Timestamp", "Paciente", "Offset (Ch1)", "Detalles"])

        for row, entry in enumerate(history_to_show):
            ts = datetime.fromisoformat(entry["timestamp"]).strftime('%Y-%m-%d %H:%M:%S')
            offset_ch1 = f"{entry['offset_values'][0]:.3f}" if entry['offset_values'] else "N/A"
            
            table.setItem(row, 0, QTableWidgetItem(ts))
            table.setItem(row, 1, QTableWidgetItem(entry.get("patient_id", "N/A")))
            table.setItem(row, 2, QTableWidgetItem(offset_ch1))
            table.setItem(row, 3, QTableWidgetItem(entry["details"]))
        table.resizeColumnsToContents()

    def _filter_calibration_history(self):
        search_text = self.findChild(QLineEdit, "search_edit").text().lower()
        selected_date = self.findChild(QDateEdit, "date_filter").date()

        filtered = []
        for entry in self.calibration_history:
            entry_date = datetime.fromisoformat(entry["timestamp"]).date()
            matches_date = (entry_date == selected_date.toPyDate())
            
            matches_text = True
            if search_text:
                matches_text = (search_text in entry["patient_id"].lower() or
                                search_text in entry["details"].lower() or
                                search_text in str(entry["offset_values"]).lower())
            
            if matches_date and matches_text:
                filtered.append(entry)
        self._update_history_table_display(filtered)

    def _export_calibration_history(self):
        if not self.calibration_history:
            QMessageBox.information(self, "Exportar", "No hay historial para exportar.")
            return
        filepath, _ = QFileDialog.getSaveFileName(self, "Exportar Historial de Calibración", "", "JSON Files (*.json);;CSV Files (*.csv)")
        if not filepath: return

        try:
            if filepath.endswith(".json"):
                with open(filepath, 'w') as f:
                    json.dump(self.calibration_history, f, indent=4)
            elif filepath.endswith(".csv"):
                import csv
                with open(filepath, 'w', newline='') as f:
                    if not self.calibration_history: return
                    # Aplanar los datos para CSV, especialmente 'offset_values'
                    fieldnames = ["timestamp", "patient_id", "details"]
                    # Añadir columnas para cada canal de offset
                    max_channels_in_history = 0
                    if self.calibration_history and self.calibration_history[0].get("offset_values"):
                        max_channels_in_history = len(self.calibration_history[0]["offset_values"])
                    for i in range(max_channels_in_history):
                        fieldnames.append(f"offset_ch{i+1}")
                    
                    writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
                    writer.writeheader()
                    for entry in self.calibration_history:
                        row_data = entry.copy()
                        offsets = row_data.pop("offset_values", [])
                        for i, offset_val in enumerate(offsets):
                            row_data[f"offset_ch{i+1}"] = offset_val
                        writer.writerow(row_data)
            QMessageBox.information(self, "Exportado", "Historial de calibración exportado exitosamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo exportar el historial: {e}")
            logger.error(f"Error exportando historial de calibración: {e}")


    def _print_calibration_history(self):
        if not self.calibration_history:
            QMessageBox.information(self, "Imprimir", "No hay historial para imprimir.")
            return

        doc = QTextDocument()
        html = "<html><body><h1>Historial de Calibración</h1><table border='1' cellspacing='0' cellpadding='5'>"
        html += "<tr><th>Timestamp</th><th>Paciente</th><th>Offset (Ch1)</th><th>Detalles</th></tr>"
        for entry in self.calibration_history:
            ts = datetime.fromisoformat(entry["timestamp"]).strftime('%Y-%m-%d %H:%M:%S')
            offset_ch1 = f"{entry['offset_values'][0]:.3f}" if entry['offset_values'] else "N/A"
            html += f"<tr><td>{ts}</td><td>{entry['patient_id']}</td><td>{offset_ch1}</td><td>{entry['details']}</td></tr>"
        html += "</table></body></html>"
        doc.setHtml(html)

        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            doc.print_(printer)
            QMessageBox.information(self, "Impreso", "Historial enviado a la impresora.")


    # --- Utilidades ---
    def _log(self, message: str, level: str = "info"):
        # Asumir que hay un QTextEdit llamado 'log_area_calib' o similar en la UI
        log_widget = self.findChild(QTextEdit, "log_area_calib") # Ajustar nombre si es diferente
        if log_widget:
            timestamp = datetime.now().strftime("%H:%M:%S")
            formatted_message = f"[{timestamp}] {message}"
            if level == "error": log_widget.append(f"<font color='red'>{formatted_message}</font>")
            elif level == "warning": log_widget.append(f"<font color='orange'>{formatted_message}</font>")
            else: log_widget.append(formatted_message)
            log_widget.ensureCursorVisible()
        
        if level == "error": logger.error(message)
        elif level == "warning": logger.warning(message)
        else: logger.info(message)

    def closeEvent(self, event):
        logger.info("Cerrando Página de Calibración...")
        if self.calibration_thread and self.calibration_thread.isRunning():
            self.calibration_thread.quit() # No hay stop() explícito, quit() es para QThread
            self.calibration_thread.wait(1000)
        if self.emg_acquirer:
            self.emg_acquirer.close()
        self._save_page_config()
        super().closeEvent(event)

# Ejemplo de Uso (si se ejecuta como script independiente)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    class DummyDataManager: # Para prueba
        def guardar_datos(self, patient_id, data_type, data): pass
        def cargar_datos(self, patient_id, data_type):
            if data_type == "calibration_page_config": return None # Forzar defaults
            if data_type == "calibration_history": return []
            return None

    dummy_dm = DummyDataManager() # type: ignore
    
    # Cargar estilos
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss") # Ajustar ruta
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f:
            app.setStyleSheet(f.read())
    
    main_window = PaginaCalibracion(data_manager=dummy_dm, patient_id="test_patient_calib_gui")
    main_window.show()
    sys.exit(app.exec())
    