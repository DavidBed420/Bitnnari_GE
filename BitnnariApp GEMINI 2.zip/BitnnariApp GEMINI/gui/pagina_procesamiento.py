"""
pagina_procesamiento.py

Interfaz gráfica (PyQt6) para el módulo de Procesamiento de Señales EMG.
Permite al usuario configurar filtros, visualizar señales en diferentes etapas
(cruda, calibrada, procesada), extraer características y realizar análisis avanzados.

Esta página interactúa con EMGProcessingEngine, EMGCalibrationManager (opcional),
EMGAcquisition (para tiempo real) y GestorDatos. Idealmente, estas interacciones
se canalizarían a través de una EmgAppFacade.
"""
import sys
import json
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QTabWidget, QProgressBar, QLineEdit, QScrollArea,
    QGroupBox, QFormLayout, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox,
    QFileDialog, QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QSizePolicy, QCheckBox, QFrame
)

# Importaciones del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos # Asumiendo que está en el path
from BitnnariApp.processing.emg_processing import EMGProcessingEngine
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager, CalibrationRunConfig
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition, SerialConfig, AcquisitionConfig as EMGDeviceAcqConfig, FilterConfig as EMGFilterConfig, LogConfig as EMGLogConfig
from BitnnariApp.data.models.emg_record import EmgRecordModel

logger = logging.getLogger(__name__)
if not logger.handlers: # Evitar duplicar handlers si ya está configurado globalmente
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


# Hilo para adquisición y procesamiento en tiempo real
class RealTimeProcessingThread(QThread):
    new_data_processed = pyqtSignal(dict) # Emite {'raw': ndarray, 'calibrated': ndarray, 'processed': ndarray, 'timestamp': float}
    processing_error = pyqtSignal(str)
    finished_signal = pyqtSignal()

    def __init__(self,
                 acquirer: EMGAcquisition,
                 processor: EMGProcessingEngine,
                 calibrator: Optional[EMGCalibrationManager] = None,
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.acquirer = acquirer
        self.processor = processor
        self.calibrator = calibrator
        self._is_running = False
        self.num_channels = self.acquirer.acq_config.num_channels_active

    def run(self):
        self._is_running = True
        if not self.acquirer.is_connected():
            if not self.acquirer.connect():
                self.processing_error.emit("Fallo al conectar con el dispositivo de adquisición.")
                self._is_running = False
                self.finished_signal.emit()
                return
        
        # Asegurar modo continuo
        original_mode = self.acquirer.acq_config.mode
        self.acquirer.set_mode('continuous')

        logger.info("Hilo de procesamiento en tiempo real iniciado.")
        while self._is_running:
            try:
                packet = self.acquirer.read_data() # Lee un paquete (que puede tener múltiples muestras si el Arduino las agrupa)
                if packet and 'raw_data' in packet:
                    raw_signal_segment = np.array(packet['raw_data'], dtype=float) # Asumir que es [valores_canal1, ..., valores_canalN] para una muestra temporal
                    
                    # Para procesamiento, necesitamos [n_samples, n_channels]
                    # Si read_data devuelve una sola "muestra" multicanal, la reformateamos
                    if raw_signal_segment.ndim == 1:
                        raw_signal_segment = raw_signal_segment.reshape(1, -1) # [1, n_channels]

                    calibrated_signal = raw_signal_segment
                    if self.calibrator and self.calibrator.current_calibration_params:
                        calibrated_signal = self.calibrator.apply_calibration_to_signal(raw_signal_segment)
                    
                    processed_signal = self.processor.process_signal(calibrated_signal, calibration_manager=None) # Calibración ya aplicada
                    
                    self.new_data_processed.emit({
                        'raw': raw_signal_segment.squeeze(),
                        'calibrated': calibrated_signal.squeeze(),
                        'processed': processed_signal.squeeze(),
                        'timestamp': packet.get('arduino_ms', time.time() * 1000)
                    })
                
                # El delay lo maneja el Arduino y el timeout de lectura.
                # Un pequeño sleep aquí para ceder el control si no hay datos.
                # El método read_data() del adquisidor ya tiene un manejo de buffer y timeouts.
                # Si el Arduino envía datos a, por ejemplo, 10ms (100Hz), el bucle se ejecutará tan rápido como pueda leer.
                time.sleep(self.acquirer.acq_config.delay_ms / 2000.0 if self.acquirer.acq_config.delay_ms > 0 else 0.001)


            except Exception as e:
                logger.error(f"Error en el hilo de procesamiento: {e}", exc_info=True)
                self.processing_error.emit(str(e))
                # Considerar si detener el hilo en caso de error grave
        
        self.acquirer.set_mode(original_mode) # Restaurar modo
        # self.acquirer.disconnect() # No desconectar aquí, la página principal lo maneja
        self.finished_signal.emit()
        logger.info("Hilo de procesamiento en tiempo real detenido.")

    def stop(self):
        self._is_running = False


class PaginaProcesamiento(QWidget):
    """
    Página de la GUI para la configuración y ejecución del procesamiento de señales EMG.
    """
    # Señal para actualizar la barra de estado de la ventana principal (si existe)
    status_message_signal = pyqtSignal(str)

    def __init__(self,
                 patient_dni: str,
                 data_manager: GestorDatos,
                 # facade: Optional[EmgAppFacade] = None, # Idealmente se pasaría la fachada
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("paginaProcesamiento")
        self.patient_dni = patient_dni
        self.data_manager = data_manager
        # self.facade = facade # Guardar referencia a la fachada

        # Instanciar componentes de lógica de negocio
        # Estos deberían venir de la fachada o ser gestionados por ella.
        # Por ahora, los creamos aquí para que la página sea funcional.
        
        # Cargar configuración de adquisición para el paciente o usar defaults
        acq_serial_conf_dict = self.data_manager.cargar_configuracion_paciente(patient_dni, "acquisition_serial_config")
        acq_device_conf_dict = self.data_manager.cargar_configuracion_paciente(patient_dni, "acquisition_device_config")
        acq_filter_conf_dict = self.data_manager.cargar_configuracion_paciente(patient_dni, "acquisition_filter_config")
        acq_log_conf_dict = self.data_manager.cargar_configuracion_paciente(patient_dni, "acquisition_log_config")

        serial_conf = SerialConfig(**acq_serial_conf_dict) if acq_serial_conf_dict else SerialConfig()
        device_conf = EMGDeviceAcqConfig(**acq_device_conf_dict) if acq_device_conf_dict else EMGDeviceAcqConfig()
        # Usar la tasa de muestreo real de la config del dispositivo para el filtro del adquisidor
        acq_fs = 1000.0 / device_conf.delay_ms if device_conf.delay_ms > 0 else 1000.0
        filter_conf_acq = EMGFilterConfig(**acq_filter_conf_dict, sample_rate=acq_fs) if acq_filter_conf_dict else EMGFilterConfig(sample_rate=acq_fs)
        log_conf_acq = EMGLogConfig(**acq_log_conf_dict) if acq_log_conf_dict else EMGLogConfig(enabled=False) # No loguear desde aquí por defecto

        self.emg_acquirer = EMGAcquisition(
            serial_config=serial_conf,
            acq_config=device_conf,
            filter_config=filter_conf_acq, # El adquisidor puede tener su propio procesador básico
            log_config=log_conf_acq,
            simulate=True # Iniciar en modo simulación por defecto, conectar manualmente
        )
        
        # El procesador principal de esta página usará la tasa de muestreo del adquisidor
        self.processing_engine = EMGProcessingEngine(
            sampling_rate=self.emg_acquirer.processor.config.sample_rate,
            data_manager=self.data_manager,
            patient_id=self.patient_dni
        )
        
        self.calibration_manager = EMGCalibrationManager(
            data_manager=self.data_manager,
            emg_acquirer=self.emg_acquirer, # Pasar el mismo adquisidor
            patient_dni=self.patient_dni
        )

        self.real_time_thread: Optional[RealTimeProcessingThread] = None
        self.is_processing_real_time = False
        
        # Buffers para gráficos en tiempo real
        self.rt_buffer_size = int(self.processing_engine.sampling_rate * 5) # 5 segundos de datos
        self.rt_raw_data: List[np.ndarray] = []
        self.rt_calibrated_data: List[np.ndarray] = []
        self.rt_processed_data: List[np.ndarray] = []
        self.rt_time_vector: Optional[np.ndarray] = None

        self._init_ui()
        self._connect_signals()
        self.load_patient_specific_processing_config() # Carga la config de filtros para este paciente

    def _init_ui(self):
        """Inicializa la interfaz de usuario de la página."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10,10,10,10)
        main_layout.setSpacing(10)

        # Título
        title_label = QLabel("⚙️ Módulo de Procesamiento Avanzado de Señales EMG ⚙️")
        title_label.setObjectName("pageTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_label)

        # Pestañas principales
        self.tabs = QTabWidget()
        self.tabs.addTab(self._create_config_tab(), QIcon(":/icons/config.png"), "Configuración y Control")
        self.tabs.addTab(self._create_visualization_tab(), QIcon(":/icons/visualize.png"), "Visualización de Señales")
        self.tabs.addTab(self._create_features_tab(), QIcon(":/icons/features.png"), "Extracción de Características")
        self.tabs.addTab(self._create_batch_processing_tab(), QIcon(":/icons/batch.png"), "Procesamiento por Lotes")
        main_layout.addWidget(self.tabs)

        # Log de eventos
        log_group = QGroupBox("Registro de Eventos del Módulo de Procesamiento")
        log_layout = QVBoxLayout(log_group)
        self.log_text_edit = QTextEdit()
        self.log_text_edit.setReadOnly(True)
        self.log_text_edit.setFixedHeight(120)
        log_layout.addWidget(self.log_text_edit)
        main_layout.addWidget(log_group)

        self.setLayout(main_layout)
        self._populate_filter_config_ui() # Llenar UI con config cargada/default

    def _connect_signals(self):
        """Conecta señales y slots de los widgets."""
        # Botones de la pestaña de configuración
        self.btn_save_proc_config.clicked.connect(self.save_current_processing_config)
        self.btn_load_proc_config.clicked.connect(self.load_patient_specific_processing_config)
        self.btn_reset_proc_config.clicked.connect(self.reset_processing_config_to_defaults)
        
        self.btn_start_rt_processing.clicked.connect(self.toggle_real_time_processing)
        self.btn_process_loaded_signal.clicked.connect(self.process_loaded_signal_manually)
        self.btn_load_signal_file.clicked.connect(self.load_signal_from_file_action)

        # Checkbox de calibración
        self.check_apply_calibration.stateChanged.connect(self._on_calibration_toggle)

    def _log_message(self, message: str, level: str = "info"):
        """Añade un mensaje al QTextEdit de log y al logger del módulo."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.log_text_edit.append(log_entry)
        if level == "info": logger.info(message)
        elif level == "warning": logger.warning(message)
        elif level == "error": logger.error(message)

    # --- Pestaña de Configuración y Control ---
    def _create_config_tab(self) -> QWidget:
        tab = QWidget()
        layout = QGridLayout(tab) # Usar GridLayout para mejor distribución

        # Columna 0: Controles de Adquisición y Calibración
        col0_widget = QWidget()
        col0_v_layout = QVBoxLayout(col0_widget)

        # -- Grupo Conexión Dispositivo --
        connection_group = QGroupBox("🔌 Conexión Dispositivo (Adquisición)")
        conn_layout = QFormLayout(connection_group)
        self.combo_ports = QComboBox()
        self._populate_ports()
        self.btn_refresh_ports = QPushButton(QIcon.fromTheme("view-refresh"), "Refrescar") # type: ignore
        self.btn_refresh_ports.clicked.connect(self._populate_ports)
        port_layout = QHBoxLayout()
        port_layout.addWidget(self.combo_ports, 1)
        port_layout.addWidget(self.btn_refresh_ports)
        conn_layout.addRow("Puerto Serial:", port_layout)
        
        self.combo_baudrate = QComboBox()
        self.combo_baudrate.addItems(["9600", "57600", "115200", "250000"])
        self.combo_baudrate.setCurrentText(str(self.emg_acquirer.serial_config.baud_rate))
        conn_layout.addRow("Baud Rate:", self.combo_baudrate)
        
        self.btn_connect_acquirer = QPushButton(QIcon.fromTheme("network-connect"), "Conectar Adquisidor") # type: ignore
        self.btn_connect_acquirer.setCheckable(True)
        self.btn_connect_acquirer.clicked.connect(self._toggle_acquirer_connection)
        conn_layout.addRow(self.btn_connect_acquirer)
        self.label_acquirer_status = QLabel("Estado: Desconectado")
        conn_layout.addRow(self.label_acquirer_status)
        col0_v_layout.addWidget(connection_group)

        # -- Grupo Calibración --
        calibration_group = QGroupBox("⚖️ Calibración")
        cal_layout = QFormLayout(calibration_group)
        self.check_apply_calibration = QCheckBox("Aplicar Calibración Guardada")
        self.check_apply_calibration.setChecked(False) # Por defecto no aplicar hasta cargar
        cal_layout.addRow(self.check_apply_calibration)
        self.btn_perform_offset_cal = QPushButton("Realizar Calibración de Offset")
        self.btn_perform_offset_cal.clicked.connect(self._perform_offset_calibration_action)
        cal_layout.addRow(self.btn_perform_offset_cal)
        self.label_cal_status = QLabel("Estado Calibración: No cargada")
        cal_layout.addRow(self.label_cal_status)
        col0_v_layout.addWidget(calibration_group)
        
        col0_v_layout.addStretch()
        layout.addWidget(col0_widget, 0, 0)


        # Columna 1: Configuración de Filtros (Scrollable)
        filters_scroll_area = QScrollArea()
        filters_scroll_area.setWidgetResizable(True)
        filters_widget_container = QWidget()
        filters_main_layout = QVBoxLayout(filters_widget_container)
        
        self.filter_checkboxes: Dict[str, QCheckBox] = {}
        self.filter_param_widgets: Dict[str, Dict[str, QWidget]] = {}

        for filter_key, default_conf in EMGProcessingEngine.DEFAULT_FILTER_CONFIG.items():
            group = QGroupBox(filter_key.replace("_", " ").title())
            form = QFormLayout(group)
            
            cb_enabled = QCheckBox("Habilitado")
            cb_enabled.setChecked(default_conf.get("enabled", False))
            cb_enabled.stateChanged.connect(lambda state, k=filter_key: self._update_filter_enable_state(k, state))
            form.addRow(cb_enabled)
            self.filter_checkboxes[filter_key] = cb_enabled
            self.filter_param_widgets[filter_key] = {}

            for param_name, param_val in default_conf.items():
                if param_name == "enabled": continue
                
                param_label = QLabel(f"{param_name.replace('_', ' ').title()}:")
                if isinstance(param_val, bool): # Debería ser manejado por el checkbox principal
                    continue
                elif isinstance(param_val, (int, float)):
                    if "order" in param_name or "kernel_size" in param_name or "window_length" in param_name or "polyorder" in param_name or "window_size" in param_name:
                        widget = QSpinBox()
                        widget.setRange(1, 100) # Rango genérico, ajustar si es necesario
                        if "polyorder" in param_name: widget.setRange(0,10)
                        if "kernel_size" in param_name or "window_length" in param_name: widget.setSingleStep(2) # Para impares
                    else:
                        widget = QDoubleSpinBox()
                        widget.setDecimals(2)
                        widget.setRange(-10000.0, 10000.0) # Rango genérico
                    widget.setValue(param_val)
                elif isinstance(param_val, str) and param_name == "method": # Para baseline o normalización
                    widget = QComboBox()
                    if filter_key == "baseline_correction": widget.addItems(["mean", "initial_segment"])
                    elif filter_key == "normalization": widget.addItems(["min-max", "z-score"])
                    widget.setCurrentText(param_val)
                else:
                    widget = QLineEdit(str(param_val)) # Fallback
                
                form.addRow(param_label, widget)
                self.filter_param_widgets[filter_key][param_name] = widget
            filters_main_layout.addWidget(group)
        
        filters_scroll_area.setWidget(filters_widget_container)
        layout.addWidget(filters_scroll_area, 0, 1) # Columna 1 para filtros

        # Columna 2: Acciones y Carga de Señal
        col2_widget = QWidget()
        col2_v_layout = QVBoxLayout(col2_widget)

        # -- Grupo Controles de Configuración de Procesamiento --
        proc_config_group = QGroupBox("🛠️ Gestión Config. Procesamiento")
        proc_config_layout = QVBoxLayout(proc_config_group)
        self.btn_save_proc_config = QPushButton(QIcon.fromTheme("document-save"), "Guardar Config. Proc.") # type: ignore
        self.btn_load_proc_config = QPushButton(QIcon.fromTheme("document-open"), "Cargar Config. Proc.") # type: ignore
        self.btn_reset_proc_config = QPushButton(QIcon.fromTheme("edit-undo"), "Restaurar Defaults Proc.") # type: ignore
        proc_config_layout.addWidget(self.btn_save_proc_config)
        proc_config_layout.addWidget(self.btn_load_proc_config)
        proc_config_layout.addWidget(self.btn_reset_proc_config)
        col2_v_layout.addWidget(proc_config_group)

        # -- Grupo Control de Procesamiento --
        processing_control_group = QGroupBox("⏯️ Control de Procesamiento")
        pcg_layout = QVBoxLayout(processing_control_group)
        self.btn_start_rt_processing = QPushButton(QIcon.fromTheme("media-playback-start"), "Iniciar/Detener Procesamiento en Tiempo Real") # type: ignore
        self.btn_start_rt_processing.setCheckable(True)
        pcg_layout.addWidget(self.btn_start_rt_processing)
        
        self.btn_load_signal_file = QPushButton(QIcon.fromTheme("document-open"), "Cargar Señal desde Archivo...") # type: ignore
        pcg_layout.addWidget(self.btn_load_signal_file)
        self.label_loaded_signal_info = QLabel("Ninguna señal cargada.")
        pcg_layout.addWidget(self.label_loaded_signal_info)
        self.btn_process_loaded_signal = QPushButton("Procesar Señal Cargada Manualmente")
        self.btn_process_loaded_signal.setEnabled(False) # Habilitar cuando se carga una señal
        pcg_layout.addWidget(self.btn_process_loaded_signal)
        col2_v_layout.addWidget(processing_control_group)
        
        col2_v_layout.addStretch()
        layout.addWidget(col2_widget, 0, 2)

        layout.setColumnStretch(0,1) # Columna de conexión/calibración
        layout.setColumnStretch(1,2) # Columna de filtros (más ancha)
        layout.setColumnStretch(2,1) # Columna de acciones

        return tab

    def _populate_ports(self):
        """Llena el QComboBox de puertos seriales."""
        self.combo_ports.clear()
        ports = serial.tools.list_ports.comports()
        if not ports:
            self.combo_ports.addItem("No hay puertos disponibles")
            self.combo_ports.setEnabled(False)
        else:
            for port in ports:
                self.combo_ports.addItem(port.device, port.description)
            self.combo_ports.setEnabled(True)
            # Intentar seleccionar el puerto guardado si existe
            saved_port = self.emg_acquirer.serial_config.port
            if saved_port:
                index = self.combo_ports.findData(saved_port) # Asumiendo que guardamos device como data
                if index == -1: index = self.combo_ports.findText(saved_port) # Probar por texto
                if index != -1: self.combo_ports.setCurrentIndex(index)


    def _toggle_acquirer_connection(self):
        """Conecta o desconecta el dispositivo de adquisición."""
        if self.emg_acquirer.is_connected():
            self.emg_acquirer.disconnect()
            self.btn_connect_acquirer.setText("Conectar Adquisidor")
            self.btn_connect_acquirer.setChecked(False)
            self.label_acquirer_status.setText("Estado: Desconectado")
            self.status_message_signal.emit("Adquisidor desconectado.")
            self._log_message("Adquisidor desconectado.", "info")
        else:
            selected_port = self.combo_ports.currentText()
            selected_baud = int(self.combo_baudrate.currentText())
            
            self.emg_acquirer.serial_config.port = selected_port
            self.emg_acquirer.serial_config.baud_rate = selected_baud
            
            if self.emg_acquirer.connect():
                self.btn_connect_acquirer.setText("Desconectar Adquisidor")
                self.btn_connect_acquirer.setChecked(True)
                self.label_acquirer_status.setText(f"Estado: Conectado a {selected_port}")
                self.status_message_signal.emit(f"Adquisidor conectado a {selected_port}.")
                self._log_message(f"Adquisidor conectado a {selected_port}.", "info")
                # Actualizar la tasa de muestreo del procesador si cambió en el adquisidor
                self.processing_engine.update_sampling_rate(1000.0 / self.emg_acquirer.acq_config.delay_ms 
                                                            if self.emg_acquirer.acq_config.delay_ms > 0 
                                                            else self.emg_acquirer.processor.config.sample_rate)
            else:
                self.btn_connect_acquirer.setChecked(False)
                self.label_acquirer_status.setText("Estado: Fallo al conectar")
                QMessageBox.critical(self, "Error de Conexión", f"No se pudo conectar al puerto {selected_port}.")
                self.status_message_signal.emit(f"Fallo al conectar a {selected_port}.")
                self._log_message(f"Fallo al conectar a {selected_port}.", "error")


    def _on_calibration_toggle(self, state: int):
        """Maneja el cambio de estado del checkbox de calibración."""
        if state == Qt.CheckState.Checked.value:
            if self.calibration_manager and self.patient_dni:
                if not self.calibration_manager.current_calibration_params:
                    # Intentar cargar la última calibración si no hay una activa
                    self.calibration_manager.load_latest_calibration_params(self.patient_dni)
                
                if self.calibration_manager.current_calibration_params:
                    self.label_cal_status.setText(f"Estado Calibración: Cargada (ID: {self.calibration_manager.current_calibration_params.calibration_id[:8]}...)")
                    self._log_message("Calibración aplicada.", "info")
                else:
                    QMessageBox.warning(self, "Calibración no disponible",
                                        "No hay parámetros de calibración cargados para este paciente. "
                                        "Por favor, realice una calibración primero.")
                    self.check_apply_calibration.setChecked(False)
                    self.label_cal_status.setText("Estado Calibración: No cargada")
            else:
                QMessageBox.warning(self, "Error", "Gestor de calibración o DNI de paciente no disponible.")
                self.check_apply_calibration.setChecked(False)
        else:
            self.label_cal_status.setText("Estado Calibración: No aplicada")
            self._log_message("Calibración desactivada.", "info")


    def _perform_offset_calibration_action(self):
        """Inicia el proceso de calibración de offset."""
        if not (self.calibration_manager and self.emg_acquirer and self.patient_dni):
            QMessageBox.critical(self, "Error", "Componentes necesarios (calibrador, adquisidor, DNI) no están listos.")
            return

        if not self.emg_acquirer.is_connected():
            QMessageBox.warning(self, "Advertencia", "El dispositivo de adquisición no está conectado. Conéctelo primero.")
            return

        # Usar una configuración de ejecución de calibración por defecto o configurable
        # Por ahora, usamos valores fijos para el ejemplo.
        # La config de filtro para calibración podría venir de la UI o ser un preset.
        cal_filter_conf = EMGFilterConfig(
            sample_rate=self.processing_engine.sampling_rate, # Usar la tasa actual
            notch_freq=self.processing_engine.filters_config["notch"]["freq_hz"],
            notch_quality=self.processing_engine.filters_config["notch"]["quality_factor"],
            bandpass_low_freq=1.0, # HP muy bajo para offset
            bandpass_high_freq=40.0, # LP para quitar ruido pero mantener línea base
            bandpass_order=2,
            enabled=True
        )
        run_config = CalibrationRunConfig(offset_duration_s=5.0, apply_filter_during_offset_cal=True, filter_config_for_cal=cal_filter_conf)
        
        QMessageBox.information(self, "Calibración de Offset", 
                                "Se adquirirán datos durante 5 segundos. "
                                "Por favor, mantenga los músculos en completo reposo.")
        
        # Esto podría ser un QProgressDialog en una app real
        self.status_message_signal.emit("Realizando calibración de offset...")
        self._log_message("Iniciando calibración de offset...", "info")
        
        success = self.calibration_manager.perform_offset_calibration(run_config)
        
        if success and self.calibration_manager.current_calibration_params:
            self.label_cal_status.setText(f"Offset Calibrado (ID: {self.calibration_manager.current_calibration_params.calibration_id[:8]}...)")
            QMessageBox.information(self, "Calibración Exitosa", "Calibración de offset completada y guardada.")
            self.status_message_signal.emit("Calibración de offset completada.")
            self._log_message(f"Offset calibrado: {self.calibration_manager.current_calibration_params.offset_values}", "info")
            self.check_apply_calibration.setChecked(True) # Activarla por defecto
        else:
            self.label_cal_status.setText("Estado Calibración: Falló")
            QMessageBox.critical(self, "Error de Calibración", "No se pudo completar la calibración de offset.")
            self.status_message_signal.emit("Fallo en calibración de offset.")
            self._log_message("Fallo en calibración de offset.", "error")


    def _update_filter_enable_state(self, filter_key: str, state: int):
        """Actualiza el estado 'enabled' de un filtro en la configuración del engine."""
        is_enabled = (state == Qt.CheckState.Checked.value)
        if filter_key in self.processing_engine.filters_config:
            self.processing_engine.filters_config[filter_key]["enabled"] = is_enabled
            self._log_message(f"Filtro '{filter_key}' {'habilitado' if is_enabled else 'deshabilitado'}.", "debug")
            # Habilitar/deshabilitar widgets de parámetros asociados
            for param_widget in self.filter_param_widgets.get(filter_key, {}).values():
                param_widget.setEnabled(is_enabled)


    def _collect_filter_config_from_ui(self) -> Dict[str, Any]:
        """Recolecta la configuración de filtros desde los widgets de la UI."""
        current_config = self.processing_engine.DEFAULT_FILTER_CONFIG.copy()
        for filter_key, params_widgets_dict in self.filter_param_widgets.items():
            current_config[filter_key] = {"enabled": self.filter_checkboxes[filter_key].isChecked()}
            for param_name, widget in params_widgets_dict.items():
                if isinstance(widget, QSpinBox):
                    current_config[filter_key][param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    current_config[filter_key][param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    current_config[filter_key][param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit): # Podría necesitar conversión de tipo
                    current_config[filter_key][param_name] = widget.text() 
        return current_config

    def _populate_filter_config_ui(self, config_to_load: Optional[Dict[str, Any]] = None):
        """Llena los widgets de la UI con una configuración de filtros dada o la del engine."""
        config = config_to_load if config_to_load else self.processing_engine.filters_config
        
        for filter_key, params_widgets_dict in self.filter_param_widgets.items():
            filter_conf_data = config.get(filter_key, {})
            
            # Checkbox de habilitación
            is_enabled = filter_conf_data.get("enabled", False)
            self.filter_checkboxes[filter_key].setChecked(is_enabled)
            
            for param_name, widget in params_widgets_dict.items():
                widget.setEnabled(is_enabled) # Habilitar/deshabilitar widget de parámetro
                value = filter_conf_data.get(param_name)
                if value is None: continue

                if isinstance(widget, QSpinBox): widget.setValue(int(value))
                elif isinstance(widget, QDoubleSpinBox): widget.setValue(float(value))
                elif isinstance(widget, QComboBox): widget.setCurrentText(str(value))
                elif isinstance(widget, QLineEdit): widget.setText(str(value))
        self._log_message("UI de configuración de filtros actualizada.", "debug")

    def save_current_processing_config(self):
        """Guarda la configuración de procesamiento actual (desde la UI) para el paciente."""
        if not self.patient_dni:
            QMessageBox.warning(self, "Error", "No hay un paciente seleccionado para guardar la configuración.")
            return
        
        current_ui_config = self._collect_filter_config_from_ui()
        self.processing_engine.filters_config = current_ui_config # Actualizar config del engine
        self.processing_engine.save_processing_config(self.patient_dni)
        self._log_message(f"Configuración de procesamiento guardada para paciente {self.patient_dni}.", "info")
        QMessageBox.information(self, "Configuración Guardada", "La configuración de procesamiento ha sido guardada.")

    def load_patient_specific_processing_config(self):
        """Carga la configuración de procesamiento guardada para el paciente actual y actualiza la UI."""
        if not self.patient_dni:
            QMessageBox.information(self, "Información", "No hay paciente seleccionado. Se usarán/mantendrán los defaults.")
            self._populate_filter_config_ui(self.processing_engine.DEFAULT_FILTER_CONFIG)
            return

        self.processing_engine.load_processing_config(self.patient_dni) # Esto actualiza self.processing_engine.filters_config
        self._populate_filter_config_ui(self.processing_engine.filters_config)
        self._log_message(f"Configuración de procesamiento cargada para paciente {self.patient_dni}.", "info")
        # QMessageBox.information(self, "Configuración Cargada", "Configuración de procesamiento cargada.") # Puede ser molesto

    def reset_processing_config_to_defaults(self):
        """Restaura la configuración de filtros de la UI a los valores por defecto del engine."""
        self.processing_engine.filters_config = self.processing_engine.DEFAULT_FILTER_CONFIG.copy()
        self._populate_filter_config_ui()
        self._log_message("Configuración de procesamiento restaurada a los valores por defecto.", "info")
        QMessageBox.information(self, "Configuración Restaurada", "Los filtros se han restaurado a sus valores por defecto.")


    # --- Pestaña de Visualización ---
    def _create_visualization_tab(self) -> QWidget:
        tab = QWidget()
        layout = QGridLayout(tab) # Usar GridLayout para múltiples gráficos

        self.plot_raw = pg.PlotWidget(title="Señal Cruda")
        self.plot_raw.setBackground((30,30,30)) # Color de fondo oscuro
        self.plot_raw.showGrid(x=True, y=True, alpha=0.3)
        layout.addWidget(self.plot_raw, 0, 0)

        self.plot_calibrated = pg.PlotWidget(title="Señal Calibrada")
        self.plot_calibrated.setBackground((30,30,30))
        self.plot_calibrated.showGrid(x=True, y=True, alpha=0.3)
        layout.addWidget(self.plot_calibrated, 0, 1)

        self.plot_processed = pg.PlotWidget(title="Señal Procesada (Filtrada)")
        self.plot_processed.setBackground((30,30,30))
        self.plot_processed.showGrid(x=True, y=True, alpha=0.3)
        layout.addWidget(self.plot_processed, 1, 0)

        self.plot_fft = pg.PlotWidget(title="Espectro de Frecuencia (FFT de Señal Procesada)")
        self.plot_fft.setBackground((30,30,30))
        self.plot_fft.showGrid(x=True, y=True, alpha=0.3)
        self.plot_fft.setLabel('bottom', 'Frecuencia', units='Hz')
        self.plot_fft.setLabel('left', 'Amplitud')
        layout.addWidget(self.plot_fft, 1, 1)
        
        # Curvas para los gráficos (se inicializan vacías)
        self.curves_raw: List[pg.PlotDataItem] = []
        self.curves_calibrated: List[pg.PlotDataItem] = []
        self.curves_processed: List[pg.PlotDataItem] = []
        self.curve_fft: Optional[pg.PlotDataItem] = None

        return tab

    def _init_plot_curves(self, num_channels: int):
        """Inicializa o reinicializa las curvas en los gráficos según el número de canales."""
        colors = pg.colormap.get("CET-D1A").getColors(mode=pg.ColorMap.BYTE, N=max(8, num_channels)) # Colormap variado

        for plot, curve_list in [(self.plot_raw, self.curves_raw),
                                 (self.plot_calibrated, self.curves_calibrated),
                                 (self.plot_processed, self.curves_processed)]:
            plot.clear()
            curve_list.clear()
            plot.addLegend(offset=(10,10))
            for i in range(num_channels):
                pen_color = colors[i % len(colors)]
                curve = plot.plot(pen=pg.mkPen(color=pen_color, width=1), name=f'Canal {i+1}')
                curve_list.append(curve)
        
        self.plot_fft.clear()
        self.curve_fft = self.plot_fft.plot(pen=pg.mkPen(color='y', width=1), name='FFT')


    # --- Pestaña de Extracción de Características ---
    def _create_features_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        self.btn_extract_features = QPushButton(QIcon.fromTheme("applications-science"), "Extraer Características de Señal Procesada Actual") # type: ignore
        self.btn_extract_features.clicked.connect(self.extract_and_display_features)
        layout.addWidget(self.btn_extract_features)

        self.table_features = QTableWidget()
        self.table_features.setColumnCount(2) # Característica, Valor
        self.table_features.setHorizontalHeaderLabels(["Característica", "Valor (por canal, promedio o global)"])
        self.table_features.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table_features.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table_features)
        
        return tab

    # --- Pestaña de Procesamiento por Lotes ---
    def _create_batch_processing_tab(self) -> QWidget:
        tab = QWidget()
        layout = QGridLayout(tab) # Usar grid para mejor organización

        # Selección de archivos
        files_group = QGroupBox("Archivos para Procesamiento en Lote")
        files_layout = QVBoxLayout(files_group)
        self.list_batch_files = QListWidget()
        self.list_batch_files.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        files_layout.addWidget(self.list_batch_files)
        
        btn_layout_files = QHBoxLayout()
        self.btn_batch_add_files = QPushButton(QIcon.fromTheme("list-add"), "Añadir Archivos...") # type: ignore
        self.btn_batch_add_files.clicked.connect(self._add_files_to_batch)
        btn_layout_files.addWidget(self.btn_batch_add_files)
        self.btn_batch_remove_files = QPushButton(QIcon.fromTheme("list-remove"), "Quitar Seleccionados") # type: ignore
        self.btn_batch_remove_files.clicked.connect(self._remove_files_from_batch)
        btn_layout_files.addWidget(self.btn_batch_remove_files)
        self.btn_batch_clear_files = QPushButton(QIcon.fromTheme("edit-clear"), "Limpiar Lista") # type: ignore
        self.btn_batch_clear_files.clicked.connect(lambda: self.list_batch_files.clear())
        btn_layout_files.addWidget(self.btn_batch_clear_files)
        files_layout.addLayout(btn_layout_files)
        layout.addWidget(files_group, 0, 0)

        # Configuración y ejecución
        action_group = QGroupBox("Acciones de Lote")
        action_layout = QVBoxLayout(action_group)
        self.check_batch_use_current_filters = QCheckBox("Usar configuración de filtros actual de la pestaña 'Configuración'")
        self.check_batch_use_current_filters.setChecked(True)
        action_layout.addWidget(self.check_batch_use_current_filters)
        # Se podrían añadir opciones para cargar una config de filtros específica para el lote
        
        self.btn_batch_run_processing = QPushButton(QIcon.fromTheme("media-playback-start"), "Iniciar Procesamiento en Lote") # type: ignore
        self.btn_batch_run_processing.clicked.connect(self._run_batch_processing)
        action_layout.addWidget(self.btn_batch_run_processing)
        
        self.progress_batch = QProgressBar()
        self.progress_batch.setVisible(False)
        action_layout.addWidget(self.progress_batch)
        layout.addWidget(action_group, 1, 0)

        # Resultados del lote
        results_group = QGroupBox("Resultados del Procesamiento en Lote (Resumen)")
        results_layout = QVBoxLayout(results_group)
        self.table_batch_results = QTableWidget()
        self.table_batch_results.setColumnCount(4) # Archivo, Status, Features Principales (ej. RMS), Errores
        self.table_batch_results.setHorizontalHeaderLabels(["Archivo", "Estado", "RMS (Prom. Canales)", "Errores"])
        self.table_batch_results.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table_batch_results.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)
        results_layout.addWidget(self.table_batch_results)
        
        self.btn_export_batch_summary = QPushButton(QIcon.fromTheme("document-save"), "Exportar Resumen del Lote...") # type: ignore
        self.btn_export_batch_summary.clicked.connect(self._export_batch_summary)
        results_layout.addWidget(self.btn_export_batch_summary)
        layout.addWidget(results_group, 0, 1, 2, 1) # Ocupa 2 filas en la columna 1

        layout.setColumnStretch(0,1)
        layout.setColumnStretch(1,2)
        return tab


    # --- Lógica de la Página ---
    def toggle_real_time_processing(self):
        if not self.emg_acquirer:
            QMessageBox.critical(self, "Error", "El sistema de adquisición no está inicializado.")
            self.btn_start_rt_processing.setChecked(False)
            return

        if self.is_processing_real_time: # Detener
            if self.real_time_thread and self.real_time_thread.isRunning():
                self.real_time_thread.stop()
                # self.real_time_thread.wait() # Esperar a que termine limpiamente
            self.is_processing_real_time = False
            self.btn_start_rt_processing.setText("Iniciar Procesamiento en Tiempo Real")
            self.btn_start_rt_processing.setIcon(QIcon.fromTheme("media-playback-start")) # type: ignore
            self.status_message_signal.emit("Procesamiento en tiempo real detenido.")
            self._log_message("Procesamiento en tiempo real detenido.", "info")
            # Habilitar otros controles
            self.btn_process_loaded_signal.setEnabled(hasattr(self, '_loaded_signal_data_for_manual_process') and self._loaded_signal_data_for_manual_process is not None)
            self.btn_load_signal_file.setEnabled(True)

        else: # Iniciar
            if not self.emg_acquirer.is_connected():
                QMessageBox.warning(self, "Adquisidor no conectado", "Por favor, conecte el dispositivo de adquisición primero desde la pestaña 'Configuración y Control'.")
                self.btn_start_rt_processing.setChecked(False)
                return

            # Configurar el motor de procesamiento con los parámetros actuales de la UI
            self.processing_engine.filters_config = self._collect_filter_config_from_ui()
            self.processing_engine.update_sampling_rate(1000.0 / self.emg_acquirer.acq_config.delay_ms 
                                                        if self.emg_acquirer.acq_config.delay_ms > 0 
                                                        else self.emg_acquirer.processor.config.sample_rate)


            # Limpiar buffers y gráficos para nueva sesión RT
            self._rt_raw_data.clear()
            self._rt_calibrated_data.clear()
            self._rt_processed_data.clear()
            num_ch = self.emg_acquirer.acq_config.num_channels_active
            self._init_plot_curves(num_ch) # Reinicializar curvas para el número actual de canales
            self.rt_time_vector = np.linspace(0, self.rt_buffer_size / self.processing_engine.sampling_rate, self.rt_buffer_size, endpoint=False)


            self.real_time_thread = RealTimeProcessingThread(self.emg_acquirer, self.processing_engine, self.calibration_manager if self.check_apply_calibration.isChecked() else None)
            self.real_time_thread.new_data_processed.connect(self._update_rt_plots_and_data)
            self.real_time_thread.processing_error.connect(lambda err_msg: self._log_message(f"Error en RT Thread: {err_msg}", "error"))
            self.real_time_thread.finished_signal.connect(self._on_rt_thread_finished)
            
            self.real_time_thread.start()
            self.is_processing_real_time = True
            self.btn_start_rt_processing.setText("Detener Procesamiento en Tiempo Real")
            self.btn_start_rt_processing.setIcon(QIcon.fromTheme("media-playback-stop")) # type: ignore
            self.status_message_signal.emit("Procesamiento en tiempo real iniciado.")
            self._log_message("Procesamiento en tiempo real iniciado.", "info")
            # Deshabilitar otros controles
            self.btn_process_loaded_signal.setEnabled(False)
            self.btn_load_signal_file.setEnabled(False)

    def _on_rt_thread_finished(self):
        """Slot para cuando el hilo de tiempo real termina por sí mismo o por error."""
        if self.is_processing_real_time: # Si no fue detenido explícitamente por el botón
            self.is_processing_real_time = False
            self.btn_start_rt_processing.setChecked(False)
            self.btn_start_rt_processing.setText("Iniciar Procesamiento en Tiempo Real")
            self.btn_start_rt_processing.setIcon(QIcon.fromTheme("media-playback-start")) # type: ignore
            self.status_message_signal.emit("Procesamiento en tiempo real finalizado inesperadamente.")
            self._log_message("Procesamiento en tiempo real finalizado inesperadamente.", "warning")
            self.btn_process_loaded_signal.setEnabled(hasattr(self, '_loaded_signal_data_for_manual_process') and self._loaded_signal_data_for_manual_process is not None)
            self.btn_load_signal_file.setEnabled(True)


    def _update_rt_plots_and_data(self, data_dict: Dict[str, Any]):
        """Actualiza los gráficos y buffers con nuevos datos en tiempo real."""
        raw_segment = data_dict['raw']
        cal_segment = data_dict['calibrated']
        proc_segment = data_dict['processed']
        
        # Asumimos que raw_segment, etc., son [1, n_channels] o [n_channels] para una "muestra"
        # Necesitamos mantener un buffer de las últimas N muestras para graficar.
        
        def update_buffer(buffer_list: List[np.ndarray], new_data: np.ndarray, num_channels: int):
            if new_data.ndim == 0: # Escalar
                new_data_reshaped = np.full(num_channels, new_data)
            elif new_data.ndim == 1 and len(new_data) == num_channels: # [n_channels]
                new_data_reshaped = new_data
            elif new_data.ndim == 2 and new_data.shape[0] == 1 and new_data.shape[1] == num_channels: # [1, n_channels]
                new_data_reshaped = new_data.squeeze()
            else: # Forma inesperada
                logger.warning(f"Forma de datos RT inesperada: {new_data.shape}, se esperaban {num_channels} canales.")
                return # No añadir si la forma es incorrecta

            buffer_list.append(new_data_reshaped)
            if len(buffer_list) > self.rt_buffer_size:
                buffer_list.pop(0)

        num_ch = self.emg_acquirer.acq_config.num_channels_active
        update_buffer(self.rt_raw_data, raw_segment, num_ch)
        update_buffer(self.rt_calibrated_data, cal_segment, num_ch)
        update_buffer(self.rt_processed_data, proc_segment, num_ch)

        # Actualizar gráficos (solo si hay datos suficientes y curvas inicializadas)
        if len(self.rt_raw_data) > 1 and len(self.curves_raw) == num_ch:
            # Convertir listas de arrays a un array 2D [muestras, canales]
            data_to_plot_raw = np.array(self.rt_raw_data)
            data_to_plot_cal = np.array(self.rt_calibrated_data)
            data_to_plot_proc = np.array(self.rt_processed_data)

            current_time_points = self.rt_time_vector[:len(self.rt_raw_data)] if self.rt_time_vector is not None else None


            for i in range(num_ch):
                if i < data_to_plot_raw.shape[1]: self.curves_raw[i].setData(x=current_time_points, y=data_to_plot_raw[:, i])
                if i < data_to_plot_cal.shape[1]: self.curves_calibrated[i].setData(x=current_time_points, y=data_to_plot_cal[:, i])
                if i < data_to_plot_proc.shape[1]: self.curves_processed[i].setData(x=current_time_points, y=data_to_plot_proc[:, i])
            
            # Actualizar FFT (de la señal procesada, por ejemplo, del primer canal o promedio)
            if data_to_plot_proc.shape[1] > 0:
                signal_for_fft = data_to_plot_proc[:, 0] # FFT del primer canal procesado
                if len(signal_for_fft) > 1: # Necesita al menos 2 puntos para FFT
                    freqs, fft_amps = self.processing_engine.fourier_transform(signal_for_fft)
                    if self.curve_fft: self.curve_fft.setData(x=freqs, y=fft_amps)


    def load_signal_from_file_action(self):
        """Carga una señal EMG desde un archivo (CSV, TXT, o JSON de EmgRecordModel)."""
        if not self.patient_dni:
            QMessageBox.warning(self, "Paciente no seleccionado", "Por favor, seleccione un paciente primero.")
            return

        filepath, _ = QFileDialog.getOpenFileName(
            self, "Cargar Señal EMG", "", 
            "Archivos de Sesión EMG (*.json);;Archivos de Texto (*.txt *.csv);;Todos los Archivos (*)"
        )
        if not filepath: return

        try:
            loaded_signal_data: Optional[np.ndarray] = None
            sampling_rate_loaded: float = self.processing_engine.sampling_rate # Usar actual como default

            if filepath.endswith(".json"):
                with open(filepath, 'r', encoding='utf-8') as f:
                    data_dict = json.load(f)
                # Intentar parsear como EmgRecordModel
                # Esto es útil si el JSON fue guardado por esta misma app o sigue ese formato.
                if "record_id" in data_dict and "raw_data" in data_dict: # Asumir formato EmgRecordModel
                    record = EmgRecordModel.from_dict(data_dict)
                    loaded_signal_data = record.get_raw_data_as_array(orientation='samples_x_channels')
                    sampling_rate_loaded = record.sampling_rate_hz
                    self._log_message(f"Señal cargada desde archivo EmgRecord JSON: {os.path.basename(filepath)}", "info")
                else: # JSON genérico, buscar un campo 'signal' o 'data'
                    if "signal" in data_dict: loaded_signal_data = np.array(data_dict["signal"])
                    elif "data" in data_dict: loaded_signal_data = np.array(data_dict["data"])
                    if "sampling_rate" in data_dict: sampling_rate_loaded = float(data_dict["sampling_rate"])
                    self._log_message(f"Señal cargada desde archivo JSON genérico: {os.path.basename(filepath)}", "info")

            elif filepath.endswith((".csv", ".txt")):
                # Asumir columnas son canales, filas son muestras, o una sola columna.
                # Delimitador podría ser coma, espacio, tab. Intentar con coma primero.
                try:
                    loaded_signal_data = np.loadtxt(filepath, delimiter=',', ndmin=2)
                except ValueError:
                    try:
                        loaded_signal_data = np.loadtxt(filepath, ndmin=2) # Intentar con espacio/tab
                    except Exception as e_load:
                        raise ValueError(f"No se pudo parsear el archivo de texto. Asegúrese que sea numérico con delimitadores comunes. Error: {e_load}")
                self._log_message(f"Señal cargada desde archivo de texto: {os.path.basename(filepath)}", "info")
                # Para archivos de texto, la tasa de muestreo debe ser ingresada o asumida.
                # Podríamos añadir un QInputDialog para pedirla. Por ahora, usa la actual del engine.

            if loaded_signal_data is None or loaded_signal_data.size == 0:
                raise ValueError("El archivo no contiene datos de señal válidos o está vacío.")

            # Actualizar la tasa de muestreo del engine si se cargó una diferente
            if sampling_rate_loaded != self.processing_engine.sampling_rate:
                self.processing_engine.update_sampling_rate(sampling_rate_loaded)
                self._log_message(f"Tasa de muestreo actualizada a {sampling_rate_loaded} Hz desde el archivo.", "info")
                # Actualizar también la UI si hay un spinbox para ello
                # self.spin_sampling_rate_ui.setValue(int(sampling_rate_loaded))

            # Guardar para procesamiento manual y habilitar botón
            self._loaded_signal_data_for_manual_process = loaded_signal_data # [samples, channels]
            self.btn_process_loaded_signal.setEnabled(True)
            self.label_loaded_signal_info.setText(f"Cargado: {os.path.basename(filepath)} ({loaded_signal_data.shape[0]} muestras, {loaded_signal_data.shape[1]} canales)")
            
            # Visualizar la señal cruda cargada
            num_ch = loaded_signal_data.shape[1]
            self._init_plot_curves(num_ch) # Asegurar que las curvas estén listas
            time_vec = np.arange(loaded_signal_data.shape[0]) / sampling_rate_loaded
            for i in range(num_ch):
                self.curves_raw[i].setData(x=time_vec, y=loaded_signal_data[:, i])
            self.plot_raw.autoRange()
            self.plot_calibrated.clear() # Limpiar otros gráficos
            self.plot_processed.clear()
            self.plot_fft.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error al Cargar Señal", f"No se pudo cargar o procesar el archivo:\n{e}")
            self._log_message(f"Error cargando señal desde {filepath}: {e}", "error")
            self.btn_process_loaded_signal.setEnabled(False)
            self.label_loaded_signal_info.setText("Error al cargar señal.")


    def process_loaded_signal_manually(self):
        """Procesa la señal que fue cargada desde un archivo."""
        if not hasattr(self, '_loaded_signal_data_for_manual_process') or self._loaded_signal_data_for_manual_process is None:
            QMessageBox.warning(self, "Sin Señal", "No hay señal cargada para procesar. Por favor, cargue un archivo primero.")
            return

        raw_signal = self._loaded_signal_data_for_manual_process
        self._log_message(f"Iniciando procesamiento manual de señal cargada ({raw_signal.shape[0]}x{raw_signal.shape[1]}).", "info")
        
        # Configurar el motor de procesamiento con los parámetros actuales de la UI
        self.processing_engine.filters_config = self._collect_filter_config_from_ui()
        # La tasa de muestreo ya debería estar actualizada al cargar el archivo.

        calibrated_signal = raw_signal
        if self.check_apply_calibration.isChecked() and self.calibration_manager and self.calibration_manager.current_calibration_params:
            try:
                calibrated_signal = self.calibration_manager.apply_calibration_to_signal(raw_signal)
                self._log_message("Calibración aplicada a señal cargada.", "info")
            except Exception as e:
                self._log_message(f"Error aplicando calibración a señal cargada: {e}", "warning")
        
        processed_signal = self.processing_engine.process_signal(calibrated_signal, calibration_manager=None) # Calibración ya aplicada
        
        # Actualizar gráficos
        num_ch = raw_signal.shape[1]
        self._init_plot_curves(num_ch) # Reinicializar si el número de canales cambió
        
        time_vec = np.arange(raw_signal.shape[0]) / self.processing_engine.sampling_rate

        for i in range(num_ch):
            self.curves_raw[i].setData(x=time_vec, y=raw_signal[:, i])
            self.curves_calibrated[i].setData(x=time_vec, y=calibrated_signal[:, i])
            self.curves_processed[i].setData(x=time_vec, y=processed_signal[:, i])
        
        if num_ch > 0:
            freqs, fft_amps = self.processing_engine.fourier_transform(processed_signal[:, 0]) # FFT del primer canal procesado
            if self.curve_fft: self.curve_fft.setData(x=freqs, y=fft_amps)

        self.plot_raw.autoRange()
        self.plot_calibrated.autoRange()
        self.plot_processed.autoRange()
        self.plot_fft.autoRange()

        self._log_message("Procesamiento manual de señal cargada completado.", "info")
        self.status_message_signal.emit("Señal cargada procesada.")
        
        # Guardar resultados (opcional, o con un botón dedicado)
        if self.patient_dni and self.data_manager:
            self.processing_engine.save_processed_data(self.patient_dni, raw_signal, processed_signal)


    def extract_and_display_features(self):
        """Extrae características de la última señal procesada y las muestra en la tabla."""
        if self.is_processing_real_time:
            # Usar el último segmento de datos procesados en RT
            if not self.rt_processed_data or not self.rt_processed_data[-1].any():
                QMessageBox.warning(self, "Sin Datos", "No hay datos procesados en tiempo real para extraer características.")
                return
            # Tomar el último buffer completo para un análisis más estable
            signal_to_feature_extract = np.array(self.rt_processed_data) # [muestras_buffer, canales]
        elif hasattr(self, '_loaded_signal_data_for_manual_process') and self._loaded_signal_data_for_manual_process is not None:
            # Necesitamos la señal procesada, no la cruda cargada.
            # Re-procesar si es necesario o usar la última procesada.
            # Para ser simple, asumimos que self.plot_processed tiene los datos más recientes.
            # Esto es una simplificación; idealmente se guardaría la última señal procesada.
            if self.curves_processed and self.curves_processed[0].yData is not None:
                 signal_to_feature_extract = np.array([c.yData for c in self.curves_processed if c.yData is not None]).T
            else:
                 QMessageBox.warning(self, "Sin Datos", "No hay datos procesados de la señal cargada.")
                 return
        else:
            QMessageBox.warning(self, "Sin Datos", "No hay señal procesada disponible. Inicie procesamiento o cargue una señal.")
            return

        if signal_to_feature_extract.size == 0:
            QMessageBox.warning(self, "Datos Vacíos", "La señal procesada está vacía.")
            return
            
        self._log_message("Extrayendo características...", "info")
        
        # Asegurar que la señal sea [muestras, canales]
        if signal_to_feature_extract.ndim == 1:
            signal_to_feature_extract = signal_to_feature_extract[:, np.newaxis]

        all_channel_features = self.processing_engine.extract_all_features(signal_to_feature_extract)
        
        self.table_features.setRowCount(0) # Limpiar tabla
        if not all_channel_features:
            self._log_message("No se pudieron extraer características.", "warning")
            return

        # Asumimos que todas las listas de features tienen las mismas claves
        feature_names = list(all_channel_features[0].keys())
        self.table_features.setRowCount(len(feature_names))
        self.table_features.setColumnCount(signal_to_feature_extract.shape[1] + 1) # Feature Name + Canales
        
        header_labels = ["Característica"] + [f"Canal {i+1}" for i in range(signal_to_feature_extract.shape[1])]
        self.table_features.setHorizontalHeaderLabels(header_labels)

        for row_idx, feat_name in enumerate(feature_names):
            self.table_features.setItem(row_idx, 0, QTableWidgetItem(feat_name))
            for ch_idx in range(signal_to_feature_extract.shape[1]):
                value = all_channel_features[ch_idx].get(feat_name, float('nan'))
                self.table_features.setItem(row_idx, ch_idx + 1, QTableWidgetItem(f"{value:.4f}"))
        
        self._log_message(f"Características extraídas y mostradas para {signal_to_feature_extract.shape[1]} canales.", "info")

    # --- Métodos para Procesamiento por Lotes ---
    def _add_files_to_batch(self):
        filepaths, _ = QFileDialog.getOpenFileNames(
            self, "Seleccionar Archivos EMG para Lote", "",
            "Archivos de Sesión EMG (*.json);;Archivos de Texto (*.txt *.csv);;Todos los Archivos (*)"
        )
        if filepaths:
            for fp in filepaths:
                # Evitar duplicados
                if not self.list_batch_files.findItems(fp, Qt.MatchFlag.MatchExactly):
                    self.list_batch_files.addItem(fp)
            self._log_message(f"{len(filepaths)} archivo(s) añadido(s) al lote.", "info")

    def _remove_files_from_batch(self):
        selected_items = self.list_batch_files.selectedItems()
        if not selected_items: return
        for item in selected_items:
            self.list_batch_files.takeItem(self.list_batch_files.row(item))
        self._log_message(f"{len(selected_items)} archivo(s) quitado(s) del lote.", "info")

    def _run_batch_processing(self):
        num_files = self.list_batch_files.count()
        if num_files == 0:
            QMessageBox.information(self, "Lote Vacío", "No hay archivos en la lista para procesar.")
            return

        self.table_batch_results.setRowCount(0) # Limpiar resultados anteriores
        self.progress_batch.setVisible(True)
        self.progress_batch.setValue(0)
        
        # Usar config de filtros actual o una específica para batch?
        if self.check_batch_use_current_filters.isChecked():
            self.processing_engine.filters_config = self._collect_filter_config_from_ui()
            self._log_message("Usando configuración de filtros actual para el lote.", "info")
        else:
            # Aquí se podría cargar una config específica para el lote
            # self.processing_engine.load_processing_config("batch_default_config") # Ejemplo
            self._log_message("Lógica para cargar config de lote específica no implementada, usando la actual del engine.", "warning")


        processed_count = 0
        for i in range(num_files):
            filepath = self.list_batch_files.item(i).text()
            self.table_batch_results.insertRow(i)
            self.table_batch_results.setItem(i, 0, QTableWidgetItem(os.path.basename(filepath)))
            self.table_batch_results.setItem(i, 1, QTableWidgetItem("Procesando..."))
            QApplication.processEvents() # Mantener UI responsiva

            try:
                # Lógica de carga de señal (similar a load_signal_from_file_action)
                raw_signal_batch: Optional[np.ndarray] = None
                sampling_rate_batch = self.processing_engine.sampling_rate # Default

                if filepath.endswith(".json"): # Asumir formato EmgRecordModel
                    with open(filepath, 'r', encoding='utf-8') as f: data_dict = json.load(f)
                    if "record_id" in data_dict and "raw_data" in data_dict:
                        record = EmgRecordModel.from_dict(data_dict)
                        raw_signal_batch = record.get_raw_data_as_array(orientation='samples_x_channels')
                        sampling_rate_batch = record.sampling_rate_hz
                elif filepath.endswith((".csv", ".txt")):
                    raw_signal_batch = np.loadtxt(filepath, delimiter=',', ndmin=2) # Probar con coma
                    # Aquí, la tasa de muestreo se asume la del engine o se podría buscar en metadatos

                if raw_signal_batch is None or raw_signal_batch.size == 0:
                    raise ValueError("No se pudieron cargar datos válidos del archivo.")

                # Actualizar sampling rate del engine si es diferente para este archivo
                original_engine_fs = self.processing_engine.sampling_rate
                if sampling_rate_batch != original_engine_fs:
                    self.processing_engine.update_sampling_rate(sampling_rate_batch)
                
                # Aplicar calibración si está habilitada y disponible para el DNI del archivo
                # (Necesitaríamos una forma de asociar DNI a archivos de lote, o una cal. global)
                # Por ahora, no se aplica calibración en lote a menos que se cargue una global.
                calibrated_signal_batch = raw_signal_batch
                # if self.check_apply_calibration.isChecked() and self.calibration_manager ...

                processed_signal_batch = self.processing_engine.process_signal(calibrated_signal_batch)
                
                # Restaurar sampling rate original del engine si se cambió
                if sampling_rate_batch != original_engine_fs:
                    self.processing_engine.update_sampling_rate(original_engine_fs)

                # Extraer algunas features resumen
                if processed_signal_batch.ndim == 1: processed_signal_batch = processed_signal_batch[:,np.newaxis]
                
                avg_rms_channels = 0.0
                if processed_signal_batch.shape[1] > 0:
                    rms_values = [root_mean_square(processed_signal_batch[:, ch]) for ch in range(processed_signal_batch.shape[1])]
                    avg_rms_channels = np.mean(rms_values) if rms_values else 0.0
                
                self.table_batch_results.setItem(i, 1, QTableWidgetItem("Completado"))
                self.table_batch_results.setItem(i, 2, QTableWidgetItem(f"{avg_rms_channels:.4f}"))
                
                # Opcional: Guardar la señal procesada para cada archivo del lote
                # output_dir_batch = Path(filepath).parent / "processed_batch"
                # output_dir_batch.mkdir(exist_ok=True)
                # output_filename = output_dir_batch / f"{Path(filepath).stem}_processed.csv"
                # np.savetxt(output_filename, processed_signal_batch, delimiter=',')

                processed_count += 1
            except Exception as e:
                logger.error(f"Error procesando archivo de lote {filepath}: {e}")
                self.table_batch_results.setItem(i, 1, QTableWidgetItem("Error"))
                self.table_batch_results.setItem(i, 3, QTableWidgetItem(str(e)))
            
            self.progress_batch.setValue(int((i + 1) / num_files * 100))
        
        self.progress_batch.setVisible(False)
        self._log_message(f"Procesamiento en lote completado. {processed_count}/{num_files} archivos procesados exitosamente.", "info")
        QMessageBox.information(self, "Procesamiento en Lote Finalizado", 
                                f"{processed_count} de {num_files} archivos procesados.")


    def _export_batch_summary(self):
        """Exporta la tabla de resumen del lote a un archivo CSV."""
        if self.table_batch_results.rowCount() == 0:
            QMessageBox.information(self, "Sin Resultados", "No hay resultados en la tabla para exportar.")
            return

        filepath, _ = QFileDialog.getSaveFileName(self, "Exportar Resumen de Lote", "", "CSV Files (*.csv)")
        if not filepath: return

        try:
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                headers = [self.table_batch_results.horizontalHeaderItem(i).text() 
                           for i in range(self.table_batch_results.columnCount())]
                writer.writerow(headers)
                for row in range(self.table_batch_results.rowCount()):
                    row_data = [self.table_batch_results.item(row, col).text() if self.table_batch_results.item(row, col) else ""
                                for col in range(self.table_batch_results.columnCount())]
                    writer.writerow(row_data)
            self._log_message(f"Resumen del lote exportado a: {filepath}", "info")
            QMessageBox.information(self, "Exportación Exitosa", f"Resumen del lote guardado en {filepath}")
        except IOError as e:
            self._log_message(f"Error al exportar resumen del lote: {e}", "error")
            QMessageBox.critical(self, "Error de Exportación", f"No se pudo guardar el archivo: {e}")

    def closeEvent(self, event):
        """Asegura que el hilo de tiempo real se detenga al cerrar la página/ventana."""
        if self.real_time_thread and self.real_time_thread.isRunning():
            self.real_time_thread.stop()
            self.real_time_thread.wait()
        super().closeEvent(event)