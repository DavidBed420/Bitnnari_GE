"""
pagina_adquisicion.py

Interfaz gráfica (PyQt6) para la adquisición, visualización y gestión de sesiones EMG.
Este módulo se encarga de la interacción del usuario para configurar la adquisición,
visualizar datos en tiempo real y guardados, y gestionar sesiones.

Características Principales:
- Carga de UI: Utiliza un archivo .ui (ui_pagina_adquisicion.ui) para la definición de la interfaz.
- Configuración de Adquisición:
    - Puerto serial, baud rate, delay, número de canales.
    - Nombres y colores de canales personalizables.
- Filtros:
    - Configuración de filtros hardware (enviados al dispositivo si soporta).
    - Configuración de filtros software (aplicados por EMGDataProcessor).
- Visualización de Datos:
    - Gráficos 2D en tiempo real (pyqtgraph) para señal cruda y filtrada.
    - Múltiples tipos de gráfica (línea, barras, dispersión).
    - Controles de zoom, pan, grid y leyenda.
    - Visualización 3D opcional de la señal (GLViewWidget).
- Gestión de Sesiones:
    - Guardado de datos de adquisición (crudos, filtrados, configuración).
    - Carga de sesiones previas para visualización y análisis.
    - Tabla para mostrar historial de sesiones.
- Estadísticas y Características:
    - Cálculo y visualización de estadísticas básicas (Media, Máx, Mín, Desv. Est.).
    - Tabla para mostrar características extraídas.
- Análisis Avanzado (Básico):
    - Funcionalidad placeholder para segmentación, tendencias, histogramas.
- Exportación e Impresión:
    - Exportación de reportes de datos/estadísticas (PDF, Word, Excel).
    - Impresión de historial de sesiones.
- Logging de Eventos: Área de texto para mostrar mensajes de la aplicación.
- Threading:
    - Hilo para conexión al dispositivo (evita bloqueo de UI).
    - Hilo para adquisición continua de datos.
- Integración con GestorDatos:
    - Carga/guardado de configuraciones de adquisición y filtros por paciente.
    - Carga/guardado de datos de sesiones.
- Estilo: Diseñado para ser compatible con un QSS global (e.g., estilo_adquisicion.qss).
"""
import os
import sys
import json
import datetime
import logging
from typing import Optional, Dict, Any, List

import numpy as np
import serial.tools.list_ports
from PyQt6 import uic
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QSize, QDate
from PyQt6.QtGui import QColor, QTextDocument, QIcon
from PyQt6.QtWidgets import (
    QWidget, QComboBox, QPushButton, QSpinBox, QDoubleSpinBox,
    QMessageBox, QLineEdit, QTableWidget, QTableWidgetItem, QDateEdit,
    QTextEdit, QCheckBox, QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QFileDialog, QLabel, QColorDialog, QFrame, QSizePolicy
)
from PyQt6.QtPrintSupport import QPrinter, QPrintDialog
import pyqtgraph as pg
import pyqtgraph.opengl as gl

# Importaciones de módulos del proyecto
from BitnnariApp.acquisition.emg_adquisition import (
    EMGAcquisition, AcquisitionWorker,
    SerialConfig, AcquisitionConfig as DeviceAcqConfig,
    FilterConfig as DeviceFilterConfig, LogConfig as DeviceLogConfig
)
from BitnnariApp.data.gestor_datos import GestorDatos

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Ruta al archivo .ui
UI_FILE_PATH = os.path.join(os.path.dirname(__file__), "ui", "ui_pagina_adquisicion_actualizado.ui")
# Nota: El archivo .ui original era "ui_pagina_adquisicion.ui". Si el nuevo es "ui_pagina_adquisicion_actualizado.ui",
# asegurarse que exista o ajustar la ruta. Usaré el nombre del prompt.

DEFAULT_ACQUISITION_PAGE_CONFIG = {
    "serial_port": None,
    "baud_rate": 115200,
    "device_delay_ms": 10,
    "device_num_channels_active": 2, # Canales que el Arduino está configurado para enviar
    "device_acquisition_mode": "continuous",
    "app_num_channels_to_display": 2, # Canales que la app va a procesar/mostrar
    "channel_names": {1: "Canal 1", 2: "Canal 2", 3: "Canal 3", 4: "Canal 4", 5: "Canal 5", 6: "Canal 6", 7: "Canal 7", 8: "Canal 8"},
    "channel_colors": {
        1: "#FF0000", 2: "#00FF00", 3: "#0000FF", 4: "#FFFF00",
        5: "#FF00FF", 6: "#00FFFF", 7: "#FFA500", 8: "#800080"
    },
    "filter_sample_rate": 100.0, # Calculado como 1000/device_delay_ms
    "filter_notch_freq": 50.0,
    "filter_notch_q": 30.0,
    "filter_bandpass_low": 20.0,
    "filter_bandpass_high": 450.0,
    "filter_bandpass_order": 4,
    "filters_enabled": True,
    "log_enabled": True,
    "log_path": "emg_gui_logs",
    "log_prefix": "gui_session",
    "log_format": "csv",
    "plot_update_interval_ms": 50,
    "plot_type_2d": "Línea",
    "plot_data_range_points": 500, # Puntos a mostrar en gráfica 2D
    "3d_view_enabled_default": False,
    "3d_update_interval_ms": 100,
    "auto_connect_on_startup": False # Para no intentar conectar al inicio de la página
}


class ConnectionThread(QThread):
    """Hilo para manejar la conexión al dispositivo EMG sin bloquear la UI."""
    connection_status = pyqtSignal(bool, str) # success, message

    def __init__(self, emg_acquirer: EMGAcquisition, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.emg_acquirer = emg_acquirer

    def run(self):
        try:
            if self.emg_acquirer.connect():
                self.connection_status.emit(True, f"Conectado a {self.emg_acquirer.serial_config.port}")
            else:
                self.connection_status.emit(False, f"Fallo al conectar a {self.emg_acquirer.serial_config.port or 'puerto no especificado'}")
        except Exception as e:
            logger.error(f"Excepción en ConnectionThread: {e}")
            self.connection_status.emit(False, f"Error de conexión: {e}")


class PaginaAdquisicion(QWidget):
    """Página principal para la adquisición y visualización de señales EMG."""

    def __init__(self, data_manager: GestorDatos, patient_id: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        uic.loadUi(UI_FILE_PATH, self)
        self.setObjectName("paginaAdquisicion") # Para estilos QSS

        self.data_manager = data_manager
        self.patient_id = patient_id
        
        self.config = self._load_or_default_page_config()

        self.emg_acquirer: Optional[EMGAcquisition] = None
        self.acquisition_worker: Optional[AcquisitionWorker] = None
        self.acquisition_thread: Optional[QThread] = None
        self.connection_thread: Optional[ConnectionThread] = None

        self._plot_curves_2d: Dict[int, pg.PlotDataItem] = {}
        self._plot_data_buffers_2d: Dict[int, deque] = {}
        self._plot_3d_lines: Dict[int, GLLinePlotItem] = {}
        self._is_plot_paused = False
        self._is_3d_view_active = False

        self._setup_internal_widgets() # Para widgets creados en Python (e.g. plots)
        self._connect_signals()
        self._apply_initial_config()
        
        # Timer para actualizar la UI (e.g. estadísticas) si no es por señal directa
        self.ui_update_timer = QTimer(self)
        self.ui_update_timer.timeout.connect(self._update_ui_elements_periodically)
        # self.ui_update_timer.start(1000) # Actualizar cada segundo, por ejemplo

        logger.info(f"Página de Adquisición inicializada para paciente: {self.patient_id}")

    def _load_or_default_page_config(self) -> Dict[str, Any]:
        """Carga la configuración de la página o usa los valores por defecto."""
        page_conf_key = "acquisition_page_config"
        conf = self.data_manager.cargar_datos(self.patient_id, page_conf_key)
        if conf and isinstance(conf, dict):
            # Fusionar con defaults para asegurar que todas las claves existan
            merged_conf = DEFAULT_ACQUISITION_PAGE_CONFIG.copy()
            for key, value in conf.items():
                if key in merged_conf and isinstance(merged_conf[key], dict) and isinstance(value, dict):
                    merged_conf[key].update(value)
                else:
                    merged_conf[key] = value
            logger.info(f"Configuración de página de adquisición cargada para {self.patient_id}.")
            return merged_conf
        else:
            logger.info(f"Usando configuración por defecto para página de adquisición (paciente {self.patient_id}).")
            # Guardar la config por defecto para este paciente si no existe
            self.data_manager.guardar_datos(self.patient_id, page_conf_key, DEFAULT_ACQUISITION_PAGE_CONFIG)
            return DEFAULT_ACQUISITION_PAGE_CONFIG.copy()

    def _save_page_config(self):
        """Guarda la configuración actual de la página."""
        # Recolectar valores de los widgets de UI en self.config
        self._update_config_from_ui()
        page_conf_key = "acquisition_page_config"
        self.data_manager.guardar_datos(self.patient_id, page_conf_key, self.config)
        logger.info(f"Configuración de página de adquisición guardada para {self.patient_id}.")


    def _setup_internal_widgets(self):
        """Configura widgets que no se definen en el .ui, como los plots."""
        # Plot 2D
        self.plot_widget_2d = pg.PlotWidget(background=QColor("#1e1e1e")) # Color de fondo oscuro
        self.plot_widget_2d.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget_2d.addLegend(offset=(10,10))
        # Reemplazar el placeholder del .ui con este plot widget
        placeholder_2d = self.findChild(QWidget, "plot_widget_2d_placeholder")
        if placeholder_2d:
            layout = QVBoxLayout(placeholder_2d)
            layout.setContentsMargins(0,0,0,0)
            layout.addWidget(self.plot_widget_2d)
        else:
            logger.warning("Placeholder 'plot_widget_2d_placeholder' no encontrado en el UI.")
            # Añadirlo a algún layout por defecto si no se encuentra
            self.tabs_main.widget(1).layout().addWidget(self.plot_widget_2d)


        # Plot 3D (GLViewWidget)
        self.gl_view_widget = gl.GLViewWidget()
        self.gl_view_widget.setCameraPosition(distance=40, elevation=30, azimuth=45)
        grid = gl.GLGridItem()
        grid.scale(10,10,1)
        self.gl_view_widget.addItem(grid)
        # Reemplazar placeholder 3D
        placeholder_3d = self.findChild(QWidget, "gl_view_placeholder")
        if placeholder_3d:
            layout_3d = QVBoxLayout(placeholder_3d)
            layout_3d.setContentsMargins(0,0,0,0)
            layout_3d.addWidget(self.gl_view_widget)
        else:
            logger.warning("Placeholder 'gl_view_placeholder' no encontrado en el UI.")
            # Añadirlo a algún layout por defecto si no se encuentra
            # (asumiendo que está en la misma pestaña que el 2D, pero podría estar en otra)
            self.tabs_main.widget(1).layout().addWidget(self.gl_view_widget)
        
        self.gl_view_widget.setVisible(self.config.get("3d_view_enabled_default", False))
        self._is_3d_view_active = self.config.get("3d_view_enabled_default", False)
        self.stacked_plots.setCurrentWidget(self.page_plot_3d if self._is_3d_view_active else self.page_plot_2d)


    def _connect_signals(self):
        """Conecta señales de widgets a slots."""
        # Pestaña Configuración
        self.findChild(QPushButton, "btn_actualizar").clicked.connect(self._update_serial_ports)
        self.findChild(QPushButton, "btn_conectar").clicked.connect(self._toggle_connection)
        self.findChild(QPushButton, "btn_guardar_conf").clicked.connect(self._save_page_config)
        self.findChild(QPushButton, "btn_cargar_conf").clicked.connect(self._load_and_apply_page_config)
        
        self.findChild(QSpinBox, "num_channels_spin").valueChanged.connect(self._update_channel_config_ui)
        self.findChild(QPushButton, "btn_apply_filter_changes").clicked.connect(self._apply_filter_config_changes)

        # Pestaña Visualización
        self.findChild(QPushButton, "btn_autorange_2d").clicked.connect(lambda: self.plot_widget_2d.autoRange())
        self.findChild(QPushButton, "btn_pause_resume_2d").clicked.connect(self._toggle_plot_pause)
        self.findChild(QPushButton, "btn_toggle_view").clicked.connect(self._toggle_2d_3d_view)

        # Pestaña Sesiones
        self.findChild(QPushButton, "btn_add_sessions").clicked.connect(self._add_sessions_to_list)
        self.findChild(QPushButton, "btn_remove_session").clicked.connect(self._remove_selected_session)
        self.findChild(QPushButton, "btn_load_session_data").clicked.connect(self._load_selected_session_data)
        
        # Pestaña Análisis Batch
        self.findChild(QPushButton, "btn_batch_add_files").clicked.connect(self._batch_add_files)
        self.findChild(QPushButton, "btn_batch_remove_files").clicked.connect(self._batch_remove_files)
        self.findChild(QPushButton, "btn_batch_clear_files").clicked.connect(self._batch_clear_files)
        self.findChild(QPushButton, "btn_batch_run").clicked.connect(self._run_batch_analysis)
        self.findChild(QPushButton, "btn_export_batch_results").clicked.connect(self._export_batch_results)

        # Pestaña Análisis Avanzado
        self.findChild(QComboBox, "tipo_analisis_combo").currentIndexChanged.connect(self._update_advanced_analysis_params_ui)
        self.findChild(QPushButton, "btn_ejecutar_analisis_2").clicked.connect(self._run_advanced_analysis)
        self.findChild(QCheckBox, "check_analysis_all_channels").stateChanged.connect(self._toggle_advanced_channel_selection)


        # Barra de Acción Inferior
        self.findChild(QPushButton, "btn_iniciar_adquisicion").clicked.connect(self._toggle_acquisition_stream)
        self.findChild(QPushButton, "btn_guardar_adquisicion").clicked.connect(self._save_current_acquisition_data)
        self.findChild(QPushButton, "btn_exportar_datos").clicked.connect(self._export_current_data_report)
        self.findChild(QPushButton, "btn_imprimir_historial").clicked.connect(self._print_session_history_report)

    def _apply_initial_config(self):
        """Aplica la configuración cargada/default a los widgets de la UI."""
        # Conexión
        self._update_serial_ports() # Poblar puertos
        if self.config["serial_port"] and self.findChild(QComboBox, "puerto_combo").findText(self.config["serial_port"]) != -1:
            self.findChild(QComboBox, "puerto_combo").setCurrentText(self.config["serial_port"])
        self.findChild(QComboBox, "baud_combo").setCurrentText(str(self.config["baud_rate"]))
        self.findChild(QCheckBox, "check_auto_reconnect").setChecked(self.config.get("auto_reconnect", True))
        self.findChild(QCheckBox, "checkbox_adquisicion_continua").setChecked(self.config["device_acquisition_mode"] == "continuous")
        self.findChild(QSpinBox, "duracion_spin").setValue(self.config.get("device_acquisition_duration_s", 60))


        # Canales (Dispositivo y App)
        self.findChild(QSpinBox, "num_channels_spin").setValue(self.config["app_num_channels_to_display"])
        self._update_channel_config_ui(self.config["app_num_channels_to_display"]) # Esto también inicializa plots

        # Configuración Hardware (Dispositivo)
        self.findChild(QDoubleSpinBox, "low_pass_freq_spin").setValue(self.config.get("device_hw_lp_hz", 450.0))
        self.findChild(QDoubleSpinBox, "high_pass_freq_spin").setValue(self.config.get("device_hw_hp_hz", 20.0))
        self.findChild(QSpinBox, "sampling_rate_spin").setValue(int(1000.0 / self.config["device_delay_ms"])) # Muestra como FS

        # Filtros Software
        self.findChild(QCheckBox, "checkbox_highpass").setChecked(self.config.get("sw_filter_hp_enabled", True))
        self.findChild(QDoubleSpinBox, "spin_hp_cutoff").setValue(self.config["filter_bandpass_low"])
        self.findChild(QSpinBox, "spin_hp_order").setValue(self.config["filter_bandpass_order"])

        self.findChild(QCheckBox, "checkbox_notch").setChecked(self.config.get("sw_filter_notch_enabled", True))
        self.findChild(QDoubleSpinBox, "spin_notch_freq").setValue(self.config["filter_notch_freq"])
        self.findChild(QDoubleSpinBox, "spin_notch_q").setValue(self.config["filter_notch_q"])

        self.findChild(QCheckBox, "checkbox_lowpass").setChecked(self.config.get("sw_filter_lp_enabled", True))
        self.findChild(QDoubleSpinBox, "spin_lp_cutoff").setValue(self.config["filter_bandpass_high"])
        self.findChild(QSpinBox, "spin_lp_order").setValue(self.config["filter_bandpass_order"])
        
        self.findChild(QCheckBox, "checkbox_amplification").setChecked(self.config.get("sw_filter_amp_enabled", False))
        self.findChild(QDoubleSpinBox, "spin_amp_gain").setValue(self.config.get("sw_filter_amp_factor", 1.0))

        # Visualización
        self.findChild(QComboBox, "combo_3d_mode").setCurrentText(self.config.get("3d_plot_mode", "Waterfall 3D (Rápida)"))
        self.findChild(QSpinBox, "spin_3d_update_ms").setValue(self.config["3d_update_interval_ms"])
        
        # Cargar sesiones y métricas de batch si existen
        self._load_sessions_from_history()
        self._populate_batch_metrics_list()

        if self.config.get("auto_connect_on_startup", False):
            self._toggle_connection()

    def _update_config_from_ui(self):
        """Actualiza el diccionario self.config con los valores actuales de la UI."""
        self.config["serial_port"] = self.findChild(QComboBox, "puerto_combo").currentText()
        self.config["baud_rate"] = int(self.findChild(QComboBox, "baud_combo").currentText())
        self.config["auto_reconnect"] = self.findChild(QCheckBox, "check_auto_reconnect").isChecked()
        self.config["device_acquisition_mode"] = "continuous" if self.findChild(QCheckBox, "checkbox_adquisicion_continua").isChecked() else "timed" # Asumiendo que 'request' es 'timed'
        self.config["device_acquisition_duration_s"] = self.findChild(QSpinBox, "duracion_spin").value()
        
        self.config["app_num_channels_to_display"] = self.findChild(QSpinBox, "num_channels_spin").value()
        # Nombres y colores de canales se guardan dinámicamente en _update_channel_config_ui

        # HW Config
        self.config["device_hw_lp_hz"] = self.findChild(QDoubleSpinBox, "low_pass_freq_spin").value()
        self.config["device_hw_hp_hz"] = self.findChild(QDoubleSpinBox, "high_pass_freq_spin").value()
        self.config["device_delay_ms"] = int(1000.0 / self.findChild(QSpinBox, "sampling_rate_spin").value()) if self.findChild(QSpinBox, "sampling_rate_spin").value() > 0 else 10

        # SW Filters
        self.config["sw_filter_hp_enabled"] = self.findChild(QCheckBox, "checkbox_highpass").isChecked()
        self.config["filter_bandpass_low"] = self.findChild(QDoubleSpinBox, "spin_hp_cutoff").value() # Reusando nombre de config
        self.config["filter_bandpass_order"] = self.findChild(QSpinBox, "spin_hp_order").value() # Reusando nombre de config

        self.config["sw_filter_notch_enabled"] = self.findChild(QCheckBox, "checkbox_notch").isChecked()
        self.config["filter_notch_freq"] = self.findChild(QDoubleSpinBox, "spin_notch_freq").value()
        self.config["filter_notch_q"] = self.findChild(QDoubleSpinBox, "spin_notch_q").value()

        self.config["sw_filter_lp_enabled"] = self.findChild(QCheckBox, "checkbox_lowpass").isChecked()
        self.config["filter_bandpass_high"] = self.findChild(QDoubleSpinBox, "spin_lp_cutoff").value() # Reusando nombre de config
        # self.config["filter_bandpass_order"] ya está arriba

        self.config["sw_filter_amp_enabled"] = self.findChild(QCheckBox, "checkbox_amplification").isChecked()
        self.config["sw_filter_amp_factor"] = self.findChild(QDoubleSpinBox, "spin_amp_gain").value()
        
        # Recalcular filter_sample_rate basado en device_delay_ms
        self.config["filter_sample_rate"] = 1000.0 / self.config["device_delay_ms"] if self.config["device_delay_ms"] > 0 else 100.0

        # 3D View
        self.config["3d_plot_mode"] = self.findChild(QComboBox, "combo_3d_mode").currentText()
        self.config["3d_update_interval_ms"] = self.findChild(QSpinBox, "spin_3d_update_ms").value()


    # --- Manejo de Conexión ---
    def _update_serial_ports(self):
        """Actualiza la lista de puertos seriales disponibles."""
        combo_puerto = self.findChild(QComboBox, "puerto_combo")
        combo_puerto.clear()
        ports = serial.tools.list_ports.comports()
        if ports:
            for port_info in ports:
                combo_puerto.addItem(f"{port_info.device} ({port_info.description})", port_info.device)
            if self.config["serial_port"]: # Intentar seleccionar el guardado
                idx = combo_puerto.findData(self.config["serial_port"])
                if idx != -1: combo_puerto.setCurrentIndex(idx)
        else:
            combo_puerto.addItem("No se encontraron puertos")
        self._log("Lista de puertos seriales actualizada.")

    def _toggle_connection(self):
        """Conecta o desconecta del dispositivo EMG."""
        btn_conectar = self.findChild(QPushButton, "btn_conectar")
        if self.emg_acquirer and self.emg_acquirer.is_connected():
            self.emg_acquirer.disconnect()
            self._update_connection_status_ui(False, "Desconectado por usuario.")
            btn_conectar.setText("🔌 Conectar")
            btn_conectar.setIcon(QIcon(":/icons/connect.png")) # Asumiendo que tienes iconos
        else:
            selected_port_data = self.findChild(QComboBox, "puerto_combo").currentData()
            if not selected_port_data:
                QMessageBox.warning(self, "Error de Conexión", "Por favor, seleccione un puerto serial válido.")
                return

            serial_conf = SerialConfig(
                port=selected_port_data, # Usar el device string
                baud_rate=int(self.findChild(QComboBox, "baud_combo").currentText()),
                auto_connect=False, # La conexión se maneja aquí
                reconnect_delay=self.config.get("reconnect_delay_s", 5.0)
            )
            # Usar los valores de la UI para la config del dispositivo
            device_delay_ms = int(1000.0 / self.findChild(QSpinBox, "sampling_rate_spin").value()) if self.findChild(QSpinBox, "sampling_rate_spin").value() > 0 else 10
            device_acq_conf = DeviceAcqConfig(
                delay_ms=device_delay_ms,
                num_channels_active=self.findChild(QSpinBox, "num_channels_spin").value(), # Num canales de la app
                mode="continuous" if self.findChild(QCheckBox, "checkbox_adquisicion_continua").isChecked() else "request"
            )
            device_filter_conf = self._get_current_device_filter_config()
            device_log_conf = DeviceLogConfig(enabled=False) # El logging de EMGAcquisition no se usa aquí, la página tiene el suyo

            self.emg_acquirer = EMGAcquisition(
                serial_conf, device_acq_conf, device_filter_conf, device_log_conf, simulate=False
            )
            
            btn_conectar.setText("Conectando...")
            btn_conectar.setEnabled(False)
            
            self.connection_thread = ConnectionThread(self.emg_acquirer, self)
            self.connection_thread.connection_status.connect(self._on_connection_finished)
            self.connection_thread.start()

    def _on_connection_finished(self, success: bool, message: str):
        """Slot para manejar el resultado del hilo de conexión."""
        btn_conectar = self.findChild(QPushButton, "btn_conectar")
        btn_conectar.setEnabled(True)
        self._update_connection_status_ui(success, message)
        if success:
            btn_conectar.setText("🔌 Desconectar")
            btn_conectar.setIcon(QIcon(":/icons/disconnect.png"))
            # Actualizar configuración del Arduino una vez conectado
            if self.emg_acquirer:
                self.emg_acquirer.update_arduino_config()
        else:
            btn_conectar.setText("🔌 Conectar")
            btn_conectar.setIcon(QIcon(":/icons/connect.png"))
            QMessageBox.critical(self, "Error de Conexión", message)
            self.emg_acquirer = None # Limpiar si falló

    def _update_connection_status_ui(self, connected: bool, message: str):
        """Actualiza la UI para reflejar el estado de la conexión."""
        status_label = self.findChild(QLabel, "label_conexion_status")
        status_indicator = self.findChild(QLabel, "label_conexion_status_indicator") # Asumiendo que tienes un QLabel para el círculo
        
        if connected:
            status_label.setText(f"Conectado: {message}")
            status_label.setStyleSheet("color: #4CAF50;") # Verde
            if status_indicator: status_indicator.setStyleSheet("background-color: #4CAF50; border-radius: 5px; min-width: 10px; max-width:10px; min-height:10px; max-height:10px;")
        else:
            status_label.setText(f"Desconectado: {message}")
            status_label.setStyleSheet("color: #F44336;") # Rojo
            if status_indicator: status_indicator.setStyleSheet("background-color: #F44336; border-radius: 5px; min-width: 10px; max-width:10px; min-height:10px; max-height:10px;")
        self._log(f"Estado conexión: {message}")


    # --- Configuración de Canales ---
    def _update_channel_config_ui(self, num_channels_app: int):
        """Actualiza la UI para configurar nombres y colores de canales."""
        layout = self.findChild(QGridLayout, "channels_config_layout")
        if not layout:
            logger.error("Layout 'channels_config_layout' no encontrado en UI.")
            return

        # Limpiar layout anterior
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        
        self.config["app_num_channels_to_display"] = num_channels_app
        current_names = self.config["channel_names"]
        current_colors = self.config["channel_colors"]

        for i in range(1, num_channels_app + 1):
            row = (i - 1)
            
            name_edit = QLineEdit(current_names.get(i, f"Canal {i}"))
            name_edit.setObjectName(f"channel_name_edit_{i}")
            name_edit.editingFinished.connect(lambda idx=i: self._update_channel_name_config(idx))
            
            color_btn = QPushButton()
            color_btn.setObjectName(f"channel_color_btn_{i}")
            initial_color = current_colors.get(i, DEFAULT_ACQUISITION_PAGE_CONFIG["channel_colors"].get(i, "#FFFFFF"))
            color_btn.setStyleSheet(f"background-color: {initial_color}; border: 1px solid grey;")
            color_btn.setFixedSize(QSize(24,24))
            color_btn.setProperty("channel_index", i) # Guardar índice para el slot
            color_btn.setProperty("current_color", initial_color)
            color_btn.clicked.connect(self._pick_channel_color)
            
            layout.addWidget(QLabel(f"Ch {i}:"), row, 0)
            layout.addWidget(name_edit, row, 1)
            layout.addWidget(color_btn, row, 2)
        
        self._setup_plot_curves() # Reinicializar curvas de los plots
        self._log(f"UI de configuración de canales actualizada para {num_channels_app} canales.")

    def _update_channel_name_config(self, channel_idx: int):
        name_edit = self.findChild(QLineEdit, f"channel_name_edit_{channel_idx}")
        if name_edit:
            self.config["channel_names"][channel_idx] = name_edit.text()
            self._setup_plot_curves() # Actualizar leyenda del plot
            # No es necesario guardar toda la config aquí, se hará con el botón general.

    def _pick_channel_color(self):
        sender_button = self.sender()
        if not isinstance(sender_button, QPushButton): return
        
        channel_idx = sender_button.property("channel_index")
        current_color_hex = sender_button.property("current_color")
        
        color = QColorDialog.getColor(QColor(current_color_hex), self, "Seleccionar Color del Canal")
        if color.isValid():
            new_color_hex = color.name()
            sender_button.setStyleSheet(f"background-color: {new_color_hex}; border: 1px solid grey;")
            sender_button.setProperty("current_color", new_color_hex)
            self.config["channel_colors"][channel_idx] = new_color_hex
            self._setup_plot_curves() # Actualizar color de la curva
            # No guardar toda la config aquí.

    # --- Configuración de Filtros ---
    def _get_current_device_filter_config(self) -> DeviceFilterConfig:
        """Obtiene la configuración de filtros del dispositivo desde la UI."""
        # La frecuencia de muestreo para los filtros del dispositivo se basa en el delay_ms
        delay_ms = int(1000.0 / self.findChild(QSpinBox, "sampling_rate_spin").value()) if self.findChild(QSpinBox, "sampling_rate_spin").value() > 0 else 10
        fs_device = 1000.0 / delay_ms if delay_ms > 0 else 100.0

        return DeviceFilterConfig(
            sample_rate=fs_device,
            # Los filtros Notch y Bandpass son más comunes en el software de la app.
            # El dispositivo podría tener un Pasa-Bajo y Pasa-Alto más simples.
            notch_freq=None, # Asumir que el HW no tiene Notch configurable por comando
            bandpass_low_freq=self.findChild(QDoubleSpinBox, "high_pass_freq_spin").value(), # HW HP
            bandpass_high_freq=self.findChild(QDoubleSpinBox, "low_pass_freq_spin").value(), # HW LP
            bandpass_order=self.config.get("device_hw_filter_order", 4), # Podría ser configurable
            enabled=True # Asumir que si se configuran, están habilitados en el HW
        )

    def _get_current_app_filter_config(self) -> DeviceFilterConfig:
        """Obtiene la configuración de filtros de la aplicación desde la UI."""
        fs_app = 1000.0 / self.config["device_delay_ms"] if self.config["device_delay_ms"] > 0 else 100.0
        
        return DeviceFilterConfig(
            sample_rate=fs_app,
            notch_freq=self.findChild(QDoubleSpinBox, "spin_notch_freq").value() if self.findChild(QCheckBox, "checkbox_notch").isChecked() else None,
            notch_quality=self.findChild(QDoubleSpinBox, "spin_notch_q").value(),
            bandpass_low_freq=self.findChild(QDoubleSpinBox, "spin_hp_cutoff").value() if self.findChild(QCheckBox, "checkbox_highpass").isChecked() else None,
            bandpass_high_freq=self.findChild(QDoubleSpinBox, "spin_lp_cutoff").value() if self.findChild(QCheckBox, "checkbox_lowpass").isChecked() else None,
            bandpass_order=self.findChild(QSpinBox, "spin_hp_order").value(), # Usar uno de los órdenes, o tener separados
            enabled=True # La habilitación general de filtros de app
        )

    def _apply_filter_config_changes(self):
        """Aplica los cambios de configuración de filtros al EMGAcquisition si está activo."""
        if self.emg_acquirer:
            new_app_filter_config = self._get_current_app_filter_config()
            self.emg_acquirer.processor.update_config(new_app_filter_config)
            
            # También actualizar la config del dispositivo si está conectado
            if self.emg_acquirer.is_connected():
                new_device_filter_config = self._get_current_device_filter_config()
                # Esto es conceptual, EMGAcquisition no tiene un método directo para "actualizar config de filtros del HW"
                # Se haría a través de comandos específicos si el HW lo permite.
                # Por ahora, actualizamos los parámetros que sí se envían (delay, num_channels)
                self.emg_acquirer.acq_config.delay_ms = int(1000.0 / self.findChild(QSpinBox, "sampling_rate_spin").value()) if self.findChild(QSpinBox, "sampling_rate_spin").value() > 0 else 10
                self.emg_acquirer.update_arduino_config()

            self._log("Configuración de filtros de aplicación actualizada.")
        else:
            self._log("EMG Acquirer no inicializado. Cambios de filtro no aplicados en tiempo real.")
        self._save_page_config() # Guardar cambios en la config de la página


    # --- Adquisición y Visualización ---
    def _setup_plot_curves(self):
        """Prepara las curvas para los plots 2D y 3D según el número de canales."""
        self.plot_widget_2d.clear()
        self._plot_curves_2d.clear()
        self._plot_data_buffers_2d.clear()
        
        # Limpiar items del GLViewWidget excepto el grid
        for item in list(self.gl_view_widget.items): # Iterar sobre una copia
            if not isinstance(item, gl.GLGridItem):
                self.gl_view_widget.removeItem(item)
        self._plot_3d_lines.clear()

        num_channels_app = self.config["app_num_channels_to_display"]
        channel_names = self.config["channel_names"]
        channel_colors = self.config["channel_colors"]
        plot_range_points = self.config["plot_data_range_points"]

        for i in range(1, num_channels_app + 1):
            name = channel_names.get(i, f"Canal {i}")
            color_hex = channel_colors.get(i, DEFAULT_ACQUISITION_PAGE_CONFIG["channel_colors"].get(i, "#FFFFFF"))
            color_qcolor = QColor(color_hex)
            
            # Curvas 2D
            curve = self.plot_widget_2d.plot(pen=pg.mkPen(color_qcolor, width=2), name=name)
            self._plot_curves_2d[i] = curve
            self._plot_data_buffers_2d[i] = deque(maxlen=plot_range_points)
            
            # Líneas 3D (Waterfall)
            # Posición inicial (se actualizará con datos)
            # Cada línea 3D representará un canal a lo largo del tiempo (eje Y en 3D)
            # y su amplitud (eje Z en 3D). El eje X en 3D será el índice del canal.
            # Esto es para un waterfall. Si es otro tipo de 3D, la lógica cambia.
            pos = np.zeros((plot_range_points, 3))
            pos[:,0] = i # Coordenada X fija para este canal
            pos[:,1] = np.linspace(-plot_range_points/2, plot_range_points/2, plot_range_points) # Eje Y (tiempo)
            
            line_3d = gl.GLLinePlotItem(pos=pos, color=pg.glColor(color_qcolor), width=2, antialias=True)
            self._plot_3d_lines[i] = line_3d
            self.gl_view_widget.addItem(line_3d)

    def _toggle_acquisition_stream(self):
        """Inicia o detiene el stream de adquisición de datos."""
        btn_stream = self.findChild(QPushButton, "btn_iniciar_adquisicion")
        if self.acquisition_thread and self.acquisition_thread.isRunning():
            # Detener adquisición
            if self.acquisition_worker: self.acquisition_worker.stop()
            if self.acquisition_thread: self.acquisition_thread.wait(1000) # Esperar un poco
            
            btn_stream.setText("▶️ Iniciar Adquisición")
            btn_stream.setIcon(QIcon(":/icons/play.png"))
            self._log("Stream de adquisición detenido.")
        else:
            # Iniciar adquisición
            if not self.emg_acquirer or not self.emg_acquirer.is_connected():
                QMessageBox.warning(self, "No Conectado", "Debe conectar el dispositivo EMG primero.")
                return

            # Actualizar la config del dispositivo EMG con los valores de la UI
            self.emg_acquirer.acq_config.delay_ms = int(1000.0 / self.findChild(QSpinBox, "sampling_rate_spin").value()) if self.findChild(QSpinBox, "sampling_rate_spin").value() > 0 else 10
            self.emg_acquirer.acq_config.num_channels_active = self.config["app_num_channels_to_display"] # Que el Arduino envíe lo que la app espera
            self.emg_acquirer.acq_config.mode = "continuous" if self.findChild(QCheckBox, "checkbox_adquisicion_continua").isChecked() else "request"
            self.emg_acquirer.update_arduino_config()

            # Actualizar la config de filtros de la app
            app_filter_config = self._get_current_app_filter_config()
            self.emg_acquirer.processor.update_config(app_filter_config)


            self.acquisition_worker = AcquisitionWorker(self.emg_acquirer)
            self.acquisition_thread = QThread(self) # Parent para que se cierre con la ventana
            self.acquisition_worker.moveToThread(self.acquisition_thread)

            self.acquisition_worker.data_signal.connect(self._handle_new_emg_data)
            self.acquisition_worker.finished_signal.connect(self._on_acquisition_thread_finished)
            self.acquisition_worker.error_signal.connect(self._on_acquisition_thread_error)
            self.acquisition_thread.started.connect(self.acquisition_worker.run)
            
            self.acquisition_thread.start()
            btn_stream.setText("⏹ Detener Adquisición")
            btn_stream.setIcon(QIcon(":/icons/stop.png"))
            self._log("Stream de adquisición iniciado.")

    def _on_acquisition_thread_finished(self):
        logger.info("Hilo de adquisición (worker) ha finalizado.")
        btn_stream = self.findChild(QPushButton, "btn_iniciar_adquisicion")
        btn_stream.setText("▶️ Iniciar Adquisición")
        btn_stream.setIcon(QIcon(":/icons/play.png"))
        if self.acquisition_thread:
            self.acquisition_thread.quit() # Pedir al QThread que termine su bucle de eventos
            # self.acquisition_thread.wait() # Esperar a que termine (puede causar deadlock si se llama desde el mismo hilo)
        self.acquisition_thread = None
        self.acquisition_worker = None


    def _on_acquisition_thread_error(self, error_message: str):
        logger.error(f"Error en hilo de adquisición: {error_message}")
        QMessageBox.critical(self, "Error de Adquisición", error_message)
        self._on_acquisition_thread_finished() # Tratar como si hubiera terminado


    def _handle_new_emg_data(self, data_packet: Dict[str, Any]):
        """Maneja un nuevo paquete de datos EMG recibido."""
        if self._is_plot_paused:
            return

        raw_data = np.array(data_packet.get("raw_data", []))
        # filtered_data = np.array(data_packet.get("filtered_data", [])) # EMGDataProcessor ya lo aplica
        
        num_channels_received = data_packet.get("num_channels_active", 0)
        num_channels_app = self.config["app_num_channels_to_display"]

        if num_channels_received == 0 or raw_data.size == 0:
            return

        # Asegurar que raw_data sea 1D si es una sola muestra multicanal
        if raw_data.ndim > 1 and raw_data.shape[0] == 1: # e.g. [[ch1, ch2]]
            raw_data = raw_data.squeeze(0)
        
        # Actualizar buffers y plots 2D
        for i in range(1, min(num_channels_app, num_channels_received) + 1):
            if i <= len(raw_data): # Verificar que el índice es válido
                self._plot_data_buffers_2d[i].append(raw_data[i-1])
                # Crear array X si no existe o si la longitud del buffer cambió
                if not hasattr(self._plot_curves_2d[i], '_x_coords') or \
                   len(self._plot_curves_2d[i]._x_coords) != len(self._plot_data_buffers_2d[i]):
                    self._plot_curves_2d[i]._x_coords = np.arange(len(self._plot_data_buffers_2d[i]))
                
                self._plot_curves_2d[i].setData(x=self._plot_curves_2d[i]._x_coords, y=list(self._plot_data_buffers_2d[i]))

        # Actualizar plot 3D (si está activo)
        if self._is_3d_view_active and self.gl_view_widget.isVisible():
            # Para waterfall, necesitamos desplazar los datos existentes y añadir los nuevos
            # Esto puede ser costoso. Una alternativa es actualizar solo el último punto de cada línea.
            # O redibujar con un buffer más corto.
            # Simplificación: actualizamos la coordenada Z del último punto de cada línea 3D.
            # Esto no crea un waterfall, sino que mueve la "punta" de cada línea.
            # Para un waterfall real, se necesitaría una estructura de datos 2D por canal para el plot 3D.
            
            # Ejemplo de actualización simple para 3D (no waterfall):
            for i in range(1, min(num_channels_app, num_channels_received) + 1):
                if i in self._plot_3d_lines and i <= len(raw_data):
                    line_item = self._plot_3d_lines[i]
                    current_pos = line_item.pos # Obtener array de posiciones [N,3]
                    
                    # Desplazar todos los puntos en Y (tiempo) y Z (amplitud)
                    current_pos[:-1, 1:3] = current_pos[1:, 1:3] # Mover Y y Z hacia atrás
                    current_pos[-1, 1] = self.config["plot_data_range_points"]/2 # Nuevo punto de tiempo al final
                    current_pos[-1, 2] = raw_data[i-1] # Nueva amplitud
                    line_item.setData(pos=current_pos)
        
        # Actualizar tabla de estadísticas (podría ser menos frecuente)
        self._update_stats_table(raw_data) # Usar raw_data para estadísticas directas

    def _toggle_plot_pause(self):
        self._is_plot_paused = not self._is_plot_paused
        btn = self.findChild(QPushButton, "btn_pause_resume_2d")
        btn.setText("▶️ Reanudar Gráfico" if self._is_plot_paused else "⏸ Pausar Gráfico")
        self._log(f"Actualización de gráficos {'pausada' if self._is_plot_paused else 'reanudada'}.")

    def _toggle_2d_3d_view(self):
        self._is_3d_view_active = not self._is_3d_view_active
        self.stacked_plots.setCurrentWidget(self.page_plot_3d if self._is_3d_view_active else self.page_plot_2d)
        btn = self.findChild(QPushButton, "btn_toggle_view")
        btn.setText("Ver 2D" if self._is_3d_view_active else "Ver 3D")
        self.findChild(QLabel, "label_3d_mode").setVisible(self._is_3d_view_active)
        self.findChild(QComboBox, "combo_3d_mode").setVisible(self._is_3d_view_active)
        self.findChild(QLabel, "label_3d_update").setVisible(self._is_3d_view_active)
        self.findChild(QSpinBox, "spin_3d_update_ms").setVisible(self._is_3d_view_active)
        self._log(f"Vista cambiada a {'3D' if self._is_3d_view_active else '2D'}.")


    # --- Estadísticas y Datos ---
    def _update_stats_table(self, current_sample_data: np.ndarray):
        """Actualiza la tabla de características/estadísticas."""
        table = self.findChild(QTableWidget, "tabla_caracteristicas")
        if not table: return

        num_channels_to_show = min(len(current_sample_data), self.config["app_num_channels_to_display"])
        table.setRowCount(num_channels_to_show)

        for i in range(num_channels_to_show):
            val = current_sample_data[i]
            table.setItem(i, 0, QTableWidgetItem(self.config["channel_names"].get(i+1, f"Canal {i+1}")))
            
            # Para estadísticas más significativas, se necesitaría un buffer de datos por canal
            # Aquí solo mostramos el valor actual como "Media" (placeholder)
            # En una implementación real, calcularías Media, RMS, etc., sobre una ventana de datos.
            # Por ahora, como el buffer _plot_data_buffers_2d tiene los datos recientes:
            if i+1 in self._plot_data_buffers_2d and len(self._plot_data_buffers_2d[i+1]) > 0:
                window_data = np.array(list(self._plot_data_buffers_2d[i+1]))
                table.setItem(i, 1, QTableWidgetItem(f"{np.mean(window_data):.2f}"))
                table.setItem(i, 2, QTableWidgetItem(f"{np.max(window_data):.2f}"))
                table.setItem(i, 3, QTableWidgetItem(f"{np.min(window_data):.2f}"))
                table.setItem(i, 4, QTableWidgetItem(f"{np.std(window_data):.2f}"))
                table.setItem(i, 5, QTableWidgetItem(f"{np.sqrt(np.mean(window_data**2)):.2f}")) # RMS
                table.setItem(i, 6, QTableWidgetItem(f"{np.median(window_data):.2f}"))
            else: # Si no hay buffer, mostrar valor actual
                 for col_idx in range(1,7): table.setItem(i, col_idx, QTableWidgetItem(f"{val:.2f}" if isinstance(val, (int, float)) else str(val)))


    # --- Gestión de Sesiones ---
    def _save_current_acquisition_data(self):
        """Guarda los datos de la adquisición actual (buffer de plots) y la configuración."""
        if not self.patient_id:
            QMessageBox.warning(self, "Error", "ID de paciente no definido. No se puede guardar.")
            return

        # Recopilar datos de los buffers de los plots 2D
        all_channels_data = []
        num_channels_app = self.config["app_num_channels_to_display"]
        min_len = float('inf')
        for i in range(1, num_channels_app + 1):
            if i in self._plot_data_buffers_2d:
                channel_data = list(self._plot_data_buffers_2d[i])
                all_channels_data.append(channel_data)
                min_len = min(min_len, len(channel_data))
            else: # Si un canal no tiene buffer, añadir lista vacía para mantener estructura
                all_channels_data.append([])
                min_len = 0
        
        if min_len == 0 or min_len == float('inf'):
            QMessageBox.information(self, "Guardar", "No hay datos suficientes en los buffers para guardar.")
            return

        # Truncar todos los canales a la longitud mínima para que sean consistentes
        # y transponer para tener [n_samples, n_channels]
        try:
            data_array_to_save = np.array([ch_data[:min_len] for ch_data in all_channels_data]).T
        except Exception as e:
            logger.error(f"Error conformando array de datos para guardar: {e}")
            QMessageBox.critical(self, "Error", f"Error al preparar datos para guardar: {e}")
            return

        session_data = {
            "patient_id": self.patient_id,
            "timestamp": datetime.now().isoformat(),
            "duration_s": min_len / (1000.0 / self.config["device_delay_ms"]) if self.config["device_delay_ms"] > 0 else 0,
            "sampling_rate_hz": 1000.0 / self.config["device_delay_ms"] if self.config["device_delay_ms"] > 0 else 0,
            "num_channels": num_channels_app,
            "channel_names": {k:v for k,v in self.config["channel_names"].items() if k <= num_channels_app},
            "configuration_snapshot": self.config.copy(), # Guardar una copia de la config de la página
            "emg_data": data_array_to_save.tolist() # Guardar como lista de listas
        }
        
        # Usar DataManager para guardar
        # El DataManager debería manejar la creación de la ruta y el nombre del archivo.
        # Ejemplo: "paciente_id/acquisition_sessions/session_timestamp.json"
        session_filename = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        self.data_manager.guardar_datos_sesion(self.patient_id, "acquisition_sessions", session_filename, session_data)
        
        self._log(f"Datos de adquisición guardados como '{session_filename}'.")
        QMessageBox.information(self, "Guardado", f"Sesión guardada como '{session_filename}'.")
        self._load_sessions_from_history() # Actualizar tabla de sesiones

    def _load_sessions_from_history(self):
        """Carga y muestra el historial de sesiones guardadas para el paciente."""
        table = self.findChild(QTableWidget, "tabla_sesiones")
        if not table or not self.patient_id: return

        sessions = self.data_manager.listar_sesiones(self.patient_id, "acquisition_sessions")
        table.setRowCount(len(sessions))
        for row, session_info in enumerate(sessions): # session_info es (filename, filepath)
            filename = session_info[0]
            # Intentar extraer info del nombre o cargar el JSON para más detalles
            # Placeholder:
            table.setItem(row, 0, QTableWidgetItem(filename))
            try:
                # Cargar el JSON para obtener más detalles (esto puede ser lento si hay muchas sesiones)
                # session_data = self.data_manager.cargar_datos_sesion(self.patient_id, "acquisition_sessions", filename)
                # if session_data:
                #     table.setItem(row, 1, QTableWidgetItem(session_data.get("timestamp", "N/A")))
                #     table.setItem(row, 2, QTableWidgetItem(str(session_data.get("duration_s", "N/A"))))
                # else:
                #     table.setItem(row, 1, QTableWidgetItem("Error al cargar"))
                #     table.setItem(row, 2, QTableWidgetItem("N/A"))
                # Por ahora, solo el nombre y la ruta
                table.setItem(row, 1, QTableWidgetItem("N/A")) # Fecha
                table.setItem(row, 2, QTableWidgetItem("N/A")) # Duración
            except Exception as e:
                logger.error(f"Error cargando detalles de sesión {filename}: {e}")
                table.setItem(row, 1, QTableWidgetItem("Error"))
            table.setItem(row, 3, QTableWidgetItem(session_info[1])) # Ruta completa
        self._log("Historial de sesiones cargado.")

    def _add_sessions_to_list(self):
        # Esta función podría permitir al usuario añadir manualmente archivos de sesión a la lista
        # que no fueron guardados por esta instancia de la app pero siguen el formato.
        # Por ahora, se asume que _load_sessions_from_history carga todo lo relevante.
        QMessageBox.information(self, "Info", "Use 'Guardar Adquisición' para crear nuevas sesiones. La lista se actualiza automáticamente.")

    def _remove_selected_session(self):
        # Implementar lógica para eliminar una sesión de la lista (y opcionalmente del disco)
        # Cuidado con borrar archivos del disco sin confirmación.
        QMessageBox.information(self, "Info", "Funcionalidad para eliminar sesión no implementada aún.")

    def _load_selected_session_data(self):
        table = self.findChild(QTableWidget, "tabla_sesiones")
        if not table or table.currentRow() < 0:
            QMessageBox.warning(self, "Error", "Seleccione una sesión de la tabla para cargar.")
            return
        
        filename_item = table.item(table.currentRow(), 0)
        if not filename_item: return

        filename = filename_item.text()
        session_data = self.data_manager.cargar_datos_sesion(self.patient_id, "acquisition_sessions", filename)

        if session_data and "emg_data" in session_data:
            emg_data_list = session_data["emg_data"]
            emg_data_np = np.array(emg_data_list) # Debería ser [n_samples, n_channels]

            # Limpiar buffers y plots actuales
            self._setup_plot_curves() # Esto reinicia las curvas

            num_channels_loaded = emg_data_np.shape[1]
            num_channels_app = self.config["app_num_channels_to_display"]

            # Actualizar buffers y plots 2D con datos cargados
            for i in range(1, min(num_channels_app, num_channels_loaded) + 1):
                channel_data_segment = emg_data_np[:, i-1]
                # Llenar el buffer (o solo una porción si es muy largo)
                buffer = self._plot_data_buffers_2d[i]
                buffer.clear()
                buffer.extend(channel_data_segment[-self.config["plot_data_range_points"]:]) # Mostrar los últimos N puntos
                
                if hasattr(self._plot_curves_2d[i], '_x_coords'): # Recrear X si es necesario
                     self._plot_curves_2d[i]._x_coords = np.arange(len(buffer))
                self._plot_curves_2d[i].setData(x=self._plot_curves_2d[i]._x_coords, y=list(buffer))
            
            self._log(f"Datos de sesión '{filename}' cargados y visualizados.")
            # Opcional: Actualizar estadísticas con los datos cargados
            # self._update_stats_table(emg_data_np[-1, :]) # Stats del último punto
        else:
            QMessageBox.critical(self, "Error", f"No se pudieron cargar los datos de la sesión '{filename}'.")


    # --- Análisis Batch y Avanzado (Placeholders) ---
    def _populate_batch_metrics_list(self):
        list_widget = self.findChild(QListWidget, "list_batch_metrics")
        if list_widget:
            list_widget.clear()
            # Ejemplo de métricas, podrían cargarse de una config
            metrics = ["RMS", "MAV", "IEMG", "Mean Frequency", "Median Frequency", "Peak Frequency"]
            for metric in metrics:
                item = QListWidgetItem(metric)
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Unchecked)
                list_widget.addItem(item)
    
    def _batch_add_files(self): QMessageBox.information(self, "Info", "Funcionalidad Batch: Añadir Archivos no implementada.")
    def _batch_remove_files(self): QMessageBox.information(self, "Info", "Funcionalidad Batch: Quitar Archivos no implementada.")
    def _batch_clear_files(self): QMessageBox.information(self, "Info", "Funcionalidad Batch: Limpiar Lista no implementada.")
    def _run_batch_analysis(self): QMessageBox.information(self, "Info", "Funcionalidad Batch: Ejecutar Análisis no implementada.")
    def _export_batch_results(self): QMessageBox.information(self, "Info", "Funcionalidad Batch: Exportar Resultados no implementada.")
    
    def _update_advanced_analysis_params_ui(self, index: int):
        # Lógica para mostrar diferentes widgets de parámetros según el análisis seleccionado
        # self.findChild(QStackedWidget, "stacked_analysis_params").setCurrentIndex(index_correspondiente)
        pass
    def _run_advanced_analysis(self): QMessageBox.information(self, "Info", "Funcionalidad Análisis Avanzado no implementada.")
    def _toggle_advanced_channel_selection(self, state: int):
        is_all_checked = (state == Qt.CheckState.Checked.value)
        for i in range(1, 4): # Asumiendo 3 checkboxes de canal
            cb = self.findChild(QCheckBox, f"check_analysis_ch{i}")
            if cb:
                cb.setEnabled(not is_all_checked)
                if is_all_checked: cb.setChecked(True)


    # --- Exportación e Impresión ---
    def _export_current_data_report(self):
        # Similar a _save_current_acquisition_data pero con formato de reporte y elección de archivo
        QMessageBox.information(self, "Info", "Funcionalidad Exportar Reporte no implementada.")

    def _print_session_history_report(self):
        # Usar QPrinter y QTextDocument para crear un reporte imprimible de la tabla de sesiones
        QMessageBox.information(self, "Info", "Funcionalidad Imprimir Historial no implementada.")


    # --- Utilidades ---
    def _log(self, message: str, level: str = "info"):
        """Añade un mensaje al área de log de la UI."""
        log_area = self.findChild(QTextEdit, "log_area")
        if log_area:
            timestamp = datetime.now().strftime("%H:%M:%S")
            formatted_message = f"[{timestamp}] {message}"
            if level == "error":
                log_area.append(f"<font color='red'>{formatted_message}</font>")
                logger.error(message)
            elif level == "warning":
                log_area.append(f"<font color='orange'>{formatted_message}</font>")
                logger.warning(message)
            else:
                log_area.append(formatted_message)
                logger.info(message)
            log_area.ensureCursorVisible() # Auto-scroll

    def _update_ui_elements_periodically(self):
        """Actualiza elementos de la UI que no se actualizan por señales directas."""
        # Ejemplo: si se quiere mostrar el número de paquetes perdidos total del emg_acquirer
        # if self.emg_acquirer:
        #     self.findChild(QLabel, "label_lost_packets_total").setText(str(self.emg_acquirer._total_lost_frames))
        pass
    
    def _load_and_apply_page_config(self):
        self.config = self._load_or_default_page_config()
        self._apply_initial_config()
        self._log("Configuración de página cargada y aplicada.")

    def closeEvent(self, event):
        """Maneja el cierre de la ventana."""
        logger.info("Cerrando Página de Adquisición...")
        if self.acquisition_thread and self.acquisition_thread.isRunning():
            if self.acquisition_worker: self.acquisition_worker.stop()
            self.acquisition_thread.quit()
            self.acquisition_thread.wait(2000) # Esperar máx 2 segundos
        
        if self.emg_acquirer:
            self.emg_acquirer.close() # Esto también cierra el logger del emg_acquirer
        
        self._save_page_config() # Guardar la config de la página al cerrar
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Crear un DataManager dummy para el ejemplo
    class DummyDataManager:
        def guardar_datos(self, patient_id: str, data_type: str, data: Dict):
            logger.info(f"[DummyDM] Guardando para {patient_id}, tipo {data_type}")
        def cargar_datos(self, patient_id: str, data_type: str) -> Optional[Dict]:
            logger.info(f"[DummyDM] Cargando para {patient_id}, tipo {data_type}")
            if data_type == "acquisition_page_config" and patient_id == "test_patient_gui":
                 # Devolver una config parcial para probar la fusión con defaults
                return {"serial_port": "COM_DUMMY", "baud_rate": 9600}
            return None
        def guardar_datos_sesion(self, patient_id: str, session_type: str, filename: str, data: Dict):
            logger.info(f"[DummyDM] Guardando sesión {filename} para {patient_id}")
        def listar_sesiones(self, patient_id: str, session_type: str) -> List[Tuple[str,str]]:
            logger.info(f"[DummyDM] Listando sesiones para {patient_id}")
            return [("dummy_session1.json", "/path/to/dummy_session1.json")]
        def cargar_datos_sesion(self, patient_id: str, session_type: str, filename: str) -> Optional[Dict]:
            logger.info(f"[DummyDM] Cargando sesión {filename} para {patient_id}")
            if filename == "dummy_session1.json":
                return {"emg_data": np.random.rand(100,2).tolist(), "timestamp": "dummy_time"}
            return None


    dummy_dm = DummyDataManager() # type: ignore
    
    # Cargar estilos (si existe el archivo)
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_adquisicion.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f:
            app.setStyleSheet(f.read())
            logger.info(f"Estilo QSS cargado desde: {qss_path}")
    else:
        logger.warning(f"Archivo QSS no encontrado en: {qss_path}")

    main_window = PaginaAdquisicion(data_manager=dummy_dm, patient_id="test_patient_gui")
    main_window.show()
    sys.exit(app.exec())
    