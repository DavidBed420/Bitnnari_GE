"""
pagina_paciente.py

Módulo de la interfaz gráfica para la gestión integral de la información del paciente.
Permite visualizar y editar datos personales, historial clínico, evolución,
instrucciones y notificaciones.

Características Principales:
- Visualización Detallada: Muestra DNI, nombre, fecha de nacimiento, dirección,
  teléfono, patologías y foto del paciente.
- Edición de Datos: A través de un diálogo modal (EditarPacienteDialog) para
  modificar la información del paciente.
- Gestión de Historial: Permite agregar notas fechadas y filtrar el historial.
- Visualización de Evolución: Gráfico interactivo (pyqtgraph) para mostrar
  la evolución de parámetros a lo largo del tiempo, con configuración de ejes.
- Pestañas de Instrucciones y Notificaciones: Para información de ayuda y alertas.
- Sidebar Avanzado Animado:
    - Eliminar paciente.
    - Exportar todos los datos del paciente.
    - Editar tratamiento (placeholder).
    - Programar cita (placeholder).
    - Enviar notificación (placeholder).
- Exportación e Impresión:
    - Exportar datos del paciente a CSV/JSON.
    - Imprimir un reporte básico del paciente.
- Integración con GestorDatos: Para la persistencia y recuperación de datos.
- Estilo: Diseñado para ser compatible con un QSS global y con estilos
  locales para un aspecto "Dark Mode" profesional.
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

import pyqtgraph as pg
from PyQt6.QtCore import Qt, QPropertyAnimation, QDateTime, QEasingCurve, QSize, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QTabWidget, QTableWidget, QTableWidgetItem, QLineEdit,
    QGroupBox, QFormLayout, QMessageBox, QFileDialog, QDialog,
    QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDialogButtonBox,
    QHeaderView, QFrame, QSizePolicy
)
from PyQt6.QtPrintSupport import QPrinter, QPrintDialog

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos # Asumiendo la ruta correcta

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


# --- Diálogo para Editar Datos del Paciente ---
class EditarPacienteDialog(QDialog):
    """Diálogo para editar la información del paciente."""
    def __init__(self, paciente_data: Dict[str, Any], data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("✏️ Editar Información del Paciente")
        self.setMinimumWidth(450)
        self.data_manager = data_manager
        self.paciente_original_dni = paciente_data.get("dni", "") # Guardar DNI original por si se edita
        self.current_paciente_data = paciente_data.copy() # Trabajar con una copia

        self._init_ui()
        self._populate_fields()
        self._apply_dialog_style() # Estilo específico para el diálogo

    def _init_ui(self):
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        self.input_dni = QLineEdit()
        self.input_dni.setPlaceholderText("DNI del paciente")
        self.input_dni.setReadOnly(True) # DNI no editable desde aquí para evitar inconsistencias
        form_layout.addRow("🆔 DNI:", self.input_dni)

        self.input_nombre = QLineEdit()
        self.input_nombre.setPlaceholderText("Nombre completo")
        form_layout.addRow("👤 Nombre:", self.input_nombre)

        self.input_fecha_nacimiento = QLineEdit() # Usar QDateEdit sería mejor, pero QLineEdit para YYYY-MM-DD
        self.input_fecha_nacimiento.setPlaceholderText("YYYY-MM-DD")
        form_layout.addRow("📆 Fecha Nacimiento:", self.input_fecha_nacimiento)

        self.input_direccion = QLineEdit()
        self.input_direccion.setPlaceholderText("Dirección completa")
        form_layout.addRow("🏠 Dirección:", self.input_direccion)

        self.input_telefono = QLineEdit()
        self.input_telefono.setPlaceholderText("Número de teléfono")
        form_layout.addRow("📞 Teléfono:", self.input_telefono)
        
        self.input_email = QLineEdit()
        self.input_email.setPlaceholderText("correo@ejemplo.com")
        form_layout.addRow("📧 Email:", self.input_email)

        self.input_patologias = QTextEdit() # Para múltiples líneas
        self.input_patologias.setPlaceholderText("Patologías, alergias, notas relevantes (una por línea)")
        self.input_patologias.setFixedHeight(80)
        form_layout.addRow("📝 Patologías/Notas:", self.input_patologias)
        
        layout.addLayout(form_layout)

        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self._save_changes)
        self.button_box.rejected.connect(self.reject)
        layout.addWidget(self.button_box)

    def _populate_fields(self):
        """Llena los campos del diálogo con los datos del paciente."""
        self.input_dni.setText(self.current_paciente_data.get("dni", ""))
        self.input_nombre.setText(self.current_paciente_data.get("nombre", ""))
        self.input_fecha_nacimiento.setText(self.current_paciente_data.get("fecha_nacimiento", ""))
        self.input_direccion.setText(self.current_paciente_data.get("direccion", ""))
        self.input_telefono.setText(self.current_paciente_data.get("contacto", {}).get("telefono", ""))
        self.input_email.setText(self.current_paciente_data.get("contacto", {}).get("email", ""))
        
        patologias_list = self.current_paciente_data.get("patologias", [])
        self.input_patologias.setPlainText("\n".join(patologias_list))

    def _apply_dialog_style(self):
        self.setStyleSheet("""
            QDialog { background-color: #2a2a38; color: #e0e0e0; border-radius: 8px; }
            QLabel { color: #c0c0c0; font-size: 10pt; margin-bottom: 2px;}
            QLineEdit, QTextEdit {
                background-color: #353545; color: #e0e0e0;
                border: 1px solid #4a4a5a; padding: 6px; border-radius: 4px;
                font-size: 10pt;
            }
            QLineEdit:focus, QTextEdit:focus { border: 1px solid #7a7a9a; }
            QPushButton {
                background-color: #4a5568; color: white; border: none;
                padding: 8px 15px; border-radius: 4px; font-size: 10pt;
            }
            QPushButton:hover { background-color: #5a6578; }
            QPushButton:pressed { background-color: #3a4558; }
        """)

    def _save_changes(self):
        """Valida y guarda los cambios en el DataManager."""
        nombre = self.input_nombre.text().strip()
        fecha_nac_str = self.input_fecha_nacimiento.text().strip()

        if not nombre:
            QMessageBox.warning(self, "Campo Requerido", "El nombre del paciente no puede estar vacío.")
            return
        try:
            datetime.strptime(fecha_nac_str, "%Y-%m-%d")
        except ValueError:
            QMessageBox.warning(self, "Formato Incorrecto", "La fecha de nacimiento debe estar en formato YYYY-MM-DD.")
            return

        updated_data = {
            "nombre": nombre,
            "fecha_nacimiento": fecha_nac_str,
            "direccion": self.input_direccion.text().strip(),
            "contacto": {
                "telefono": self.input_telefono.text().strip(),
                "email": self.input_email.text().strip()
            },
            "patologias": [p.strip() for p in self.input_patologias.toPlainText().splitlines() if p.strip()]
        }
        
        # Fusionar con datos existentes que no se editan aquí (como 'foto', 'historial', etc.)
        for key, value in self.current_paciente_data.items():
            if key not in updated_data and key != "contacto": # Contacto se maneja por separado
                updated_data[key] = value
            elif key == "contacto" and isinstance(value, dict): # Fusionar contacto
                for c_key, c_value in value.items():
                    if c_key not in updated_data["contacto"]:
                        updated_data["contacto"][c_key] = c_value


        if self.data_manager.actualizar_paciente(self.paciente_original_dni, updated_data):
            QMessageBox.information(self, "Éxito", "Información del paciente actualizada correctamente.")
            self.accept() # Cierra el diálogo con resultado aceptado
        else:
            QMessageBox.critical(self, "Error", "No se pudo actualizar la información del paciente.")


# --- Página Principal de Gestión del Paciente ---
class PaginaPaciente(QWidget):
    """Página principal para la gestión de la información de un paciente."""
    paciente_actualizado = pyqtSignal() # Señal para notificar actualizaciones

    def __init__(self, stacked_widget: Optional[QStackedWidget], patient_id: str, data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("paginaPaciente")
        self.stacked_widget = stacked_widget # Para navegación
        self.patient_id = patient_id
        self.data_manager = data_manager
        
        self.current_patient_data: Dict[str, Any] = {}
        self.historial_clinico_local: List[Dict[str, str]] = [] # {timestamp: "YYYY-MM-DD HH:MM", nota: "texto"}

        self._init_ui()
        self._connect_signals()
        self.load_patient_data() # Cargar datos al iniciar
        # self.apply_page_style() # El estilo se maneja globalmente por QSS

    def _init_ui(self):
        main_layout = QHBoxLayout(self) # Layout principal: Sidebar + Contenido
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0,0,0,0)

        # --- Sidebar (Panel de Acciones Rápidas) ---
        self._setup_sidebar(main_layout)

        # --- Contenido Principal (Pestañas) ---
        content_widget = QFrame() # Usar QFrame para poder aplicar estilos de borde/fondo
        content_widget.setObjectName("contentAreaPaciente")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(15,15,15,15)

        # Encabezado de la página
        header_label = QLabel(f"Gestión del Paciente: {self.patient_id}")
        header_label.setObjectName("pageHeader") # Para QSS
        header_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        content_layout.addWidget(header_label)
        self.header_label_paciente = header_label # Guardar referencia para actualizar nombre

        # TabWidget para las secciones
        self.tabs_paciente = QTabWidget()
        self.tabs_paciente.addTab(self._create_tab_datos_personales(), "👤 Datos Personales")
        self.tabs_paciente.addTab(self._create_tab_historial(), "📜 Historial Clínico")
        self.tabs_paciente.addTab(self._create_tab_evolucion(), "📈 Evolución")
        self.tabs_paciente.addTab(self._create_tab_instrucciones(), "ℹ️ Instrucciones")
        self.tabs_paciente.addTab(self._create_tab_notificaciones(), "🔔 Notificaciones")
        content_layout.addWidget(self.tabs_paciente)
        
        main_layout.addWidget(content_widget, stretch=1)
        self.setLayout(main_layout)

    def _connect_signals(self):
        # Conexiones para botones dentro de las pestañas (si los hay)
        # Ejemplo: self.btn_editar_info_personal.clicked.connect(self._open_edit_patient_dialog)
        # (Estos botones se crean en los métodos _create_tab_*)
        pass

    # --- Creación de Pestañas ---
    def _create_tab_datos_personales(self) -> QWidget:
        tab = QWidget()
        layout = QGridLayout(tab) # Usar QGridLayout para más control

        # Foto del Paciente
        self.label_foto_paciente = QLabel("📷 Foto no disponible")
        self.label_foto_paciente.setObjectName("patientPhotoLabel")
        self.label_foto_paciente.setFixedSize(150, 180)
        self.label_foto_paciente.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_foto_paciente.setScaledContents(True)
        layout.addWidget(self.label_foto_paciente, 0, 0, 3, 1) # Ocupa 3 filas, 1 columna

        self.btn_cargar_foto = QPushButton("🖼️ Cargar Foto")
        self.btn_cargar_foto.clicked.connect(self._upload_patient_photo)
        layout.addWidget(self.btn_cargar_foto, 3, 0, 1, 1)

        # Campos de Información (en un QGroupBox)
        info_group = QGroupBox("Información Principal")
        info_form = QFormLayout(info_group)
        
        self.label_dni_display = QLabel("N/A")
        info_form.addRow("🆔 DNI:", self.label_dni_display)
        self.label_nombre_display = QLabel("N/A")
        info_form.addRow("👤 Nombre:", self.label_nombre_display)
        self.label_fecha_nac_display = QLabel("N/A")
        info_form.addRow("📆 Nacimiento:", self.label_fecha_nac_display)
        self.label_edad_display = QLabel("N/A") # Se calculará
        info_form.addRow("🎂 Edad:", self.label_edad_display)
        
        layout.addWidget(info_group, 0, 1, 1, 2) # Fila 0, Col 1, Ocupa 1 fila, 2 columnas

        # Contacto y Dirección (en otro QGroupBox)
        contact_group = QGroupBox("Contacto y Dirección")
        contact_form = QFormLayout(contact_group)
        self.label_telefono_display = QLabel("N/A")
        contact_form.addRow("📞 Teléfono:", self.label_telefono_display)
        self.label_email_display = QLabel("N/A")
        contact_form.addRow("📧 Email:", self.label_email_display)
        self.label_direccion_display = QLabel("N/A")
        contact_form.addRow("🏠 Dirección:", self.label_direccion_display)
        layout.addWidget(contact_group, 1, 1, 1, 2)

        # Patologías (en otro QGroupBox)
        pathologies_group = QGroupBox("Patologías y Notas Relevantes")
        pathologies_layout = QVBoxLayout(pathologies_group)
        self.text_patologias_display = QTextEdit()
        self.text_patologias_display.setReadOnly(True)
        self.text_patologias_display.setFixedHeight(100)
        pathologies_layout.addWidget(self.text_patologias_display)
        layout.addWidget(pathologies_group, 2, 1, 2, 2) # Ocupa 2 filas

        # Botón para editar toda la información
        self.btn_editar_info_personal = QPushButton("✏️ Editar Información del Paciente")
        self.btn_editar_info_personal.clicked.connect(self._open_edit_patient_dialog)
        layout.addWidget(self.btn_editar_info_personal, 4, 1, 1, 2) # Fila 4

        layout.setColumnStretch(1, 1) # Columna de labels
        layout.setColumnStretch(2, 2) # Columna de valores
        return tab

    def _create_tab_historial(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Filtro y Búsqueda
        filter_layout = QHBoxLayout()
        self.input_filtro_historial = QLineEdit()
        self.input_filtro_historial.setPlaceholderText("Buscar en historial...")
        self.input_filtro_historial.textChanged.connect(self._filter_history_table)
        filter_layout.addWidget(QLabel("Filtrar:"))
        filter_layout.addWidget(self.input_filtro_historial)
        layout.addLayout(filter_layout)

        # Tabla de Historial
        self.table_historial_clinico = QTableWidget()
        self.table_historial_clinico.setColumnCount(2) # Fecha, Nota
        self.table_historial_clinico.setHorizontalHeaderLabels(["📅 Fecha y Hora", "📝 Nota / Evento"])
        self.table_historial_clinico.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table_historial_clinico.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table_historial_clinico.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table_historial_clinico.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.table_historial_clinico)

        # Área para agregar nueva nota
        add_note_layout = QHBoxLayout()
        self.input_nueva_nota_historial = QTextEdit()
        self.input_nueva_nota_historial.setPlaceholderText("Escriba una nueva nota o evento...")
        self.input_nueva_nota_historial.setFixedHeight(60)
        add_note_layout.addWidget(self.input_nueva_nota_historial, stretch=3)
        
        btn_agregar_nota = QPushButton("➕ Añadir Nota")
        btn_agregar_nota.clicked.connect(self._add_new_history_entry)
        add_note_layout.addWidget(btn_agregar_nota, stretch=1)
        layout.addLayout(add_note_layout)
        
        return tab

    def _create_tab_evolucion(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Controles para seleccionar qué graficar (placeholder)
        controls_evol_layout = QHBoxLayout()
        controls_evol_layout.addWidget(QLabel("Parámetro a Graficar:"))
        self.combo_param_evolucion = QComboBox()
        self.combo_param_evolucion.addItems(["RMS Muslo Izquierdo", "Fuerza Máxima", "Ángulo Flexión Rodilla"]) # Ejemplo
        controls_evol_layout.addWidget(self.combo_param_evolucion)
        btn_actualizar_graf_evol = QPushButton("Actualizar Gráfico")
        btn_actualizar_graf_evol.clicked.connect(self._update_evolution_graph)
        controls_evol_layout.addWidget(btn_actualizar_graf_evol)
        layout.addLayout(controls_evol_layout)

        self.plot_evolucion = pg.PlotWidget(title="Gráfico de Evolución")
        self.plot_evolucion.setBackground(QColor("#1e1e1e"))
        self.plot_evolucion.showGrid(x=True, y=True, alpha=0.3)
        self.plot_evolucion.setLabel('left', "Valor del Parámetro")
        self.plot_evolucion.setLabel('bottom', "Fecha de Sesión", units="s") # Usar AxisItem para fechas
        self.plot_evolucion.getAxis('bottom').setTickSpacing(3600*24, 3600*24*30) # Ticks por día/mes
        self.curve_evolucion = self.plot_evolucion.plot(pen=pg.mkPen("cyan", width=2), symbol='o', symbolBrush='c')
        layout.addWidget(self.plot_evolucion)
        return tab

    def _create_tab_instrucciones(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        title = QLabel("ℹ️ Instrucciones y Ayuda - Gestión de Paciente")
        title.setObjectName("subPageHeader")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        text_area = QTextEdit()
        text_area.setReadOnly(True)
        text_area.setHtml("""
            <h3>Gestión de Pacientes</h3>
            <p>Esta sección le permite administrar toda la información relevante de un paciente.</p>
            <ul>
                <li><b>Datos Personales:</b> Vea y edite la información básica, contacto y foto.</li>
                <li><b>Historial Clínico:</b> Registre y consulte notas, eventos y observaciones importantes a lo largo del tiempo.</li>
                <li><b>Evolución:</b> Visualice gráficamente el progreso de diferentes parámetros o métricas del paciente.</li>
                <li><b>Notificaciones:</b> (Funcionalidad futura) Vea recordatorios de citas, tareas pendientes, etc.</li>
            </ul>
            <p>Utilice el <b>panel lateral (☰)</b> para acceder a acciones rápidas como eliminar el paciente, exportar todos sus datos, o iniciar nuevas actividades relacionadas con él.</p>
            <p>Para editar la información, use el botón "Editar Información" en la pestaña de Datos Personales.</p>
        """)
        layout.addWidget(text_area)
        return tab

    def _create_tab_notificaciones(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        title = QLabel("🔔 Notificaciones del Paciente")
        title.setObjectName("subPageHeader")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        self.table_notificaciones = QTableWidget()
        self.table_notificaciones.setColumnCount(3) # Fecha, Tipo, Mensaje
        self.table_notificaciones.setHorizontalHeaderLabels(["Fecha", "Tipo", "Mensaje"])
        self.table_notificaciones.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table_notificaciones)
        
        # Placeholder para futuras notificaciones
        layout.addWidget(QLabel("Funcionalidad de notificaciones en desarrollo."))
        return tab

    # --- Sidebar ---
    def _setup_sidebar(self, main_layout: QHBoxLayout):
        self.sidebar_widget = QFrame()
        self.sidebar_widget.setObjectName("sidebarPaciente")
        self.sidebar_widget.setFixedWidth(220) # Ancho fijo para el sidebar
        
        sidebar_layout_internal = QVBoxLayout(self.sidebar_widget)
        sidebar_layout_internal.setContentsMargins(10, 20, 10, 20)
        sidebar_layout_internal.setSpacing(15)

        sidebar_title = QLabel("Acciones Rápidas")
        sidebar_title.setObjectName("sidebarTitle")
        sidebar_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sidebar_layout_internal.addWidget(sidebar_title)

        actions = [
            ("🗑️ Eliminar Paciente", self._action_delete_patient),
            ("📤 Exportar Datos Completos", self._action_export_all_data),
            ("✍️ Editar Tratamiento Actual", self._action_edit_treatment), # Placeholder
            ("📅 Programar Nueva Cita", self._action_schedule_appointment), # Placeholder
            ("📢 Enviar Notificación Manual", self._action_send_manual_notification) # Placeholder
        ]
        for text, func in actions:
            btn = QPushButton(text)
            btn.setObjectName("sidebarButton")
            btn.clicked.connect(func)
            sidebar_layout_internal.addWidget(btn)
        
        sidebar_layout_internal.addStretch()
        main_layout.addWidget(self.sidebar_widget)

        # Animación (opcional, si se quiere deslizable)
        # Por ahora, lo dejamos fijo. Si se quiere deslizable, se necesitaría un botón de toggle.


    # --- Carga y Actualización de Datos ---
    def load_patient_data(self):
        """Carga los datos del paciente desde DataManager y actualiza la UI."""
        self.current_patient_data = self.data_manager.cargar_paciente(self.patient_id)
        if not self.current_patient_data:
            logger.error(f"No se pudieron cargar datos para el paciente ID: {self.patient_id}")
            QMessageBox.critical(self, "Error", f"No se encontraron datos para el paciente {self.patient_id}.")
            # Podríamos cerrar esta página o mostrar un estado de error.
            # Si se usa en un QStackedWidget, se podría volver a la página anterior.
            if self.stacked_widget: self.stacked_widget.setCurrentIndex(0) # Volver a la primera página
            return

        # Actualizar Header
        self.header_label_paciente.setText(f"Gestión del Paciente: {self.current_patient_data.get('nombre', self.patient_id)}")

        # Pestaña Datos Personales
        self.label_dni_display.setText(self.current_patient_data.get("dni", "N/A"))
        self.label_nombre_display.setText(self.current_patient_data.get("nombre", "N/A"))
        
        fecha_nac_str = self.current_patient_data.get("fecha_nacimiento", "N/A")
        self.label_fecha_nac_display.setText(fecha_nac_str)
        if fecha_nac_str != "N/A":
            try:
                fecha_nac_dt = datetime.strptime(fecha_nac_str, "%Y-%m-%d")
                edad = (datetime.now() - fecha_nac_dt).days // 365
                self.label_edad_display.setText(f"{edad} años")
            except ValueError:
                self.label_edad_display.setText("N/A (formato fecha inválido)")
        else:
            self.label_edad_display.setText("N/A")

        contacto = self.current_patient_data.get("contacto", {})
        self.label_telefono_display.setText(contacto.get("telefono", "N/A"))
        self.label_email_display.setText(contacto.get("email", "N/A"))
        self.label_direccion_display.setText(self.current_patient_data.get("direccion", "N/A"))
        
        patologias_list = self.current_patient_data.get("patologias", [])
        self.text_patologias_display.setPlainText("\n".join(patologias_list) if patologias_list else "Ninguna registrada.")

        # Cargar Foto
        foto_path = self.current_patient_data.get("foto_path", None) # Asumir que se guarda la ruta
        if foto_path and os.path.exists(foto_path):
            pixmap = QPixmap(foto_path)
            self.label_foto_paciente.setPixmap(pixmap)
        else:
            self.label_foto_paciente.setText("📷 Foto no disponible")

        # Pestaña Historial Clínico
        self.historial_clinico_local = self.current_patient_data.get("historial_clinico", [])
        self._update_history_table_display()

        # Pestaña Evolución (cargar datos si existen)
        self._update_evolution_graph()
        
        # Pestaña Notificaciones (cargar si existen)
        self._load_notifications()

        self.paciente_actualizado.emit() # Emitir señal para que otros módulos sepan
        logger.info(f"Datos cargados para paciente {self.patient_id}")

    # --- Métodos para Pestaña Datos Personales ---
    def _upload_patient_photo(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Seleccionar Foto del Paciente", "", "Imágenes (*.png *.jpg *.jpeg)")
        if filepath:
            # Guardar la ruta en GestorDatos y actualizar la UI
            if self.data_manager.actualizar_campo_paciente(self.patient_id, "foto_path", filepath):
                pixmap = QPixmap(filepath)
                self.label_foto_paciente.setPixmap(pixmap)
                self.current_patient_data["foto_path"] = filepath # Actualizar localmente
                self._log_action_paciente("Foto del paciente actualizada.")
            else:
                QMessageBox.warning(self, "Error", "No se pudo guardar la ruta de la foto.")

    def _open_edit_patient_dialog(self):
        dialog = EditarPacienteDialog(self.current_patient_data, self.data_manager, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_patient_data() # Recargar datos para reflejar cambios
            self._log_action_paciente("Información del paciente editada.")

    # --- Métodos para Pestaña Historial Clínico ---
    def _update_history_table_display(self):
        self.table_historial_clinico.setRowCount(0) # Limpiar tabla
        
        filter_text = self.input_filtro_historial.text().lower()

        for entry in sorted(self.historial_clinico_local, key=lambda x: x.get("timestamp", ""), reverse=True):
            ts_str = entry.get("timestamp", "")
            nota = entry.get("nota", "")
            
            if filter_text and not (filter_text in ts_str.lower() or filter_text in nota.lower()):
                continue # Omitir si no coincide con el filtro

            row_pos = self.table_historial_clinico.rowCount()
            self.table_historial_clinico.insertRow(row_pos)
            self.table_historial_clinico.setItem(row_pos, 0, QTableWidgetItem(ts_str))
            self.table_historial_clinico.setItem(row_pos, 1, QTableWidgetItem(nota))
        self.table_historial_clinico.resizeRowsToContents()


    def _filter_history_table(self):
        self._update_history_table_display()

    def _add_new_history_entry(self):
        nota_text = self.input_nueva_nota_historial.toPlainText().strip()
        if not nota_text:
            QMessageBox.warning(self, "Nota Vacía", "Por favor, escriba una nota antes de agregarla.")
            return
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        new_entry = {"timestamp": timestamp, "nota": nota_text}
        self.historial_clinico_local.append(new_entry)
        
        # Guardar el historial actualizado en GestorDatos
        if self.data_manager.actualizar_campo_paciente(self.patient_id, "historial_clinico", self.historial_clinico_local):
            self._update_history_table_display()
            self.input_nueva_nota_historial.clear()
            self._log_action_paciente(f"Nueva nota agregada al historial: '{nota_text[:30]}...'")
        else:
            QMessageBox.critical(self, "Error", "No se pudo guardar la nueva nota en el historial.")
            self.historial_clinico_local.pop() # Revertir si falla el guardado

    # --- Métodos para Pestaña Evolución ---
    def _update_evolution_graph(self):
        # Esta es una función placeholder. En una app real, se cargarían datos de evolución
        # (e.g., de sesiones de tratamiento) y se graficarían según el parámetro seleccionado.
        param_seleccionado = self.combo_param_evolucion.currentText()
        logger.info(f"Actualizando gráfico de evolución para: {param_seleccionado}")

        # Datos de ejemplo
        # En la realidad, estos vendrían de self.current_patient_data.get("evolucion_data", {}).get(param_seleccionado)
        # Y serían listas de (timestamp, valor)
        if "RMS" in param_seleccionado:
            timestamps = np.array([datetime(2024, 1, d).timestamp() for d in range(1, 11)])
            valores = np.random.rand(10) * 100 + 50 # Valores RMS simulados
        elif "Fuerza" in param_seleccionado:
            timestamps = np.array([datetime(2024, 2, d).timestamp() for d in range(5, 16)])
            valores = np.linspace(20, 80, 11) + np.random.randn(11) * 5
        else: # Ángulo
            timestamps = np.array([datetime(2024, 3, d).timestamp() for d in range(10, 21)])
            valores = 90 - np.abs(np.linspace(-45, 45, 11)) + np.random.randn(11) * 3
        
        # Limpiar y actualizar la curva
        self.curve_evolucion.setData(x=timestamps, y=valores)
        # self.plot_evolucion.setXRange(min(timestamps), max(timestamps)) # Ajustar rango X
        # self.plot_evolucion.setYRange(min(valores)-5, max(valores)+5) # Ajustar rango Y

    # --- Métodos para Pestaña Notificaciones ---
    def _load_notifications(self):
        # Placeholder: Cargar notificaciones desde GestorDatos
        # notifs = self.data_manager.cargar_notificaciones_paciente(self.patient_id)
        # self.table_notificaciones.setRowCount(len(notifs))
        # for i, (fecha, tipo, mensaje) in enumerate(notifs):
        #     self.table_notificaciones.setItem(i, 0, QTableWidgetItem(fecha))
        #     self.table_notificaciones.setItem(i, 1, QTableWidgetItem(tipo))
        #     self.table_notificaciones.setItem(i, 2, QTableWidgetItem(mensaje))
        logger.info("Funcionalidad de carga de notificaciones pendiente.")


    # --- Acciones del Sidebar ---
    def _action_delete_patient(self):
        confirm = QMessageBox.question(self, "Confirmar Eliminación",
                                       f"¿Está seguro de que desea eliminar permanentemente al paciente {self.current_patient_data.get('nombre', self.patient_id)} y todos sus datos?",
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                       QMessageBox.StandardButton.No)
        if confirm == QMessageBox.StandardButton.Yes:
            if self.data_manager.eliminar_paciente_completo(self.patient_id): # Asumir este método en GestorDatos
                QMessageBox.information(self, "Paciente Eliminado", "El paciente ha sido eliminado.")
                self._log_action_paciente("Paciente eliminado del sistema.")
                # Navegar a la pantalla de inicio o selección de paciente
                if self.stacked_widget: self.stacked_widget.setCurrentIndex(0)
                self.close() # Cerrar esta instancia de PaginaPaciente
            else:
                QMessageBox.critical(self, "Error", "No se pudo eliminar al paciente.")

    def _action_export_all_data(self):
        filepath, _ = QFileDialog.getSaveFileName(self, "Exportar Datos Completos del Paciente",
                                                  f"{self.patient_id}_datos_completos.json",
                                                  "JSON Files (*.json)")
        if filepath:
            if self.data_manager.exportar_datos_paciente_a_json(self.patient_id, filepath): # Asumir este método
                QMessageBox.information(self, "Exportación Exitosa", f"Datos del paciente exportados a:\n{filepath}")
                self._log_action_paciente(f"Datos completos exportados a {filepath}.")
            else:
                QMessageBox.critical(self, "Error de Exportación", "No se pudieron exportar los datos.")

    def _action_edit_treatment(self):
        QMessageBox.information(self, "Editar Tratamiento", "Funcionalidad para editar el plan de tratamiento (en desarrollo).")
        self._log_action_paciente("Intento de editar tratamiento (funcionalidad placeholder).")

    def _action_schedule_appointment(self):
        QMessageBox.information(self, "Programar Cita", "Funcionalidad para programar citas (en desarrollo).")
        self._log_action_paciente("Intento de programar cita (funcionalidad placeholder).")

    def _action_send_manual_notification(self):
        QMessageBox.information(self, "Enviar Notificación", "Funcionalidad para enviar notificaciones manuales (en desarrollo).")
        self._log_action_paciente("Intento de enviar notificación manual (funcionalidad placeholder).")

    # --- Utilidades ---
    def _log_action_paciente(self, mensaje: str):
        """Registra una acción específica de esta página."""
        logger.info(f"[Paciente: {self.patient_id}] {mensaje}")
        # Podría también añadir a un log visible en la UI si fuera necesario.

    def closeEvent(self, event):
        logger.info(f"Cerrando página del paciente {self.patient_id}.")
        super().closeEvent(event)

# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Crear un DataManager dummy para el ejemplo
    class DummyDataManager:
        def __init__(self):
            self.pacientes_db = {
                "12345678X": {
                    "dni": "12345678X", "nombre": "Juan Ejemplo Pérez", "fecha_nacimiento": "1985-07-15",
                    "contacto": {"telefono": "+34600000000", "email": "juan@ejemplo.com"},
                    "direccion": "Calle Falsa 123, Ciudad Ejemplo",
                    "patologias": ["Hipertensión Leve", "Alergia al polen"],
                    "foto_path": None, # Poner una ruta a una imagen para probar
                    "historial_clinico": [
                        {"timestamp": "2024-01-10 10:00", "nota": "Primera consulta. Dolor lumbar."},
                        {"timestamp": "2024-01-17 11:30", "nota": "Sesión de fisioterapia. Mejoría leve."}
                    ],
                    "evolucion_data": { # Datos para el gráfico de evolución
                        "RMS Muslo Izquierdo": {
                            "timestamps": [datetime(2024,1,10).timestamp(), datetime(2024,1,17).timestamp()],
                            "valores": [75.0, 82.5]
                        }
                    }
                }
            }
        def cargar_paciente(self, patient_id: str) -> Optional[Dict[str, Any]]:
            return self.pacientes_db.get(patient_id)
        def actualizar_paciente(self, patient_id: str, updated_data: Dict[str, Any]) -> bool:
            if patient_id in self.pacientes_db:
                self.pacientes_db[patient_id].update(updated_data)
                logger.info(f"[DummyDM] Paciente {patient_id} actualizado.")
                return True
            return False
        def actualizar_campo_paciente(self, patient_id: str, field_name: str, field_value: Any) -> bool:
            if patient_id in self.pacientes_db:
                self.pacientes_db[patient_id][field_name] = field_value
                logger.info(f"[DummyDM] Campo '{field_name}' del paciente {patient_id} actualizado.")
                return True
            return False
        def eliminar_paciente_completo(self, patient_id: str) -> bool:
            if patient_id in self.pacientes_db:
                del self.pacientes_db[patient_id]
                logger.info(f"[DummyDM] Paciente {patient_id} eliminado.")
                return True
            return False
        def exportar_datos_paciente_a_json(self, patient_id: str, filepath: str) -> bool:
            if patient_id in self.pacientes_db:
                try:
                    with open(filepath, 'w') as f:
                        json.dump(self.pacientes_db[patient_id], f, indent=4)
                    return True
                except Exception as e:
                    logger.error(f"Error exportando JSON: {e}")
            return False


    dummy_dm = DummyDataManager()
    
    # Cargar estilos (si existe el archivo)
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f:
            app.setStyleSheet(f.read())
            logger.info(f"Estilo QSS cargado desde: {qss_path}")
    else:
        logger.warning(f"Archivo QSS no encontrado en: {qss_path}")

    # Crear un QStackedWidget dummy para el contexto
    stacked_widget_dummy = QWidget() # En una app real, sería el QStackedWidget principal

    main_window = PaginaPaciente(stacked_widget=None, patient_id="12345678X", data_manager=dummy_dm)
    main_window.setWindowTitle("Gestión de Paciente - Ejemplo Standalone")
    main_window.resize(1000, 700)
    main_window.show()
    
    sys.exit(app.exec())
    