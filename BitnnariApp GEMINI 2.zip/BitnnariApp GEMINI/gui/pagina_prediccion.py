"""
pagina_prediccion.py

Interfaz gráfica (PyQt6) para la predicción de movimientos a partir de señales EMG
utilizando modelos de Machine Learning previamente entrenados.

Características Principales:
- Carga de Modelos: Permite al usuario cargar modelos de clasificación entrenados.
- Modos de Entrada de Señal:
    - Tiempo Real: Adquiere señal EMG continuamente y realiza predicciones.
    - Señal Guardada: Permite ingresar una señal manualmente o cargarla desde un archivo.
- Preprocesamiento:
    - Aplica calibración (si está configurada y disponible).
    - Aplica procesamiento de características (usando EMGProcessingEngine).
- Predicción:
    - Utiliza EMGClassificationEngine para obtener la predicción del modelo cargado.
    - Muestra el resultado de la predicción (e.g., gesto o movimiento).
- Visualización:
    - Gráfico 2D (pyqtgraph) para la señal EMG de entrada.
    - Widget 3D (Hand3DWidget) para representar el movimiento predicho de la mano.
- Historial de Predicciones:
    - Tabla para registrar cada predicción con timestamp, modelo usado y resultado.
    - Opciones para exportar e imprimir el historial.
- Configuración de Gráficos: Panel para ajustar los rangos de los ejes de los gráficos.
- Logging y Progreso: Muestra mensajes de estado y una barra de progreso para operaciones largas.
- Estilo: Diseñado para ser compatible con un QSS global (objeto principal nombrado "paginaPrediccion").
"""

import os
import sys
import json
import logging
from typing import Optional, Dict, Any, List, Tuple

import numpy as np
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QIcon, QColor
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QComboBox, QFileDialog, QMessageBox, QTextEdit, QGroupBox, QLineEdit,
    QTabWidget, QProgressBar, QSpinBox, QDoubleSpinBox, QTableWidget,
    QTableWidgetItem, QFrame, QSizePolicy
)
import pyqtgraph as pg
from pyqtgraph.opengl import GLViewWidget, GLGridItem, GLLinePlotItem # Para Hand3DWidget

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.acquisition.emg_adquisition import (
    EMGAcquisition, SerialConfig as EMGSerialConfig,
    AcquisitionConfig as EMGDeviceAcqConfig, FilterConfig as EMGFilterConfig,
    LogConfig as EMGLogConfig
)
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager
from BitnnariApp.processing.emg_processing import EMGProcessingEngine
from BitnnariApp.classification.emg_classification import EMGClassificationEngine, TorchModel # Importar TorchModel si se usa directamente

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

DEFAULT_PREDICTION_PAGE_CONFIG = {
    "acquisition_mode": "Tiempo Real", # "Tiempo Real" o "Señal Guardada"
    "rt_acquisition_duration_s": 0.2, # Duración de la ventana para predicción RT (más corta)
    "selected_model_name": "random_forest", # Modelo por defecto
    "loaded_model_path": None,
    "apply_calibration_predict": True,
    "apply_processing_predict": True,
    "plot_update_interval_ms": 50, # Para la señal de entrada en RT
    "prediction_history_max_items": 100,
    # Config para la adquisición (similar a pagina_entrenamiento pero puede ser específica)
    "rt_acq_config_predict": {
        "serial_port": None, "baud_rate": 115200, "num_channels": 2,
        "sampling_rate_hz": 1000, "delay_ms": 10,
    },
    # Config para Hand3DWidget (si es necesario)
    "hand_3d_config": {
        "finger_colors": ["#FF5733", "#33FF57", "#3357FF", "#FF33A1", "#F1C40F"]
    }
}

# --- Widget 3D para la Mano ---
class Hand3DWidget(GLViewWidget):
    """Widget para visualizar en 3D la mano (5 dedos con líneas)."""
    def __init__(self, finger_colors: Optional[List[str]] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setCameraPosition(distance=30, elevation=20, azimuth=90)
        self.setBackgroundColor(QColor("#1A1A1A")) # Fondo oscuro para contraste

        grid = GLGridItem()
        grid.scale(5, 5, 1) # Escala de la cuadrícula
        grid.setDepthValue(10) # Para que esté detrás de los dedos
        self.addItem(grid)

        self.finger_lines: Dict[int, GLLinePlotItem] = {}
        # Posiciones base de los dedos (simplificado, podría ser más anatómico)
        # (x, y, z) - y es "profundidad" de la palma, z es "altura"
        base_positions_palm = [
            np.array([-4, 0, 0]), # Pulgar (más separado)
            np.array([-1.5, 1, 0]), # Índice
            np.array([0, 1.2, 0]),  # Medio
            np.array([1.5, 1, 0]),  # Anular
            np.array([3, 0.8, 0])   # Meñique
        ]
        
        default_colors = ["#FF5733", "#33FF57", "#3357FF", "#FF33A1", "#F1C40F"] # Naranja, Verde, Azul, Rosa, Amarillo
        colors_to_use = finger_colors if finger_colors and len(finger_colors) == 5 else default_colors

        for i in range(5): # 5 dedos
            base_palm = base_positions_palm[i]
            # Articulaciones (simplificado: base_palma -> nudillo -> punta)
            # Longitudes relativas de los segmentos (aproximadas)
            len_meta = 3.0 # Metacarpiano (parte de la palma) - no se dibuja como segmento separado aquí
            len_prox = 4.0 # Falange proximal
            len_med = 3.0  # Falange media (pulgar no tiene)
            len_dist = 2.5 # Falange distal

            # Punto de origen del dedo en la "palma" (nudillo)
            knuckle = base_palm + np.array([0, len_meta * 0.3, 0]) # Ligero desplazamiento "hacia adelante"

            # Punta inicial (dedo extendido a lo largo del eje Y)
            if i == 0: # Pulgar (2 segmentos principales visibles)
                tip = knuckle + np.array([0, len_prox + len_dist, 0])
            else: # Otros dedos (3 segmentos visibles)
                tip = knuckle + np.array([0, len_prox + len_med + len_dist, 0])

            points = np.array([knuckle, tip]) # Simplificado a una línea por ahora
            
            finger_line = GLLinePlotItem(
                pos=points,
                color=pg.glColor(colors_to_use[i]),
                width=5, # Grosor del dedo
                antialias=True
            )
            self.finger_lines[i] = finger_line
            self.addItem(finger_line)
            
        # Placeholder para la palma (opcional)
        # palm_mesh = gl.GLBoxItem(size=pg.QtGui.QVector3D(8,1,5), color=(0.5,0.4,0.3,0.5)) # Color piel
        # palm_mesh.translate(-0.5, -1, -0.5) # Ajustar posición
        # self.addItem(palm_mesh)

    def update_fingers(self, finger_predictions: np.ndarray):
        """
        Actualiza la posición de los dedos basado en las predicciones.
        finger_predictions: Array de [5, 2], donde cada fila es [angulo_flexion, angulo_abduccion]
                           o alguna otra representación del estado del dedo.
                           Para este ejemplo, usaremos solo un ángulo de flexión.
        """
        if not isinstance(finger_predictions, np.ndarray) or finger_predictions.shape[0] < 5:
            # logger.warning(f"Predicciones de dedos inválidas: {finger_predictions}")
            return

        for i in range(5):
            if i not in self.finger_lines: continue
            
            # Asumir que la predicción es un valor de flexión (0-1) o ángulo
            # Para este ejemplo, usemos un solo valor de flexión por dedo.
            # Si `finger_predictions` es [valor_dedo1, valor_dedo2, ...], tomar `finger_predictions[i]`
            # Si `finger_predictions` es [[ang1,fuerza1], [ang2,fuerza2], ...], tomar `finger_predictions[i,0]`
            
            flexion_value = 0.0
            if finger_predictions.ndim == 1 and i < len(finger_predictions):
                flexion_value = finger_predictions[i] # Asume un valor por dedo
            elif finger_predictions.ndim == 2 and i < finger_predictions.shape[0] and finger_predictions.shape[1] > 0:
                flexion_value = finger_predictions[i, 0] # Asume [angulo, ...]

            # Convertir valor de flexión a un ángulo (ej. 0=extendido, 1=totalmente flexionado ~90 grados)
            # Esto es una simplificación. Una cinemática real sería más compleja.
            max_flex_angle_rad = np.deg2rad(90) # Máxima flexión
            current_flex_angle_rad = flexion_value * max_flex_angle_rad

            line_item = self.finger_lines[i]
            original_knuckle_pos = line_item.pos[0] # Posición del nudillo (no cambia)
            
            # Longitud total del dedo (simplificado)
            finger_length = np.linalg.norm(line_item.pos[1] - original_knuckle_pos)
            
            # Calcular nueva posición de la punta del dedo
            # Flexión en el plano XY (rotación alrededor del eje Z del nudillo, si el dedo está en Y)
            # O flexión en el plano YZ (rotación alrededor del eje X del nudillo)
            # Asumamos flexión en el plano YZ (dedo se mueve "hacia abajo/arriba")
            
            new_tip_y = original_knuckle_pos[1] + finger_length * np.cos(current_flex_angle_rad)
            new_tip_z = original_knuckle_pos[2] + finger_length * np.sin(current_flex_angle_rad) # Z positivo es "hacia arriba"
            
            new_tip_pos = np.array([original_knuckle_pos[0], new_tip_y, new_tip_z])
            
            line_item.setData(pos=np.array([original_knuckle_pos, new_tip_pos]))


# --- Hilo para Predicción en Tiempo Real ---
class RealTimePredictionThread(QThread):
    """Hilo para adquirir datos y realizar predicciones en tiempo real."""
    new_prediction = pyqtSignal(np.ndarray, np.ndarray, dict) # raw_signal, processed_signal, prediction_result
    status_update = pyqtSignal(str)

    def __init__(self,
                 emg_acquirer: EMGAcquisition,
                 calibration_manager: EMGCalibrationManager,
                 processing_engine: EMGProcessingEngine,
                 classification_engine: EMGClassificationEngine,
                 model_name_to_use: str,
                 window_duration_s: float, # Duración de la ventana de datos para una predicción
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.emg_acquirer = emg_acquirer
        self.cal_manager = calibration_manager
        self.proc_engine = processing_engine
        self.class_engine = classification_engine
        self.model_name = model_name_to_use
        self.window_duration_s = window_duration_s
        
        self._is_running = False
        self.samples_per_window = int(window_duration_s * self.proc_engine.sampling_rate)
        self.data_window: List[np.ndarray] = [] # Almacena muestras para una ventana

    def run(self):
        self._is_running = True
        self.data_window = []

        if not self.emg_acquirer.is_connected():
            self.status_update.emit("RT Pred: Conectando a EMG...")
            if not self.emg_acquirer.connect():
                self.status_update.emit("RT Pred: Fallo al conectar EMG.")
                self._is_running = False
                return
        
        # Asegurar modo continuo
        original_mode = self.emg_acquirer.acq_config.mode
        self.emg_acquirer.set_mode('continuous')
        self.status_update.emit("RT Pred: Adquiriendo y prediciendo...")

        while self._is_running:
            packet = self.emg_acquirer.read_data()
            if packet and 'raw_data' in packet:
                raw_sample = np.array(packet['raw_data'])
                self.data_window.append(raw_sample)

                if len(self.data_window) >= self.samples_per_window:
                    window_array = np.array(self.data_window) # Shape: [samples_per_window, n_channels]
                    self.data_window = [] # Resetear ventana para la próxima predicción

                    # 1. Calibrar
                    calibrated_signal = self.cal_manager.apply_calibration(window_array)
                    
                    # 2. Procesar (extraer características)
                    # El motor de procesamiento debe estar configurado para extraer las features que el modelo espera.
                    # Esto es una simplificación. process_signal aplica filtros.
                    # extract_all_features devuelve una lista de dicts (uno por canal).
                    # Necesitamos un único vector de características.
                    
                    # Opción A: procesar la señal y luego extraer características
                    processed_filtered_signal = self.proc_engine.process_signal(calibrated_signal, calibration_manager=None) # Cal ya aplicada
                    
                    # La extracción de características debe ser consistente con el entrenamiento.
                    # Si el modelo se entrenó con características de segmentos, aquí también.
                    # Asumimos que extract_all_features toma la ventana completa y devuelve un vector.
                    # Esto es una simplificación crítica.
                    # features_list_of_dicts = self.proc_engine.extract_all_features(processed_filtered_signal)
                    # features_vector = np.concatenate([list(d.values()) for d in features_list_of_dicts])
                    
                    # Opción B: Si el modelo espera la señal procesada directamente (e.g. CNN)
                    # features_vector = processed_filtered_signal.ravel() # Aplanar o remodelar según modelo

                    # Opción C: Usar una función específica para obtener features para predicción
                    # Esto es lo más probable. Asumimos que el modelo fue entrenado con features
                    # extraídas por `extract_all_features` sobre una ventana.
                    # Si `extract_all_features` devuelve List[Dict], necesitamos aplanarlo.
                    
                    # Simplificación: Usamos la señal procesada y filtrada directamente si el modelo es una NN que toma secuencias.
                    # O, si es un modelo clásico, necesitamos extraer features de esta ventana.
                    # Para este ejemplo, asumimos que el modelo toma la señal procesada (o sus features).
                    # Si el modelo fue entrenado con features de EMGProcessingEngine.extract_all_features:
                    # Y si el modelo espera un vector de features por muestra (ventana):
                    # (Esto es complejo y depende de cómo se entrenó el modelo)
                    # Por ahora, pasamos la señal procesada. El motor de clasificación se encargará.
                    # Esto implica que `predict` en `EMGClassificationEngine` debe manejar la extracción de features si es necesario.
                    
                    # Si el modelo fue entrenado con características de EMGProcessingEngine.extract_all_features
                    # y estas características se calculan sobre la ventana completa:
                    features_for_prediction_list = self.proc_engine.extract_all_features(processed_filtered_signal)
                    # Aplanar la lista de diccionarios de características en un solo vector
                    # (asumiendo que el orden de las características es consistente)
                    feature_vector = []
                    for ch_features in features_for_prediction_list:
                        feature_vector.extend(ch_features.values())
                    features_np = np.array(feature_vector)


                    # 3. Predecir
                    prediction_output = self.class_engine.predict(features_np, self.model_name)
                    
                    # El formato de prediction_output depende del modelo.
                    # Para Hand3DWidget, esperamos algo como [5, 2] o un array de 5 elementos.
                    # Aquí se necesita adaptar la salida del modelo a lo que espera Hand3DWidget.
                    # Ejemplo: si el modelo predice una clase de gesto, mapear esa clase a ángulos de dedos.
                    # Por ahora, asumimos que prediction_output es directamente utilizable o un placeholder.
                    
                    # Placeholder para la predicción de la mano
                    # Si el modelo da N clases, necesitamos un mapeo clase -> postura de mano
                    # Si el modelo da directamente ángulos/fuerzas, usar eso.
                    # Ejemplo: si prediction_output es un array de 5 valores (uno por dedo)
                    hand_prediction_placeholder = np.zeros(5) # Extendido
                    if prediction_output is not None and prediction_output.size > 0:
                        # Ejemplo simple: si la clase predicha es 1, flexionar el índice
                        # Esto es muy específico del problema y del modelo.
                        predicted_class = int(prediction_output[0]) # Asumir una sola clase predicha
                        if predicted_class == 1: hand_prediction_placeholder[1] = 0.8 # Flexionar índice
                        elif predicted_class == 2: hand_prediction_placeholder[2] = 0.8 # Flexionar medio
                        # ... etc.
                    
                    # Emitir señal con datos para UI
                    self.new_prediction.emit(window_array, processed_filtered_signal, 
                                             {"prediction_raw": prediction_output, 
                                              "hand_posture": hand_prediction_placeholder}) # Enviar placeholder
            else: # No hay paquete completo
                time.sleep(0.001) # Pequeña pausa

        self.emg_acquirer.set_mode(original_mode) # Restaurar modo
        self.status_update.emit("RT Pred: Detenido.")
        self._is_running = False

    def stop(self):
        self.status_update.emit("RT Pred: Solicitando detención...")
        self._is_running = False


class PredictionPage(QWidget):
    """Página de la GUI para la predicción de movimientos EMG."""

    def __init__(self, patient_id: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("paginaPrediccion")

        self.patient_id = patient_id
        self.data_manager = GestorDatos()
        self.page_config = self._load_or_default_page_config()

        # Motores y Managers
        self.emg_acquirer: Optional[EMGAcquisition] = None
        fs_initial = self.page_config["rt_acq_config_predict"]["sampling_rate_hz"]
        self.calibration_manager = EMGCalibrationManager(data_manager=self.data_manager, patient_id=self.patient_id)
        self.processing_engine = EMGProcessingEngine(sampling_rate=fs_initial, data_manager=self.data_manager, patient_id=self.patient_id)
        self.classification_engine = EMGClassificationEngine(data_manager=self.data_manager, patient_id=self.patient_id)
        
        # Pasar dependencias al motor de clasificación
        self.classification_engine.set_dependencies(
            calibration_manager=self.calibration_manager,
            processing_engine=self.processing_engine
            # emg_acquirer se setea dinámicamente si se usa RT
        )

        self.rt_prediction_thread: Optional[RealTimePredictionThread] = None
        self.prediction_history: List[Dict[str, Any]] = []
        
        self._plot_curve_input_signal: Optional[pg.PlotDataItem] = None
        self._input_signal_buffer: deque = deque(maxlen=500) # Buffer para plot 2D

        self._init_ui()
        self._connect_signals()
        self._apply_initial_page_config()
        self._load_prediction_history()

        logger.info(f"Página de Predicción inicializada para paciente: {self.patient_id}")

    def _load_or_default_page_config(self) -> Dict[str, Any]:
        page_conf_key = "prediction_page_config"
        conf = self.data_manager.cargar_datos(self.patient_id, page_conf_key)
        default_conf = json.loads(json.dumps(DEFAULT_PREDICTION_PAGE_CONFIG)) # Copia profunda
        if conf and isinstance(conf, dict):
            for key, default_value in default_conf.items():
                if key in conf:
                    if isinstance(default_value, dict) and isinstance(conf[key], dict):
                        default_value.update(conf[key])
                    else:
                        default_conf[key] = conf[key]
            logger.info(f"Configuración de página de predicción cargada para {self.patient_id}.")
            return default_conf
        else:
            logger.info(f"Usando config por defecto para página de predicción (paciente {self.patient_id}).")
            self.data_manager.guardar_datos(self.patient_id, page_conf_key, default_conf)
            return default_conf

    def _save_page_config(self):
        self._update_page_config_from_ui()
        page_conf_key = "prediction_page_config"
        self.data_manager.guardar_datos(self.patient_id, page_conf_key, self.page_config)
        logger.info(f"Configuración de página de predicción guardada para {self.patient_id}.")

    def _update_page_config_from_ui(self):
        self.page_config["acquisition_mode"] = self.findChild(QComboBox, "mode_selector_predict").currentText()
        self.page_config["rt_acquisition_duration_s"] = self.findChild(QDoubleSpinBox, "duration_spin_predict").value()
        self.page_config["selected_model_name"] = self.findChild(QComboBox, "model_selector_predict").currentText()
        # loaded_model_path se actualiza en _load_model
        self.page_config["apply_calibration_predict"] = self.findChild(QCheckBox, "check_apply_calib_predict").isChecked()
        self.page_config["apply_processing_predict"] = self.findChild(QCheckBox, "check_apply_proc_predict").isChecked()
        
        # Config de adquisición RT
        rt_acq_conf = self.page_config["rt_acq_config_predict"]
        rt_acq_conf["serial_port"] = self.findChild(QComboBox, "combo_serial_port_predict_rt").currentData()
        rt_acq_conf["baud_rate"] = int(self.findChild(QComboBox, "combo_baud_rate_predict_rt").currentText())
        rt_acq_conf["num_channels"] = self.findChild(QSpinBox, "spin_num_channels_predict_rt").value()
        rt_acq_conf["sampling_rate_hz"] = self.findChild(QSpinBox, "spin_sampling_rate_predict_rt").value()
        rt_acq_conf["delay_ms"] = int(1000.0 / rt_acq_conf["sampling_rate_hz"]) if rt_acq_conf["sampling_rate_hz"] > 0 else 10


    def _apply_initial_page_config(self):
        self.findChild(QComboBox, "mode_selector_predict").setCurrentText(self.page_config["acquisition_mode"])
        self.findChild(QDoubleSpinBox, "duration_spin_predict").setValue(self.page_config["rt_acquisition_duration_s"])
        self.findChild(QComboBox, "model_selector_predict").setCurrentText(self.page_config["selected_model_name"])
        
        if self.page_config["loaded_model_path"]: # Intentar cargar modelo si hay ruta guardada
            self._load_model(self.page_config["loaded_model_path"])

        self.findChild(QCheckBox, "check_apply_calib_predict").setChecked(self.page_config["apply_calibration_predict"])
        self.findChild(QCheckBox, "check_apply_proc_predict").setChecked(self.page_config["apply_processing_predict"])

        # Config de adquisición RT
        rt_acq_conf = self.page_config["rt_acq_config_predict"]
        self._update_serial_ports_predict_rt()
        if rt_acq_conf["serial_port"]:
            idx = self.findChild(QComboBox, "combo_serial_port_predict_rt").findData(rt_acq_conf["serial_port"])
            if idx != -1: self.findChild(QComboBox, "combo_serial_port_predict_rt").setCurrentIndex(idx)
        self.findChild(QComboBox, "combo_baud_rate_predict_rt").setCurrentText(str(rt_acq_conf["baud_rate"]))
        self.findChild(QSpinBox, "spin_num_channels_predict_rt").setValue(rt_acq_conf["num_channels"])
        self.findChild(QSpinBox, "spin_sampling_rate_predict_rt").setValue(rt_acq_conf["sampling_rate_hz"])
        
        self._toggle_rt_acquisition_config_visibility() # Mostrar/ocultar según modo


    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        # Título (ya estaba en el prompt original, lo mantengo)
        title = QLabel("🤖 Predicción de Movimientos EMG – BitnnaExpert Plus") # El prompt tenía este título
        title.setObjectName("pageTitle") # Para QSS
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title)

        self.tabs_predict = QTabWidget()
        
        # Pestaña 1: Predicción Principal
        predict_tab = QWidget()
        predict_layout = QVBoxLayout(predict_tab)
        
        # Grupo: Modo de Adquisición y Configuración RT (si aplica)
        group_acq_mode = QGroupBox("Modo de Entrada de Señal")
        acq_mode_form = QFormLayout()
        self.mode_selector_predict = QComboBox(); self.mode_selector_predict.addItems(["Tiempo Real", "Señal Guardada"])
        acq_mode_form.addRow("Modo:", self.mode_selector_predict)
        
        # Contenedor para config RT, se muestra/oculta
        self.container_rt_config_predict = QWidget()
        form_rt_config = QFormLayout(self.container_rt_config_predict)
        self.combo_serial_port_predict_rt = QComboBox()
        self.btn_refresh_ports_predict_rt = QPushButton("Refrescar")
        rt_port_layout = QHBoxLayout(); rt_port_layout.addWidget(self.combo_serial_port_predict_rt); rt_port_layout.addWidget(self.btn_refresh_ports_predict_rt)
        form_rt_config.addRow("Puerto Serial RT:", rt_port_layout)
        self.combo_baud_rate_predict_rt = QComboBox(); self.combo_baud_rate_predict_rt.addItems(["9600", "115200", "250000"])
        form_rt_config.addRow("Baud Rate RT:", self.combo_baud_rate_predict_rt)
        self.spin_num_channels_predict_rt = QSpinBox(); self.spin_num_channels_predict_rt.setRange(1,8)
        form_rt_config.addRow("Canales RT:", self.spin_num_channels_predict_rt)
        self.spin_sampling_rate_predict_rt = QSpinBox(); self.spin_sampling_rate_predict_rt.setRange(100,2000); self.spin_sampling_rate_predict_rt.setSuffix(" Hz")
        form_rt_config.addRow("Frec. Muestreo RT:", self.spin_sampling_rate_predict_rt)
        self.duration_spin_predict = QDoubleSpinBox(); self.duration_spin_predict.setRange(0.1, 10.0); self.duration_spin_predict.setSuffix(" s"); self.duration_spin_predict.setToolTip("Duración de la ventana de señal para una predicción en RT.")
        form_rt_config.addRow("Ventana Pred. RT:", self.duration_spin_predict)
        acq_mode_form.addRow(self.container_rt_config_predict)
        group_acq_mode.setLayout(acq_mode_form)
        predict_layout.addWidget(group_acq_mode)

        # Grupo: Entrada de Señal (para modo "Señal Guardada")
        self.group_signal_input_predict = QGroupBox("Entrada de Señal Manual/Archivo")
        signal_input_layout = QVBoxLayout()
        self.signal_input_predict = QLineEdit(); self.signal_input_predict.setPlaceholderText("Valores EMG separados por comas (ej: 0.1,0.2,-0.1...)")
        signal_input_layout.addWidget(self.signal_input_predict)
        self.btn_load_signal_file_predict = QPushButton("📂 Cargar Señal desde Archivo")
        signal_input_layout.addWidget(self.btn_load_signal_file_predict)
        self.group_signal_input_predict.setLayout(signal_input_layout)
        predict_layout.addWidget(self.group_signal_input_predict)

        # Grupo: Configuración del Modelo y Preprocesamiento
        group_model_proc = QGroupBox("Modelo y Preprocesamiento")
        model_proc_layout = QFormLayout()
        self.model_selector_predict = QComboBox(); self.model_selector_predict.addItems(list(DEFAULT_CLASSIFICATION_CONFIG["model_hyperparameters"].keys()))
        self.btn_load_model_predict = QPushButton("📥 Cargar Modelo Entrenado")
        model_load_layout = QHBoxLayout(); model_load_layout.addWidget(self.model_selector_predict); model_load_layout.addWidget(self.btn_load_model_predict)
        model_proc_layout.addRow("Modelo:", model_load_layout)
        self.check_apply_calib_predict = QCheckBox("Aplicar Calibración Guardada"); self.check_apply_calib_predict.setChecked(True)
        model_proc_layout.addRow(self.check_apply_calib_predict)
        self.check_apply_proc_predict = QCheckBox("Aplicar Procesamiento/Extracción de Features"); self.check_apply_proc_predict.setChecked(True)
        model_proc_layout.addRow(self.check_apply_proc_predict)
        group_model_proc.setLayout(model_proc_layout)
        predict_layout.addWidget(group_model_proc)

        # Botones de Predicción
        predict_btn_layout = QHBoxLayout()
        self.btn_run_prediction_manual = QPushButton("👆 Predecir (Manual/Archivo)")
        predict_btn_layout.addWidget(self.btn_run_prediction_manual)
        self.btn_toggle_rt_prediction = QPushButton("⏯ Iniciar Predicción RT"); self.btn_toggle_rt_prediction.setCheckable(True)
        predict_btn_layout.addWidget(self.btn_toggle_rt_prediction)
        predict_layout.addLayout(predict_btn_layout)

        # Gráfico 2D para señal de entrada
        self.plot_input_signal = pg.PlotWidget(title="Señal EMG de Entrada")
        self.plot_input_signal.setBackground(QColor("#1e1e1e"))
        self.plot_input_signal.showGrid(x=True, y=True, alpha=0.3)
        predict_layout.addWidget(self.plot_input_signal, stretch=1) # Stretch para que ocupe espacio

        # Resultado de la predicción
        self.label_prediction_result = QLabel("Resultado Predicción: N/A")
        self.label_prediction_result.setObjectName("predictionResultLabel") # Para QSS
        self.label_prediction_result.setAlignment(Qt.AlignmentFlag.AlignCenter)
        predict_layout.addWidget(self.label_prediction_result)
        
        self.tabs_predict.addTab(predict_tab, "Predicción Principal")

        # Pestaña 2: Mano 3D
        hand_3d_tab = QWidget()
        hand_3d_layout = QVBoxLayout(hand_3d_tab)
        self.hand_3d_widget = Hand3DWidget(finger_colors=self.page_config["hand_3d_config"]["finger_colors"])
        hand_3d_layout.addWidget(self.hand_3d_widget)
        self.tabs_predict.addTab(hand_3d_tab, "Visualización Mano 3D")

        # Pestaña 3: Historial
        history_tab = QWidget()
        history_layout = QVBoxLayout(history_tab)
        self.table_prediction_history = QTableWidget()
        self.table_prediction_history.setColumnCount(4) # Timestamp, Modelo, Señal (resumen), Predicción
        self.table_prediction_history.setHorizontalHeaderLabels(["Timestamp", "Modelo Usado", "Señal Entrada (resumen)", "Resultado Predicción"])
        self.table_prediction_history.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        history_layout.addWidget(self.table_prediction_history)
        btn_export_history = QPushButton("📤 Exportar Historial")
        history_layout.addWidget(btn_export_history) # Conectar después
        self.tabs_predict.addTab(history_tab, "Historial de Predicciones")
        
        main_layout.addWidget(self.tabs_predict)

        # Barra de Progreso y Log
        self.progress_bar_predict = QProgressBar()
        main_layout.addWidget(self.progress_bar_predict)
        self.log_area_predict = QTextEdit(); self.log_area_predict.setReadOnly(True)
        main_layout.addWidget(QLabel("Log de Predicción:"))
        main_layout.addWidget(self.log_area_predict)

        self.setLayout(main_layout)

    def _connect_signals(self):
        self.mode_selector_predict.currentTextChanged.connect(self._toggle_rt_acquisition_config_visibility)
        self.btn_refresh_ports_predict_rt.clicked.connect(self._update_serial_ports_predict_rt)
        self.btn_load_signal_file_predict.clicked.connect(self._load_signal_from_file_predict)
        self.btn_load_model_predict.clicked.connect(self._load_model_dialog)
        
        self.btn_run_prediction_manual.clicked.connect(self._run_manual_prediction)
        self.btn_toggle_rt_prediction.clicked.connect(self._toggle_real_time_prediction)
        
        self.findChild(QPushButton, "btn_export_history_predict", Qt.FindChildOption. 찾을_수_없음).clicked.connect(self._export_prediction_history) # Asumiendo que existe este botón en el tab de historial

    def _update_serial_ports_predict_rt(self):
        combo = self.findChild(QComboBox, "combo_serial_port_predict_rt")
        combo.clear()
        ports = serial.tools.list_ports.comports()
        if ports:
            for port_info in ports:
                combo.addItem(f"{port_info.device} ({port_info.description})", port_info.device)
        else:
            combo.addItem("No hay puertos")

    def _toggle_rt_acquisition_config_visibility(self):
        is_rt_mode = (self.mode_selector_predict.currentText() == "Tiempo Real")
        self.container_rt_config_predict.setVisible(is_rt_mode)
        self.group_signal_input_predict.setVisible(not is_rt_mode)
        self.btn_run_prediction_manual.setEnabled(not is_rt_mode)
        self.btn_toggle_rt_prediction.setEnabled(is_rt_mode)
        if not is_rt_mode and self.rt_prediction_thread and self.rt_prediction_thread.isRunning():
            self._stop_real_time_prediction() # Detener si se cambia de modo RT

    # --- Carga de Señal y Modelo ---
    def _load_signal_from_file_predict(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Cargar Señal EMG", "", "NumPy Archivos (*.npy);;CSV Archivos (*.csv);;JSON Archivos (*.json)")
        if not filepath: return
        try:
            if filepath.endswith(".npy"):
                signal_data = np.load(filepath)
            elif filepath.endswith(".csv"):
                signal_data = np.loadtxt(filepath, delimiter=',')
            elif filepath.endswith(".json"):
                with open(filepath, 'r') as f:
                    data_dict = json.load(f)
                signal_data = np.array(data_dict.get("signal_data", data_dict.get("emg_data", []))) # Buscar claves comunes
            else:
                raise ValueError("Formato de archivo no soportado para señal.")

            if signal_data.ndim > 2 or signal_data.size == 0:
                raise ValueError("Formato de datos de señal inválido.")
            
            # Si es multicanal, podríamos pedir al usuario que seleccione uno o promediar.
            # Por ahora, si es [N, C], tomamos el primer canal o el promedio.
            if signal_data.ndim == 2 and signal_data.shape[1] > 1:
                signal_data = signal_data[:, 0] # Tomar primer canal para visualización 2D simple
            
            # Mostrar en el QLineEdit (si es corto) y en el plot
            if signal_data.size < 200: # No llenar el lineedit con señales largas
                 self.signal_input_predict.setText(",".join(map(lambda x: f"{x:.4f}", signal_data.tolist())))
            else:
                 self.signal_input_predict.setText(f"Señal cargada desde {os.path.basename(filepath)} ({signal_data.size} puntos)")
            
            self._update_input_signal_plot(signal_data)
            self._log(f"Señal cargada desde {filepath}")
        except Exception as e:
            QMessageBox.critical(self, "Error al Cargar Señal", f"No se pudo cargar o interpretar el archivo: {e}")
            logger.error(f"Error cargando señal desde {filepath}: {e}")

    def _load_model_dialog(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Cargar Modelo Entrenado", 
                                                  self.classification_engine.config["paths"]["models_dir"],
                                                  "Modelos Joblib (*.joblib);;Modelos PyTorch (*.pth);;Todos los Archivos (*)")
        if filepath:
            self._load_model(filepath)

    def _load_model(self, filepath: str) -> bool:
        model_name = self.model_selector_predict.currentText() # Usar el nombre del selector como guía
        if self.classification_engine.load_model(model_name, filepath):
            self.page_config["loaded_model_path"] = filepath
            self.page_config["selected_model_name"] = model_name # Actualizar si se cargó con otro nombre
            self._log(f"Modelo '{model_name}' cargado desde {filepath}")
            QMessageBox.information(self, "Modelo Cargado", f"Modelo '{model_name}' cargado exitosamente.")
            return True
        else:
            QMessageBox.critical(self, "Error al Cargar Modelo", f"No se pudo cargar el modelo desde {filepath}.")
            return False

    # --- Lógica de Predicción ---
    def _get_signal_for_manual_prediction(self) -> Optional[np.ndarray]:
        signal_text = self.signal_input_predict.text().strip()
        if not signal_text or signal_text.startswith("Señal cargada desde"):
            # Si el texto indica que se cargó de archivo, pero no hay datos en buffer,
            # o si está vacío, no hay nada que predecir.
            # Esto es un poco vago, idealmente tendríamos un buffer interno para la señal cargada.
            # Por ahora, si el LineEdit no tiene datos numéricos, no hacemos nada.
            # Podríamos intentar recargar del archivo si `self.page_config["last_loaded_signal_file"]` existe.
            QMessageBox.warning(self, "Entrada Requerida", "Ingrese datos de señal o cargue un archivo para predicción manual.")
            return None
        try:
            # Asumir que es una sola muestra o una ventana corta de datos
            # Si es multicanal, el usuario debe ingresarlo adecuadamente o el modelo manejarlo.
            # Ejemplo: "0.1,0.2;0.3,0.4" para 2 canales, 2 muestras.
            # O si es una sola muestra multicanal: "0.1,0.2,0.3"
            # Esto es complejo de parsear sin un formato estricto.
            # Simplificación: asumir una sola secuencia de un canal.
            signal_values = np.array([float(x.strip()) for x in signal_text.split(',')])
            return signal_values
        except ValueError:
            QMessageBox.critical(self, "Error de Formato", "La señal ingresada no tiene un formato numérico válido (valores separados por coma).")
            return None

    def _run_manual_prediction(self):
        if not self.classification_engine.trained_models.get(self.page_config["selected_model_name"]):
            QMessageBox.warning(self, "Modelo No Cargado", "Por favor, cargue un modelo entrenado primero.")
            return

        signal_data = self._get_signal_for_manual_prediction()
        if signal_data is None: return

        self._update_input_signal_plot(signal_data)
        self._perform_prediction_step(signal_data)

    def _toggle_real_time_prediction(self):
        if self.btn_toggle_rt_prediction.isChecked(): # Iniciar RT
            if not self.classification_engine.trained_models.get(self.page_config["selected_model_name"]):
                QMessageBox.warning(self, "Modelo No Cargado", "Cargue un modelo antes de iniciar la predicción en tiempo real.")
                self.btn_toggle_rt_prediction.setChecked(False)
                return
            
            if not self._initialize_rt_acquirer_for_prediction():
                self.btn_toggle_rt_prediction.setChecked(False)
                return

            self.rt_prediction_thread = RealTimePredictionThread(
                self.emg_acquirer, self.calibration_manager, self.processing_engine,
                self.classification_engine, self.page_config["selected_model_name"],
                self.page_config["rt_acquisition_duration_s"], self
            )
            self.rt_prediction_thread.new_prediction.connect(self._handle_rt_prediction_result)
            self.rt_prediction_thread.status_update.connect(lambda msg: self._log(msg, level="rt")) # Nivel especial para RT
            self.rt_prediction_thread.finished.connect(self._on_rt_prediction_thread_finished)
            
            self.rt_prediction_thread.start()
            self.btn_toggle_rt_prediction.setText("⏹ Detener Predicción RT")
            self.mode_selector_predict.setEnabled(False) # Bloquear cambio de modo
        else: # Detener RT
            self._stop_real_time_prediction()

    def _stop_real_time_prediction(self):
        if self.rt_prediction_thread and self.rt_prediction_thread.isRunning():
            self.rt_prediction_thread.stop()
            # El hilo emitirá finished, que llamará a _on_rt_prediction_thread_finished
        else: # Si no estaba corriendo pero el botón estaba en estado "Detener"
            self.btn_toggle_rt_prediction.setText("⏯ Iniciar Predicción RT")
            self.mode_selector_predict.setEnabled(True)


    def _initialize_rt_acquirer_for_prediction(self) -> bool:
        """Inicializa EMGAcquisition para predicción en tiempo real."""
        rt_acq_conf_ui = self.page_config["rt_acq_config_predict"]
        
        serial_cfg = EMGSerialConfig(port=rt_acq_conf_ui["serial_port"], baud_rate=rt_acq_conf_ui["baud_rate"], auto_connect=False)
        device_cfg = EMGDeviceAcqConfig(delay_ms=rt_acq_conf_ui["delay_ms"], num_channels_active=rt_acq_conf_ui["num_channels"], mode='continuous')
        filter_cfg = EMGFilterConfig(sample_rate=rt_acq_conf_ui["sampling_rate_hz"]) # Filtros de app, no de dispositivo
        log_cfg = EMGLogConfig(enabled=False)

        try:
            self.emg_acquirer = EMGAcquisition(serial_cfg, device_cfg, filter_cfg, log_cfg, simulate=False)
            self.classification_engine.set_dependencies(emg_acquirer=self.emg_acquirer, # Actualizar dependencia
                                                        calibration_manager=self.calibration_manager,
                                                        processing_engine=self.processing_engine)
            self.processing_engine.update_sampling_rate(rt_acq_conf_ui["sampling_rate_hz"]) # Asegurar FS del procesador
            return True
        except Exception as e:
            QMessageBox.critical(self, "Error Adquisición RT", f"No se pudo inicializar el sistema de adquisición para RT: {e}")
            logger.error(f"Error inicializando EMGAcquisition para predicción RT: {e}")
            self.emg_acquirer = None
            return False

    def _perform_prediction_step(self, current_signal_segment: np.ndarray):
        """Realiza un paso de predicción (calibrar, procesar, predecir)."""
        self.progress_bar_predict.setValue(10)
        
        # 1. Calibrar (si está habilitado)
        signal_to_process = current_signal_segment
        if self.page_config["apply_calibration_predict"]:
            if self.calibration_manager.offset_params is None: # Cargar si no está
                self.calibration_manager.load_calibration_params(self.patient_id)
            if self.calibration_manager.offset_params is not None:
                signal_to_process = self.calibration_manager.apply_calibration(current_signal_segment)
            else:
                self._log("Advertencia: Calibración habilitada pero no hay parámetros cargados.", "warning")
        self.progress_bar_predict.setValue(30)

        # 2. Procesar (extraer características)
        # La lógica aquí depende críticamente de cómo se entrenó el modelo.
        # Si el modelo espera características específicas, EMGProcessingEngine debe extraerlas.
        # Si el modelo (e.g., una CNN) toma la señal (filtrada) directamente, entonces
        # EMGProcessingEngine.process_signal() se usaría para filtrar, y el resultado se pasaría.
        
        features_for_prediction: np.ndarray
        if self.page_config["apply_processing_predict"]:
            # Asumimos que el modelo fue entrenado con características de EMGProcessingEngine.extract_all_features
            # aplicadas a una ventana de señal.
            # Primero, aplicar filtros configurados en EMGProcessingEngine
            filtered_window = self.processing_engine.process_signal(signal_to_process, calibration_manager=None) # Calibración ya hecha
            
            # Luego, extraer características de esa ventana filtrada
            # extract_all_features devuelve List[Dict], necesitamos un vector
            list_of_feature_dicts = self.processing_engine.extract_all_features(filtered_window)
            
            feature_vector_list = []
            if list_of_feature_dicts:
                # Asumir que el orden de las claves es consistente o tomar claves específicas
                # Esto es frágil. Sería mejor tener un método en EMGProcessingEngine que devuelva un vector.
                for ch_dict in list_of_feature_dicts:
                    feature_vector_list.extend(ch_dict.values()) 
            features_for_prediction = np.array(feature_vector_list)
        else:
            # Si no se aplica procesamiento, se usan los datos (posiblemente calibrados) directamente.
            # Esto solo tiene sentido si el modelo fue entrenado con datos crudos/calibrados.
            features_for_prediction = signal_to_process.ravel() # Aplanar para modelos que esperan vector 1D
        
        self.progress_bar_predict.setValue(60)

        # 3. Predecir
        model_name = self.page_config["selected_model_name"]
        prediction_output = self.classification_engine.predict(features_for_prediction, model_name)
        self.progress_bar_predict.setValue(90)

        if prediction_output is not None:
            # Adaptar prediction_output al formato esperado por Hand3DWidget y la UI
            # Esto es muy dependiente del tipo de predicción (clase, regresión de ángulos, etc.)
            # Ejemplo: si es una clase, mapearla a una postura.
            # Si son directamente N valores para los dedos:
            
            # Placeholder: asumir que la predicción es un array de 5 valores para los dedos
            # o una clase que se mapea a eso.
            if isinstance(prediction_output, (int, float, np.number)): # Si es una sola clase
                predicted_class = int(prediction_output)
                self.label_prediction_result.setText(f"Clase Predicha: {predicted_class}")
                # Mapear clase a postura de mano (ejemplo muy simple)
                hand_posture = np.zeros(5) 
                if 0 <= predicted_class < 5:
                    hand_posture[predicted_class] = 0.8 # Flexionar el dedo correspondiente
                elif predicted_class == 5: # Ejemplo: puño cerrado
                    hand_posture = np.full(5, 0.9)
            elif isinstance(prediction_output, np.ndarray) and prediction_output.ndim == 1:
                self.label_prediction_result.setText(f"Predicción Vector: {np.array2string(prediction_output, precision=2)}")
                hand_posture = prediction_output[:5] if len(prediction_output) >= 5 else np.zeros(5)
            else:
                self.label_prediction_result.setText(f"Predicción: {str(prediction_output)}")
                hand_posture = np.zeros(5) # Default

            self.hand_3d_widget.update_fingers(hand_posture)
            self._add_prediction_to_history(model_name, current_signal_segment, prediction_output, hand_posture)
            self._log(f"Predicción ({model_name}): {str(prediction_output)}")
        else:
            self.label_prediction_result.setText("Resultado Predicción: Error")
            self._log("Fallo al obtener predicción del modelo.", "error")
        
        self.progress_bar_predict.setValue(100)
        QTimer.singleShot(500, lambda: self.progress_bar_predict.setValue(0)) # Resetear barra


    def _handle_rt_prediction_result(self, raw_signal_window: np.ndarray, processed_signal_window: np.ndarray, prediction_info: dict):
        """Maneja el resultado de una predicción en tiempo real."""
        # Actualizar plot 2D con la señal de entrada (cruda o procesada)
        # raw_signal_window es [samples_in_window, n_channels]
        # Tomar el primer canal para el plot 2D simple
        self._update_input_signal_plot(raw_signal_window[:, 0] if raw_signal_window.ndim > 1 else raw_signal_window)
        
        prediction_raw = prediction_info.get("prediction_raw")
        hand_posture = prediction_info.get("hand_posture", np.zeros(5))

        if prediction_raw is not None:
            if isinstance(prediction_raw, (int, float, np.number)):
                self.label_prediction_result.setText(f"Clase Predicha (RT): {int(prediction_raw)}")
            elif isinstance(prediction_raw, np.ndarray):
                 self.label_prediction_result.setText(f"Predicción Vector (RT): {np.array2string(prediction_raw, precision=2)}")
            else:
                self.label_prediction_result.setText(f"Predicción (RT): {str(prediction_raw)}")
            
            self.hand_3d_widget.update_fingers(hand_posture)
            self._add_prediction_to_history(self.page_config["selected_model_name"], raw_signal_window, prediction_raw, hand_posture)
            # No loguear cada predicción RT para no saturar, el status_update del hilo lo hace.
        else:
            self.label_prediction_result.setText("Resultado Predicción (RT): Error")

    def _on_rt_prediction_thread_finished(self):
        self.btn_toggle_rt_prediction.setChecked(False) # Asegurar que el botón refleje el estado
        self.btn_toggle_rt_prediction.setText("⏯ Iniciar Predicción RT")
        self.mode_selector_predict.setEnabled(True)
        if self.emg_acquirer: # Desconectar si el hilo lo usó
            self.emg_acquirer.disconnect()
            self.emg_acquirer = None # Limpiar para que se reinicialice si es necesario
        self.rt_prediction_thread = None
        self._log("Hilo de predicción en tiempo real finalizado.", "rt")


    # --- Visualización ---
    def _update_input_signal_plot(self, signal_segment: np.ndarray):
        """Actualiza el gráfico 2D de la señal de entrada."""
        # Asumir que signal_segment es 1D para este plot
        if signal_segment.ndim > 1: signal_segment = signal_segment[:,0] # Tomar primer canal si es multicanal

        self._input_signal_buffer.extend(signal_segment) # Añadir nuevos datos al buffer
        
        y_data = list(self._input_signal_buffer)
        x_data = np.arange(len(y_data))

        if self._plot_curve_input_signal is None:
            self._plot_curve_input_signal = self.plot_input_signal.plot(pen=pg.mkPen("c", width=2))
        
        self._plot_curve_input_signal.setData(x=x_data, y=y_data)
        # self.plot_input_signal.autoRange() # Opcional: autoajustar ejes


    # --- Historial ---
    def _add_prediction_to_history(self, model_name: str, input_signal: np.ndarray, prediction_raw: Any, hand_posture: np.ndarray):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        # Resumen de la señal de entrada (e.g., RMS del primer canal)
        input_summary = f"RMS: {np.sqrt(np.mean(input_signal[:,0]**2)):.3f}" if input_signal.ndim > 1 and input_signal.size > 0 else "N/A"
        
        pred_str = ""
        if isinstance(prediction_raw, (int, float, np.number)): pred_str = f"Clase {int(prediction_raw)}"
        elif isinstance(prediction_raw, np.ndarray): pred_str = np.array2string(prediction_raw, precision=2)
        else: pred_str = str(prediction_raw)

        entry = {
            "timestamp": ts, "model_name": model_name, 
            "input_summary": input_summary, "prediction_result": pred_str,
            "hand_posture_data": hand_posture.tolist() # Guardar datos de la mano para posible re-visualización
        }
        self.prediction_history.append(entry)
        if len(self.prediction_history) > self.page_config["prediction_history_max_items"]:
            self.prediction_history.pop(0) # Mantener tamaño máximo
        
        self._update_history_table_display()
        # Guardar historial en DataManager
        if self.patient_id:
            self.data_manager.guardar_datos(self.patient_id, "prediction_history", self.prediction_history)

    def _update_history_table_display(self):
        self.table_prediction_history.setRowCount(len(self.prediction_history))
        for row, entry in enumerate(reversed(self.prediction_history)): # Mostrar más recientes primero
            self.table_prediction_history.setItem(row, 0, QTableWidgetItem(entry["timestamp"]))
            self.table_prediction_history.setItem(row, 1, QTableWidgetItem(entry["model_name"]))
            self.table_prediction_history.setItem(row, 2, QTableWidgetItem(entry["input_summary"]))
            self.table_prediction_history.setItem(row, 3, QTableWidgetItem(entry["prediction_result"]))
    
    def _load_prediction_history(self):
        if self.patient_id:
            loaded_history = self.data_manager.cargar_datos(self.patient_id, "prediction_history")
            if isinstance(loaded_history, list):
                self.prediction_history = loaded_history
                self._update_history_table_display()

    def _export_prediction_history(self):
        if not self.prediction_history:
            QMessageBox.information(self, "Exportar", "No hay historial de predicciones para exportar.")
            return
        filepath, _ = QFileDialog.getSaveFileName(self, "Exportar Historial de Predicciones", "", "JSON Files (*.json);;CSV Files (*.csv)")
        if not filepath: return
        try:
            if filepath.endswith(".json"):
                with open(filepath, 'w') as f: json.dump(self.prediction_history, f, indent=4)
            elif filepath.endswith(".csv"):
                import csv
                with open(filepath, 'w', newline='') as f:
                    if not self.prediction_history: return
                    writer = csv.DictWriter(f, fieldnames=self.prediction_history[0].keys())
                    writer.writeheader()
                    writer.writerows(self.prediction_history)
            QMessageBox.information(self, "Exportado", "Historial de predicciones exportado.")
            self._log(f"Historial de predicciones exportado a {filepath}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo exportar el historial: {e}")
            logger.error(f"Error exportando historial de predicciones: {e}")


    # --- Utilidades ---
    def _log(self, message: str, level: str = "info"):
        log_widget = self.log_area_predict # Usar el nombre correcto del widget de log
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}"
        if level == "error": log_widget.append(f"<font color='red'>{formatted_message}</font>"); logger.error(message)
        elif level == "warning": log_widget.append(f"<font color='orange'>{formatted_message}</font>"); logger.warning(message)
        elif level == "rt": log_widget.append(f"<font color='lightblue'>{formatted_message}</font>"); logger.info(message) # Color especial para RT
        else: log_widget.append(formatted_message); logger.info(message)
        log_widget.ensureCursorVisible()

    def closeEvent(self, event):
        logger.info("Cerrando Página de Predicción...")
        self._stop_real_time_prediction() # Asegurar que el hilo se detenga
        if self.emg_acquirer:
            self.emg_acquirer.close()
        self._save_page_config()
        super().closeEvent(event)

# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    class DummyDataManager:
        def __init__(self): self.db = {}
        def guardar_datos(self, patient_id, data_type, data): self.db[f"{patient_id}_{data_type}"] = data
        def cargar_datos(self, patient_id, data_type): return self.db.get(f"{patient_id}_{data_type}")

    dummy_dm = DummyDataManager() # type: ignore
    
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f: app.setStyleSheet(f.read())

    main_window = PredictionPage(patient_id="test_patient_predict_gui")
    main_window.show()
    sys.exit(app.exec())
    