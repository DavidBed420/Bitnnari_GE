"""
ventana_registro.py

Módulo de la interfaz gráfica para el registro y edición de pacientes.
Presenta una ventana moderna sin bordes, con barra de título personalizada,
validación de campos, formateo automático de DNI y animaciones.

Características Principales:
- Diseño Moderno: Ventana sin bordes, fondo translúcido, efecto drop shadow.
- Barra de Título Personalizada: Incluye título y botones de minimizar/cerrar,
  y permite mover la ventana.
- Validación y Formateo de DNI:
    - Permite dígitos, puntos y un guion opcional.
    - Formatea automáticamente el DNI con puntos mientras se escribe.
    - Verifica si el paciente ya existe al perder el foco del campo DNI.
- Formulario Organizado: Campos agrupados en QGroupBox para datos personales,
  información clínica y contacto.
- Edición de Paciente Existente: Si se ingresa un DNI existente, ofrece cargar
  los datos para edición.
- Sugerencias de Patologías: QCompleter para el campo de patologías.
- Experiencia de Usuario:
    - Animación de "fade in" al mostrar la ventana.
    - Atajos de teclado: Ctrl+S (Guardar), Esc (Cancelar/Volver).
    - Tooltips informativos en los campos.
- Integración con GestorDatos: Para registrar, obtener y actualizar pacientes.
- Logging: Registro de acciones y errores.
- Estilo: Diseñado para ser compatible con un QSS global.
"""

import os
import sys
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

from PyQt6.QtCore import (
    Qt, QRegularExpression, QTimer, QDate, QEvent, QPoint,
    QPropertyAnimation, QSize, QEasingCurve
)
from PyQt6.QtGui import (
    QRegularExpressionValidator, QFont, QColor, QPainter, QGuiApplication,
    QShortcut, QKeySequence, QIcon, QPixmap
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QFormLayout,
    QMessageBox, QComboBox, QLineEdit, QDateEdit, QTextEdit, QHBoxLayout,
    QStackedWidget, QSizePolicy, QProgressDialog, QCompleter, QFrame,
    QGraphicsDropShadowEffect, QGroupBox, QStyle, QProxyStyle
)

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos # Asumiendo la ruta correcta

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


# --- Barra de Título Personalizada (Reutilizable) ---
class CustomTitleBar(QFrame):
    """Barra de título personalizada para ventanas sin bordes."""
    def __init__(self, parent_window: QWidget, title: str = "Ventana"):
        super().__init__(parent_window)
        self.parent_window = parent_window
        self.setObjectName("customTitleBar") # Para QSS
        self.setFixedHeight(40) # Altura fija para la barra

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 5, 0) # Márgenes: izq, arr, der, ab
        layout.setSpacing(5)

        # Icono de la aplicación (opcional)
        # self.app_icon_label = QLabel()
        # icon_path = os.path.join(os.path.dirname(__file__), "..", "resources", "icons", "app_icon.png") # Ajustar ruta
        # if os.path.exists(icon_path):
        #     self.app_icon_label.setPixmap(QPixmap(icon_path).scaled(24, 24, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        #     layout.addWidget(self.app_icon_label)

        self.title_label = QLabel(title)
        self.title_label.setObjectName("titleBarLabel")
        layout.addWidget(self.title_label)
        layout.addStretch()

        # Botones de control de ventana
        self.btn_minimize = QPushButton("—") # Caracter unicode para minimizar
        self.btn_minimize.setObjectName("minimizeButton")
        self.btn_minimize.setFixedSize(30, 30)
        self.btn_minimize.setToolTip("Minimizar")
        self.btn_minimize.clicked.connect(self.parent_window.showMinimized)
        layout.addWidget(self.btn_minimize)

        self.btn_close = QPushButton("✕") # Caracter unicode para cerrar
        self.btn_close.setObjectName("closeButton")
        self.btn_close.setFixedSize(30, 30)
        self.btn_close.setToolTip("Cerrar")
        self.btn_close.clicked.connect(self.parent_window.close)
        layout.addWidget(self.btn_close)

        self._mouse_press_pos: Optional[QPoint] = None
        self._mouse_move_pos: Optional[QPoint] = None

    def setTitle(self, title: str):
        self.title_label.setText(title)

    def mousePressEvent(self, event: QEvent.Type.MouseButtonPress): # Corrección de tipo de evento
        if event.button() == Qt.MouseButton.LeftButton:
            self._mouse_press_pos = event.globalPosition().toPoint()
            self._mouse_move_pos = self.parent_window.pos()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QEvent.Type.MouseMove): # Corrección de tipo de evento
        if self._mouse_press_pos is not None and event.buttons() & Qt.MouseButton.LeftButton:
            diff = event.globalPosition().toPoint() - self._mouse_press_pos
            self.parent_window.move(self._mouse_move_pos + diff)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QEvent.Type.MouseButtonRelease): # Corrección de tipo de evento
        self._mouse_press_pos = None
        self._mouse_move_pos = None
        super().mouseReleaseEvent(event)


# --- Ventana de Registro ---
class VentanaRegistro(QWidget):
    """Ventana para registrar o editar información de pacientes."""
    WINDOW_TITLE = "Registro de Pacientes"
    paciente_registrado_o_actualizado = pyqtSignal(str) # Emite DNI del paciente

    def __init__(self, stacked_widget: Optional[QStackedWidget], data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.stacked_widget = stacked_widget
        self.data_manager = data_manager
        self.paciente_dni_para_edicion: Optional[str] = None # DNI del paciente que se está editando

        self._init_window_style()
        
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(1,1,1,1) # Margen pequeño para el efecto de sombra
        self.main_layout.setSpacing(0)

        self.title_bar = CustomTitleBar(self, self.WINDOW_TITLE)
        self.main_layout.addWidget(self.title_bar)

        self.content_frame = QFrame() # Frame para el contenido principal y la sombra
        self.content_frame.setObjectName("contentFrameRegistro") # Para QSS
        content_layout_internal = QVBoxLayout(self.content_frame)
        content_layout_internal.setContentsMargins(20, 15, 20, 20) # Márgenes internos
        content_layout_internal.setSpacing(15)
        self.main_layout.addWidget(self.content_frame)

        self._init_ui_fields(content_layout_internal)
        self._apply_drop_shadow()
        self._setup_fade_in_animation()
        self._setup_shortcuts()

        logger.info("Ventana de Registro inicializada.")

    def _init_window_style(self):
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window) # Sin bordes
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True) # Para sombra y bordes redondeados
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setMinimumSize(600, 700) # Tamaño mínimo
        self.resize(750, 750) # Tamaño inicial
        self._center_on_screen()

    def _center_on_screen(self):
        screen_geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(screen_geo.center() - self.rect().center())

    def _apply_drop_shadow(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(25)
        shadow.setXOffset(0)
        shadow.setYOffset(4)
        shadow.setColor(QColor(0, 0, 0, 100))
        self.content_frame.setGraphicsEffect(shadow) # Aplicar sombra al frame de contenido

    def _setup_fade_in_animation(self):
        self.setWindowOpacity(0.0)
        self.fade_animation = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade_animation.setDuration(600)
        self.fade_animation.setStartValue(0.0)
        self.fade_animation.setEndValue(1.0)
        self.fade_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

    def showEvent(self, event):
        super().showEvent(event)
        # Iniciar animación solo si no se está ya mostrando (evita re-animar al minimizar/restaurar)
        if self.windowOpacity() < 0.1: # Umbral pequeño para considerar "no visible"
            self.fade_animation.start()

    def _setup_shortcuts(self):
        QShortcut(QKeySequence("Ctrl+S"), self, self._save_patient_data)
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, self._cancel_and_go_back)

    def _init_ui_fields(self, parent_layout: QVBoxLayout):
        """Inicializa los campos del formulario y los añade al layout proporcionado."""
        
        # --- Grupo: Datos Personales ---
        group_personal = QGroupBox("Datos Personales del Paciente")
        form_personal = QFormLayout(group_personal)
        
        self.input_dni = QLineEdit(); self.input_dni.setPlaceholderText("Ej: 12.345.678-9")
        self.input_dni.setToolTip("DNI del paciente. Se formateará automáticamente.")
        self.input_dni.textChanged.connect(self._format_dni_text)
        self.input_dni.editingFinished.connect(self._check_if_patient_exists) # Verificar al perder foco
        form_personal.addRow("🆔 DNI:", self.input_dni)

        self.input_nombre = QLineEdit(); self.input_nombre.setPlaceholderText("Nombre completo")
        form_personal.addRow("👤 Nombre:", self.input_nombre)

        self.input_fecha_nac = QDateEdit()
        self.input_fecha_nac.setDisplayFormat("dd/MM/yyyy"); self.input_fecha_nac.setCalendarPopup(True)
        self.input_fecha_nac.setDate(QDate.currentDate().addYears(-30)) # Default razonable
        self.input_fecha_nac.setMaximumDate(QDate.currentDate())
        form_personal.addRow("📆 Fecha Nacimiento:", self.input_fecha_nac)
        parent_layout.addWidget(group_personal)

        # --- Grupo: Información Clínica ---
        group_clinical = QGroupBox("Información Clínica Relevante")
        form_clinical = QFormLayout(group_clinical)
        self.input_patologias = QTextEdit()
        self.input_patologias.setPlaceholderText("Alergias, condiciones preexistentes, medicación actual (una por línea).")
        self.input_patologias.setFixedHeight(70)
        form_clinical.addRow("📝 Patologías/Notas:", self.input_patologias)
        
        # Sugerencias para patologías
        patologias_sugeridas = ["Hipertensión", "Diabetes Tipo 2", "Asma", "Artritis", "Hipotiroidismo", "Alergia Penicilina"]
        self.input_patologia_sugerida = QLineEdit()
        self.input_patologia_sugerida.setPlaceholderText("Buscar o añadir patología...")
        completer = QCompleter(patologias_sugeridas, self)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.input_patologia_sugerida.setCompleter(completer)
        self.btn_add_patologia = QPushButton("➕ Añadir")
        self.btn_add_patologia.clicked.connect(self._add_suggested_patologia)
        sug_layout = QHBoxLayout(); sug_layout.addWidget(self.input_patologia_sugerida); sug_layout.addWidget(self.btn_add_patologia)
        form_clinical.addRow("Añadir Patología:", sug_layout)
        parent_layout.addWidget(group_clinical)

        # --- Grupo: Información de Contacto (Opcional) ---
        group_contact = QGroupBox("Información de Contacto (Opcional)")
        form_contact = QFormLayout(group_contact)
        self.input_telefono = QLineEdit(); self.input_telefono.setPlaceholderText("Ej: +54 9 11 12345678")
        form_contact.addRow("📞 Teléfono:", self.input_telefono)
        self.input_email = QLineEdit(); self.input_email.setPlaceholderText("correo@ejemplo.com")
        form_contact.addRow("📧 Email:", self.input_email)
        self.input_direccion = QTextEdit(); self.input_direccion.setPlaceholderText("Calle, Número, Ciudad, Provincia, Código Postal")
        self.input_direccion.setFixedHeight(60)
        form_contact.addRow("🏠 Dirección:", self.input_direccion)
        parent_layout.addWidget(group_contact)

        parent_layout.addStretch(1) # Empujar botones hacia abajo

        # --- Botones de Acción ---
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        self.btn_save = QPushButton("💾 Guardar Paciente"); self.btn_save.setObjectName("primaryButton")
        self.btn_save.clicked.connect(self._save_patient_data)
        button_layout.addWidget(self.btn_save)
        self.btn_cancel = QPushButton("❌ Cancelar"); self.btn_cancel.setObjectName("secondaryButton")
        self.btn_cancel.clicked.connect(self._cancel_and_go_back)
        button_layout.addWidget(self.btn_cancel)
        parent_layout.addLayout(button_layout)

    # --- Lógica de Formulario y Datos ---
    def _format_dni_text(self):
        """Formatea el DNI con puntos mientras el usuario escribe."""
        dni_input = self.input_dni
        current_text = dni_input.text()
        original_cursor_pos = dni_input.cursorPosition()
        
        # Quitar todo excepto dígitos y el guion final si existe
        clean_dni = "".join(filter(str.isdigit, current_text.split('-')[0]))
        verifier = current_text.split('-')[-1] if '-' in current_text and current_text.split('-')[-1] else ""

        formatted_dni = ""
        if clean_dni:
            # Formatear la parte numérica con puntos cada 3 dígitos desde la derecha
            # (excepto si es muy corto)
            if len(clean_dni) > 3:
                parts = []
                temp_clean_dni = clean_dni
                while len(temp_clean_dni) > 3:
                    parts.insert(0, temp_clean_dni[-3:])
                    temp_clean_dni = temp_clean_dni[:-3]
                if temp_clean_dni: # Añadir la parte restante
                    parts.insert(0, temp_clean_dni)
                formatted_dni = ".".join(parts)
            else:
                formatted_dni = clean_dni
        
        if verifier and (verifier.isdigit() or verifier.upper() == 'K'):
            formatted_dni += "-" + verifier.upper()
        elif '-' in current_text and not verifier: # Si hay un guion pero nada después
             formatted_dni += "-"


        # Evitar bucle infinito de textChanged
        dni_input.blockSignals(True)
        dni_input.setText(formatted_dni)
        dni_input.blockSignals(False)

        # Restaurar cursor (aproximado, puede mejorar)
        # Contar cuántos puntos se añadieron/quitaron antes de la posición original
        new_cursor_pos = original_cursor_pos
        # Esta lógica de ajuste de cursor es compleja, una simplificación es ponerlo al final
        dni_input.setCursorPosition(len(formatted_dni))


    def _check_if_patient_exists(self):
        """Verifica si el DNI ingresado ya existe y ofrece cargar datos."""
        dni_raw = self.input_dni.text().strip()
        if not dni_raw: return

        # Limpiar DNI para búsqueda en base de datos (quitar puntos, mantener guion si es parte del ID)
        dni_cleaned_for_db = dni_raw.replace(".", "")
        
        existing_patient_data = self.data_manager.cargar_paciente(dni_cleaned_for_db)
        if existing_patient_data:
            self.paciente_dni_para_edicion = dni_cleaned_for_db # Marcar que estamos editando
            self.title_bar.setTitle(f"{self.WINDOW_TITLE} - Editando: {existing_patient_data.get('nombre', dni_cleaned_for_db)}")
            confirm = QMessageBox.question(self, "Paciente Encontrado",
                                           f"El paciente con DNI {dni_raw} ya existe.\n"
                                           f"Nombre: {existing_patient_data.get('nombre', 'N/A')}\n"
                                           "¿Desea cargar sus datos para editarlos?",
                                           QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                           QMessageBox.StandardButton.Yes)
            if confirm == QMessageBox.StandardButton.Yes:
                self._populate_form_with_data(existing_patient_data)
            else: # Si no quiere editar, limpiar DNI para que pueda ingresar uno nuevo
                self.input_dni.clear()
                self.paciente_dni_para_edicion = None
                self.title_bar.setTitle(self.WINDOW_TITLE)
        else:
            self.paciente_dni_para_edicion = None # Asegurar que no estamos en modo edición
            self.title_bar.setTitle(self.WINDOW_TITLE)


    def _populate_form_with_data(self, patient_data: Dict[str, Any]):
        """Llena los campos del formulario con los datos de un paciente existente."""
        self.input_dni.setText(patient_data.get("dni_display_format", patient_data.get("dni", ""))) # Usar formato con puntos si se guardó
        self.input_nombre.setText(patient_data.get("nombre", ""))
        
        fecha_nac_str = patient_data.get("fecha_nacimiento", "")
        if fecha_nac_str:
            try:
                self.input_fecha_nac.setDate(QDate.fromString(fecha_nac_str, "yyyy-MM-dd"))
            except: pass # Ignorar si el formato es incorrecto

        self.input_patologias.setPlainText("\n".join(patient_data.get("patologias", [])))
        
        contacto = patient_data.get("contacto", {})
        self.input_telefono.setText(contacto.get("telefono", ""))
        self.input_email.setText(contacto.get("email", ""))
        self.input_direccion.setPlainText(patient_data.get("direccion", ""))
        logger.info(f"Datos del paciente {patient_data.get('dni')} cargados en el formulario para edición.")

    def _add_suggested_patologia(self):
        sugerencia = self.input_patologia_sugerida.text().strip()
        if sugerencia:
            current_text = self.input_patologias.toPlainText()
            if current_text:
                self.input_patologias.setPlainText(current_text + "\n" + sugerencia)
            else:
                self.input_patologias.setPlainText(sugerencia)
            self.input_patologia_sugerida.clear()

    def _validate_fields(self) -> bool:
        """Valida los campos obligatorios del formulario."""
        dni = self.input_dni.text().strip()
        nombre = self.input_nombre.text().strip()

        if not dni:
            QMessageBox.warning(self, "Campo Requerido", "El DNI del paciente es obligatorio.")
            self.input_dni.setFocus()
            return False
        # Validación más flexible de DNI (permite puntos y guion, pero se limpia para guardar)
        # La validación real de formato/existencia se hace en _check_if_patient_exists y al guardar.

        if not nombre:
            QMessageBox.warning(self, "Campo Requerido", "El nombre del paciente es obligatorio.")
            self.input_nombre.setFocus()
            return False
        
        # Validar fecha (opcional, QDateEdit ya lo hace en parte)
        if not self.input_fecha_nac.date().isValid() or self.input_fecha_nac.date() > QDate.currentDate():
            QMessageBox.warning(self, "Fecha Inválida", "La fecha de nacimiento no es válida o es futura.")
            self.input_fecha_nac.setFocus()
            return False
            
        return True

    def _save_patient_data(self):
        """Recolecta datos, valida y guarda/actualiza el paciente."""
        if not self._validate_fields():
            return

        dni_display = self.input_dni.text().strip() # DNI como lo ve el usuario (con puntos)
        dni_db = dni_display.replace(".", "") # DNI limpio para la base de datos

        patient_data = {
            "dni": dni_db, # DNI limpio para ID
            "dni_display_format": dni_display, # Guardar cómo se mostró para recargar
            "nombre": self.input_nombre.text().strip(),
            "fecha_nacimiento": self.input_fecha_nac.date().toString("yyyy-MM-dd"),
            "patologias": [p.strip() for p in self.input_patologias.toPlainText().splitlines() if p.strip()],
            "contacto": {
                "telefono": self.input_telefono.text().strip(),
                "email": self.input_email.text().strip()
            },
            "direccion": self.input_direccion.toPlainText().strip(),
            "ultima_actualizacion": datetime.now().isoformat()
            # Otros campos como 'foto_path', 'historial_clinico' se mantendrían si se está editando
            # y no se modifican directamente en este formulario.
        }

        is_update = bool(self.paciente_dni_para_edicion) # Estamos actualizando si este DNI está seteado

        if is_update:
            # Cargar datos existentes para no perder campos no editables aquí
            existing_data = self.data_manager.cargar_paciente(self.paciente_dni_para_edicion)
            if existing_data:
                # Mantener campos que no se editan en este formulario
                for key in ["foto_path", "historial_clinico", "evolucion_data", "notificaciones", "modelo_ml_preferido"]:
                    if key in existing_data:
                        patient_data[key] = existing_data[key]
            
            success = self.data_manager.actualizar_paciente(self.paciente_dni_para_edicion, patient_data)
            action_msg = "actualizado"
        else:
            # Verificar si el DNI (limpio) ya existe antes de registrar como nuevo
            if self.data_manager.cargar_paciente(dni_db):
                QMessageBox.warning(self, "Paciente Existente", 
                                    f"Un paciente con DNI {dni_db} ya está registrado. "
                                    "Si desea editarlo, ingrese el DNI y el sistema le ofrecerá cargarlo.")
                return
            success = self.data_manager.registrar_nuevo_paciente(dni_db, patient_data) # Asumir que registrar_nuevo_paciente toma el dict completo
            action_msg = "registrado"

        if success:
            QMessageBox.information(self, "Éxito", f"Paciente {patient_data['nombre']} {action_msg} correctamente.")
            logger.info(f"Paciente {dni_db} ({patient_data['nombre']}) {action_msg}.")
            self.paciente_registrado_o_actualizado.emit(dni_db)
            self._clear_form()
            if self.stacked_widget: # Volver a la página anterior (asumiendo que es la de inicio/lista)
                self.stacked_widget.setCurrentIndex(0) # O el índice que corresponda
            else:
                self.close() # Si es una ventana standalone
        else:
            QMessageBox.critical(self, "Error", f"No se pudo {action_msg.replace('o','ar')} al paciente.")

    def _clear_form(self):
        """Limpia todos los campos del formulario."""
        self.input_dni.clear()
        self.input_nombre.clear()
        self.input_fecha_nac.setDate(QDate.currentDate().addYears(-30))
        self.input_patologias.clear()
        self.input_patologia_sugerida.clear()
        self.input_telefono.clear()
        self.input_email.clear()
        self.input_direccion.clear()
        self.paciente_dni_para_edicion = None
        self.title_bar.setTitle(self.WINDOW_TITLE)
        self.input_dni.setFocus()
        logger.info("Formulario de registro limpiado.")

    def _cancel_and_go_back(self):
        # Verificar si hay cambios sin guardar
        # (Esta lógica de is_modified puede ser compleja si se compara con datos cargados)
        # Simplificación: preguntar siempre si hay algo en DNI o Nombre
        if self.input_dni.text().strip() or self.input_nombre.text().strip():
            confirm = QMessageBox.question(self, "Cancelar Registro",
                                           "¿Está seguro de que desea cancelar? Los datos no guardados se perderán.",
                                           QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                           QMessageBox.StandardButton.No)
            if confirm == QMessageBox.StandardButton.No:
                return
        
        self._clear_form()
        if self.stacked_widget:
            self.stacked_widget.setCurrentIndex(0) # Asumir que el índice 0 es la ventana de inicio/principal
        else:
            self.close() # Si es standalone

    def load_data_for_editing(self, patient_dni: str):
        """Pre-carga los datos de un paciente para edición."""
        patient_data = self.data_manager.cargar_paciente(patient_dni)
        if patient_data:
            self.paciente_dni_para_edicion = patient_dni
            self.title_bar.setTitle(f"{self.WINDOW_TITLE} - Editando: {patient_data.get('nombre', patient_dni)}")
            self._populate_form_with_data(patient_data)
            logger.info(f"Cargando datos del paciente {patient_dni} para edición.")
        else:
            QMessageBox.warning(self, "Error", f"No se encontraron datos para el paciente con DNI {patient_dni}.")
            self.paciente_dni_para_edicion = None # Asegurar que no estamos en modo edición

# Ejemplo de Uso
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Cargar estilos QSS (si existe)
    qss_path = os.path.join(os.path.dirname(__file__), "..", "resources", "qss", "estilo_moderno.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r") as f:
            app.setStyleSheet(f.read())
            logger.info(f"Estilo QSS cargado desde: {qss_path}")

    # Crear un DataManager dummy para el ejemplo
    class DummyDataManager:
        def __init__(self): self.pacientes = {}
        def cargar_paciente(self, dni): return self.pacientes.get(dni)
        def actualizar_paciente(self, dni, data): self.pacientes[dni] = data; return True
        def registrar_nuevo_paciente(self, dni, data): self.pacientes[dni] = data; return True

    dummy_dm = DummyDataManager() # type: ignore
    
    # Crear un QStackedWidget dummy para el contexto
    stacked_widget_dummy = QStackedWidget()
    
    main_window = VentanaRegistro(stacked_widget=stacked_widget_dummy, data_manager=dummy_dm)
    
    # Para probar la carga para edición:
    # dummy_dm.pacientes["11.222.333-4"] = {
    #     "dni": "11222333-4", "dni_display_format": "11.222.333-4", "nombre": "Paciente de Prueba",
    #     "fecha_nacimiento": "1990-01-01", "patologias": ["Testitis"],
    #     "contacto": {"telefono": "123", "email": "test@test.com"}, "direccion": "Casa"
    # }
    # main_window.load_data_for_editing("11222333-4") # Descomentar para probar edición

    stacked_widget_dummy.addWidget(main_window) # Añadir al stack para que el go_back funcione
    stacked_widget_dummy.setCurrentWidget(main_window)
    # En una app real, el stacked_widget sería la ventana principal.
    # Para probar standalone, mostramos la ventana de registro directamente.
    # Si el stacked_widget no es visible, la ventana de registro tampoco lo será.
    # Por tanto, para prueba standalone, es mejor mostrar `main_window` directamente
    # y el `stacked_widget` sería `None` o no se usaría para `setCurrentIndex`.
    
    # Si se prueba standalone sin un QStackedWidget visible:
    # main_window = VentanaRegistro(stacked_widget=None, data_manager=dummy_dm)
    main_window.show() # Mostrar la ventana de registro directamente
    
    sys.exit(app.exec())
    