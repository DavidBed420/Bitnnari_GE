"""
fernet.py

Script de utilidad para generar una nueva clave de cifrado Fernet.
Las claves Fernet son base64url-encoded y contienen 32 bytes de material
criptogr�ficamente aleatorio.

Uso:
   python fernet.py
   
El script imprimir� una nueva clave en la consola. Esta clave puede ser usada
para la variable de entorno MASTER_FERNET_KEY o para generar claves de usuario.
"""

from cryptography.fernet import Fernet
import sys

def generate_fernet_key() -> str:
   """
   Genera una nueva clave Fernet y la retorna como una cadena decodificada.
   """
   key_bytes = Fernet.generate_key()
   return key_bytes.decode('utf-8')

if __name__ == "__main__":
   new_key = generate_fernet_key()
   print("Nueva clave Fernet generada:")
   print(new_key)
   print("\nGuarde esta clave de forma segura. Es necesaria para el cifrado y descifrado.")
   print("Puede usarla para la variable de entorno MASTER_FERNET_KEY.")
   
   # Opcional: Escribir la clave a un archivo (con precauci�n)
   # with open(".fernet_key", "w") as f:
   #     f.write(new_key)
   # print("\nClave tambi�n guardada en el archivo '.fernet_key' en el directorio actual.")
   # print("Aseg�rese de que este archivo est� en .gitignore si es un repositorio.")
