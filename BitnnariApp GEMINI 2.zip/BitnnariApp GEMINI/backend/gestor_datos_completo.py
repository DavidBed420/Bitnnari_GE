import os
import sys
import json
import csv
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager
from pydantic import BaseModel, Field, ValidationError, validator
from cryptography.fernet import Fernet, MultiFernet
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from dash import Dash, html, dcc, dash_table, Input, Output
import plotly.graph_objs as go
import pymongo
from pymongo import MongoClient, ASCENDING, DESCENDING
from celery import Celery
from celery.schedules import crontab
import pandas as pd
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from docx import Document
from openpyxl import Workbook
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Environment, FileSystemLoader
from dotenv import load_dotenv
from passlib.context import CryptContext
from jose import JWTError, jwt
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
import pickle
import redis
import firebase_admin
from firebase_admin import credentials, messaging

# Cargar variables de entorno
load_dotenv()

# Configuración de logging
logger = logging.getLogger("GestorDatos")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
logger.addHandler(ch)

# Variables de entorno
MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017")
REDIS_URI = os.getenv("REDIS_URI", "redis://redis:6379/0")
SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
MASTER_FERNET_KEY = os.getenv("MASTER_FERNET_KEY")
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
GOOGLE_CREDENTIALS_FILE = os.getenv("GOOGLE_CREDENTIALS_FILE", "credentials.json")
TOKEN_FILE = "token.pickle"
FIREBASE_CRED_PATH = os.getenv("FIREBASE_CRED_PATH", "firebase_credentials.json")

# Inicializar FastAPI
app = FastAPI(title="Gestor de Datos Médicos", description="API avanzada para gestión de datos médicos")

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar Dash
dash_app = Dash(__name__, server=app, url_base_pathname="/dash/", external_stylesheets=["https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"])

# Configurar Celery
celery_app = Celery("gestor", broker=REDIS_URI, backend=REDIS_URI)
celery_app.conf.beat_schedule = {
    "rotate-keys": {
        "task": "gestor_datos_completo.rotate_keys",
        "schedule": crontab(day_of_month=1, hour=0, minute=0),
    },
    "clean-old-files": {
        "task": "gestor_datos_completo.clean_old_files",
        "schedule": crontab(hour=0, minute=0),  # Diario a medianoche
    },
}

# Conectar a MongoDB
client = MongoClient(MONGO_URI)
db = client["gestor_datos"]

# Configurar Redis para caching
redis_client = redis.Redis.from_url(REDIS_URI)

# Configurar contexto de hashing de contraseñas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Inicializar Firebase para notificaciones push
if not firebase_admin._apps:
    cred = credentials.Certificate(FIREBASE_CRED_PATH)
    firebase_admin.initialize_app(cred)

# Configuración de índices en MongoDB
db["pacientes"].create_index([("dni", ASCENDING)], unique=True)
db["colaboradores"].create_index([("dni", ASCENDING)], unique=True)
db["sesiones"].create_index([("session_id", ASCENDING)], unique=True)
db["audit_log"].create_index([("timestamp", DESCENDING)])
db["tareas_programadas"].create_index([("task_id", ASCENDING)], unique=True)

# Modelos Pydantic
class Patient(BaseModel):
    dni: str = Field(..., min_length=8)
    nombre: str
    fecha_nacimiento: Optional[datetime] = None
    contacto: Dict[str, str] = {}
    foto: Optional[str] = None
    patologias: List[str] = []
    factores_riesgo: List[str] = []
    factores_predisponentes: List[str] = []
    diagnostico_amputacion: Optional[str] = None
    direccion: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @validator("dni")
    def up(cls, v):
        return v.upper()

class Collaborator(BaseModel):
    dni: str = Field(..., min_length=8)
    nombre: str
    especialidad: str
    contacto: Dict[str, str] = {}
    foto: Optional[str] = None
    direccion: Optional[str] = None
    encrypted_key: bytes
    password_hash: str
    role: str = "colaborador"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @validator("dni")
    def up(cls, v):
        return v.upper()

class Session(BaseModel):
    session_id: str
    paciente_dni: str
    tipo: str
    parametros: Dict[str, Any] = {}
    datos_crudos: List[float]
    datos_procesados: List[float]
    registros_vitales: Dict[str, Any] = {}
    foto: Optional[str] = None
    notas: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class AuditLog(BaseModel):
    colaborador_dni: str
    action: str
    details: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class TaskModel(BaseModel):
    task_id: str
    colaborador_dni: str
    name: str
    args: List[Any]
    kwargs: Dict[str, Any]
    run_at: datetime
    created_at: datetime = Field(default_factory=datetime.utcnow)

# Seguridad: Gestión de claves
class SecurityManager:
    def __init__(self):
        self.master_key = MASTER_FERNET_KEY.encode()
        self.master = Fernet(self.master_key)
        self.key_expiry = timedelta(days=90)

    def gen_user_key(self) -> str:
        return Fernet.generate_key().decode()

    def encrypt_user_key(self, user_key: str) -> bytes:
        return self.master.encrypt(user_key.encode())

    def decrypt_user_key(self, token: bytes) -> str:
        return self.master.decrypt(token).decode()

    def rotate_user_key(self, enc_old: bytes) -> bytes:
        old_key = self.decrypt_user_key(enc_old)
        new_key = self.gen_user_key()
        return self.encrypt_user_key(new_key)

    def check_key_expiry(self, dni: str):
        doc = db["colaboradores"].find_one({"dni": dni})
        if not doc or "updated_at" not in doc:
            return
        last_updated = doc["updated_at"]
        if datetime.utcnow() - last_updated > self.key_expiry:
            new_key = self.rotate_user_key(doc["encrypted_key"])
            db["colaboradores"].update_one(
                {"dni": dni},
                {"$set": {"encrypted_key": new_key, "updated_at": datetime.utcnow()}}
            )
            self.notify_key_expiry(dni)

    def notify_key_expiry(self, dni: str):
        col = db["colaboradores"].find_one({"dni": dni})
        email = col.get("contacto", {}).get("email")
        if email:
            send_email.delay("Notificación de Expiración de Clave", "Su clave ha expirado y ha sido rotada.", email)

# Funciones de utilidad
def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    credentials_exception = HTTPException(
        status_code=401,
        detail="No se pudieron validar las credenciales",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        dni: str = payload.get("sub")
        if dni is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = db["colaboradores"].find_one({"dni": dni})
    if user is None:
        raise credentials_exception
    return user

# Endpoints de autenticación
@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = db["colaboradores"].find_one({"dni": form_data.username.upper()})
    if not user or not verify_password(form_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    access_token = create_access_token(data={"sub": user["dni"]})
    return {"access_token": access_token, "token_type": "bearer"}

# CRUD Pacientes
@app.post("/pacientes")
async def create_paciente(p: Patient, current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["admin", "colaborador"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    p_dict = p.dict()
    try:
        db["pacientes"].insert_one(p_dict)
        db["audit_log"].insert_one({
            "colaborador_dni": current_user["dni"],
            "action": "create_paciente",
            "details": f"Paciente {p.dni} creado",
            "timestamp": datetime.utcnow(),
        })
        send_push_notification(current_user["dni"], "Paciente Creado", f"Se ha creado el paciente {p.dni}")
        return {"msg": "Paciente creado"}
    except pymongo.errors.DuplicateKeyError:
        raise HTTPException(400, "Paciente ya existe")

@app.get("/pacientes/{dni}")
async def get_paciente(dni: str, current_user: dict = Depends(get_current_user)):
    paciente = db["pacientes"].find_one({"dni": dni.upper()}, {"_id": 0})
    if not paciente:
        raise HTTPException(404, "Paciente no encontrado")
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "get_paciente",
        "details": f"Consultó paciente {dni}",
        "timestamp": datetime.utcnow(),
    })
    return paciente

@app.put("/pacientes/{dni}")
async def update_paciente(dni: str, data: Dict[str, Any], current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["admin", "colaborador"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    existing = db["pacientes"].find_one({"dni": dni.upper()})
    if not existing:
        raise HTTPException(404, "Paciente no encontrado")
    updated = Patient(**{**existing, **data})
    db["pacientes"].update_one(
        {"dni": dni.upper()},
        {"$set": updated.dict(exclude={"created_at"}), "$currentDate": {"updated_at": True}}
    )
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "update_paciente",
        "details": f"Paciente {dni} actualizado",
        "timestamp": datetime.utcnow(),
    })
    return {"msg": "Paciente actualizado"}

# CRUD Sesiones
@app.post("/sesiones")
async def create_sesion(s: Session, current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["admin", "colaborador"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    s_dict = s.dict()
    db["sesiones"].insert_one(s_dict)
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "create_sesion",
        "details": f"Sesión {s.session_id} creada para {s.paciente_dni}",
        "timestamp": datetime.utcnow(),
    })
    return {"msg": "Sesión guardada"}

@app.get("/sesiones/{dni}")
async def list_sesiones(dni: str, current_user: dict = Depends(get_current_user)):
    sesiones = list(db["sesiones"].find({"paciente_dni": dni.upper()}, {"_id": 0}))
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "list_sesiones",
        "details": f"Listó sesiones de {dni}",
        "timestamp": datetime.utcnow(),
    })
    return sesiones

# CRUD Colaboradores
@app.post("/colaboradores")
async def create_colaborador(data: Collaborator, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Solo administradores pueden crear colaboradores")
    sec = SecurityManager()
    key = sec.gen_user_key()
    data.encrypted_key = sec.encrypt_user_key(key)
    data.password_hash = get_password_hash(data.password_hash)
    try:
        db["colaboradores"].insert_one(data.dict())
        db["audit_log"].insert_one({
            "colaborador_dni": current_user["dni"],
            "action": "create_colaborador",
            "details": f"Colaborador {data.dni} creado",
            "timestamp": datetime.utcnow(),
        })
        return {"user_key": key}
    except pymongo.errors.DuplicateKeyError:
        raise HTTPException(400, "Colaborador ya existe")

@app.put("/colaboradores/{dni}/password")
async def set_colaborador_password(dni: str, password: str, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin" and current_user["dni"] != dni:
        raise HTTPException(status_code=403, detail="No autorizado")
    col = db["colaboradores"].find_one({"dni": dni.upper()})
    if not col:
        raise HTTPException(404, "Colaborador no encontrado")
    password_hash = get_password_hash(password)
    db["colaboradores"].update_one(
        {"dni": dni.upper()},
        {"$set": {"password_hash": password_hash, "updated_at": datetime.utcnow()}}
    )
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "set_password",
        "details": f"Contraseña actualizada para {dni}",
        "timestamp": datetime.utcnow(),
    })
    return {"msg": "Contraseña actualizada"}

# Gestión de Tareas
@app.post("/schedule")
async def schedule(t: TaskModel, current_user: dict = Depends(get_current_user)):
    if current_user["role"] not in ["admin", "colaborador"]:
        raise HTTPException(status_code=403, detail="No autorizado")
    db["tareas_programadas"].insert_one(t.dict())
    celery_app.send_task("gestor_datos_completo.send_reminder", (t.task_id,), eta=t.run_at)
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "schedule_task",
        "details": f"Tarea {t.task_id} programada",
        "timestamp": datetime.utcnow(),
    })
    return {"msg": "Tarea programada"}

@app.get("/tasks")
async def list_tasks(current_user: dict = Depends(get_current_user)):
    tasks = list(db["tareas_programadas"].find({"colaborador_dni": current_user["dni"]}, {"_id": 0}))
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "list_tasks",
        "details": "Listó tareas programadas",
        "timestamp": datetime.utcnow(),
    })
    return tasks

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: str, current_user: dict = Depends(get_current_user)):
    result = db["tareas_programadas"].delete_one({"task_id": task_id, "colaborador_dni": current_user["dni"]})
    if result.deleted_count:
        db["audit_log"].insert_one({
            "colaborador_dni": current_user["dni"],
            "action": "delete_task",
            "details": f"Tarea {task_id} eliminada",
            "timestamp": datetime.utcnow(),
        })
        return {"msg": "Tarea eliminada"}
    raise HTTPException(404, "Tarea no encontrada")

# Auditoría
@app.get("/audit")
async def get_audit(limit: int = 100, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Solo administradores pueden ver la auditoría")
    logs = list(db["audit_log"].find({}, {"_id": 0}).sort("timestamp", DESCENDING).limit(limit))
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "get_audit",
        "details": f"Consultó registros de auditoría (límite: {limit})",
        "timestamp": datetime.utcnow(),
    })
    return logs

# Exportación Avanzada
@app.get("/export/{dni}")
async def export_paciente(
    dni: str,
    formato: str,
    secciones: Optional[str] = "datos_personales,sesiones",
    graficos: bool = False,
    chart_types: str = "bar,line",
    current_user: dict = Depends(get_current_user)
):
    paciente = db["pacientes"].find_one({"dni": dni.upper()})
    if not paciente:
        raise HTTPException(404, "Paciente no encontrado")
    secciones_list = secciones.split(",")
    data_to_export = {}
    if "datos_personales" in secciones_list:
        data_to_export["datos_personales"] = paciente
    if "sesiones" in secciones_list:
        data_to_export["sesiones"] = list(db["sesiones"].find({"paciente_dni": dni.upper()}, {"_id": 0}))
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    destino = f"export_{dni}_{timestamp}.{formato.lower()}"
    chart_types_list = chart_types.split(",")

    if formato.lower() == "csv":
        flat_data = {k: flatten_data(v) for k, v in data_to_export.items()}
        df = pd.DataFrame.from_dict(flat_data, orient="index")
        df.to_csv(destino, encoding="utf-8")
        if graficos:
            generate_charts(df, destino.replace(".csv", ""), chart_types_list)
    elif formato.lower() in ("xlsx", "xls"):
        wb = Workbook()
        ws = wb.active
        ws.title = "Datos del Paciente"
        append_to_sheet(ws, paciente, data_to_export)
        wb.save(destino)
        if graficos:
            df = pd.DataFrame.from_dict({k: flatten_data(v) for k, v in data_to_export.items()}, orient="index")
            generate_charts(df, destino.replace(".xlsx", ""), chart_types_list)
    elif formato.lower() == "pdf":
        doc = SimpleDocTemplate(destino, pagesize=letter)
        elements = build_pdf_elements(data_to_export, paciente)
        doc.build(elements)
        if graficos:
            df = pd.DataFrame.from_dict({k: flatten_data(v) for k, v in data_to_export.items()}, orient="index")
            generate_charts(df, destino.replace(".pdf", ""), chart_types_list)
    else:
        raise HTTPException(400, "Formato no soportado")
    
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "export_paciente",
        "details": f"Exportó datos de {dni} a {formato}",
        "timestamp": datetime.utcnow(),
    })
    return FileResponse(destino)

def flatten_data(data: Any, parent_key: str = "", sep: str = "_") -> Dict[str, Any]:
    items = {}
    if isinstance(data, dict):
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            items.update(flatten_data(v, new_key, sep))
    elif isinstance(data, list):
        for i, v in enumerate(data):
            new_key = f"{parent_key}{sep}{i}"
            items.update(flatten_data(v, new_key, sep))
    else:
        items[parent_key] = data
    return items

def append_to_sheet(ws, paciente: Dict[str, Any], data_map: Dict[str, Any]):
    ws.append(["", "DNI", paciente["dni"]])
    ws.append(["", "Nombre", paciente["nombre"]])
    for path, data in data_map.items():
        ws.append([path])
        flat_data = flatten_data(data)
        ws.append(list(flat_data.keys()))
        ws.append(list(flat_data.values()))

def build_pdf_elements(data_map: Dict[str, Any], paciente: Dict[str, Any]) -> List:
    elements = []
    styles = getSampleStyleSheet()
    elements.append(Paragraph(f"DNI: {paciente['dni']}", styles["Normal"]))
    for path, data in data_map.items():
        elements.append(Paragraph(path, styles["Heading1"]))
        flat_data = flatten_data(data)
        table_data = [list(flat_data.keys()), list(flat_data.values())]
        table = Table(table_data)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table)
    return elements

def generate_charts(df: pd.DataFrame, base_path: str, chart_types: List[str]):
    for col in df.select_dtypes(include=["float64", "int64"]).columns:
        for chart_type in chart_types:
            plt.figure()
            if chart_type == "bar":
                df[col].plot(kind="bar", title=f"Histograma de {col}")
            elif chart_type == "line":
                df[col].plot(kind="line", title=f"Curva de {col}")
            plt.savefig(f"{base_path}_{col}_{chart_type}.png")
            plt.close()

# Google Drive Integration
def get_drive_service():
    creds = None
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                GOOGLE_CREDENTIALS_FILE, ["https://www.googleapis.com/auth/drive"]
            )
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "wb") as token:
            pickle.dump(creds, token)
    return build("drive", "v3", credentials=creds)

@app.post("/upload-to-drive/{dni}")
async def upload_to_drive(dni: str, file_path: str, current_user: dict = Depends(get_current_user)):
    service = get_drive_service()
    file_metadata = {"name": os.path.basename(file_path), "parents": ["root"]}
    media = service.files().create(
        body=file_metadata,
        media_body=file_path,
        fields="id"
    ).execute()
    db["audit_log"].insert_one({
        "colaborador_dni": current_user["dni"],
        "action": "upload_to_drive",
        "details": f"Subió archivo {file_path} a Google Drive para {dni}",
        "timestamp": datetime.utcnow(),
    })
    return {"file_id": media.get("id")}

# Tareas Celery
@celery_app.task(bind=True, max_retries=3, default_retry_delay=60)
def send_email(self, subject: str, body: str, to: str):
    try:
        msg = MIMEMultipart()
        msg["Subject"] = subject
        msg["From"] = SMTP_USER
        msg["To"] = to
        msg.attach(MIMEText(body, "plain"))
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as s:
            s.starttls()
            s.login(SMTP_USER, SMTP_PASSWORD)
            s.send_message(msg)
        logger.info(f"Correo enviado a {to}: {subject}")
    except Exception as e:
        logger.error(f"Error al enviar correo: {e}")
        raise self.retry(exc=e)

@celery_app.task
def send_reminder(task_id: str):
    doc = db["tareas_programadas"].find_one({"task_id": task_id})
    if not doc:
        logger.warning(f"Tarea {task_id} no encontrada")
        return
    email = db["colaboradores"].find_one({"dni": doc["colaborador_dni"]}).get("contacto", {}).get("email")
    if email:
        send_email.delay(f"Recordatorio: {doc['name']}", f"Programado para: {doc['run_at']}", email)

@celery_app.task
def rotate_keys():
    sec = SecurityManager()
    cutoff = datetime.utcnow() - timedelta(days=90)
    for col in db["colaboradores"].find({"updated_at": {"$lt": cutoff}}):
        sec.check_key_expiry(col["dni"])
    logger.info("Rotación de claves completada")

@celery_app.task
def clean_old_files():
    service = get_drive_service()
    cutoff = (datetime.utcnow() - timedelta(days=5*365)).isoformat() + "Z"  # 5 años
    files = service.files().list(q=f"modifiedTime < '{cutoff}'").execute().get("files", [])
    for file in files:
        service.files().delete(fileId=file["id"]).execute()
        db["audit_log"].insert_one({
            "colaborador_dni": "system",
            "action": "clean_old_files",
            "details": f"Archivo {file['id']} eliminado de Google Drive",
            "timestamp": datetime.utcnow(),
        })
    logger.info("Limpieza de archivos antiguos completada")

# Notificaciones Push
def send_push_notification(user_dni: str, title: str, body: str):
    user = db["colaboradores"].find_one({"dni": user_dni})
    token = user.get("device_token")  # Asume que el token del dispositivo está almacenado
    if token:
        message = messaging.Message(
            notification=messaging.Notification(title=title, body=body),
            token=token
        )
        response = messaging.send(message)
        logger.info(f"Notificación enviada a {user_dni}: {response}")

# Dashboard Dash
dash_app.layout = html.Div(className="container", children=[
    html.H1("EMG Dashboard", className="my-4"),
    dcc.Dropdown(
        id="patient-dropdown",
        options=[{"label": p["nombre"], "value": p["dni"]} for p in db["pacientes"].find()],
        placeholder="Seleccione un paciente",
        className="mb-3"
    ),
    dcc.DatePickerRange(
        id="date-picker",
        start_date_placeholder_text="Fecha inicial",
        end_date_placeholder_text="Fecha final",
        className="mb-3"
    ),
    dcc.Graph(id="emg-graph"),
    dash_table.DataTable(
        id="session-table",
        columns=[
            {"name": "ID Sesión", "id": "session_id"},
            {"name": "Tipo", "id": "tipo"},
            {"name": "Fecha", "id": "created_at"}
        ],
        page_size=10,
        style_table={"overflowX": "auto"},
    )
])

@dash_app.callback(
    [Output("emg-graph", "figure"), Output("session-table", "data")],
    [Input("patient-dropdown", "value"), Input("date-picker", "start_date"), Input("date-picker", "end_date")]
)
def update_dashboard(selected_patient, start_date, end_date):
    query = {"paciente_dni": selected_patient} if selected_patient else {}
    if start_date and end_date:
        query["created_at"] = {"$gte": datetime.fromisoformat(start_date), "$lte": datetime.fromisoformat(end_date)}
    sesiones = list(db["sesiones"].find(query, {"_id": 0}))
    if not sesiones:
        return go.Figure(), []
    
    df = pd.DataFrame([{"x": i, "y": d} for s in sesiones for i, d in enumerate(s["datos_procesados"])])
    fig = go.Figure(data=[go.Scatter(x=df["x"], y=df["y"], mode="lines", name="EMG Procesado")])
    fig.update_layout(title=f"Datos EMG para {selected_patient}", xaxis_title="Tiempo", yaxis_title="Amplitud")
    return fig, sesiones

# Script de inicialización
def init_admin():
    sec = SecurityManager()
    admin_key = sec.gen_user_key()
    admin = Collaborator(
        dni="ADMIN001",
        nombre="Administrator",
        especialidad="Admin",
        contacto={"email": "admin@example.com"},
        foto="",
        encrypted_key=sec.encrypt_user_key(admin_key),
        password_hash=get_password_hash("admin123"),
        role="admin"
    )
    try:
        db["colaboradores"].insert_one(admin.dict())
        logger.info("Administrador creado.")
    except pymongo.errors.DuplicateKeyError:
        logger.info("Administrador ya existe.")

if __name__ == "__main__":
    init_admin()
    import uvicorn
    uvicorn.run("gestor_datos_completo:app", host="0.0.0.0", port=8000, reload=True)

