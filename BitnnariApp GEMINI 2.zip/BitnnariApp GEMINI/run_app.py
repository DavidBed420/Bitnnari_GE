"""
run_app.py

Punto de entrada principal para la aplicación BitnariApp EMG Suite.
Inicializa la aplicación Qt, carga estilos, gestiona el flujo de autenticación
inicial y luego la navegación de alto nivel entre la pantalla de inicio/registro
y la ventana principal de la aplicación.
"""

import os
import sys
import logging

from PyQt6.QtWidgets import QApplication, QStackedWidget, QMainWindow, QWidget, QDialog
from PyQt6.QtCore import pyqtSignal, QTimer # QTimer para cierre elegante

# Importaciones de módulos del proyecto
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.gui.login_dialog import LoginDialog # Para el inicio de sesión
from BitnnariApp.gui.ventana_inicio import VentanaInicio
from BitnnariApp.gui.ventana_registro import VentanaRegistro
from BitnnariApp.gui.ventana_principal import VentanaPrincipal
from BitnnariApp.auth.authentication import get_auth_service # Para acceder al servicio de auth
from BitnnariApp.classification.emg_classification import DEFAULT_CLASSIFICATION_CONFIG # Para modelos en ModeloSeleccionDialog

# Configuración del logging global
LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s (%(filename)s:%(lineno)d) - %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT) # Nivel INFO por defecto
logger = logging.getLogger("BitnariAppRun")

# Cargar configuración de logging personalizada si existe
try:
    from BitnnariApp.utils.logging_config import setup_logging
    # Configurar para que los logs de la app sean más detallados si es necesario
    setup_logging(console_level=logging.INFO, file_level=logging.DEBUG)
    logger.info("Configuración de logging personalizada (desde utils) aplicada.")
except ImportError:
    logger.warning("Usando configuración de logging básica. 'logging_config.py' no encontrado o con errores.")
except Exception as e:
    logger.error(f"Error al aplicar logging_config.py: {e}")


def load_global_stylesheet(app: QApplication, qss_filename: str = "estilo_moderno.qss"):
    """Carga la hoja de estilos QSS global para la aplicación."""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        qss_path = os.path.join(current_dir, "resources", "qss", qss_filename)

        if not os.path.exists(qss_path):
            logger.warning(f"Archivo QSS global no encontrado en: {qss_path}. Se intentará ruta relativa simple.")
            qss_path = qss_filename
            if not os.path.exists(qss_path):
                 logger.error(f"Archivo QSS global '{qss_filename}' no encontrado. La aplicación podría no tener estilos definidos.")
                 return

        with open(qss_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
        logger.info(f"Hoja de estilos global '{qss_filename}' cargada desde '{qss_path}'.")
    except Exception as e:
        logger.error(f"Error al cargar la hoja de estilos global '{qss_filename}': {e}", exc_info=True)


class MainApplicationController(QObject): # QObject para usar señales si fuera necesario en el futuro
    """
    Controlador de la aplicación de más alto nivel.
    Gestiona el flujo inicial (login) y la ventana principal de la aplicación.
    """
    def __init__(self, data_manager: GestorDatos, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.data_manager = data_manager
        self.auth_service = get_auth_service()
        
        self.main_app_window: Optional[MainApplicationWindowInternal] = None
        self.login_dialog: Optional[LoginDialog] = None

    def start(self):
        """Inicia el flujo de la aplicación: primero el login, luego la app principal."""
        self.login_dialog = LoginDialog(use_frameless_window=True) # Usar la versión sin bordes
        
        # Conectar señales del LoginDialog
        self.login_dialog.accepted.connect(self._handle_login_success)
        self.login_dialog.rejected.connect(self._handle_login_failure_or_cancel)
        
        logger.info("Mostrando diálogo de inicio de sesión.")
        self.login_dialog.exec() # Muestra el diálogo de forma modal

        # El flujo continúa en _handle_login_success o _handle_login_failure_or_cancel

    def _handle_login_success(self):
        logger.info("Inicio de sesión exitoso.")
        if self.login_dialog:
            self.login_dialog.deleteLater() # Limpiar el diálogo de login
            self.login_dialog = None

        # Proceder a mostrar la ventana principal de la aplicación
        self.main_app_window = MainApplicationWindowInternal(self.data_manager)
        
        # Conectar señales de navegación de la ventana principal
        self.main_app_window.request_logout.connect(self._handle_logout_request)

        self.main_app_window.show()
        logger.info("Ventana principal de la aplicación mostrada.")

    def _handle_login_failure_or_cancel(self):
        logger.info("Inicio de sesión fallido o cancelado por el usuario. Saliendo de la aplicación.")
        if self.login_dialog:
            self.login_dialog.deleteLater()
        QApplication.instance().quit() # Salir de la aplicación Qt

    def _handle_logout_request(self):
        logger.info("Solicitud de cierre de sesión recibida.")
        if self.auth_service:
            self.auth_service.logout()
        
        if self.main_app_window:
            self.main_app_window.close() # Cierra la ventana principal
            self.main_app_window.deleteLater()
            self.main_app_window = None
        
        # Volver a mostrar el diálogo de login para un nuevo inicio de sesión
        # o salir de la aplicación. Por ahora, reiniciamos el flujo de login.
        logger.info("Volviendo a la pantalla de inicio de sesión después del logout.")
        QTimer.singleShot(100, self.start) # Pequeño delay para asegurar limpieza de UI


class MainApplicationWindowInternal(QMainWindow): # Renombrada para evitar conflicto con la clase del prompt anterior
    """
    Ventana contenedora interna que se muestra después de un login exitoso.
    Gestiona el QStackedWidget para VentanaInicio, VentanaRegistro y VentanaPrincipal.
    """
    request_logout = pyqtSignal() # Para solicitar cierre de sesión

    def __init__(self, data_manager: GestorDatos, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.data_manager = data_manager
        self.auth_service = get_auth_service() # Para obtener info del usuario actual

        self.setWindowTitle(f"BitnariApp EMG Suite - Usuario: {self.auth_service.get_current_user_data().get('nombre', 'N/A') if self.auth_service.get_current_user_data() else 'Desconocido'}")
        self.setMinimumSize(1000, 700) # Un mínimo para la ventana principal
        self.resize(1280, 800) # Tamaño inicial
        self._center_on_screen_internal()

        self.stacked_widget = QStackedWidget(self)
        self.setCentralWidget(self.stacked_widget)

        self._setup_internal_pages()
        self._connect_internal_navigation_signals()

        self.stacked_widget.setCurrentWidget(self.ventana_inicio)
        
        # Opcional: Añadir un menú con opción de "Cerrar Sesión"
        self._create_main_menu()

        logger.info("MainApplicationWindowInternal (post-login) inicializada.")

    def _center_on_screen_internal(self):
        screen_geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(screen_geo.center() - self.rect().center())

    def _setup_internal_pages(self):
        self.ventana_inicio = VentanaInicio(stacked_widget=self.stacked_widget, data_manager=self.data_manager, parent=self)
        self.ventana_inicio.setObjectName("ventanaInicioScreenApp")

        self.ventana_registro = VentanaRegistro(stacked_widget=self.stacked_widget, data_manager=self.data_manager, parent=self)
        self.ventana_registro.setObjectName("ventanaRegistroScreenApp")
        
        self.ventana_principal_instance: Optional[VentanaPrincipal] = None # Se crea bajo demanda

        self.stacked_widget.addWidget(self.ventana_inicio)
        self.stacked_widget.addWidget(self.ventana_registro)

    def _connect_internal_navigation_signals(self):
        # Conexiones de VentanaInicio para navegar a Registro o a VentanaPrincipal
        # Asumimos que VentanaInicio tiene estas señales:
        if hasattr(self.ventana_inicio, 'navigate_to_register_signal'): # Señal hipotética
             self.ventana_inicio.navigate_to_register_signal.connect(self.show_registration_page_internal)
        else: # Conectar al botón si no hay señal explícita
            if hasattr(self.ventana_inicio, 'btn_go_to_register'): # Asumiendo que VentanaInicio tiene este botón
                 self.ventana_inicio.btn_go_to_register.clicked.connect(
                     lambda: self.show_registration_page_internal(self.ventana_inicio.input_dni_inicio.text().strip())
                 )


        if hasattr(self.ventana_inicio, 'patient_found_and_model_selected_signal'): # Señal hipotética
            self.ventana_inicio.patient_found_and_model_selected_signal.connect(self.show_main_treatment_area)
        else: # Conectar al botón de búsqueda si no hay señal explícita
            if hasattr(self.ventana_inicio, 'btn_search_patient'):
                 self.ventana_inicio.btn_search_patient.clicked.connect(self.ventana_inicio._search_patient_action)
                 # Y VentanaInicio._search_patient_action debe llamar a self.parent().show_main_treatment_area(...)

        # Conexiones de VentanaRegistro
        if hasattr(self.ventana_registro, 'registration_cancelled_signal'):
            self.ventana_registro.registration_cancelled_signal.connect(self.show_initial_screen_internal)
        else: # Conectar al botón cancelar
            if hasattr(self.ventana_registro, 'btn_cancel'):
                self.ventana_registro.btn_cancel.clicked.connect(self.ventana_registro._cancel_and_go_back) # Este ya navega


        self.ventana_registro.paciente_registrado_o_actualizado.connect(self._handle_patient_registered_internal)

    def _create_main_menu(self):
        menu_bar = self.menuBar()
        menu_bar.setObjectName("mainMenuBar") # Para QSS
        
        archivo_menu = menu_bar.addMenu("&Archivo")
        
        logout_action = QAction("🚪 Cerrar Sesión", self)
        logout_action.setShortcut(Qt.Key.Key_Q | Qt.KeyboardModifier.ControlModifier) # Ctrl+Q para logout
        logout_action.setStatusTip("Cerrar la sesión actual y volver a la pantalla de inicio de sesión.")
        logout_action.triggered.connect(self.request_logout.emit) # Emitir señal para que MainApplicationController maneje
        archivo_menu.addAction(logout_action)

        archivo_menu.addSeparator()
        
        exit_action = QAction("✕ Salir de BitnariApp", self)
        exit_action.setShortcut(Qt.Key.Key_X | Qt.KeyboardModifier.AltModifier) # Alt+X para salir
        exit_action.setStatusTip("Cerrar la aplicación.")
        exit_action.triggered.connect(QApplication.instance().quit)
        archivo_menu.addAction(exit_action)

    def _handle_patient_registered_internal(self, patient_dni: str):
        logger.info(f"Paciente {patient_dni} registrado/actualizado desde VentanaRegistro. Solicitando modelo.")
        patient_data = self.data_manager.cargar_paciente(patient_dni)
        if not patient_data:
            QMessageBox.critical(self, "Error", f"No se pudieron cargar datos del paciente {patient_dni}.")
            self.show_initial_screen_internal()
            return

        from BitnnariApp.gui.ventana_inicio import ModeloSeleccionDialog # Importación local
        modelos_disponibles = list(DEFAULT_CLASSIFICATION_CONFIG["model_hyperparameters"].keys())
        modelo_actual = patient_data.get("modelo_ml_preferido", modelos_disponibles[0])
        
        dialog = ModeloSeleccionDialog(patient_data.get('nombre', patient_dni), modelos_disponibles, modelo_actual, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected_model = dialog.get_selected_model()
            self.data_manager.actualizar_campo_paciente(patient_dni, "modelo_ml_preferido", selected_model)
            self.show_main_treatment_area(patient_dni, selected_model)
        else:
            self.show_initial_screen_internal()


    def show_initial_screen_internal(self):
        self.stacked_widget.setCurrentWidget(self.ventana_inicio)
        self.ventana_inicio.input_dni_inicio.clear()
        self.ventana_inicio.input_dni_inicio.setFocus()
        self.resize(self.ventana_inicio.sizeHint().width() + 2, self.ventana_inicio.sizeHint().height() + self.ventana_inicio.title_bar.height() + 2 if hasattr(self.ventana_inicio, 'title_bar') else 600)
        logger.info("Mostrando pantalla de inicio (interna).")

    def show_registration_page_internal(self, dni_to_prefill: Optional[str] = None):
        if dni_to_prefill:
            self.ventana_registro.input_dni.setText(dni_to_prefill)
            self.ventana_registro.paciente_dni_para_edicion = None
            if hasattr(self.ventana_registro, 'title_bar'):
                self.ventana_registro.title_bar.setTitle(self.ventana_registro.WINDOW_TITLE)
        else:
            self.ventana_registro._clear_form()
        self.stacked_widget.setCurrentWidget(self.ventana_registro)
        self.resize(self.ventana_registro.sizeHint().width() + 2, self.ventana_registro.sizeHint().height() + self.ventana_registro.title_bar.height() + 2 if hasattr(self.ventana_registro, 'title_bar') else 750)
        logger.info(f"Mostrando página de registro (interna). DNI pre-llenado: {dni_to_prefill or 'No'}")

    def show_main_treatment_area(self, patient_id: str, selected_model: str):
        logger.info(f"Solicitando mostrar VentanaPrincipal para paciente {patient_id}, modelo {selected_model}.")
        if self.ventana_principal_instance is None or self.ventana_principal_instance.patient_id != patient_id:
            if self.ventana_principal_instance:
                self.stacked_widget.removeWidget(self.ventana_principal_instance)
                self.ventana_principal_instance.deleteLater()
            
            self.ventana_principal_instance = VentanaPrincipal(
                patient_id=patient_id,
                selected_model=selected_model,
                data_manager=self.data_manager,
                parent=self # Parent es MainApplicationWindowInternal
            )
            self.ventana_principal_instance.setObjectName("ventanaPrincipalScreenApp")
            self.stacked_widget.addWidget(self.ventana_principal_instance)
        else:
            self.ventana_principal_instance.update_for_patient(patient_id, selected_model)

        self.stacked_widget.setCurrentWidget(self.ventana_principal_instance)
        self.resize(self.ventana_principal_instance.size())
        logger.info(f"Mostrando VentanaPrincipal (interna) para paciente {patient_id}.")

    def closeEvent(self, event):
        logger.info("Cerrando MainApplicationWindowInternal...")
        if self.ventana_principal_instance:
            self.ventana_principal_instance.close() # Llama al closeEvent de VentanaPrincipal
        super().closeEvent(event)


def main():
    """Función principal para ejecutar la aplicación."""
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True) # Para QMovie y PyOpenGL
    app = QApplication(sys.argv)
    app.setApplicationName("BitnariApp EMG Suite")
    app.setOrganizationName("BitnariTech")

    load_global_stylesheet(app, "estilo_moderno.qss")

    try:
        data_manager = GestorDatos()
    except Exception as e:
        logger.critical(f"No se pudo inicializar GestorDatos: {e}", exc_info=True)
        QMessageBox.critical(None, "Error Crítico", f"Fallo al iniciar el gestor de datos: {e}")
        sys.exit(1)

    controller = MainApplicationController(data_manager)
    controller.start() # Esto mostrará el diálogo de login primero

    # Solo ejecutar app.exec() si el login fue exitoso y main_app_window se creó.
    # El flujo de salida si el login falla o se cancela ya está en _handle_login_failure_or_cancel.
    # Si controller.start() retorna (porque el login falló y llamó a app.quit()),
    # app.exec() no debería ejecutarse o lo haría brevemente.
    
    # Una forma de manejar esto es que _handle_login_failure_or_cancel no llame a app.quit()
    # y que controller.start() retorne un booleano.
    # O, simplemente, si el login falla, la app se cierra desde allí.
    # Si el login tiene éxito, MainApplicationWindowInternal se muestra y app.exec() mantiene la app viva.

    exit_code = app.exec()
    logger.info(f"Aplicación finalizada con código de salida: {exit_code}")
    sys.exit(exit_code)


if __name__ == "__main__":
    main()