"""
emg_processing.py

M�dulo avanzado para el procesamiento de se�ales EMG. Proporciona una clase
EMGProcessingEngine que encapsula diversas t�cnicas de filtrado, extracci�n
de caracter�sticas y an�lisis de se�ales EMG.

Caracter�sticas Principales:
- Encapsulaci�n en Clase: L�gica de procesamiento organizada en EMGProcessingEngine.
- Configuraci�n Flexible de Filtros: Permite habilitar/deshabilitar y configurar
 par�metros para m�ltiples filtros (Pasa-alto, Pasa-bajo, Pasa-banda, Notch,
 Mediana, Savitzky-Golay, Media M�vil, Hilbert, EMD).
- Extracci�n de Caracter�sticas:
   - Dominio del Tiempo: MAV, RMS, IEMG, Varianza, Cruces por Cero.
   - Dominio de la Frecuencia: Potencia Total, Frecuencia Media, Frecuencia Mediana (Welch).
   - Dominio Tiempo-Frecuencia: Frecuencia Dominante, Ancho de Banda, Energ�a Total (STFT).
- Transformadas de Se�al: FFT, Transformada Wavelet (DWT).
- Segmentaci�n de Se�al: Divide la se�al en ventanas para an�lisis localizado.
- Integraci�n Opcional: Puede utilizar instancias de EMGAcquisition y
 EMGCalibrationManager para un flujo de trabajo completo desde la adquisici�n
 hasta el procesamiento.
- Persistencia de Datos: Guarda se�ales procesadas y caracter�sticas a trav�s de
 un DataManager (e.g., GestorDatos).
- Generaci�n de Reportes: Crea un resumen en formato diccionario con caracter�sticas
 y transformadas de las se�ales crudas y procesadas.
- Manejo de M�ltiples Canales: La mayor�a de las funciones est�n dise�adas o adaptadas
 para operar sobre datos multicanal (formato [n_samples, n_channels]).
"""

import os
import json
import logging
from typing import Any, Dict, Optional, Union, List, Tuple
from datetime import datetime

import numpy as np
import scipy.signal as signal
import pywt # Para Wavelet Transform
from pyemd import EMD # Para Empirical Mode Decomposition

# Importaciones de m�dulos del proyecto (asumiendo estructura de carpetas)
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager

# Configuraci�n del logger para este m�dulo
logger = logging.getLogger(__name__)
if not logger.handlers:
   handler = logging.StreamHandler()
   handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
   logger.addHandler(handler)
logger.setLevel(logging.INFO)


class EMGProcessingEngine:
   """
   Motor de procesamiento para se�ales EMG.
   Aplica filtros, extrae caracter�sticas y realiza transformaciones.
   """
   DEFAULT_FILTER_CONFIG = {
       "highpass": {"enabled": True, "cutoff_hz": 20.0, "order": 4},
       "lowpass": {"enabled": True, "cutoff_hz": 450.0, "order": 4},
       # Bandpass se puede lograr combinando highpass y lowpass o usando uno espec�fico.
       # Por simplicidad, aqu� se usan HP y LP separados. Se podr�a a�adir un 'bandpass' expl�cito.
       "notch": {"enabled": True, "freq_hz": 50.0, "quality_factor": 30.0},
       "median": {"enabled": False, "kernel_size": 3}, # Kernel debe ser impar
       "savitzky_golay": {"enabled": False, "window_length": 11, "polyorder": 3}, # Window debe ser impar y > polyorder
       "moving_average": {"enabled": False, "window_size": 5},
       "hilbert_envelope": {"enabled": False}, # Para obtener la envolvente
       "emd_decomposition": {"enabled": False, "num_imfs_to_sum": 3}, # Sumar las primeras N IMFs
       "amplification": {"enabled": False, "factor": 1.0},
       "baseline_correction": {"enabled": True, "method": "mean"}, # 'mean' o 'initial_segment'
       "normalization": {"enabled": False, "method": "min-max"} # 'min-max' o 'z-score'
   }

   def __init__(self,
                sampling_rate: float,
                data_manager: Optional[GestorDatos] = None,
                patient_id: Optional[str] = None):
       """
       Inicializa el motor de procesamiento.

       Args:
           sampling_rate (float): Frecuencia de muestreo de la se�al (Hz).
           data_manager (Optional[GestorDatos]): Instancia para guardar/cargar datos.
           patient_id (Optional[str]): ID del paciente actual.
       """
       if sampling_rate <= 0:
           raise ValueError("La frecuencia de muestreo debe ser positiva.")
       self.sampling_rate = sampling_rate
       self.data_manager = data_manager
       self.patient_id = patient_id
       
       self.filters_config: Dict[str, Any] = self.DEFAULT_FILTER_CONFIG.copy()
       self.last_processed_output: Optional[Dict[str, Any]] = None

       if patient_id and data_manager:
           self.load_processing_config(patient_id)

   def update_sampling_rate(self, new_sampling_rate: float):
       """Actualiza la frecuencia de muestreo."""
       if new_sampling_rate <= 0:
           logger.error("La nueva frecuencia de muestreo debe ser positiva.")
           return
       self.sampling_rate = new_sampling_rate
       logger.info(f"Frecuencia de muestreo actualizada a: {self.sampling_rate} Hz")

   def configure_filter(self, filter_name: str, config: Dict[str, Any]):
       """
       Configura un filtro espec�fico.

       Args:
           filter_name (str): Nombre del filtro (e.g., "highpass", "notch").
           config (Dict[str, Any]): Diccionario con los par�metros del filtro.
                                    Debe incluir "enabled": bool.
       """
       if filter_name in self.filters_config:
           self.filters_config[filter_name].update(config)
           logger.info(f"Configuraci�n del filtro '{filter_name}' actualizada: {self.filters_config[filter_name]}")
       else:
           logger.warning(f"Filtro '{filter_name}' no reconocido.")

   def process_signal(self, raw_signal: np.ndarray, calibration_manager: Optional[EMGCalibrationManager] = None) -> np.ndarray:
       """
       Aplica la cadena de procesamiento completa a la se�al EMG cruda.
       Incluye calibraci�n (si se proporciona y est� habilitada), correcci�n de l�nea base,
       filtrado y normalizaci�n.

       Args:
           raw_signal (np.ndarray): Se�al EMG cruda. Formato: [n_samples, n_channels] o [n_samples] para un solo canal.
           calibration_manager (Optional[EMGCalibrationManager]): Gestor de calibraci�n para aplicar offset/ganancia.

       Returns:
           np.ndarray: Se�al EMG procesada.
       """
       if not isinstance(raw_signal, np.ndarray):
           logger.error("La se�al de entrada debe ser un NumPy array.")
           return np.array([])
       if raw_signal.size == 0:
           logger.warning("Se�al de entrada vac�a, no se procesar�.")
           return np.array([])

       # Asegurar que la se�al sea 2D [n_samples, n_channels]
       processed_signal = raw_signal.copy()
       if processed_signal.ndim == 1:
           processed_signal = processed_signal[:, np.newaxis] # Convertir a [n_samples, 1]

       # 1. Aplicar Calibraci�n (Offset y Ganancia)
       if calibration_manager and calibration_manager.offset_params is not None:
           processed_signal = calibration_manager.apply_calibration(processed_signal)
           logger.debug("Calibraci�n aplicada.")

       # 2. Correcci�n de L�nea Base
       if self.filters_config["baseline_correction"]["enabled"]:
           method = self.filters_config["baseline_correction"]["method"]
           for i in range(processed_signal.shape[1]): # Canal por canal
               if method == "mean":
                   processed_signal[:, i] = processed_signal[:, i] - np.mean(processed_signal[:, i])
               elif method == "initial_segment":
                   # Podr�a tomarse un N configurable, e.g., primeras 100ms
                   n_initial = int(self.sampling_rate * 0.1) 
                   if processed_signal.shape[0] > n_initial:
                       processed_signal[:, i] = processed_signal[:, i] - np.mean(processed_signal[:n_initial, i])
           logger.debug(f"Correcci�n de l�nea base ({method}) aplicada.")

       # 3. Filtrado Secuencial
       # Highpass
       if self.filters_config["highpass"]["enabled"]:
           hp_conf = self.filters_config["highpass"]
           sos_hp = signal.butter(hp_conf["order"], hp_conf["cutoff_hz"], btype='highpass', fs=self.sampling_rate, output='sos')
           processed_signal = signal.sosfiltfilt(sos_hp, processed_signal, axis=0)
           logger.debug("Filtro Pasa-Alto aplicado.")

       # Lowpass
       if self.filters_config["lowpass"]["enabled"]:
           lp_conf = self.filters_config["lowpass"]
           sos_lp = signal.butter(lp_conf["order"], lp_conf["cutoff_hz"], btype='lowpass', fs=self.sampling_rate, output='sos')
           processed_signal = signal.sosfiltfilt(sos_lp, processed_signal, axis=0)
           logger.debug("Filtro Pasa-Bajo aplicado.")
       
       # Notch
       if self.filters_config["notch"]["enabled"]:
           notch_conf = self.filters_config["notch"]
           b_notch, a_notch = signal.iirnotch(notch_conf["freq_hz"], notch_conf["quality_factor"], fs=self.sampling_rate)
           processed_signal = signal.filtfilt(b_notch, a_notch, processed_signal, axis=0)
           logger.debug("Filtro Notch aplicado.")

       # Median Filter
       if self.filters_config["median"]["enabled"]:
           kernel = self.filters_config["median"]["kernel_size"]
           if kernel % 2 == 0: kernel +=1 # Debe ser impar
           processed_signal = signal.medfilt(processed_signal, kernel_size=(kernel, 1) if processed_signal.ndim > 1 else kernel, axis=0)
           logger.debug("Filtro de Mediana aplicado.")

       # Savitzky-Golay
       if self.filters_config["savitzky_golay"]["enabled"]:
           sg_conf = self.filters_config["savitzky_golay"]
           win = sg_conf["window_length"]
           poly = sg_conf["polyorder"]
           if win % 2 == 0: win +=1
           if poly >= win: poly = win -1 ; logger.warning(f"Polyorder ajustado a {poly} para SavGol.")
           if win > 0 and poly > 0:
                processed_signal = signal.savgol_filter(processed_signal, window_length=win, polyorder=poly, axis=0)
                logger.debug("Filtro Savitzky-Golay aplicado.")

       # Moving Average
       if self.filters_config["moving_average"]["enabled"]:
           win_size = self.filters_config["moving_average"]["window_size"]
           if win_size > 0:
               kernel = np.ones(win_size) / win_size
               # Aplicar convoluci�n canal por canal si es multicanal
               for i in range(processed_signal.shape[1]):
                   processed_signal[:, i] = np.convolve(processed_signal[:, i], kernel, mode='same')
               logger.debug("Filtro de Media M�vil aplicado.")

       # Hilbert Envelope
       if self.filters_config["hilbert_envelope"]["enabled"]:
           for i in range(processed_signal.shape[1]):
               analytic_signal = signal.hilbert(processed_signal[:, i])
               processed_signal[:, i] = np.abs(analytic_signal)
           logger.debug("Envolvente de Hilbert aplicada.")

       # EMD Decomposition (sumar primeras N IMFs)
       if self.filters_config["emd_decomposition"]["enabled"]:
           emd_conf = self.filters_config["emd_decomposition"]
           num_imfs = emd_conf["num_imfs_to_sum"]
           reconstructed_signal = np.zeros_like(processed_signal)
           try:
               emd_instance = EMD()
               for i in range(processed_signal.shape[1]):
                   imfs = emd_instance.emd(processed_signal[:, i], max_imf=num_imfs)
                   if imfs.shape[0] >= num_imfs:
                       reconstructed_signal[:, i] = np.sum(imfs[:num_imfs], axis=0)
                   elif imfs.shape[0] > 0 : # Si hay menos IMFs que las solicitadas, sumar todas
                       reconstructed_signal[:, i] = np.sum(imfs, axis=0)
                   # Si no hay IMFs, el canal queda en ceros (ya inicializado)
               processed_signal = reconstructed_signal
               logger.debug(f"Descomposici�n EMD (suma de {num_imfs} IMFs) aplicada.")
           except Exception as e:
               logger.error(f"Error durante EMD: {e}. Se omite este filtro.")


       # 4. Amplificaci�n
       if self.filters_config["amplification"]["enabled"]:
           factor = self.filters_config["amplification"]["factor"]
           processed_signal *= factor
           logger.debug(f"Amplificaci�n (factor {factor}) aplicada.")

       # 5. Normalizaci�n (al final, despu�s de todos los filtros y ajustes)
       if self.filters_config["normalization"]["enabled"]:
           method = self.filters_config["normalization"]["method"]
           for i in range(processed_signal.shape[1]):
               min_val = np.min(processed_signal[:, i])
               max_val = np.max(processed_signal[:, i])
               range_val = max_val - min_val
               
               if method == "min-max":
                   if range_val > 1e-9: # Evitar divisi�n por cero
                       processed_signal[:, i] = (processed_signal[:, i] - min_val) / range_val
                   else: # Si el rango es cero, la se�al es constante, normalizar a 0 o 0.5
                       processed_signal[:, i] = 0.0 
               elif method == "z-score":
                   std_val = np.std(processed_signal[:, i])
                   if std_val > 1e-9: # Evitar divisi�n por cero
                       processed_signal[:, i] = (processed_signal[:, i] - np.mean(processed_signal[:, i])) / std_val
                   else: # Si std es cero, la se�al es constante
                       processed_signal[:, i] = 0.0
           logger.debug(f"Normalizaci�n ({method}) aplicada.")
           
       return processed_signal.squeeze() # Si era 1D originalmente, devolver 1D

   # --- Extracci�n de Caracter�sticas ---
   def extract_temporal_features(self, signal_segment: np.ndarray) -> Dict[str, float]:
       """Extrae caracter�sticas del dominio del tiempo de un segmento de se�al."""
       if signal_segment.size == 0: return {}
       mav = np.mean(np.abs(signal_segment))
       rms = np.sqrt(np.mean(signal_segment**2))
       iemg = np.sum(np.abs(signal_segment))
       variance = np.var(signal_segment)
       # Zero Crossings: necesita un umbral o manejo de ruido
       zc = np.sum(np.diff(np.sign(signal_segment - np.mean(signal_segment))) != 0)
       return {"MAV": mav, "RMS": rms, "IEMG": iemg, "Variance": variance, "ZeroCrossings": float(zc)}

   def extract_frequency_features(self, signal_segment: np.ndarray) -> Dict[str, float]:
       """Extrae caracter�sticas del dominio de la frecuencia."""
       if signal_segment.size == 0: return {}
       # Usar Welch para una estimaci�n m�s robusta del PSD
       freqs, psd = signal.welch(signal_segment, fs=self.sampling_rate, nperseg=min(256, len(signal_segment)))
       if psd.size == 0: return {}

       total_power = np.sum(psd)
       mean_freq = np.sum(freqs * psd) / total_power if total_power > 1e-9 else 0.0
       
       # Frecuencia mediana (MPF)
       cumulative_power = np.cumsum(psd)
       median_freq_idx = np.searchsorted(cumulative_power, total_power / 2.0)
       median_freq = freqs[median_freq_idx] if median_freq_idx < len(freqs) else 0.0
       
       return {"TotalPower": total_power, "MeanFrequency": mean_freq, "MedianFrequency": median_freq}

   def extract_time_frequency_features_stft(self, signal_segment: np.ndarray) -> Dict[str, float]:
       """Extrae caracter�sticas tiempo-frecuencia usando STFT."""
       if signal_segment.size < 128 : # STFT necesita suficientes puntos
           return {"STFT_DominantFreq": 0.0, "STFT_Bandwidth": 0.0, "STFT_Energy": 0.0}

       f, t, Zxx = signal.stft(signal_segment, fs=self.sampling_rate, nperseg=min(128, len(signal_segment)))
       magnitude = np.abs(Zxx)
       
       # Frecuencia dominante promedio sobre el tiempo
       dominant_freqs_per_segment = f[np.argmax(magnitude, axis=0)]
       mean_dominant_freq = np.mean(dominant_freqs_per_segment)
       
       # Ancho de banda (simple, como std de freqs dominantes)
       bandwidth = np.std(dominant_freqs_per_segment)
       
       # Energ�a total en el espectrograma
       total_energy = np.sum(magnitude**2)
       
       return {"STFT_DominantFreq": mean_dominant_freq, "STFT_Bandwidth": bandwidth, "STFT_Energy": total_energy}


   def extract_all_features(self, signal_data: np.ndarray) -> List[Dict[str, float]]:
       """
       Extrae un conjunto completo de caracter�sticas para cada canal de la se�al.
       La se�al se puede segmentar primero si se desea an�lisis por ventanas.
       """
       if signal_data.ndim == 1:
           signal_data = signal_data[:, np.newaxis]
       
       num_channels = signal_data.shape[1]
       all_channel_features: List[Dict[str, float]] = []

       for i in range(num_channels):
           channel_signal = signal_data[:, i]
           features = {}
           features.update(self.extract_temporal_features(channel_signal))
           features.update(self.extract_frequency_features(channel_signal))
           features.update(self.extract_time_frequency_features_stft(channel_signal))
           all_channel_features.append(features)
           
       return all_channel_features

   # --- Transformadas de Se�al ---
   def fourier_transform(self, signal_data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
       """Calcula la Transformada R�pida de Fourier (FFT) de la se�al."""
       if signal_data.ndim > 1 and signal_data.shape[1] > 1:
           logger.warning("FFT se calcular� para el primer canal de datos multicanal.")
           signal_data = signal_data[:, 0]
       elif signal_data.ndim == 0 or signal_data.size == 0:
           return np.array([]), np.array([])

       fft_values = np.fft.rfft(signal_data) # Real FFT
       frequencies = np.fft.rfftfreq(len(signal_data), d=1.0/self.sampling_rate)
       return frequencies, np.abs(fft_values)

   def wavelet_transform(self, signal_data: np.ndarray, wavelet_name: str = 'db4', level: int = 4) -> List[np.ndarray]:
       """Realiza la Transformada Wavelet Discreta (DWT)."""
       if signal_data.ndim > 1 and signal_data.shape[1] > 1:
           logger.warning("Wavelet Transform se calcular� para el primer canal de datos multicanal.")
           signal_data = signal_data[:, 0]
       elif signal_data.ndim == 0 or signal_data.size == 0:
           return []
           
       coeffs = pywt.wavedec(signal_data, wavelet=wavelet_name, level=level)
       return coeffs # Retorna lista de arrays de coeficientes (aprox. y detalles)

   # --- Segmentaci�n ---
   @staticmethod
   def segment_signal(signal_data: np.ndarray, window_length_samples: int, overlap_samples: int = 0) -> List[np.ndarray]:
       """Segmenta la se�al en ventanas."""
       if signal_data.ndim == 1:
           signal_data = signal_data[:, np.newaxis]
       
       num_samples, num_channels = signal_data.shape
       step = window_length_samples - overlap_samples
       
       if step <= 0:
           raise ValueError("El paso (window_length - overlap) debe ser positivo.")
       if window_length_samples > num_samples:
           logger.warning("La longitud de la ventana es mayor que la se�al. Se devolver� la se�al completa como un segmento.")
           return [signal_data]

       segments = []
       for i in range(0, num_samples - window_length_samples + 1, step):
           segments.append(signal_data[i : i + window_length_samples, :])
       
       return segments

   # --- Persistencia y Reportes ---
   def save_processing_config(self, patient_id: str):
       """Guarda la configuraci�n de procesamiento actual para un paciente."""
       if self.data_manager:
           self.data_manager.guardar_datos(patient_id, "processing_config", self.filters_config)
           logger.info(f"Configuraci�n de procesamiento guardada para paciente {patient_id}.")
       else:
           logger.warning("DataManager no configurado. No se puede guardar la configuraci�n.")

   def load_processing_config(self, patient_id: str):
       """Carga la configuraci�n de procesamiento para un paciente."""
       if self.data_manager:
           loaded_config = self.data_manager.cargar_datos(patient_id, "processing_config")
           if loaded_config and isinstance(loaded_config, dict):
               # Validar y fusionar con defaults para asegurar que todas las claves existan
               for key, default_val in self.DEFAULT_FILTER_CONFIG.items():
                   if key in loaded_config:
                       # Asegurar que la estructura interna (e.g. 'enabled') tambi�n se mantenga
                       if isinstance(default_val, dict) and isinstance(loaded_config[key], dict):
                           self.filters_config[key] = {**default_val, **loaded_config[key]}
                       else:
                            self.filters_config[key] = loaded_config[key] # Podr�a ser solo un valor simple
                   else:
                       self.filters_config[key] = default_val # Mantener default si no est� en el archivo
               logger.info(f"Configuraci�n de procesamiento cargada para paciente {patient_id}.")
           else:
               logger.info(f"No se encontr� configuraci�n de procesamiento para {patient_id}. Usando defaults.")
               self.filters_config = self.DEFAULT_FILTER_CONFIG.copy()
       else:
           logger.warning("DataManager no configurado. Usando configuraci�n por defecto.")
           self.filters_config = self.DEFAULT_FILTER_CONFIG.copy()


   def generate_processing_report(self, raw_signal: np.ndarray, processed_signal: np.ndarray) -> Dict[str, Any]:
       """
       Genera un reporte completo del procesamiento.
       """
       report: Dict[str, Any] = {
           "timestamp": datetime.now().isoformat(),
           "sampling_rate_hz": self.sampling_rate,
           "filters_applied_config": {k: v for k, v in self.filters_config.items() if v.get("enabled")},
           "raw_signal_stats": {},
           "processed_signal_stats": {},
           "raw_signal_fft": {},
           "processed_signal_fft": {}
       }

       if raw_signal.ndim == 1: raw_signal_2d = raw_signal[:, np.newaxis]
       else: raw_signal_2d = raw_signal
       if processed_signal.ndim == 1: processed_signal_2d = processed_signal[:, np.newaxis]
       else: processed_signal_2d = processed_signal
       
       num_channels = raw_signal_2d.shape[1]
       
       report["raw_signal_stats"] = self.extract_all_features(raw_signal_2d)
       report["processed_signal_stats"] = self.extract_all_features(processed_signal_2d)

       # FFT para cada canal
       raw_fft_list = []
       proc_fft_list = []
       for i in range(num_channels):
           freq_raw, fft_raw = self.fourier_transform(raw_signal_2d[:,i])
           raw_fft_list.append({"frequencies_hz": freq_raw.tolist(), "amplitudes": fft_raw.tolist()})
           
           freq_proc, fft_proc = self.fourier_transform(processed_signal_2d[:,i])
           proc_fft_list.append({"frequencies_hz": freq_proc.tolist(), "amplitudes": fft_proc.tolist()})
       
       report["raw_signal_fft_per_channel"] = raw_fft_list
       report["processed_signal_fft_per_channel"] = proc_fft_list
       
       self.last_processed_output = report # Guardar el reporte como �ltimo output
       return report

   def save_processed_data(self, patient_id: str, raw_signal: np.ndarray, processed_signal: np.ndarray):
       """Guarda la se�al cruda, procesada y el reporte de procesamiento."""
       if self.data_manager:
           report = self.generate_processing_report(raw_signal, processed_signal)
           data_to_save = {
               "raw_signal_samples": raw_signal.tolist(),
               "processed_signal_samples": processed_signal.tolist(),
               "processing_report": report
           }
           self.data_manager.guardar_datos(patient_id, "processed_emg_session", data_to_save)
           logger.info(f"Datos procesados y reporte guardados para paciente {patient_id}.")
       else:
           logger.warning("DataManager no configurado. No se pueden guardar los datos procesados.")


# Ejemplo de Uso
if __name__ == "__main__":
   # --- Configuraci�n para el ejemplo ---
   FS = 1000  # Hz
   DURATION = 5  # segundos
   N_SAMPLES = FS * DURATION
   N_CHANNELS = 2

   # Crear un GestorDatos dummy para el ejemplo
   class DummyGestorDatos:
       def guardar_datos(self, patient_id: str, data_type: str, data: Dict):
           logger.info(f"[DummyGestor] Guardando para {patient_id}, tipo {data_type}: {list(data.keys())}")
           # Guardar en un archivo JSON para simular persistencia
           os.makedirs(f"temp_data/{patient_id}", exist_ok=True)
           with open(f"temp_data/{patient_id}/{data_type}.json", 'w') as f:
               json.dump(data, f, indent=4)

       def cargar_datos(self, patient_id: str, data_type: str) -> Optional[Dict]:
           logger.info(f"[DummyGestor] Solicitando para {patient_id}, tipo {data_type}")
           try:
               with open(f"temp_data/{patient_id}/{data_type}.json", 'r') as f:
                   return json.load(f)
           except FileNotFoundError:
               return None

   dummy_gestor = DummyGestorDatos() # type: ignore

   # Crear instancia del motor de procesamiento
   engine = EMGProcessingEngine(sampling_rate=FS, data_manager=dummy_gestor, patient_id="patient_example_001")

   # Configurar filtros (ejemplo: habilitar Savitzky-Golay)
   engine.configure_filter("savitzky_golay", {"enabled": True, "window_length": 15, "polyorder": 4})
   engine.configure_filter("normalization", {"enabled": True, "method": "z-score"})
   engine.save_processing_config("patient_example_001") # Guardar esta config

   # Simular se�al EMG cruda (con ruido y offset)
   t = np.linspace(0, DURATION, N_SAMPLES, endpoint=False)
   emg_signal_ch1 = 0.5 * np.sin(2 * np.pi * 7 * t) + 0.2 * np.sin(2 * np.pi * 15 * t) # Actividad muscular
   emg_signal_ch2 = 0.3 * np.sin(2 * np.pi * 10 * t) + 0.1 * np.cos(2 * np.pi * 22 * t)
   
   noise = 0.1 * np.random.randn(N_SAMPLES) # Ruido gaussiano
   power_line_noise = 0.3 * np.sin(2 * np.pi * 50 * t) # Interferencia de 50Hz
   baseline_offset = 0.5
   
   raw_emg_ch1 = emg_signal_ch1 + noise + power_line_noise + baseline_offset
   raw_emg_ch2 = emg_signal_ch2 + noise * 0.8 + power_line_noise * 0.7 + baseline_offset * 0.5
   raw_emg_multichannel = np.vstack((raw_emg_ch1, raw_emg_ch2)).T # Shape: [N_SAMPLES, N_CHANNELS]

   logger.info(f"Forma de la se�al cruda: {raw_emg_multichannel.shape}")

   # Simular un CalibrationManager (opcional)
   # En un caso real, este se habr�a configurado y calibrado previamente.
   class DummyCalibrationManager:
       offset_params = np.array([baseline_offset, baseline_offset * 0.5]) # Offset conocido de la simulaci�n
       gain_params = np.array([1.0, 1.0]) # Ganancia unitaria
       def apply_calibration(self, data):
           return (data - self.offset_params) * self.gain_params
   
   dummy_cal_manager = DummyCalibrationManager()

   # Procesar la se�al
   processed_emg = engine.process_signal(raw_emg_multichannel, calibration_manager=dummy_cal_manager)
   logger.info(f"Forma de la se�al procesada: {processed_emg.shape}")

   # Extraer caracter�sticas de la se�al procesada
   features_per_channel = engine.extract_all_features(processed_emg)
   for i, features_ch in enumerate(features_per_channel):
       logger.info(f"\nCaracter�sticas del Canal {i+1} (Procesado):")
       for name, val in features_ch.items():
           logger.info(f"  {name}: {val:.4f}")

   # Generar y guardar reporte
   engine.save_processed_data("patient_example_001", raw_emg_multichannel, processed_emg)
   logger.info("\nReporte de procesamiento guardado (ver temp_data/patient_example_001/processed_emg_session.json).")

   # Cargar configuraci�n para verificar
   engine_loaded = EMGProcessingEngine(sampling_rate=FS, data_manager=dummy_gestor, patient_id="patient_example_001")
   logger.info(f"\nConfiguraci�n cargada para Savitzky-Golay: {engine_loaded.filters_config['savitzky_golay']}")

   # Ejemplo de segmentaci�n
   segments = engine.segment_signal(processed_emg, window_length_samples=int(FS*0.2), overlap_samples=int(FS*0.1)) # Ventanas de 200ms, solape 100ms
   logger.info(f"\nN�mero de segmentos: {len(segments)}")
   if segments:
       logger.info(f"Forma del primer segmento: {segments[0].shape}")
       # Se podr�an extraer caracter�sticas de cada segmento
       # features_segment0_ch0 = engine.extract_all_features(segments[0][:,0])
       # logger.info(f"Caracter�sticas del primer segmento, canal 0: {features_segment0_ch0}")

   # Limpiar carpeta temporal
   # import shutil
   # if os.path.exists("temp_data"):
   #     shutil.rmtree("temp_data")
   

