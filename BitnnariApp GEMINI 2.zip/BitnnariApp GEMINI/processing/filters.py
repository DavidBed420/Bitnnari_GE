    """
filters.py

M�dulo de utilidades que contiene implementaciones de diversos filtros digitales
com�nmente utilizados en el procesamiento de se�ales biom�dicas, especialmente EMG.
Estas funciones est�n dise�adas para ser robustas y eficientes, utilizando NumPy
y SciPy.
"""
import logging
import numpy as np
import scipy.signal as signal
from typing import Tuple, Optional, Union

logger = logging.getLogger(__name__)

# --- Filtros Pasa-Banda, Pasa-Alto, Pasa-Bajo (Butterworth) ---

def design_butter_filter(cutoff_hz: Union[float, Tuple[float, float]],
                        fs_hz: float,
                        order: int,
                        btype: str) -> Optional[np.ndarray]:
   """
   Dise�a un filtro Butterworth digital (devuelve coeficientes SOS).

   Args:
       cutoff_hz (Union[float, Tuple[float, float]]): Frecuencia(s) de corte en Hz.
           - Para 'lowpass' o 'highpass', es un float.
           - Para 'bandpass' o 'bandstop', es una tupla (lowcut, highcut).
       fs_hz (float): Frecuencia de muestreo en Hz.
       order (int): Orden del filtro.
       btype (str): Tipo de filtro: 'lowpass', 'highpass', 'bandpass', 'bandstop'.

   Returns:
       Optional[np.ndarray]: Coeficientes del filtro en formato Second-Order Sections (SOS),
                             o None si los par�metros son inv�lidos.
   """
   if fs_hz <= 0:
       logger.error("La frecuencia de muestreo (fs_hz) debe ser positiva.")
       return None
   if order <= 0:
       logger.error("El orden del filtro debe ser positivo.")
       return None

   nyquist_hz = 0.5 * fs_hz
   
   if btype in ['lowpass', 'highpass']:
       if not isinstance(cutoff_hz, (int, float)) or cutoff_hz <= 0 or cutoff_hz >= nyquist_hz:
           logger.error(f"Frecuencia de corte inv�lida ({cutoff_hz} Hz) para filtro {btype} "
                        f"con Nyquist a {nyquist_hz} Hz.")
           return None
       normalized_cutoff = cutoff_hz / nyquist_hz
   elif btype in ['bandpass', 'bandstop']:
       if not (isinstance(cutoff_hz, (list, tuple)) and len(cutoff_hz) == 2):
           logger.error(f"Frecuencias de corte para {btype} deben ser una tupla/lista de dos elementos.")
           return None
       lowcut, highcut = cutoff_hz
       if not (0 < lowcut < highcut < nyquist_hz):
           logger.error(f"Frecuencias de corte de banda inv�lidas ({lowcut}, {highcut} Hz) "
                        f"para filtro {btype} con Nyquist a {nyquist_hz} Hz.")
           return None
       normalized_cutoff = [lowcut / nyquist_hz, highcut / nyquist_hz]
   else:
       logger.error(f"Tipo de filtro '{btype}' no soportado.")
       return None

   try:
       sos = signal.butter(order, normalized_cutoff, btype=btype, analog=False, output='sos')
       return sos
   except ValueError as e:
       logger.error(f"Error al dise�ar el filtro Butterworth ({btype}, orden {order}, corte {cutoff_hz}, fs {fs_hz}): {e}")
       return None

def apply_sos_filter(sos_coeffs: np.ndarray,
                    data: np.ndarray,
                    axis: int = 0,
                    zi: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Optional[np.ndarray]]:
   """
   Aplica un filtro digital (dado por coeficientes SOS) a los datos.
   Utiliza sosfiltfilt para procesamiento sin retardo de fase, o sosfilt
   si se proporcionan condiciones iniciales (zi) para procesamiento en tiempo real.

   Args:
       sos_coeffs (np.ndarray): Coeficientes del filtro en formato SOS.
       data (np.ndarray): Array de datos de entrada. Puede ser 1D o 2D.
                          Si es 2D, el filtro se aplica a lo largo de `axis`.
       axis (int): Eje a lo largo del cual aplicar el filtro si `data` es multidimensional.
       zi (Optional[np.ndarray]): Condiciones iniciales para sosfilt (para filtrado en tiempo real).
                                  Si es None, se usa sosfiltfilt.

   Returns:
       Tuple[np.ndarray, Optional[np.ndarray]]:
           - Datos filtrados.
           - Estado final del filtro (zf) si se us� sosfilt, sino None.
   """
   if data.size == 0:
       return data, zi

   if zi is not None:
       # Filtrado causal para tiempo real
       filtered_data, zf = signal.sosfilt(sos_coeffs, data, axis=axis, zi=zi)
       return filtered_data, zf
   else:
       # Filtrado no causal (sin retardo de fase)
       filtered_data = signal.sosfiltfilt(sos_coeffs, data, axis=axis)
       return filtered_data, None

# --- Filtro Notch (IIR) ---

def design_notch_filter(notch_freq_hz: float,
                       quality_factor: float,
                       fs_hz: float) -> Optional[Tuple[np.ndarray, np.ndarray]]:
   """
   Dise�a un filtro Notch IIR para eliminar una frecuencia espec�fica.

   Args:
       notch_freq_hz (float): Frecuencia a eliminar en Hz.
       quality_factor (float): Factor de calidad Q (define el ancho de banda del notch).
                                Q = notch_freq_hz / bandwidth_hz.
       fs_hz (float): Frecuencia de muestreo en Hz.

   Returns:
       Optional[Tuple[np.ndarray, np.ndarray]]: Coeficientes del filtro (b, a), o None si error.
   """
   if fs_hz <= 0 or notch_freq_hz <= 0 or notch_freq_hz >= fs_hz / 2 or quality_factor <= 0:
       logger.error(f"Par�metros inv�lidos para filtro Notch: f0={notch_freq_hz}, Q={quality_factor}, fs={fs_hz}")
       return None
   try:
       b, a = signal.iirnotch(notch_freq_hz, quality_factor, fs=fs_hz)
       return b, a
   except ValueError as e:
       logger.error(f"Error al dise�ar el filtro Notch: {e}")
       return None

def apply_iir_filter(b_coeffs: np.ndarray, a_coeffs: np.ndarray,
                    data: np.ndarray,
                    axis: int = 0,
                    zi: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Optional[np.ndarray]]:
   """
   Aplica un filtro IIR digital (dado por coeficientes b, a) a los datos.
   Utiliza filtfilt para procesamiento sin retardo de fase, o lfilter
   si se proporcionan condiciones iniciales (zi) para procesamiento en tiempo real.

   Args:
       b_coeffs (np.ndarray): Coeficientes del numerador del filtro IIR.
       a_coeffs (np.ndarray): Coeficientes del denominador del filtro IIR.
       data (np.ndarray): Array de datos de entrada.
       axis (int): Eje a lo largo del cual aplicar el filtro.
       zi (Optional[np.ndarray]): Condiciones iniciales para lfilter.

   Returns:
       Tuple[np.ndarray, Optional[np.ndarray]]:
           - Datos filtrados.
           - Estado final del filtro (zf) si se us� lfilter, sino None.
   """
   if data.size == 0:
       return data, zi

   if zi is not None:
       filtered_data, zf = signal.lfilter(b_coeffs, a_coeffs, data, axis=axis, zi=zi)
       return filtered_data, zf
   else:
       filtered_data = signal.filtfilt(b_coeffs, a_coeffs, data, axis=axis)
       return filtered_data, None

# --- Filtros de Suavizado ---

def savitzky_golay_filter(data: np.ndarray,
                         window_length: int,
                         polyorder: int,
                         axis: int = 0,
                         **kwargs) -> np.ndarray:
   """
   Aplica un filtro Savitzky-Golay para suavizar la se�al.

   Args:
       data (np.ndarray): Array de datos de entrada.
       window_length (int): Longitud de la ventana del filtro (debe ser impar y > polyorder).
       polyorder (int): Orden del polinomio usado para ajustar las muestras.
       axis (int): Eje a lo largo del cual aplicar el filtro.
       **kwargs: Argumentos adicionales para scipy.signal.savgol_filter.

   Returns:
       np.ndarray: Datos suavizados.
   """
   if data.size == 0:
       return data
   if window_length <= 0 or polyorder < 0:
       logger.error("window_length y polyorder deben ser positivos.")
       return data
   if window_length % 2 == 0:
       window_length += 1 # Asegurar que sea impar
       logger.debug(f"Ajustando window_length de Savitzky-Golay a impar: {window_length}")
   if polyorder >= window_length:
       polyorder = window_length - 1
       if polyorder < 0: # Si window_length era 1
           logger.error("window_length demasiado peque�a para Savitzky-Golay.")
           return data
       logger.warning(f"Ajustando polyorder de Savitzky-Golay a {polyorder} (debe ser < window_length).")
   
   if data.shape[axis] < window_length:
       logger.warning(f"Longitud de los datos en el eje {axis} ({data.shape[axis]}) es menor que "
                      f"window_length ({window_length}). El filtro Savitzky-Golay podr�a no ser efectivo o fallar.")
       # Podr�amos devolver los datos sin filtrar o ajustar window_length,
       # pero scipy.signal.savgol_filter puede manejarlo internamente o lanzar un error claro.
       # Si data.shape[axis] es muy peque�o, el filtro no tiene sentido.
       if data.shape[axis] <= polyorder: # Condici�n de error de SciPy
            logger.error("Datos insuficientes para el orden del polinomio y la longitud de la ventana en Savitzky-Golay.")
            return data


   try:
       return signal.savgol_filter(data, window_length, polyorder, axis=axis, **kwargs)
   except ValueError as e:
       logger.error(f"Error aplicando filtro Savitzky-Golay: {e}. Datos originales devueltos.")
       return data

def moving_average_filter(data: np.ndarray,
                         window_size: int,
                         axis: int = 0,
                         mode: str = 'same') -> np.ndarray:
   """
   Aplica un filtro de media m�vil.

   Args:
       data (np.ndarray): Array de datos de entrada.
       window_size (int): Tama�o de la ventana de la media m�vil.
       axis (int): Eje a lo largo del cual aplicar el filtro.
       mode (str): Modo de la convoluci�n (e.g., 'valid', 'same', 'full').

   Returns:
       np.ndarray: Datos suavizados.
   """
   if data.size == 0 or window_size <= 0:
       return data
   if data.shape[axis] < window_size and mode == 'valid':
       logger.warning(f"Longitud de los datos en el eje {axis} ({data.shape[axis]}) es menor que "
                      f"window_size ({window_size}) para media m�vil con modo 'valid'. Se devolver� un array vac�o.")
       # Devolver un array vac�o de la forma correcta o los datos originales
       if data.ndim == 1: return np.array([])
       shape_out = list(data.shape)
       shape_out[axis] = 0
       return np.empty(tuple(shape_out))


   kernel = np.ones(window_size) / window_size
   
   # Para aplicar a lo largo de un eje en datos N-D, necesitamos np.apply_along_axis
   # o una convoluci�n N-D si el kernel es apropiado.
   # np.convolve es para 1D.
   if data.ndim > 1:
       return np.apply_along_axis(lambda m: np.convolve(m, kernel, mode=mode), axis=axis, arr=data)
   else:
       return np.convolve(data, kernel, mode=mode)

# --- Otros Filtros ---
def median_filter(data: np.ndarray, kernel_size: int, axis: int = 0) -> np.ndarray:
   """
   Aplica un filtro de mediana.

   Args:
       data (np.ndarray): Array de datos de entrada.
       kernel_size (int): Tama�o del kernel (debe ser impar).
       axis (int): Eje a lo largo del cual aplicar el filtro (no usado por signal.medfilt para N-D).

   Returns:
       np.ndarray: Datos filtrados.
   """
   if data.size == 0 or kernel_size <= 0:
       return data
   if kernel_size % 2 == 0:
       kernel_size += 1
       logger.debug(f"Ajustando kernel_size de filtro de mediana a impar: {kernel_size}")

   # scipy.signal.medfilt toma un kernel_size que puede ser una tupla para N-D
   # Si data es [samples, channels] y queremos filtrar a lo largo del tiempo (axis 0):
   if data.ndim > 1 and axis == 0:
       kernel_shape = [1] * data.ndim
       kernel_shape[0] = kernel_size
       return signal.medfilt(data, kernel_size=tuple(kernel_shape))
   elif data.ndim > 1 and axis != 0:
       # Si se quiere filtrar a lo largo de otro eje, se necesita un manejo m�s espec�fico
       # o transponer, filtrar y transponer de vuelta.
       logger.warning(f"Filtro de mediana para axis != 0 en datos N-D no implementado directamente, "
                      f"se aplicar� a lo largo de todas las dimensiones con kernel {kernel_size}.")
       return signal.medfilt(data, kernel_size=kernel_size) # Aplica a todas las dimensiones
   else: # 1D data
       return signal.medfilt(data, kernel_size=kernel_size)


if __name__ == "__main__":
   logger.setLevel(logging.DEBUG) # Mostrar todos los logs para el ejemplo
   # Ejemplo de uso de los filtros
   fs = 1000.0  # Frecuencia de muestreo
   duration = 1.0  # segundos
   t = np.linspace(0, duration, int(fs * duration), endpoint=False)

   # Crear una se�al de prueba con varios componentes de frecuencia y ruido
   sig_5hz = 0.7 * np.sin(2 * np.pi * 5 * t)    # Se�al de baja frecuencia (ruido de movimiento)
   sig_30hz = 1.0 * np.sin(2 * np.pi * 30 * t)   # Componente EMG
   sig_100hz = 0.5 * np.sin(2 * np.pi * 100 * t) # Componente EMG
   sig_50hz_noise = 0.8 * np.sin(2 * np.pi * 50 * t) # Ruido de l�nea el�ctrica
   white_noise = 0.3 * np.random.normal(size=t.shape) # Ruido blanco
   
   test_signal_1d = sig_5hz + sig_30hz + sig_100hz + sig_50hz_noise + white_noise + 1.0 # Con offset DC

   # --- Butterworth Pasa-Banda ---
   sos_bp = design_butter_filter(cutoff_hz=(20.0, 200.0), fs_hz=fs, order=4, btype='bandpass')
   if sos_bp is not None:
       filtered_bp, _ = apply_sos_filter(sos_bp, test_signal_1d)
       logger.info(f"Filtro Pasa-Banda aplicado. Longitud original: {len(test_signal_1d)}, filtrada: {len(filtered_bp)}")

   # --- Filtro Notch ---
   coeffs_notch = design_notch_filter(notch_freq_hz=50.0, quality_factor=30.0, fs_hz=fs)
   if coeffs_notch is not None:
       b_notch, a_notch = coeffs_notch
       filtered_notch, _ = apply_iir_filter(b_notch, a_notch, test_signal_1d)
       logger.info(f"Filtro Notch aplicado. Longitud original: {len(test_signal_1d)}, filtrada: {len(filtered_notch)}")

   # --- Filtro Savitzky-Golay ---
   filtered_savgol = savitzky_golay_filter(test_signal_1d, window_length=31, polyorder=3)
   logger.info(f"Filtro Savitzky-Golay aplicado. Longitud original: {len(test_signal_1d)}, filtrada: {len(filtered_savgol)}")

   # --- Filtro Media M�vil ---
   # Usar 'same' para mantener la longitud, o 'valid' para reducirla
   filtered_ma = moving_average_filter(test_signal_1d, window_size=11, mode='same')
   logger.info(f"Filtro Media M�vil ('same') aplicado. Longitud original: {len(test_signal_1d)}, filtrada: {len(filtered_ma)}")

   # --- Filtro de Mediana ---
   filtered_median = median_filter(test_signal_1d, kernel_size=5)
   logger.info(f"Filtro de Mediana aplicado. Longitud original: {len(test_signal_1d)}, filtrada: {len(filtered_median)}")

   # Visualizaci�n (opcional, requiere matplotlib)
   try:
       import matplotlib.pyplot as plt
       plt.figure(figsize=(12, 8))
       plt.subplot(3,1,1)
       plt.plot(t, test_signal_1d, label='Original')
       if sos_bp is not None: plt.plot(t, filtered_bp, label='Pasa-Banda (20-200Hz)')
       plt.legend()
       plt.title("Filtro Pasa-Banda")

       plt.subplot(3,1,2)
       plt.plot(t, test_signal_1d, label='Original')
       if coeffs_notch is not None: plt.plot(t, filtered_notch, label='Notch (50Hz)')
       plt.legend()
       plt.title("Filtro Notch")

       plt.subplot(3,1,3)
       plt.plot(t, test_signal_1d, label='Original')
       plt.plot(t, filtered_savgol, label='Savitzky-Golay (w=31, p=3)')
       plt.plot(t, filtered_ma, label='Media M�vil (w=11, same)')
       plt.plot(t, filtered_median, label='Mediana (k=5)')
       plt.legend()
       plt.title("Filtros de Suavizado")
       
       plt.tight_layout()
       plt.show()
   except ImportError:
       logger.info("Matplotlib no instalado. No se mostrar�n gr�ficos de ejemplo.")
   


