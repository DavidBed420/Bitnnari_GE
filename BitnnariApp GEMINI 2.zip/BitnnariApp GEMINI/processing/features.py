"""
features.py

M�dulo de utilidades para la extracci�n de caracter�sticas de se�ales EMG.
Estas caracter�sticas son fundamentales para el posterior an�lisis y clasificaci�n
de los patrones de actividad muscular.

Incluye caracter�sticas en el dominio del tiempo, frecuencia y tiempo-frecuencia.
"""
import logging
import numpy as np
import scipy.signal as signal
from scipy.stats import skew, kurtosis
import pywt # Para Wavelet Packet Transform y entrop�a
from typing import List, Dict, Tuple, Optional, Union

logger = logging.getLogger(__name__)

# --- Caracter�sticas en el Dominio del Tiempo ---

def mean_absolute_value(segment: np.ndarray) -> float:
   """Mean Absolute Value (MAV) o Integral Absoluta Promediada (IEMG / N)."""
   if segment.size == 0: return 0.0
   return float(np.mean(np.abs(segment)))

def root_mean_square(segment: np.ndarray) -> float:
   """Root Mean Square (RMS)."""
   if segment.size == 0: return 0.0
   return float(np.sqrt(np.mean(segment**2)))

def variance(segment: np.ndarray) -> float:
   """Variance of EMG (VAR)."""
   if segment.size == 0: return 0.0
   return float(np.var(segment))

def standard_deviation(segment: np.ndarray) -> float:
   """Standard Deviation (STD)."""
   if segment.size == 0: return 0.0
   return float(np.std(segment))

def waveform_length(segment: np.ndarray) -> float:
   """Waveform Length (WL) o Longitud de Onda."""
   if segment.size < 2: return 0.0
   return float(np.sum(np.abs(np.diff(segment))))

def zero_crossings(segment: np.ndarray, threshold: float = 0.0) -> int:
   """Zero Crossings (ZC). Cuenta cu�ntas veces la se�al cruza el cero (o un umbral)."""
   if segment.size < 2: return 0
   # Considerar cruce si el signo cambia y al menos uno de los puntos supera el umbral en magnitud
   # para evitar contar cruces por ruido muy cercano a cero.
   # Un cruce ocurre entre s[i] y s[i+1] si s[i]*s[i+1] < 0
   # y (|s[i]| > threshold o |s[i+1]| > threshold)
   
   # M�todo simple:
   # return int(np.sum(np.diff(np.sign(segment)) != 0))

   # M�todo m�s robusto con umbral:
   zc_count = 0
   for i in range(len(segment) - 1):
       if (segment[i] * segment[i+1] < 0) and \
          (np.abs(segment[i]) > threshold or np.abs(segment[i+1]) > threshold):
           zc_count += 1
   return zc_count

def slope_sign_changes(segment: np.ndarray, threshold: float = 0.0) -> int:
   """Slope Sign Changes (SSC). Cuenta cambios en el signo de la pendiente."""
   if segment.size < 3: return 0
   diff1 = np.diff(segment)
   # Un cambio de signo en la pendiente ocurre si diff1[i] * diff1[i+1] < 0
   # y la magnitud del cambio de pendiente (o de las pendientes) supera un umbral
   ssc_count = 0
   for i in range(len(diff1) - 1):
       # Condici�n de cambio de signo
       if diff1[i] * diff1[i+1] < 0:
           # Condici�n de umbral para evitar ruido: el cambio debe ser significativo
           # Se puede basar en la magnitud de las pendientes o la diferencia entre ellas.
           # Aqu�, que al menos una de las pendientes sea significativa.
           if np.abs(diff1[i]) > threshold or np.abs(diff1[i+1]) > threshold:
               ssc_count += 1
   return ssc_count

def willison_amplitude(segment: np.ndarray, threshold: float = 0.01) -> int:
   """Willison Amplitude (WAMP). N�mero de veces que el cambio en amplitud excede un umbral."""
   if segment.size < 2: return 0
   diff_abs = np.abs(np.diff(segment))
   return int(np.sum(diff_abs > threshold))

def integrated_emg(segment: np.ndarray) -> float:
   """Integrated EMG (IEMG) - Suma de los valores absolutos."""
   if segment.size == 0: return 0.0
   return float(np.sum(np.abs(segment)))

def skewness(segment: np.ndarray) -> float:
   """Skewness - Asimetr�a de la distribuci�n de la se�al."""
   if segment.size < 3: return 0.0 # skew requiere al menos 3 puntos para std no cero
   return float(skew(segment))

def kurt(segment: np.ndarray) -> float:
   """Kurtosis - Curtosis de la distribuci�n de la se�al."""
   if segment.size < 4: return 0.0 # kurtosis requiere al menos 4 puntos
   return float(kurtosis(segment))

def hjorth_parameters(segment: np.ndarray) -> Tuple[float, float, float]:
   """
   Calcula los par�metros de Hjorth: Actividad, Movilidad y Complejidad.
   Activity = varianza de la se�al.
   Mobility = std(derivada) / std(se�al).
   Complexity = (std(2da derivada) / std(derivada)) / Mobility.
   """
   if segment.size < 3: return (0.0, 0.0, 0.0)

   activity = np.var(segment)
   
   diff1 = np.diff(segment)
   if diff1.size < 2: return (activity, 0.0, 0.0)
   std_diff1 = np.std(diff1)
   std_signal = np.std(segment)
   mobility = std_diff1 / (std_signal + 1e-9) # Evitar divisi�n por cero

   diff2 = np.diff(diff1)
   if diff2.size < 2: return (activity, mobility, 0.0)
   std_diff2 = np.std(diff2)
   mobility_of_diff1 = std_diff2 / (std_diff1 + 1e-9)
   complexity = mobility_of_diff1 / (mobility + 1e-9)
   
   return float(activity), float(mobility), float(complexity)


# --- Caracter�sticas en el Dominio de la Frecuencia ---

def mean_frequency(segment: np.ndarray, fs: float) -> float:
   """Mean Frequency (MNF) - Frecuencia media del espectro de potencia."""
   if segment.size < 2 or fs <= 0: return 0.0
   freqs, psd = signal.welch(segment, fs=fs, nperseg=min(256, len(segment)))
   if psd.sum() < 1e-9: return 0.0
   return float(np.sum(freqs * psd) / np.sum(psd))

def median_frequency(segment: np.ndarray, fs: float) -> float:
   """Median Frequency (MDF) - Frecuencia que divide el espectro de potencia en dos mitades iguales."""
   if segment.size < 2 or fs <= 0: return 0.0
   freqs, psd = signal.welch(segment, fs=fs, nperseg=min(256, len(segment)))
   if psd.sum() < 1e-9: return 0.0
   cumulative_power = np.cumsum(psd)
   median_freq_idx = np.searchsorted(cumulative_power, cumulative_power[-1] / 2.0)
   if median_freq_idx >= len(freqs): # En caso de que sea el �ltimo �ndice
       return float(freqs[-1])
   return float(freqs[median_freq_idx])

def peak_frequency(segment: np.ndarray, fs: float) -> float:
   """Peak Frequency (PKF) - Frecuencia con la mayor potencia en el espectro."""
   if segment.size < 2 or fs <= 0: return 0.0
   freqs, psd = signal.welch(segment, fs=fs, nperseg=min(256, len(segment)))
   if psd.size == 0: return 0.0
   return float(freqs[np.argmax(psd)])

def total_power(segment: np.ndarray, fs: float) -> float:
   """Total Power (TTP) - Potencia total del espectro."""
   if segment.size < 2 or fs <= 0: return 0.0
   _, psd = signal.welch(segment, fs=fs, nperseg=min(256, len(segment)))
   return float(np.sum(psd))

def spectral_moment(segment: np.ndarray, fs: float, order: int) -> float:
   """Calcula el momento espectral de un orden dado."""
   if segment.size < 2 or fs <= 0: return 0.0
   freqs, psd = signal.welch(segment, fs=fs, nperseg=min(256, len(segment)))
   if psd.sum() < 1e-9: return 0.0
   return float(np.sum((freqs**order) * psd) / np.sum(psd))

# --- Caracter�sticas en el Dominio Tiempo-Frecuencia (Wavelet) ---

def wavelet_energy(segment: np.ndarray, wavelet_name: str = 'db4', level: Optional[int] = None) -> List[float]:
   """
   Calcula la energ�a de los coeficientes de detalle de la Transformada Wavelet Discreta.
   Si level es None, se calcula el m�ximo nivel posible.
   """
   if segment.size == 0: return []
   
   max_level = pywt.dwt_max_level(len(segment), pywt.Wavelet(wavelet_name).dec_len)
   if max_level == 0: # No se puede descomponer
       return [np.sum(segment**2)] # Energ�a de la se�al original

   current_level = level if (level is not None and level <= max_level) else max_level
   if current_level == 0: # No descomponer si el nivel es 0
        return [np.sum(segment**2)]

   coeffs = pywt.wavedec(segment, wavelet=wavelet_name, level=current_level)
   # Energ�a de los coeficientes de detalle (cD_level, cD_level-1, ..., cD1) y el de aproximaci�n (cA_level)
   # coeffs[0] es cA_level, coeffs[1] es cD_level, ..., coeffs[current_level] es cD1
   energies = [float(np.sum(np.square(c))) for c in coeffs if c is not None and c.size > 0]
   return energies

def wavelet_entropy(segment: np.ndarray, wavelet_name: str = 'db4', level: Optional[int] = None,
                   entropy_type: str = 'shannon') -> float:
   """
   Calcula la entrop�a de los coeficientes de la Transformada Wavelet.
   """
   if segment.size == 0: return 0.0

   max_level = pywt.dwt_max_level(len(segment), pywt.Wavelet(wavelet_name).dec_len)
   if max_level == 0: return 0.0

   current_level = level if (level is not None and level <= max_level) else max_level
   if current_level == 0: return 0.0
   
   coeffs = pywt.wavedec(segment, wavelet=wavelet_name, level=current_level)
   # Concatenar todos los coeficientes para calcular la entrop�a sobre su distribuci�n
   all_coeffs_flat = np.concatenate([c.flatten() for c in coeffs if c is not None and c.size > 0])
   if all_coeffs_flat.size == 0: return 0.0

   # Calcular la distribuci�n de probabilidad (histograma normalizado)
   prob_dist, _ = np.histogram(all_coeffs_flat, bins='auto', density=True)
   prob_dist = prob_dist[prob_dist > 0] # Solo probabilidades no nulas

   if entropy_type == 'shannon':
       return float(-np.sum(prob_dist * np.log2(prob_dist)))
   # Se pueden a�adir otros tipos de entrop�a (e.g., log_energy)
   else:
       logger.warning(f"Tipo de entrop�a '{entropy_type}' no soportado. Usando Shannon.")
       return float(-np.sum(prob_dist * np.log2(prob_dist)))

# --- Funci�n Agregadora ---

def extract_all_features_single_channel(segment: np.ndarray, fs: float,
                                       zc_threshold: float = 0.01,
                                       ssc_threshold: float = 0.01,
                                       wamp_threshold: float = 0.02,
                                       wavelet_name: str = 'db4',
                                       wavelet_level: Optional[int] = None) -> Dict[str, float]:
   """
   Extrae un conjunto completo de caracter�sticas para un �nico segmento de se�al (un canal).
   """
   if not isinstance(segment, np.ndarray) or segment.ndim != 1:
       raise ValueError("La entrada 'segment' debe ser un array NumPy 1D.")
   if segment.size < 4: # M�nimo para algunas features como kurtosis o Hjorth
       logger.warning(f"Segmento demasiado corto ({segment.size} muestras) para extraer todas las features. Se devolver�n ceros para algunas.")
       # Devolver un diccionario con ceros para mantener la estructura
       # Esto es una simplificaci�n, se podr�a ser m�s granular.
       feature_names = [
           "MAV", "RMS", "VAR", "STD", "WL", "ZC", "SSC", "WAMP", "IEMG", "Skewness", "Kurtosis",
           "HjorthActivity", "HjorthMobility", "HjorthComplexity",
           "MNF", "MDF", "PKF", "TTP", "SpectralMoment0", "SpectralMoment1", "SpectralMoment2",
           "WaveletEntropy"
       ]
       # A�adir nombres para energ�as wavelet (depende del nivel)
       max_lvl = pywt.dwt_max_level(len(segment), pywt.Wavelet(wavelet_name).dec_len) if len(segment) > pywt.Wavelet(wavelet_name).dec_len else 0
       lvl = wavelet_level if wavelet_level is not None and wavelet_level <= max_lvl else max_lvl
       if lvl > 0 : feature_names.extend([f"WaveletEnergy_L{i}" for i in range(lvl + 1)])
       else: feature_names.append("WaveletEnergy_L0")

       return {name: 0.0 for name in feature_names}


   features: Dict[str, float] = {}
   
   # Dominio del Tiempo
   features["MAV"] = mean_absolute_value(segment)
   features["RMS"] = root_mean_square(segment)
   features["VAR"] = variance(segment)
   features["STD"] = standard_deviation(segment)
   features["WL"] = waveform_length(segment)
   features["ZC"] = float(zero_crossings(segment, threshold=zc_threshold * features["RMS"])) # Umbral relativo al RMS
   features["SSC"] = float(slope_sign_changes(segment, threshold=ssc_threshold * features["RMS"]))
   features["WAMP"] = float(willison_amplitude(segment, threshold=wamp_threshold * features["RMS"]))
   features["IEMG"] = integrated_emg(segment)
   features["Skewness"] = skewness(segment)
   features["Kurtosis"] = kurt(segment)
   
   hj_act, hj_mob, hj_com = hjorth_parameters(segment)
   features["HjorthActivity"] = hj_act
   features["HjorthMobility"] = hj_mob
   features["HjorthComplexity"] = hj_com

   # Dominio de la Frecuencia
   features["MNF"] = mean_frequency(segment, fs)
   features["MDF"] = median_frequency(segment, fs)
   features["PKF"] = peak_frequency(segment, fs)
   features["TTP"] = total_power(segment, fs)
   features["SpectralMoment0"] = spectral_moment(segment, fs, order=0) # Similar a TTP
   features["SpectralMoment1"] = spectral_moment(segment, fs, order=1) # Similar a MNF * TTP
   features["SpectralMoment2"] = spectral_moment(segment, fs, order=2)

   # Dominio Tiempo-Frecuencia (Wavelet)
   energies = wavelet_energy(segment, wavelet_name=wavelet_name, level=wavelet_level)
   for i, energy_val in enumerate(energies):
       features[f"WaveletEnergy_L{i}"] = energy_val # L0 es aprox, L1..LN son detalles
   
   features["WaveletEntropy"] = wavelet_entropy(segment, wavelet_name=wavelet_name, level=wavelet_level)
   
   return features

def extract_features_multichannel(signal_data: np.ndarray, fs: float, **kwargs) -> List[Dict[str, float]]:
   """
   Extrae caracter�sticas para cada canal de una se�al multicanal.

   Args:
       signal_data (np.ndarray): Datos EMG, forma [n_samples, n_channels] o [n_channels, n_samples].
                                 Se intentar� determinar la orientaci�n.
       fs (float): Frecuencia de muestreo.
       **kwargs: Argumentos adicionales para `extract_all_features_single_channel`.

   Returns:
       List[Dict[str, float]]: Lista de diccionarios, uno por canal.
   """
   if not isinstance(signal_data, np.ndarray):
       raise ValueError("La entrada 'signal_data' debe ser un array NumPy.")
   
   if signal_data.ndim == 1: # Asumir un solo canal
       logger.debug("Datos 1D recibidos, tratando como un solo canal.")
       return [extract_all_features_single_channel(signal_data, fs, **kwargs)]
   elif signal_data.ndim == 2:
       # Heur�stica para determinar orientaci�n: si n_samples >> n_channels, asumir [n_samples, n_channels]
       n_dim0, n_dim1 = signal_data.shape
       if n_dim0 > n_dim1 * 5: # Probablemente [n_samples, n_channels]
           data_oriented = signal_data.T # Transponer a [n_channels, n_samples]
       elif n_dim1 > n_dim0 * 5: # Probablemente [n_channels, n_samples]
           data_oriented = signal_data
       else: # Ambiguo, intentar asumir [n_channels, n_samples] si n_dim0 es peque�o (<=16)
             # o [n_samples, n_channels] si n_dim1 es peque�o.
           if n_dim0 <= 16 : # Max canales t�picos
               logger.debug(f"Forma ambigua {signal_data.shape}, asumiendo [n_channels, n_samples].")
               data_oriented = signal_data
           elif n_dim1 <= 16:
               logger.debug(f"Forma ambigua {signal_data.shape}, asumiendo [n_samples, n_channels], se transpondr�.")
               data_oriented = signal_data.T
           else: # No se puede determinar con certeza
               logger.warning(f"Orientaci�n de datos multicanal ambigua ({signal_data.shape}). "
                              "Asumiendo [canales, muestras]. Si es incorrecto, transponga los datos primero.")
               data_oriented = signal_data # Asumir [canales, muestras] como fallback

       all_features = []
       for i in range(data_oriented.shape[0]): # Iterar sobre canales
           channel_segment = data_oriented[i, :]
           all_features.append(extract_all_features_single_channel(channel_segment, fs, **kwargs))
       return all_features
   else:
       raise ValueError("La entrada 'signal_data' debe ser un array NumPy 1D o 2D.")


if __name__ == "__main__":
   logger.setLevel(logging.DEBUG)
   # Ejemplo de uso con una se�al simulada
   fs_hz = 1000.0
   duration_sec = 0.5
   num_samples = int(fs_hz * duration_sec)
   t_ax = np.linspace(0, duration_sec, num_samples, endpoint=False)

   # Se�al con varios componentes
   signal_ch1 = (
       1.5 * np.sin(2 * np.pi * 10 * t_ax) +    # Componente de 10 Hz
       0.8 * np.sin(2 * np.pi * 30 * t_ax) +    # Componente de 30 Hz
       0.5 * np.sin(2 * np.pi * 150 * t_ax) +   # Componente de 150 Hz
       0.4 * np.random.randn(num_samples) +     # Ruido
       0.6 * np.sin(2 * np.pi * 50 * t_ax)      # Ruido de l�nea
   )
   signal_ch2 = (
       1.0 * np.sin(2 * np.pi * 15 * t_ax + np.pi/4) +
       0.5 * np.random.randn(num_samples) +
       0.5 * np.sin(2 * np.pi * 50 * t_ax)
   )
   
   # Probar con un solo canal
   logger.info("--- Caracter�sticas para Canal �nico (CH1) ---")
   features_ch1 = extract_all_features_single_channel(signal_ch1, fs_hz, wavelet_level=4)
   for name, val in features_ch1.items():
       logger.info(f"  {name}: {val:.4f}")

   # Probar con m�ltiples canales
   # Formato [n_samples, n_channels]
   multichannel_signal_samples_x_channels = np.vstack((signal_ch1, signal_ch2)).T 
   logger.info(f"\n--- Caracter�sticas para M�ltiples Canales (formato [n_samples, n_channels], shape: {multichannel_signal_samples_x_channels.shape}) ---")
   features_multichannel1 = extract_features_multichannel(multichannel_signal_samples_x_channels, fs_hz)
   for i, ch_feats in enumerate(features_multichannel1):
       logger.info(f"  Canal {i+1}:")
       for name, val in ch_feats.items():
           logger.info(f"    {name}: {val:.4f}")

   # Formato [n_channels, n_samples]
   multichannel_signal_channels_x_samples = np.array([signal_ch1, signal_ch2])
   logger.info(f"\n--- Caracter�sticas para M�ltiples Canales (formato [n_channels, n_samples], shape: {multichannel_signal_channels_x_samples.shape}) ---")
   features_multichannel2 = extract_features_multichannel(multichannel_signal_channels_x_samples, fs_hz)
   for i, ch_feats in enumerate(features_multichannel2):
       logger.info(f"  Canal {i+1}:")
       for name, val in ch_feats.items():
           logger.info(f"    {name}: {val:.4f}")

   # Probar con segmento corto
   short_segment = signal_ch1[:3]
   logger.info(f"\n--- Caracter�sticas para Segmento Corto ({len(short_segment)} muestras) ---")
   features_short = extract_all_features_single_channel(short_segment, fs_hz)
   for name, val in features_short.items():
       logger.info(f"  {name}: {val:.4f}")
