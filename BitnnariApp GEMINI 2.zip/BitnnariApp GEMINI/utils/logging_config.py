     """
logging_config.py

M�dulo para configurar el sistema de logging de la aplicaci�n BitnariApp.
Proporciona una configuraci�n centralizada y avanzada para los logs,
incluyendo m�ltiples handlers (consola y archivo rotatorio), formatos detallados
y captura de excepciones no controladas.
"""

import logging
import logging.handlers
import sys
import os

# Importar constantes de la aplicaci�n
try:
   from BitnnariApp.utils.constants import APP_NAME, DATA_DIR_ROOT, MAX_LOG_FILE_SIZE_MB, LOG_BACKUP_COUNT
except ImportError:
   # Fallback si se ejecuta este m�dulo aisladamente o hay problemas de importaci�n
   # Esto es principalmente para desarrollo/testing del propio m�dulo.
   # En la aplicaci�n real, se espera que las constantes est�n disponibles.
   APP_NAME = "BitnariAppDefault"
   _CURRENT_FILE_DIR_LC = os.path.dirname(os.path.abspath(__file__))
   _APP_BASE_DIR_LC = os.path.dirname(_CURRENT_FILE_DIR_LC)
   DATA_DIR_ROOT = os.path.join(_APP_BASE_DIR_LC, "data", "app_data_logs_fallback")
   MAX_LOG_FILE_SIZE_MB = 5
   LOG_BACKUP_COUNT = 3
   print(f"WARN: Constants not imported directly, using fallbacks for logging_config. DATA_DIR_ROOT: {DATA_DIR_ROOT}")


# Nombre del archivo de log principal
LOG_FILENAME = f"{APP_NAME.lower().replace(' ', '_')}_main.log"
LOG_FILE_PATH = os.path.join(DATA_DIR_ROOT, "logs") # Subdirectorio para logs

# Asegurarse de que el directorio de logs exista
os.makedirs(LOG_FILE_PATH, exist_ok=True)
FULL_LOG_PATH = os.path.join(LOG_FILE_PATH, LOG_FILENAME)

# Formato de log est�ndar
LOG_FORMAT_STRING = "%(asctime)s [%(levelname)-8s] %(name)-25s (%(filename)s:%(lineno)d) - %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Niveles de logging por defecto
CONSOLE_LOG_LEVEL = logging.INFO
FILE_LOG_LEVEL = logging.DEBUG


def setup_logging(console_level: int = CONSOLE_LOG_LEVEL,
                 file_level: int = FILE_LOG_LEVEL,
                 log_file_path: str = FULL_LOG_PATH):
   """
   Configura el sistema de logging de Python para la aplicaci�n.

   Args:
       console_level (int): Nivel de logging para la salida a consola.
       file_level (int): Nivel de logging para la salida a archivo.
       log_file_path (str): Ruta completa al archivo de log.
   """
   # Obtener el logger ra�z. Configurar el logger ra�z afecta a todos los loggers
   # a menos que tengan su propia configuraci�n m�s espec�fica.
   root_logger = logging.getLogger()
   root_logger.setLevel(min(console_level, file_level)) # El logger ra�z debe tener el nivel m�s bajo de sus handlers

   # Limpiar handlers existentes para evitar duplicaci�n si se llama m�ltiples veces
   # (�til en algunos escenarios de recarga o testing)
   for handler in root_logger.handlers[:]:
       root_logger.removeHandler(handler)
       handler.close()

   # --- StreamHandler para la consola ---
   console_handler = logging.StreamHandler(sys.stdout) # O sys.stderr para errores
   console_handler.setLevel(console_level)
   console_formatter = logging.Formatter(LOG_FORMAT_STRING, datefmt=LOG_DATE_FORMAT)
   console_handler.setFormatter(console_formatter)
   root_logger.addHandler(console_handler)

   # --- RotatingFileHandler para el archivo de log ---
   try:
       # Rotaci�n de archivos: 5MB por archivo, mantener 3 archivos de backup
       max_bytes = MAX_LOG_FILE_SIZE_MB * 1024 * 1024
       file_handler = logging.handlers.RotatingFileHandler(
           log_file_path,
           maxBytes=max_bytes,
           backupCount=LOG_BACKUP_COUNT,
           encoding='utf-8'
       )
       file_handler.setLevel(file_level)
       file_formatter = logging.Formatter(LOG_FORMAT_STRING, datefmt=LOG_DATE_FORMAT)
       file_handler.setFormatter(file_formatter)
       root_logger.addHandler(file_handler)
       root_logger.info(f"Logging configurado. Nivel consola: {logging.getLevelName(console_level)}, Nivel archivo: {logging.getLevelName(file_level)}. Archivo: {log_file_path}")
   except Exception as e:
       # Si falla la creaci�n del FileHandler (e.g., permisos), loguear a consola
       root_logger.error(f"No se pudo configurar el logging a archivo en '{log_file_path}': {e}", exc_info=True)
       # La consola seguir� funcionando.

   # --- Captura de excepciones no controladas ---
   # Esto asegura que cualquier excepci�n que termine la aplicaci�n sea logueada.
   def handle_exception(exc_type, exc_value, exc_traceback):
       if issubclass(exc_type, KeyboardInterrupt):
           # No loguear KeyboardInterrupts como errores cr�ticos si el usuario interrumpe.
           sys.__excepthook__(exc_type, exc_value, exc_traceback) # Comportamiento por defecto
           return
       # Loguear la excepci�n
       root_logger.critical("Excepci�n no controlada:", exc_info=(exc_type, exc_value, exc_traceback))

   sys.excepthook = handle_exception

   # --- Silenciar loggers de librer�as muy verbosas (opcional) ---
   # logging.getLogger("matplotlib").setLevel(logging.WARNING)
   # logging.getLogger("pyqtgraph").setLevel(logging.WARNING)


# Para probar la configuraci�n de logging directamente
if __name__ == "__main__":
   # Configurar el logging al ejecutar este script
   setup_logging(console_level=logging.DEBUG, file_level=logging.DEBUG)

   # Crear algunos loggers de ejemplo para diferentes m�dulos
   logger_main = logging.getLogger(APP_NAME) # Logger para la app principal
   logger_module_A = logging.getLogger(f"{APP_NAME}.ModuleA")
   logger_module_B = logging.getLogger(f"{APP_NAME}.ModuleB.SubModule")

   logger_main.info("Este es un mensaje informativo de la aplicaci�n principal.")
   logger_module_A.debug("Este es un mensaje de debug del M�dulo A.")
   logger_module_A.warning("Este es un aviso del M�dulo A.")
   logger_module_B.error("Este es un error del SubM�dulo de B.")
   logger_module_B.critical("Este es un error cr�tico del SubM�dulo de B.")

   # Ejemplo de c�mo se ver�a una excepci�n no controlada
   # (descomentar para probar, pero la aplicaci�n terminar�)
   # print("Probando captura de excepci�n no controlada en 3 segundos...")
   # import time
   # time.sleep(3)
   # x = 1 / 0
   
