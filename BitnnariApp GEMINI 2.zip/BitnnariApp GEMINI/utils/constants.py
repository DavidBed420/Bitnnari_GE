"""
constants.py

M�dulo para definir constantes globales utilizadas en toda la aplicaci�n BitnariApp.
Esto ayuda a evitar "magic strings" o "magic numbers" dispersos por el c�digo,
facilitando el mantenimiento y la consistencia.

Las constantes pueden incluir:
- Nombres de archivo o claves de configuraci�n.
- Valores por defecto para par�metros.
- L�mites, umbrales o rangos comunes.
- Claves para diccionarios de datos.
- Nombres de objeto para widgets de UI (si se usan consistentemente).
- Identificadores de eventos o se�ales.
"""

import os

# --- Rutas y Nombres de Archivo ---
APP_NAME = "BitnariApp EMG Suite"
ORGANIZATION_NAME = "BitnariTech" # Para QSettings, etc.

# Directorio base de la aplicaci�n (asumiendo que constants.py est� en utils/)
# Para que funcione correctamente si se ejecuta desde diferentes ubicaciones,
# es mejor calcularlo relativo al script o usar un punto de entrada que lo defina.
# Por ahora, una aproximaci�n:
_CURRENT_FILE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_BASE_DIR = os.path.dirname(_CURRENT_FILE_DIR) # Sube un nivel desde utils/

RESOURCES_DIR = os.path.join(APP_BASE_DIR, "resources")
ICONS_DIR = os.path.join(RESOURCES_DIR, "icons")
QSS_DIR = os.path.join(RESOURCES_DIR, "qss")
MODELS_DIR = os.path.join(APP_BASE_DIR, "models") # Para modelos ML y de datos guardados
DATA_DIR_ROOT = os.path.join(APP_BASE_DIR, "data", "app_data") # Ra�z para datos de pacientes, etc.

GLOBAL_STYLESHEET_NAME = "estilo_moderno.qss" # Nombre del archivo QSS principal
DATABASE_NAME = "bitnariapp_database.db" # Para SQLite si se usa, o nombre de la DB en Mongo

# --- Configuraci�n de Adquisici�n EMG ---
DEFAULT_BAUD_RATE = 115200
DEFAULT_EMG_CHANNELS = 2
DEFAULT_SAMPLING_RATE_HZ = 1000.0
DEFAULT_ACQUISITION_DELAY_MS = int(1000.0 / DEFAULT_SAMPLING_RATE_HZ) if DEFAULT_SAMPLING_RATE_HZ > 0 else 10
PACKET_HEADER_BYTE = 0xAA
MAX_HARDWARE_CHANNELS = 8 # M�ximo que el firmware puede enviar en un paquete
ARDUINO_VID_PIDS = [ # Lista de (VID, PID) para algunos Arduinos comunes
   (0x2341, 0x0043), # Arduino Uno
   (0x2341, 0x0001), # Arduino Uno R3
   (0x2A03, 0x0043), # Arduino Uno (VID alternativo)
   (0x1A86, 0x7523), # CH340/CH341 (com�n en clones)
]
ARDUINO_DESCRIPTORS = ["Arduino", "USB-SERIAL CH340", "QinHeng Electronics CH340", "Uno"]


# --- Configuraci�n de Filtros ---
DEFAULT_NOTCH_FREQ_HZ = 50.0
DEFAULT_NOTCH_Q_FACTOR = 30.0
DEFAULT_HIGHPASS_CUTOFF_HZ = 20.0
DEFAULT_LOWPASS_CUTOFF_HZ = 450.0
DEFAULT_FILTER_ORDER = 4

# --- Configuraci�n de Clasificaci�n ---
DEFAULT_MODEL_NAME = "random_forest"
CLASSIFICATION_MODELS_SUPPORTED = ["random_forest", "svm", "mlp", "xgboost", "dnn_torch"]
CLASSIFICATION_CONFIG_FILENAME = "classification_engine_config.json"
TRAINED_MODELS_SUBDIR = "trained_ml_models" # Subdirectorio dentro de DATA_DIR_ROOT/patient_id/
TRAINING_METRICS_SUBDIR = "training_metrics_logs"

# --- DataManager / GestorDatos Claves ---
# Subdirectorios dentro de la carpeta de cada paciente
PATIENT_DATA_SUBDIRS = {
   "personal_info": "datos_personales",
   "acquisition_sessions": "sesiones_adquisicion",
   "calibration_params": "parametros_calibracion",
   "calibration_references": "referencias_calibracion",
   "processing_configs": "configuraciones_procesamiento",
   "processed_sessions": "sesiones_procesadas",
   "training_data": "datos_entrenamiento", # Podr�a ser una lista de sesiones de entrenamiento
   "trained_models_info": "modelos_entrenados_info", # Metadatos sobre modelos, no los archivos en s�
   "prediction_history": "historial_predicciones",
   "treatment_plans": "planes_tratamiento",
   "page_configs": "configuraciones_gui_paginas" # Para guardar estado de UI de p�ginas espec�ficas
}
PATIENT_INDEX_FILENAME = "patients_master_index.json" # En DATA_DIR_ROOT

# Claves para datos espec�ficos dentro de los JSON de paciente
KEY_PATIENT_DNI = "dni"
KEY_PATIENT_NAME = "nombre"
KEY_PATIENT_BIRTHDATE = "fecha_nacimiento"
KEY_PATIENT_CONTACT = "contacto"
KEY_PATIENT_PHOTO_PATH = "foto_path" # Ruta a la imagen
KEY_PATIENT_PATHOLOGIES = "patologias"
KEY_PATIENT_HISTORY_CLINICAL = "historial_clinico" # Lista de dicts {timestamp, nota}
KEY_PATIENT_MODEL_PREF = "modelo_ml_preferido"
KEY_LAST_UPDATE = "ultima_actualizacion"

# --- UI Constantes ---
# Nombres de objeto para QStackedWidget y p�ginas principales (para navegaci�n)
STACKED_WIDGET_MAIN_APP = "mainAppStackedWidget" # El stack en MainApplicationWindow
PAGE_NAME_INICIO = "ventanaInicioScreen"
PAGE_NAME_REGISTRO = "ventanaRegistroScreen"
PAGE_NAME_PRINCIPAL = "ventanaPrincipalScreen" # La que contiene el sidebar y las sub-p�ginas

# Podr�an ir m�s constantes aqu�, como colores por defecto para plots si no se cargan de config,
# umbrales para detecci�n de actividad, etc.

# --- Protocolo de Comunicaci�n (si se define uno m�s complejo) ---
# CMD_SET_MODE = 0x01
# CMD_SET_CHANNELS = 0x02
# CMD_SET_DELAY = 0x03
# CMD_START_STREAM = 0x0A
# CMD_STOP_STREAM = 0x0B
# ACK_BYTE = 0xCC
# NACK_BYTE = 0x33

# --- Valores por defecto para di�logos o configuraciones ---
DEFAULT_EXPORT_FILENAME_PREFIX = "bitnariapp_export"
MAX_LOG_FILE_SIZE_MB = 5
LOG_BACKUP_COUNT = 3

# --- Internacionalizaci�n ---
# DEFAULT_LANGUAGE = "es" # Espa�ol por defecto
# SUPPORTED_LANGUAGES = {"es": "Espa�ol", "en": "English"}
# TRANSLATIONS_DIR = os.path.join(RESOURCES_DIR, "translations")


# --- Constantes para Testing ---
# (Podr�an estar en un archivo separado dentro de la carpeta tests)
TEST_PATIENT_ID_VALID = "12345678Z"
TEST_PATIENT_ID_INVALID_FORMAT = "ABCDEFG"
TEST_DUMMY_SERIAL_PORT = "LOOPBACK_TEST" # Para simular un puerto en tests

logger.info("Constantes de la aplicaci�n cargadas.")

# Para verificar que las rutas se forman correctamente (opcional, para debug)
if __name__ == "__main__":
   print(f"APP_BASE_DIR: {APP_BASE_DIR}")
   print(f"RESOURCES_DIR: {RESOURCES_DIR}")
   print(f"DATA_DIR_ROOT: {DATA_DIR_ROOT}")
   print(f"MODELS_DIR: {MODELS_DIR}")
   
