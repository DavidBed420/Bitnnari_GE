"""
adaptive_filter.py

M�dulo para la implementaci�n de filtros adaptativos, con un enfoque en el
algoritmo LMS (Least Mean Squares) y sus variantes para aplicaciones como
cancelaci�n de ruido en se�ales EMG.

Clases Implementadas:
- BaseAdaptiveFilter: Clase base abstracta para futuros filtros adaptativos.
- LMSFilter: Implementaci�n del filtro adaptativo LMS est�ndar.
- NLMSFilter: Implementaci�n del filtro adaptativo LMS Normalizado (NLMS),
             que mejora la estabilidad y convergencia del LMS.

Funciones de Aplicaci�n:
- apply_adaptive_noise_canceller: Aplica un filtro adaptativo (LMS o NLMS)
                                  en una configuraci�n de cancelador de ruido.
"""

import numpy as np
import logging
from abc import ABC, abstractmethod
from typing import Tuple, List, Optional, Type

logger = logging.getLogger(__name__)
if not logger.handlers:
   handler = logging.StreamHandler()
   formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
   handler.setFormatter(formatter)
   logger.addHandler(handler)
   logger.setLevel(logging.INFO)

EPSILON_ADAPTIVE = 1e-9 # Peque�o valor para evitar divisi�n por cero en NLMS

class BaseAdaptiveFilter(ABC):
   """Clase base abstracta para filtros adaptativos."""
   def __init__(self, filter_order: int, learning_rate: float):
       if not isinstance(filter_order, int) or filter_order <= 0:
           raise ValueError("El orden del filtro (filter_order) debe ser un entero positivo.")
       if not isinstance(learning_rate, (float, int)) or not (0 < learning_rate): # Tasa de aprendizaje debe ser positiva
           # El l�mite superior de mu depende del algoritmo y la potencia de la se�al
           logger.warning(f"Tasa de aprendizaje (mu={learning_rate}) es {learning_rate}. Aseg�rese de que sea apropiada para el algoritmo y la se�al.")

       self.order: int = filter_order
       self.mu: float = learning_rate # Tasa de aprendizaje
       self.weights: np.ndarray = np.zeros(filter_order)
       self.buffer: np.ndarray = np.zeros(filter_order) # Buffer para las muestras de entrada x(n)

   def _update_buffer(self, new_input_sample: float):
       """Desplaza el buffer e inserta la nueva muestra de entrada."""
       self.buffer = np.roll(self.buffer, 1)
       self.buffer[0] = new_input_sample

   def predict_output(self, current_input_sample: Optional[float] = None) -> float:
       """
       Calcula la salida del filtro FIR actual y_hat(n) = w^T(n) * x_buffer(n).
       Si current_input_sample es proporcionado, actualiza el buffer primero.
       """
       if current_input_sample is not None:
           self._update_buffer(current_input_sample)
       return float(np.dot(self.weights, self.buffer))

   @abstractmethod
   def adapt_weights(self, error_signal_sample: float, input_buffer_for_update: np.ndarray):
       """
       M�todo abstracto para actualizar los pesos del filtro.
       Debe ser implementado por las clases hijas.

       Args:
           error_signal_sample (float): La muestra actual de la se�al de error e(n).
           input_buffer_for_update (np.ndarray): El buffer de entrada x(n) que se usar�
                                                 para la actualizaci�n de pesos.
       """
       pass

   def process_sample(self, input_sample: float, desired_sample: float) -> Tuple[float, float, np.ndarray]:
       """
       Procesa una �nica muestra: actualiza buffer, predice salida, calcula error y adapta pesos.

       Args:
           input_sample (float): La muestra de la se�al de entrada x(n).
           desired_sample (float): La muestra de la se�al deseada d(n).

       Returns:
           Tuple[float, float, np.ndarray]:
               - y_hat (float): La salida filtrada estimada.
               - error (float): La se�al de error (desired_sample - y_hat).
               - current_weights (np.ndarray): Copia de los pesos *despu�s* de la adaptaci�n.
       """
       self._update_buffer(input_sample)
       # y_hat(n) se calcula con los pesos w(n) antes de la actualizaci�n
       y_hat = self.predict_output() # Usa el buffer ya actualizado
       error = desired_sample - y_hat # e(n) = d(n) - y_hat(n)
       
       # w(n+1) se calcula usando e(n) y x(n) (el buffer actual)
       self.adapt_weights(error, self.buffer)
       
       return y_hat, error, self.weights.copy()

   def reset(self):
       """Resetea los pesos del filtro y el buffer a sus estados iniciales (ceros)."""
       self.weights.fill(0.0)
       self.buffer.fill(0.0)
       logger.info(f"Filtro adaptativo ({self.__class__.__name__}) reseteado.")

   def get_weights(self) -> np.ndarray:
       """Retorna una copia de los pesos actuales del filtro."""
       return self.weights.copy()


class LMSFilter(BaseAdaptiveFilter):
   """Implementaci�n del filtro adaptativo LMS (Least Mean Squares) est�ndar."""
   def adapt_weights(self, error_signal_sample: float, input_buffer_for_update: np.ndarray):
       """
       Actualiza los pesos del filtro usando la regla LMS:
       w(n+1) = w(n) + mu * e(n) * x(n)
       """
       self.weights += self.mu * error_signal_sample * input_buffer_for_update


class NLMSFilter(BaseAdaptiveFilter):
   """
   Implementaci�n del filtro adaptativo LMS Normalizado (NLMS).
   NLMS ajusta la tasa de aprendizaje bas�ndose en la potencia de la se�al de entrada,
   lo que puede mejorar la estabilidad y la velocidad de convergencia.
   """
   def __init__(self, filter_order: int, learning_rate: float, epsilon: float = EPSILON_ADAPTIVE):
       """
       Inicializa el filtro NLMS.

       Args:
           filter_order (int): El n�mero de coeficientes (taps) del filtro.
           learning_rate (float): La tasa de aprendizaje base (mu_0). T�picamente entre 0 y 2.
           epsilon (float): Peque�a constante para evitar divisi�n por cero en la normalizaci�n.
       """
       super().__init__(filter_order, learning_rate)
       if not (0 < learning_rate <= 2): # Para NLMS, mu_0 suele estar en (0, 2]
            logger.warning(f"Tasa de aprendizaje base para NLMS (mu_0={learning_rate}) fuera del rango t�pico (0, 2].")
       self.epsilon = epsilon

   def adapt_weights(self, error_signal_sample: float, input_buffer_for_update: np.ndarray):
       """
       Actualiza los pesos del filtro usando la regla NLMS:
       w(n+1) = w(n) + (mu_0 / (epsilon + ||x(n)||^2)) * e(n) * x(n)
       donde ||x(n)||^2 es la potencia (norma cuadrada) del vector de entrada en el buffer.
       """
       norm_squared_input = np.dot(input_buffer_for_update, input_buffer_for_update)
       adaptive_step_size = self.mu / (self.epsilon + norm_squared_input)
       self.weights += adaptive_step_size * error_signal_sample * input_buffer_for_update


def apply_adaptive_noise_canceller(
   primary_signal_with_noise: np.ndarray, # d(n) = s(n) + noise_component_1
   noise_reference_signal: np.ndarray,    # x(n) = noise_component_2 (correlacionado con noise_component_1)
   filter_type: Type[BaseAdaptiveFilter] = NLMSFilter, # Tipo de filtro a usar (LMS o NLMS)
   filter_order: int = 32,
   learning_rate: float = 0.01,
   nlms_epsilon: float = EPSILON_ADAPTIVE
) -> Tuple[np.ndarray, np.ndarray, List[np.ndarray]]:
   """
   Aplica un filtro adaptativo en una configuraci�n de cancelador de ruido.
   El objetivo es estimar la se�al limpia `s(n)` a partir de `primary_signal_with_noise`
   utilizando `noise_reference_signal`.

   Args:
       primary_signal_with_noise (np.ndarray): La se�al principal contaminada, d(n).
                                               Debe ser un array 1D.
       noise_reference_signal (np.ndarray): La se�al de referencia de ruido, x(n),
                                            que est� correlacionada con el ruido en d(n).
                                            Debe ser un array 1D de la misma longitud que d(n).
       filter_type (Type[BaseAdaptiveFilter]): La clase del filtro adaptativo a utilizar
                                               (e.g., LMSFilter, NLMSFilter).
       filter_order (int): Orden (n�mero de taps) del filtro adaptativo.
       learning_rate (float): Tasa de aprendizaje (mu o mu_0) para el filtro.
       nlms_epsilon (float): Constante de regularizaci�n para NLMS (ignorada si se usa LMS).

   Returns:
       Tuple[np.ndarray, np.ndarray, List[np.ndarray]]:
           - signal_cleaned_estimate (np.ndarray): Estimaci�n de la se�al limpia, e(n) = d(n) - y_hat(n).
           - noise_component_estimate (np.ndarray): Estimaci�n del componente de ruido, y_hat(n).
           - weights_evolution (List[np.ndarray]): Historial de los pesos del filtro en cada iteraci�n.
   
   Raises:
       ValueError: Si las se�ales de entrada no tienen la misma longitud o no son 1D.
   """
   if not (isinstance(primary_signal_with_noise, np.ndarray) and primary_signal_with_noise.ndim == 1):
       raise ValueError("primary_signal_with_noise debe ser un array NumPy 1D.")
   if not (isinstance(noise_reference_signal, np.ndarray) and noise_reference_signal.ndim == 1):
       raise ValueError("noise_reference_signal debe ser un array NumPy 1D.")
   if len(primary_signal_with_noise) != len(noise_reference_signal):
       raise ValueError("Las se�ales 'primary_signal_with_noise' y 'noise_reference_signal' deben tener la misma longitud.")

   num_samples = len(primary_signal_with_noise)
   if num_samples == 0:
       logger.warning("Se�ales de entrada vac�as para el cancelador de ruido adaptativo.")
       return np.array([]), np.array([]), []

   # Instanciar el filtro
   if filter_type == NLMSFilter:
       adaptive_filter = NLMSFilter(filter_order, learning_rate, nlms_epsilon)
   elif filter_type == LMSFilter:
       adaptive_filter = LMSFilter(filter_order, learning_rate)
   else:
       raise ValueError(f"Tipo de filtro no soportado: {filter_type.__name__}")

   logger.info(f"Aplicando {adaptive_filter.__class__.__name__} para cancelaci�n de ruido: "
               f"orden={filter_order}, mu={learning_rate}"
               f"{f', epsilon={nlms_epsilon}' if isinstance(adaptive_filter, NLMSFilter) else ''}")

   noise_component_estimate_out = np.zeros(num_samples)
   signal_cleaned_estimate_out = np.zeros(num_samples)
   weights_evolution: List[np.ndarray] = [] # Para almacenar los pesos en cada paso

   for n in range(num_samples):
       # input_sample para process_sample es x(n) -> noise_reference_signal[n]
       # desired_sample para process_sample es d(n) -> primary_signal_with_noise[n]
       y_hat, error, current_weights = adaptive_filter.process_sample(
           input_sample=noise_reference_signal[n],
           desired_sample=primary_signal_with_noise[n]
       )
       
       noise_component_estimate_out[n] = y_hat # Estimaci�n del ruido
       signal_cleaned_estimate_out[n] = error  # Estimaci�n de la se�al limpia
       weights_evolution.append(current_weights)

   return signal_cleaned_estimate_out, noise_component_estimate_out, weights_evolution


if __name__ == "__main__":
   logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
   
   # --- Par�metros de la Simulaci�n ---
   FS = 1000  # Frecuencia de muestreo (Hz)
   DURATION = 2.0  # Duraci�n de la se�al (segundos)
   N_SAMPLES = int(FS * DURATION)
   time_vector = np.arange(N_SAMPLES) / FS

   # 1. Se�al de inter�s (limpia)
   s_clean = 0.8 * np.sin(2 * np.pi * 7 * time_vector) + \
             0.4 * np.sin(2 * np.pi * 15 * time_vector) * np.exp(-time_vector * 0.5) # Componente que decae

   # 2. Fuente de ruido principal (e.g., interferencia de 50Hz)
   noise_main_source = 1.2 * np.sin(2 * np.pi * 50 * time_vector) + \
                       0.3 * np.sin(2 * np.pi * 150 * time_vector) # Arm�nico

   # 3. Ruido de referencia (x(n) para el filtro adaptativo)
   #    Este es el ruido que el filtro "escucha" para adaptarse.
   #    Debe estar correlacionado con el ruido que contamina la se�al principal.
   #    A�adimos un peque�o ruido blanco no correlacionado a esta referencia.
   x_noise_ref = noise_main_source + 0.1 * np.random.randn(N_SAMPLES)

   # 4. Se�al primaria contaminada (d(n) = s_clean + noise_component_in_primary)
   #    El ruido en la se�al primaria es una versi�n del `noise_main_source`,
   #    posiblemente atenuada o ligeramente modificada (e.g., por un canal de acoplamiento).
   noise_in_primary = 0.6 * noise_main_source + 0.05 * np.random.randn(N_SAMPLES) # Ruido correlacionado + peque�o ruido no correlacionado
   d_primary_contaminated = s_clean + noise_in_primary

   # --- Configuraci�n del Filtro Adaptativo ---
   FILTER_ORDER = 40  # N�mero de coeficientes del filtro
   LEARNING_RATE_LMS = 0.005 # Tasa de aprendizaje para LMS (sensible)
   LEARNING_RATE_NLMS = 0.1 # Tasa de aprendizaje para NLMS (m�s robusta, t�picamente mayor)
   NLMS_EPS = 1e-6 # Constante de regularizaci�n para NLMS

   logger.info("--- Ejecutando Cancelador de Ruido con LMS Est�ndar ---")
   s_est_lms, n_est_lms, _ = apply_adaptive_noise_canceller(
       primary_signal_with_noise=d_primary_contaminated,
       noise_reference_signal=x_noise_ref,
       filter_type=LMSFilter,
       filter_order=FILTER_ORDER,
       learning_rate=LEARNING_RATE_LMS
   )

   logger.info("--- Ejecutando Cancelador de Ruido con NLMS ---")
   s_est_nlms, n_est_nlms, weights_hist_nlms = apply_adaptive_noise_canceller(
       primary_signal_with_noise=d_primary_contaminated,
       noise_reference_signal=x_noise_ref,
       filter_type=NLMSFilter,
       filter_order=FILTER_ORDER,
       learning_rate=LEARNING_RATE_NLMS,
       nlms_epsilon=NLMS_EPS
   )

   # --- Evaluaci�n Simple (MSE) ---
   mse_lms = np.mean((s_clean - s_est_lms)**2)
   mse_nlms = np.mean((s_clean - s_est_nlms)**2)
   mse_original = np.mean((s_clean - d_primary_contaminated)**2)

   logger.info(f"\nResultados de Cancelaci�n de Ruido:")
   logger.info(f"  MSE Original (Contaminada vs Limpia): {mse_original:.6f}")
   logger.info(f"  MSE con LMS (Estimada Limpia vs Limpia Original): {mse_lms:.6f}")
   logger.info(f"  MSE con NLMS (Estimada Limpia vs Limpia Original): {mse_nlms:.6f}")

   # --- Visualizaci�n (requiere matplotlib) ---
   try:
       import matplotlib.pyplot as plt
       
       fig, axs = plt.subplots(5, 1, sharex=True, figsize=(12, 10))
       fig.suptitle("Resultados del Cancelador de Ruido Adaptativo", fontsize=16)

       axs[0].plot(time_vector, s_clean, label="Se�al Limpia Original (s)", color='blue', alpha=0.8)
       axs[0].set_title("Se�al Limpia Original")
       axs[0].legend(loc='upper right'); axs[0].grid(True)

       axs[1].plot(time_vector, x_noise_ref, label="Referencia de Ruido (x)", color='gray', alpha=0.7)
       axs[1].set_title("Entrada de Ruido de Referencia al Filtro")
       axs[1].legend(loc='upper right'); axs[1].grid(True)

       axs[2].plot(time_vector, d_primary_contaminated, label="Se�al Primaria Contaminada (d)", color='purple')
       axs[2].set_title("Se�al Primaria (Limpia + Ruido)")
       axs[2].legend(loc='upper right'); axs[2].grid(True)
       
       axs[3].plot(time_vector, s_est_lms, label=f"Salida Limpia LMS (e_LMS) - MSE: {mse_lms:.4f}", color='orange')
       axs[3].plot(time_vector, s_est_nlms, label=f"Salida Limpia NLMS (e_NLMS) - MSE: {mse_nlms:.4f}", color='green', linestyle='--')
       axs[3].set_title("Estimaciones de la Se�al Limpia")
       axs[3].legend(loc='upper right'); axs[3].grid(True)

       axs[4].plot(time_vector, n_est_nlms, label="Estimaci�n del Ruido por NLMS (y_hat_NLMS)", color='red', alpha=0.7)
       axs[4].plot(time_vector, noise_in_primary, label="Ruido Real en Primaria (referencia)", color='pink', linestyle=':', alpha=0.6)
       axs[4].set_title("Estimaci�n del Ruido vs Ruido Real en Primaria")
       axs[4].legend(loc='upper right'); axs[4].grid(True)
       axs[4].set_xlabel("Tiempo (s)")

       plt.tight_layout(rect=[0, 0, 1, 0.96]) # Ajustar para el suptitle
       plt.show()

       # Plot de la evoluci�n de los pesos para NLMS
       plt.figure(figsize=(10, 5))
       weights_array = np.array(weights_hist_nlms)
       for i in range(min(FILTER_ORDER, 5)): # Graficar solo los primeros 5 pesos para no saturar
           plt.plot(weights_array[:, i], label=f'Peso w[{i}]')
       plt.title(f"Evoluci�n de los Primeros Pesos del Filtro NLMS (Orden {FILTER_ORDER})")
       plt.xlabel("Iteraci�n (Muestra)")
       plt.ylabel("Valor del Peso")
       plt.legend(loc='upper right'); plt.grid(True)
       plt.tight_layout()
       plt.show()

   except ImportError:
       logger.warning("Matplotlib no est� instalado. No se pueden mostrar los gr�ficos de prueba.")
   except Exception as e:
       logger.error(f"Error durante la visualizaci�n de prueba: {e}", exc_info=True)
   
