     """
normalization.py

M�dulo de utilidad para la normalizaci�n y escalado de se�ales num�ricas,
especialmente aplicable a datos biom�dicos como EMG. Proporciona funciones
robustas y eficientes para transformar datos a diferentes rangos o distribuciones.

Funciones Implementadas:
- normalize_min_max: Escala caracter�sticas a un rango [min, max] dado.
- normalize_z_score: Estandariza caracter�sticas restando la media y dividiendo
                    por la desviaci�n est�ndar.
- robust_scaler_iqr: Escala caracter�sticas utilizando la mediana y el Rango
                    Intercuart�lico (IQR), haci�ndolo robusto a outliers.
"""

import numpy as np
import logging
from typing import Tuple, Union

logger = logging.getLogger(__name__)
if not logger.handlers: # Evitar duplicar handlers si el m�dulo se recarga
   handler = logging.StreamHandler()
   formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
   handler.setFormatter(formatter)
   logger.addHandler(handler)
   logger.setLevel(logging.INFO) # Nivel por defecto para el logger del m�dulo

# Constante para evitar divisi�n por cero en c�lculos de desviaci�n est�ndar o rango
EPSILON = 1e-9

def normalize_min_max(
   data: np.ndarray,
   feature_range: Tuple[Union[int, float], Union[int, float]] = (0, 1),
   axis: Optional[int] = 0
) -> np.ndarray:
   """
   Normaliza un array de NumPy (datos de se�al o caracter�sticas) al rango
   especificado [min_val, max_val] (por defecto [0, 1]).

   La normalizaci�n se aplica a lo largo del eje especificado. Si `axis=0`,
   se normaliza cada columna (caracter�stica) independientemente. Si `axis=1`,
   se normaliza cada fila (muestra) independientemente. Si `axis=None`, se
   normaliza el array completo globalmente.

   Args:
       data (np.ndarray): Array de NumPy con los datos a normalizar.
                          Puede ser 1D o N-D.
       feature_range (Tuple[Union[int, float], Union[int, float]]):
                          Tupla (min_val, max_val) del rango deseado.
       axis (Optional[int]): Eje a lo largo del cual se realiza la normalizaci�n.
                             Si es None, se normaliza el array globalmente.

   Returns:
       np.ndarray: Array con los datos normalizados, de la misma forma que la entrada.

   Raises:
       ValueError: Si feature_range[0] >= feature_range[1].
   """
   if not isinstance(data, np.ndarray):
       raise TypeError("La entrada 'data' debe ser un array de NumPy.")
   if data.size == 0:
       logger.warning("Se intent� normalizar un array vac�o. Devolviendo array vac�o.")
       return data.copy() # Devolver una copia para mantener consistencia

   min_target, max_target = feature_range
   if min_target >= max_target:
       raise ValueError(f"El rango de caracter�sticas es inv�lido: min ({min_target}) debe ser menor que max ({max_target}).")

   data_min = np.min(data, axis=axis, keepdims=True)
   data_max = np.max(data, axis=axis, keepdims=True)
   
   data_range = data_max - data_min
   
   # Donde el rango es cero (datos constantes), evitamos divisi�n por cero.
   # Si el rango es cero, todos los puntos son iguales a data_min.
   # (X - data_min) ser� 0. Si escalamos, (0 / 0) es NaN.
   # Si el rango es cero, la se�al normalizada deber�a ser el punto medio del target_range,
   # o el min_target si el target_range tambi�n es cero (aunque ya validamos eso).
   
   # Crear una m�scara para los rangos no nulos
   # Si data_range es un escalar (axis=None), np.where funciona bien.
   # Si data_range es un array (axis=0 o axis=1), tambi�n.
   scale = np.where(data_range > EPSILON, (max_target - min_target) / data_range, 0)
   
   normalized_data = (data - data_min) * scale + min_target
   
   # Para los casos donde data_range era 0 (o muy cercano a 0):
   # (data - data_min) es ~0. (0 * scale) es 0. Entonces normalized_data es min_target.
   # Esto es un comportamiento razonable. Si se desea un valor diferente (e.g., punto medio),
   # se podr�a a�adir una l�gica espec�fica aqu� usando np.isclose(data_range, 0).
   # Por ejemplo:
   # zero_range_mask = np.isclose(data_range, 0)
   # normalized_data[zero_range_mask] = (min_target + max_target) / 2.0

   return normalized_data


def normalize_z_score(data: np.ndarray, axis: Optional[int] = 0) -> np.ndarray:
   """
   Normaliza un array de NumPy (datos de se�al o caracter�sticas) usando Z-score
   (media 0, desviaci�n est�ndar 1).

   La normalizaci�n se aplica a lo largo del eje especificado. Si `axis=0`,
   se normaliza cada columna (caracter�stica) independientemente. Si `axis=1`,
   se normaliza cada fila (muestra) independientemente. Si `axis=None`, se
   normaliza el array completo globalmente.

   Args:
       data (np.ndarray): Array de NumPy con los datos a normalizar.
       axis (Optional[int]): Eje a lo largo del cual se realiza la normalizaci�n.

   Returns:
       np.ndarray: Array con los datos normalizados con Z-score.
   """
   if not isinstance(data, np.ndarray):
       raise TypeError("La entrada 'data' debe ser un array de NumPy.")
   if data.size == 0:
       logger.warning("Se intent� normalizar con Z-score un array vac�o. Devolviendo array vac�o.")
       return data.copy()

   mean_val = np.mean(data, axis=axis, keepdims=True)
   std_val = np.std(data, axis=axis, keepdims=True)

   # Evitar divisi�n por cero si la desviaci�n est�ndar es cero.
   # Si std_val es cero, la se�al es constante, Z-score deber�a ser 0.
   # (X - mean_val) ser� 0. (0 / 0) es NaN.
   # Usamos np.where para manejar esto: si std_val es cercano a cero, el resultado es 0.
   normalized_data = np.where(std_val > EPSILON, (data - mean_val) / std_val, 0)
   
   return normalized_data


def robust_scaler_iqr(data: np.ndarray, axis: Optional[int] = 0) -> np.ndarray:
   """
   Escala un array de NumPy utilizando estad�sticas robustas a outliers:
   resta la mediana y escala seg�n el Rango Intercuart�lico (IQR).
   La f�rmula es: X_scaled = (X - median) / IQR.

   El escalado se aplica a lo largo del eje especificado.

   Args:
       data (np.ndarray): Array de NumPy con los datos a escalar.
       axis (Optional[int]): Eje a lo largo del cual se realiza el escalado.

   Returns:
       np.ndarray: Array con los datos escalados robustamente.
   """
   if not isinstance(data, np.ndarray):
       raise TypeError("La entrada 'data' debe ser un array de NumPy.")
   if data.size == 0:
       logger.warning("Se intent� aplicar RobustScaler a un array vac�o. Devolviendo array vac�o.")
       return data.copy()

   median_val = np.median(data, axis=axis, keepdims=True)
   q1 = np.percentile(data, 25, axis=axis, keepdims=True)
   q3 = np.percentile(data, 75, axis=axis, keepdims=True)
   iqr = q3 - q1

   # Evitar divisi�n por cero si IQR es cero.
   # Si IQR es 0, la mayor�a de los datos (al menos el 50%) son iguales.
   # (X - median_val) ser� 0 para esos datos. (0 / 0) es NaN.
   # Si IQR es 0, los datos no outliers no se escalar�n.
   scaled_data = np.where(iqr > EPSILON, (data - median_val) / iqr, 0)
   
   return scaled_data


if __name__ == "__main__":
   # Configurar logging para pruebas
   logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

   # --- Datos de Prueba Detallados ---
   data_1d_simple = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
   data_1d_offset = np.array([11.0, 12.0, 13.0, 14.0, 15.0])
   data_1d_neg = np.array([-5.0, -4.0, -3.0, -2.0, -1.0])
   data_1d_mixed = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
   data_1d_constant = np.array([7.0, 7.0, 7.0, 7.0])
   data_1d_single_val = np.array([10.0])
   data_1d_empty = np.array([])

   data_2d_simple = np.array([[1.0, 6.0], [2.0, 7.0], [3.0, 8.0], [4.0, 9.0], [5.0, 10.0]])
   data_2d_constant_col = np.array([[1.0, 5.0], [2.0, 5.0], [3.0, 5.0], [4.0, 5.0]])
   data_2d_global_constant = np.array([[3.0, 3.0], [3.0, 3.0]])

   logger.info("=========== Pruebas de Normalizaci�n Min-Max ===========")
   logger.info(f"Original 1D Simple: {data_1d_simple} -> Min-Max (0,1): {normalize_min_max(data_1d_simple)}")
   logger.info(f"Original 1D Offset: {data_1d_offset} -> Min-Max (0,1): {normalize_min_max(data_1d_offset)}")
   logger.info(f"Original 1D Neg: {data_1d_neg} -> Min-Max (0,1): {normalize_min_max(data_1d_neg)}")
   logger.info(f"Original 1D Mixed: {data_1d_mixed} -> Min-Max (-1,1): {normalize_min_max(data_1d_mixed, feature_range=(-1,1))}")
   logger.info(f"Original 1D Constant: {data_1d_constant} -> Min-Max (0,1): {normalize_min_max(data_1d_constant)}")
   logger.info(f"Original 1D Single Val: {data_1d_single_val} -> Min-Max (0,1): {normalize_min_max(data_1d_single_val)}")
   logger.info(f"Original 1D Empty: {data_1d_empty} -> Min-Max (0,1): {normalize_min_max(data_1d_empty)}")

   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nMin-Max (0,1) axis=0:\n{normalize_min_max(data_2d_simple, axis=0)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nMin-Max (0,1) axis=1:\n{normalize_min_max(data_2d_simple, axis=1)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nMin-Max (0,1) axis=None:\n{normalize_min_max(data_2d_simple, axis=None)}")
   logger.info(f"Original 2D Constant Col:\n{data_2d_constant_col}\nMin-Max (0,1) axis=0:\n{normalize_min_max(data_2d_constant_col, axis=0)}")
   logger.info(f"Original 2D Global Constant:\n{data_2d_global_constant}\nMin-Max (0,1) axis=0:\n{normalize_min_max(data_2d_global_constant, axis=0)}")

   logger.info("\n=========== Pruebas de Normalizaci�n Z-Score ===========")
   logger.info(f"Original 1D Simple: {data_1d_simple} -> Z-Score: {normalize_z_score(data_1d_simple)}")
   logger.info(f"Original 1D Constant: {data_1d_constant} -> Z-Score: {normalize_z_score(data_1d_constant)}")
   logger.info(f"Original 1D Single Val: {data_1d_single_val} -> Z-Score: {normalize_z_score(data_1d_single_val)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nZ-Score axis=0:\n{normalize_z_score(data_2d_simple, axis=0)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nZ-Score axis=1:\n{normalize_z_score(data_2d_simple, axis=1)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nZ-Score axis=None:\n{normalize_z_score(data_2d_simple, axis=None)}")
   logger.info(f"Original 2D Constant Col:\n{data_2d_constant_col}\nZ-Score axis=0:\n{normalize_z_score(data_2d_constant_col, axis=0)}")

   logger.info("\n=========== Pruebas de Robust Scaler (IQR) ===========")
   data_1d_outlier = np.array([1.0, 2.0, 1.5, 2.5, 1.8, 2.2, 15.0]) # Outlier
   logger.info(f"Original 1D Outlier: {data_1d_outlier} -> Robust Scaler: {robust_scaler_iqr(data_1d_outlier)}")
   logger.info(f"Original 1D Constant: {data_1d_constant} -> Robust Scaler: {robust_scaler_iqr(data_1d_constant)}")
   logger.info(f"Original 2D Simple:\n{data_2d_simple}\nRobust Scaler axis=0:\n{robust_scaler_iqr(data_2d_simple, axis=0)}")
   logger.info(f"Original 2D Constant Col:\n{data_2d_constant_col}\nRobust Scaler axis=0:\n{robust_scaler_iqr(data_2d_constant_col, axis=0)}")
