"""
emg_calibration.py

Módulo avanzado para la calibración de señales EMG. Este módulo se encarga de
determinar y aplicar correcciones (offset y ganancia) a las señales EMG para
mejorar la calidad y consistencia de las mediciones.

Características Principales:
- Adquisición de Datos de Calibración: Utiliza EMGAcquisition para obtener datos
  durante un período de reposo o con contracciones de referencia.
- Cálculo de Offset: Estima el offset de la línea base de la señal, con opción
  de aplicar filtros durante este proceso para mayor estabilidad.
- Cálculo de Ganancia (MVC): Implementa la calibración de ganancia basada en
  Contracción Voluntaria Máxima (MVC), permitiendo múltiples intentos y
  descansos.
- Aplicación de Calibración: Corrige nuevas señales EMG usando los parámetros calculados.
- Persistencia: Guarda y carga parámetros de calibración (CalibrationParamsModel)
  usando un DataManager (e.g., GestorDatos), asociados a un ID de paciente.
- Comparación con Referencia: Funcionalidad para comparar una señal calibrada
  con una señal de referencia previamente guardada, calculando MSE y similitud.
- Ajuste a Referencia: Intenta escalar y ajustar una señal nueva para que se
  asemeje a una señal de referencia.
- Configuración Detallada: Utiliza modelos Pydantic (CalibrationRunConfig, EMGFilterConfig)
  para una configuración robusta de las ejecuciones de calibración.
"""

import os
import json
import logging
import time
from datetime import datetime
from typing import Optional, Tuple, Dict, Any, List, Union

import numpy as np
from pydantic import BaseModel, PositiveFloat, PositiveInt, Field # Para validación de config

# Importaciones de módulos del proyecto
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition, EMGDeviceAcqConfig, EMGFilterConfig, SerialConfig
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.data.models.calibration_params import CalibrationParamsModel
from BitnnariApp.processing.filters import design_butter_filter, apply_sos_filter # Usar filtros de nuestro módulo

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


class CalibrationRunConfig(BaseModel):
    """
    Configuración para una ejecución específica de calibración.
    Permite definir duraciones, número de intentos, y si se aplican filtros.
    """
    offset_duration_s: PositiveFloat = Field(5.0, description="Duración (s) para la adquisición de datos de offset en reposo.")
    mvc_duration_s: PositiveFloat = Field(3.0, description="Duración (s) para cada contracción MVC.")
    num_mvc_trials: PositiveInt = Field(3, description="Número de intentos para la calibración MVC.")
    rest_between_mvc_s: PositiveFloat = Field(10.0, description="Tiempo de descanso (s) entre intentos de MVC.")
    apply_filter_during_offset_cal: bool = Field(True, description="Si aplicar filtros al calcular el offset.")
    filter_config_for_cal: Optional[EMGFilterConfig] = Field(None, description="Configuración de filtros a usar durante la calibración (si apply_filter_during_offset_cal es True).")
    # Podríamos añadir más, como qué tipo de MVC (isométrica, dinámica), etc.


class EMGCalibrationManager:
    """
    Gestiona el proceso de calibración de señales EMG.
    Calcula offset y ganancia (basada en MVC) para cada canal.
    Se integra con EMGAcquisition para la toma de datos y con GestorDatos para la persistencia.
    """
    REFERENCE_DATA_SUBDIR = "calibration_references" # Subdirectorio dentro de la carpeta del paciente

    def __init__(self,
                 data_manager: GestorDatos,
                 emg_acquirer: Optional[EMGAcquisition] = None,
                 patient_dni: Optional[str] = None):
        self.data_manager = data_manager
        self.emg_acquirer = emg_acquirer
        self.patient_dni = patient_dni

        self.current_calibration_params: Optional[CalibrationParamsModel] = None
        
        if patient_dni:
            self.load_latest_calibration_params(patient_dni)
        else:
            # Si no hay paciente, inicializar con num_channels=0 o un valor por defecto si se conoce
            # self.current_calibration_params podría ser None o un CalibrationParamsModel con valores nulos/default
            pass


    def set_patient_dni(self, patient_dni: str) -> None:
        """Establece o cambia el DNI del paciente y carga sus últimos parámetros de calibración."""
        if self.patient_dni != patient_dni:
            self.patient_dni = patient_dni
            self.load_latest_calibration_params(patient_dni)
        elif self.current_calibration_params is None: # DNI es el mismo pero no se cargaron params
             self.load_latest_calibration_params(patient_dni)


    def set_emg_acquirer(self, emg_acquirer: EMGAcquisition) -> None:
        """Establece la instancia de EMGAcquisition a utilizar."""
        self.emg_acquirer = emg_acquirer

    def _acquire_data_for_calibration(self, duration_s: float, acquisition_message: str) -> Optional[np.ndarray]:
        """
        Helper interno para adquirir datos usando self.emg_acquirer.
        Asegura que el dispositivo esté conectado y en modo continuo.
        """
        if self.emg_acquirer is None:
            logger.error("EMGAcquisition no está configurado. No se pueden adquirir datos de calibración.")
            return None
        
        if not self.emg_acquirer.is_connected():
            logger.info("EMGAcquisition no conectado. Intentando conectar para calibración...")
            if not self.emg_acquirer.connect():
                logger.error("Fallo al conectar con EMGAcquisition para calibración.")
                return None
        
        logger.info(f"{acquisition_message} Adquiriendo durante {duration_s} segundos...")
        
        original_acq_mode = self.emg_acquirer.acq_config.mode
        self.emg_acquirer.set_mode('continuous') # Forzar modo continuo para asegurar flujo de datos

        collected_data: List[List[float]] = []
        num_channels = self.emg_acquirer.acq_config.num_channels_active
        
        # Inicializar listas internas para cada canal
        for _ in range(num_channels):
            collected_data.append([])

        start_time = time.time()
        packets_to_collect = int(duration_s * (1000.0 / self.emg_acquirer.acq_config.delay_ms)) \
            if self.emg_acquirer.acq_config.delay_ms > 0 else int(duration_s * 100) # Fallback a 100Hz
        
        packets_collected = 0
        while (time.time() - start_time < duration_s) and (packets_collected < packets_to_collect if packets_to_collect > 0 else True):
            packet = self.emg_acquirer.read_data()
            if packet and 'raw_data' in packet:
                # raw_data es una lista de floats, un valor por canal activo
                if len(packet['raw_data']) == num_channels:
                    for i in range(num_channels):
                        collected_data[i].append(packet['raw_data'][i])
                    packets_collected +=1
                else:
                    logger.warning(f"Paquete de calibración con {len(packet['raw_data'])} valores, se esperaban {num_channels}.")
            time.sleep(0.0005) # Pequeña pausa para no consumir 100% CPU si el delay del Arduino es muy bajo

        self.emg_acquirer.set_mode(original_acq_mode) # Restaurar modo de adquisición original

        if not any(collected_data): # Si todas las listas de canales están vacías
            logger.warning("No se adquirieron datos válidos durante la calibración.")
            return None
        
        # Asegurar que todos los canales tengan la misma longitud (rellenando si es necesario, aunque no ideal)
        min_len = min(len(ch_data) for ch_data in collected_data if ch_data) if any(collected_data) else 0
        if min_len == 0 and any(collected_data): # Algún canal tiene datos, otros no
             logger.warning("Algunos canales no recibieron datos durante la calibración.")
             # Podríamos decidir fallar o rellenar con ceros/NaNs. Por ahora, fallamos si no hay datos consistentes.
             if not all(len(ch_data) > 0 for ch_data in collected_data):
                 logger.error("No todos los canales tienen datos. Fallo en la adquisición de calibración.")
                 return None
        
        # Convertir a NumPy array [canales, muestras] y luego transponer a [muestras, canales]
        # si todas las listas tienen la misma longitud.
        try:
            # Rellenar listas más cortas con el último valor o ceros si es necesario
            # o truncar todas a la longitud mínima. Truncar es más seguro.
            if min_len > 0:
                processed_collected_data = [ch_data[:min_len] for ch_data in collected_data]
                return np.array(processed_collected_data, dtype=float).T # Devuelve [muestras, canales]
            else: # No se recolectaron muestras válidas
                return None
        except ValueError as e:
            logger.error(f"Error al convertir datos de calibración a array (posiblemente longitudes de canal desiguales): {e}")
            return None


    def perform_offset_calibration(self, run_config: CalibrationRunConfig) -> bool:
        """
        Realiza la calibración del offset (línea base).
        Adquiere datos durante un período de reposo y calcula el offset medio.

        Args:
            run_config (CalibrationRunConfig): Configuración para esta ejecución.

        Returns:
            bool: True si la calibración fue exitosa, False en caso contrario.
        """
        if self.emg_acquirer is None:
            logger.error("EMGAcquirer no disponible para calibración de offset.")
            return False

        raw_data_for_offset = self._acquire_data_for_calibration(
            run_config.offset_duration_s,
            "Calibración de Offset: Mantener músculos en reposo."
        )

        if raw_data_for_offset is None or raw_data_for_offset.shape[0] == 0:
            logger.error("No se pudieron adquirir datos para la calibración de offset.")
            return False
        
        num_acquired_channels = raw_data_for_offset.shape[1]
        
        data_to_process = raw_data_for_offset
        if run_config.apply_filter_during_offset_cal and run_config.filter_config_for_cal:
            # Usar un procesador temporal o el del emg_acquirer si está disponible
            # y si su configuración es la deseada.
            # Aquí, creamos uno temporal para asegurar que se usa la config de run_config.
            temp_processor = EMGProcessingEngine(
                sampling_rate=self.emg_acquirer.processor.config.sample_rate, # Usar la tasa de muestreo del adquisidor
            )
            temp_processor.filters_config = temp_processor.DEFAULT_FILTER_CONFIG.copy() # Empezar con defaults
            # Aplicar solo filtros relevantes para offset (e.g., HP para DC, Notch)
            temp_processor.configure_filter("highpass", {
                "enabled": True, 
                "cutoff_hz": run_config.filter_config_for_cal.bandpass_low_freq or 1.0, # Usar un HP bajo
                "order": run_config.filter_config_for_cal.bandpass_order
            })
            if run_config.filter_config_for_cal.notch_freq:
                temp_processor.configure_filter("notch", {
                    "enabled": True,
                    "freq_hz": run_config.filter_config_for_cal.notch_freq,
                    "quality_factor": run_config.filter_config_for_cal.notch_quality
                })
            
            # Deshabilitar otros filtros que podrían distorsionar la media para el offset
            temp_processor.configure_filter("lowpass", {"enabled": False})
            temp_processor.configure_filter("baseline_correction", {"enabled": False}) # No queremos quitar la media aún
            temp_processor.configure_filter("normalization", {"enabled": False})

            data_to_process = temp_processor.process_signal(raw_data_for_offset)
            logger.info("Filtros aplicados para cálculo de offset.")
        
        calculated_offset = np.mean(data_to_process, axis=0)
        
        # Actualizar o crear el objeto de parámetros de calibración
        cal_id = f"offset_cal_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        if self.current_calibration_params and self.current_calibration_params.patient_dni == self.patient_dni:
            self.current_calibration_params.offset_values = calculated_offset.tolist()
            self.current_calibration_params.num_channels = num_acquired_channels
            self.current_calibration_params.timestamp = datetime.utcnow()
            self.current_calibration_params.calibration_id = cal_id # Actualizar ID si se recalibra
            self.current_calibration_params.raw_data_mean_during_cal = np.mean(raw_data_for_offset, axis=0).tolist()
            self.current_calibration_params.raw_data_std_during_cal = np.std(raw_data_for_offset, axis=0).tolist()
            if run_config.filter_config_for_cal:
                 self.current_calibration_params.filter_settings_snapshot = run_config.filter_config_for_cal.model_dump()
        else:
            self.current_calibration_params = CalibrationParamsModel(
                calibration_id=cal_id,
                patient_dni=self.patient_dni or "unknown_patient",
                num_channels=num_acquired_channels,
                offset_values=calculated_offset.tolist(),
                raw_data_mean_during_cal=np.mean(raw_data_for_offset, axis=0).tolist(),
                raw_data_std_during_cal=np.std(raw_data_for_offset, axis=0).tolist(),
                filter_settings_snapshot=run_config.filter_config_for_cal.model_dump() if run_config.filter_config_for_cal else {}
            )
        
        logger.info(f"Calibración de offset completada. Offset: {self.current_calibration_params.offset_values}")
        if self.patient_dni:
            self.save_current_calibration_params()
        return True

    def perform_mvc_gain_calibration(self, run_config: CalibrationRunConfig, channel_names: Optional[List[str]] = None) -> bool:
        """
        Realiza la calibración de ganancia usando Contracción Voluntaria Máxima (MVC).

        Args:
            run_config (CalibrationRunConfig): Configuración para esta ejecución.
            channel_names (Optional[List[str]]): Nombres de los canales para guiar al usuario.

        Returns:
            bool: True si la calibración fue exitosa.
        """
        if self.emg_acquirer is None:
            logger.error("EMGAcquirer no disponible para calibración de ganancia MVC.")
            return False
        
        num_active_channels = self.emg_acquirer.acq_config.num_channels_active
        if self.current_calibration_params is None or self.current_calibration_params.offset_values is None:
            logger.warning("Offset no calibrado o no cargado. Se recomienda calibrar offset primero para MVC. "
                           "Continuando sin corrección de offset previa para los picos MVC.")
            current_offset = np.zeros(num_active_channels)
        else:
            # Asegurar que el offset tenga la dimensión correcta
            if len(self.current_calibration_params.offset_values) == num_active_channels:
                current_offset = np.array(self.current_calibration_params.offset_values)
            else:
                logger.warning(f"Discrepancia en número de canales entre offset ({len(self.current_calibration_params.offset_values)}) "
                               f"y adquisición actual ({num_active_channels}). Usando offset de ceros para MVC.")
                current_offset = np.zeros(num_active_channels)

        all_mvc_peaks_per_channel: List[List[float]] = [[] for _ in range(num_active_channels)]

        for trial in range(run_config.num_mvc_trials):
            logger.info(f"\n--- Prueba MVC {trial + 1}/{run_config.num_mvc_trials} ---")
            # Aquí, en una GUI, se mostraría un mensaje al usuario para cada canal/músculo.
            # En modo consola, se puede pedir input o asumir una secuencia.
            for ch_idx in range(num_active_channels):
                ch_name = channel_names[ch_idx] if channel_names and ch_idx < len(channel_names) else f"Canal {ch_idx + 1}"
                input(f"PREPARADO para MVC del {ch_name}. Realice contracción máxima y presione Enter para iniciar ({run_config.mvc_duration_s}s)...")
                
                mvc_data_ch = self._acquire_data_for_calibration(
                    run_config.mvc_duration_s,
                    f"Adquiriendo MVC para {ch_name}..."
                )
                if mvc_data_ch is None or mvc_data_ch.shape[0] == 0:
                    logger.error(f"No se adquirieron datos para MVC de {ch_name} en prueba {trial + 1}.")
                    all_mvc_peaks_per_channel[ch_idx].append(0.0) # Registrar un pico de cero
                    continue

                # Procesar los datos del canal actual para esta prueba MVC
                signal_for_peak = mvc_data_ch[:, ch_idx] - current_offset[ch_idx] # Corregir offset
                
                # Aplicar filtros si están configurados (ej. rectificación, suavizado para envolvente)
                if run_config.filter_config_for_cal:
                    # Para MVC, a menudo se rectifica y luego se suaviza (LPF) para obtener la envolvente.
                    # O se calcula el RMS en ventanas.
                    # Usaremos un procesador temporal con una configuración típica para envolvente.
                    temp_processor_mvc = EMGProcessingEngine(sampling_rate=self.emg_acquirer.processor.config.sample_rate)
                    temp_processor_mvc.filters_config = temp_processor_mvc.DEFAULT_FILTER_CONFIG.copy()
                    temp_processor_mvc.configure_filter("baseline_correction", {"enabled": False}) # Ya se restó offset
                    temp_processor_mvc.configure_filter("highpass", {"enabled": False}) # Podría atenuar la envolvente
                    temp_processor_mvc.configure_filter("notch", {"enabled": False}) # Ya debería estar en offset_cal
                    temp_processor_mvc.configure_filter("lowpass", {"enabled": True, "cutoff_hz": 5.0, "order": 2}) # Suavizado de envolvente
                    
                    rectified_signal = np.abs(signal_for_peak)
                    envelope = temp_processor_mvc.process_signal(rectified_signal) # Solo LPF
                    peak_value = np.max(envelope)
                else: # Sin filtros, tomar el máximo del absoluto corregido por offset
                    peak_value = np.max(np.abs(signal_for_peak))
                
                all_mvc_peaks_per_channel[ch_idx].append(peak_value)
                logger.info(f"Pico MVC para {ch_name} (prueba {trial+1}): {peak_value:.4f}")

            if trial < run_config.num_mvc_trials - 1:
                logger.info(f"Descansar {run_config.rest_between_mvc_s} segundos antes de la siguiente prueba MVC...")
                time.sleep(run_config.rest_between_mvc_s)
        
        # Calcular la ganancia: 1.0 / (valor máximo de MVC para cada canal)
        # O normalizar a un valor de referencia (e.g., 100 si se quiere que MVC sea 100%)
        max_overall_mvc_peaks = [max(peaks) if peaks else 0.0 for peaks in all_mvc_peaks_per_channel]
        
        calculated_gain = np.zeros(num_active_channels)
        for i in range(num_active_channels):
            if max_overall_mvc_peaks[i] > 1e-9: # Evitar división por cero
                calculated_gain[i] = 1.0 / max_overall_mvc_peaks[i]
            else:
                calculated_gain[i] = 1.0 # Ganancia unitaria si no hubo actividad MVC significativa
                logger.warning(f"Pico MVC para canal {i+1} fue cero o muy bajo. Se establece ganancia a 1.0.")

        # Actualizar o crear el objeto de parámetros de calibración
        cal_id = f"mvc_cal_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        if self.current_calibration_params and self.current_calibration_params.patient_dni == self.patient_dni:
            self.current_calibration_params.gain_values = calculated_gain.tolist()
            self.current_calibration_params.mvc_peak_values = max_overall_mvc_peaks
            self.current_calibration_params.timestamp = datetime.utcnow() # Actualizar timestamp general
            # No necesariamente se actualiza el calibration_id aquí, podría ser una extensión de la cal existente
        else: # Crear nuevo si no existe o es de otro paciente
            self.current_calibration_params = CalibrationParamsModel(
                calibration_id=cal_id,
                patient_dni=self.patient_dni or "unknown_patient",
                num_channels=num_active_channels,
                offset_values=current_offset.tolist() if self.current_calibration_params else [0.0]*num_active_channels, # Usar offset si existía
                gain_values=calculated_gain.tolist(),
                mvc_peak_values=max_overall_mvc_peaks,
                filter_settings_snapshot=run_config.filter_config_for_cal.model_dump() if run_config.filter_config_for_cal else {}
            )

        logger.info(f"Calibración de ganancia MVC completada. Ganancias: {self.current_calibration_params.gain_values}")
        if self.patient_dni:
            self.save_current_calibration_params()
        return True

    def apply_calibration_to_signal(self, raw_signal_data: np.ndarray) -> np.ndarray:
        """Aplica los parámetros de calibración (offset y ganancia) a una señal."""
        if self.current_calibration_params is None:
            logger.warning("No hay parámetros de calibración cargados o calculados. Devolviendo señal original.")
            return raw_signal_data
        
        signal_arr = np.array(raw_signal_data, dtype=float)
        if signal_arr.ndim == 1: signal_arr = signal_arr[:, np.newaxis] # [samples, 1]
        
        if signal_arr.shape[1] != self.current_calibration_params.num_channels:
            logger.error(f"Discrepancia en número de canales: señal ({signal_arr.shape[1]}) vs calibración ({self.current_calibration_params.num_channels}).")
            return raw_signal_data # Devolver original si hay error de dimensiones

        calibrated_signal = signal_arr
        if self.current_calibration_params.offset_values:
            offset = np.array(self.current_calibration_params.offset_values)
            calibrated_signal = calibrated_signal - offset[np.newaxis, :]
        
        if self.current_calibration_params.gain_values:
            gain = np.array(self.current_calibration_params.gain_values)
            calibrated_signal = calibrated_signal * gain[np.newaxis, :]
            
        return calibrated_signal.squeeze()


    def save_current_calibration_params(self) -> bool:
        """Guarda los parámetros de calibración actuales usando el DataManager."""
        if self.current_calibration_params is None:
            logger.warning("No hay parámetros de calibración actuales para guardar.")
            return False
        if not self.patient_dni: # Asegurar que tenemos un DNI de paciente
             self.patient_dni = self.current_calibration_params.patient_dni
        
        if not self.patient_dni or self.patient_dni == "unknown_patient":
            logger.error("No se puede guardar calibración sin un DNI de paciente válido.")
            return False

        return self.data_manager.guardar_calibracion(self.current_calibration_params)

    def load_calibration_params(self, patient_dni: str, calibration_id: str) -> bool:
        """Carga un conjunto específico de parámetros de calibración."""
        params = self.data_manager.obtener_calibracion(patient_dni, calibration_id)
        if params:
            self.current_calibration_params = params
            self.patient_dni = patient_dni # Asegurar que el DNI del manager esté actualizado
            logger.info(f"Parámetros de calibración '{calibration_id}' cargados para paciente {patient_dni}.")
            return True
        else:
            logger.warning(f"No se encontraron parámetros de calibración '{calibration_id}' para {patient_dni}.")
            # Mantener los params actuales o resetear? Por ahora, mantener.
            return False

    def load_latest_calibration_params(self, patient_dni: str) -> bool:
        """Carga los parámetros de calibración más recientes para un paciente."""
        latest_params = self.data_manager.obtener_ultima_calibracion(patient_dni)
        if latest_params:
            self.current_calibration_params = latest_params
            self.patient_dni = patient_dni
            logger.info(f"Últimos parámetros de calibración (ID: {latest_params.calibration_id}) cargados para {patient_dni}.")
            return True
        else:
            logger.info(f"No se encontraron parámetros de calibración previos para {patient_dni}. "
                        "Se necesitará una nueva calibración.")
            self.current_calibration_params = None # Resetear si no hay nada
            # Podríamos inicializar un CalibrationParamsModel vacío aquí si fuera necesario
            # self.current_calibration_params = CalibrationParamsModel(
            #     calibration_id=f"default_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            #     patient_dni=patient_dni,
            #     num_channels=self.emg_acquirer.acq_config.num_channels_active if self.emg_acquirer else 0
            # )
            return False

    def reset_calibration(self) -> None:
        """Resetea los parámetros de calibración actuales."""
        self.current_calibration_params = None
        logger.info("Parámetros de calibración reseteados en el manager.")

    # --- Funciones de comparación y ajuste con referencia (ya definidas en el módulo, las usamos aquí) ---
    # Estas funciones ahora tomarían el `patient_dni` o `reference_id` y usarían el `data_manager`
    # para cargar la señal de referencia desde el repositorio.

    def _get_reference_signal_path(self, reference_id: str) -> Optional[str]:
        """Obtiene la ruta al archivo de la señal de referencia."""
        if not self.patient_dni:
            logger.error("DNI del paciente no establecido para obtener ruta de referencia.")
            return None
        # Asumimos que el DataManager o Repository tienen una forma de manejar esto.
        # Por ahora, construimos una ruta simple.
        # Esta lógica debería estar más centralizada en el LocalFileRepository.
        ref_dir = self.data_manager.repo._get_patient_dir(self.patient_dni) / self.REFERENCE_DATA_SUBDIR
        ref_dir.mkdir(parents=True, exist_ok=True)
        return str(ref_dir / f"{reference_id}.json")

    def save_signal_as_reference(self, signal_data: np.ndarray, reference_id: str, sampling_rate: float) -> bool:
        """Guarda una señal como referencia para el paciente actual."""
        if not self.patient_dni:
            logger.error("No se puede guardar referencia sin DNI de paciente.")
            return False
        
        path = self._get_reference_signal_path(reference_id)
        if not path: return False

        data_to_save = {
            "reference_id": reference_id,
            "patient_dni": self.patient_dni,
            "timestamp": datetime.now().isoformat(),
            "sampling_rate_hz": sampling_rate,
            "num_channels": signal_data.shape[1] if signal_data.ndim == 2 else 1,
            "data_orientation": "samples_x_channels", # O "channels_x_samples"
            "data": signal_data.tolist()
        }
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, indent=4)
            logger.info(f"Señal de referencia '{reference_id}' para paciente {self.patient_dni} guardada en {path}.")
            return True
        except IOError as e:
            logger.error(f"Error al guardar señal de referencia '{reference_id}': {e}")
            return False

    def load_reference_signal(self, reference_id: str) -> Optional[Tuple[np.ndarray, float]]:
        """Carga una señal de referencia guardada para el paciente actual. Devuelve (señal, fs)."""
        if not self.patient_dni:
            logger.error("No se puede cargar referencia sin DNI de paciente.")
            return None
            
        path = self._get_reference_signal_path(reference_id)
        if not (path and os.path.exists(path)):
            logger.warning(f"Archivo de referencia '{reference_id}' no encontrado para paciente {self.patient_dni}.")
            return None
        try:
            with open(path, 'r', encoding='utf-8') as f:
                ref_content = json.load(f)
            
            signal_data = np.array(ref_content.get("data", []))
            fs = float(ref_content.get("sampling_rate_hz", 0.0))
            
            # Manejar orientación si se guardó
            orientation = ref_content.get("data_orientation", "samples_x_channels")
            if orientation == "channels_x_samples" and signal_data.ndim == 2:
                signal_data = signal_data.T # Convertir a [samples, channels] si es necesario

            return signal_data, fs
        except (IOError, json.JSONDecodeError, ValueError) as e:
            logger.error(f"Error al cargar o parsear señal de referencia '{reference_id}': {e}")
            return None

    @staticmethod
    def calculate_mse(signal1: np.ndarray, signal2: np.ndarray) -> float:
        # Implementación idéntica a la del módulo de filtros, podría ser una utilidad compartida.
        if signal1.shape != signal2.shape:
            min_len = min(signal1.shape[0], signal2.shape[0])
            s1_adjusted = signal1[:min_len]
            s2_adjusted = signal2[:min_len]
            if s1_adjusted.shape[0] < 2: return float('inf') # No se puede calcular MSE con menos de 2 puntos
            logger.warning(f"Formas de señal no coinciden ({signal1.shape} vs {signal2.shape}), truncando a {min_len} muestras para MSE.")
            if s1_adjusted.shape != s2_adjusted.shape: # Si aún no coinciden (e.g. diferente num_channels)
                 raise ValueError("Las señales deben tener la misma forma (después de posible truncamiento) para calcular MSE.")
            return float(np.mean((s1_adjusted - s2_adjusted) ** 2))
        if signal1.shape[0] < 2 : return float('inf')
        return float(np.mean((signal1 - signal2) ** 2))

    def compare_signal_with_reference(self, new_signal: np.ndarray, reference_id: str) -> Optional[Dict[str, float]]:
        """Compara una nueva señal (ya calibrada por este manager) con una referencia guardada."""
        load_result = self.load_reference_signal(reference_id)
        if load_result is None:
            return None
        reference_signal, _ = load_result # fs_ref no se usa aquí directamente para MSE

        # Asumimos que new_signal ya ha pasado por self.apply_calibration_to_signal() si es necesario
        try:
            mse = self.calculate_mse(new_signal, reference_signal)
            
            # Similitud simple basada en MSE normalizado por la potencia de la referencia
            # (Esto es una métrica, hay muchas formas de definir similitud)
            power_ref = np.mean(reference_signal**2)
            if power_ref < 1e-9: # Evitar división por cero y si la referencia es casi cero
                similarity = 100.0 if mse < 1e-9 else 0.0
            else:
                normalized_mse = mse / power_ref
                similarity = max(0.0, 100.0 * (1.0 - normalized_mse))
            
            return {"mse": mse, "similarity_percent": similarity}
        except ValueError as e:
            logger.error(f"Error al comparar señales con referencia '{reference_id}': {e}")
            return None


# Ejemplo de Uso
if __name__ == "__main__":
    # --- Configuración para el ejemplo ---
    test_patient_dni = "CAL_MGR_TEST_001"
    
    # Crear un GestorDatos dummy para el ejemplo
    class DummyGestorDatosMgr: # Renombrar para evitar conflicto con el importado
        def __init__(self):
            self.db = {}
            self.repo = self # Simular que el repo es parte del gestor
            self.BASE_DATA_DIR = Path("./temp_cal_mgr_data") # Para _get_reference_signal_path
            self.REFERENCE_DATA_SUBDIR = EMGCalibrationManager.REFERENCE_DATA_SUBDIR

        def _get_patient_dir(self, patient_dni, ensure_exists=True): # Necesario para _get_reference_signal_path
            path = self.BASE_DATA_DIR / "patients" / patient_dni
            if ensure_exists: path.mkdir(parents=True, exist_ok=True)
            return path

        def guardar_calibracion(self, params: CalibrationParamsModel) -> bool:
            key = (params.patient_dni, "calibration_params", params.calibration_id)
            self.db[key] = params.to_dict()
            logger.info(f"[DummyGestorMgr] Guardando calibración {params.calibration_id} para {params.patient_dni}")
            return True

        def obtener_calibracion(self, patient_dni: str, calibration_id: str) -> Optional[CalibrationParamsModel]:
            key = (patient_dni, "calibration_params", calibration_id)
            data = self.db.get(key)
            logger.info(f"[DummyGestorMgr] Obteniendo calibración {calibration_id} para {patient_dni}")
            return CalibrationParamsModel.from_dict(data) if data else None
        
        def obtener_ultima_calibracion(self, patient_dni: str) -> Optional[CalibrationParamsModel]:
            all_cals = [v for k, v in self.db.items() if k[0] == patient_dni and k[1] == "calibration_params"]
            if not all_cals: return None
            all_cals_models = [CalibrationParamsModel.from_dict(c) for c in all_cals]
            all_cals_models.sort(key=lambda c: c.timestamp, reverse=True)
            logger.info(f"[DummyGestorMgr] Obteniendo última calibración para {patient_dni}")
            return all_cals_models[0]

    dummy_data_manager = DummyGestorDatosMgr()

    # Configuración de EMGAcquisition (para simulación)
    serial_conf = SerialConfig(port="SIM_CAL") # Puerto no importa en simulación
    acq_conf_dev = EMGDeviceAcqConfig(num_channels_active=2, delay_ms=10) # 100 Hz
    filter_conf_dev = EMGFilterConfig(sample_rate=100.0)
    log_conf_dev = LogConfig(enabled=False) # Deshabilitar logs de adquisición para este test
    
    sim_acquirer = EMGAcquisition(serial_conf, acq_conf_dev, filter_conf_dev, log_conf_dev, simulate=True)

    # Crear instancia del CalibrationManager
    cal_manager = EMGCalibrationManager(
        data_manager=dummy_data_manager, # type: ignore
        emg_acquirer=sim_acquirer,
        patient_dni=test_patient_dni
    )

    # Definir configuración para la ejecución de calibración
    filter_settings_for_cal = EMGFilterConfig(
        sample_rate=100.0, # Coincidir con la tasa de adquisición
        notch_freq=50.0,
        bandpass_low_freq=5.0, # HP bajo para offset
        bandpass_high_freq=45.0 # LP para eliminar ruido HF pero mantener línea base
    )
    run_config = CalibrationRunConfig(
        offset_duration_s=2.0, # Corto para prueba rápida
        apply_filter_during_offset_cal=True,
        filter_config_for_cal=filter_settings_for_cal,
        mvc_duration_s=1.5,
        num_mvc_trials=1, # Solo 1 trial para prueba rápida
        rest_between_mvc_s=1.0
    )

    logger.info("\n--- Realizando Calibración de Offset ---")
    if cal_manager.perform_offset_calibration(run_config):
        logger.info(f"Offset Calibrado: {cal_manager.current_calibration_params.offset_values if cal_manager.current_calibration_params else 'N/A'}") # type: ignore

        logger.info("\n--- Realizando Calibración de Ganancia MVC ---")
        # input() será llamado aquí si se ejecuta interactivamente.
        # Para un test automático, se podría mockear input() o diseñar para no requerirlo en simulación.
        # Por ahora, asumimos que se presiona Enter.
        if cal_manager.perform_mvc_gain_calibration(run_config, channel_names=["Biceps", "Triceps"]):
            logger.info(f"Ganancia MVC Calibrada: {cal_manager.current_calibration_params.gain_values if cal_manager.current_calibration_params else 'N/A'}") # type: ignore
            
            # Aplicar a una señal de prueba
            test_raw_signal = np.random.rand(100, sim_acquirer.acq_config.num_channels_active) + 0.5 # Señal con offset
            calibrated_signal = cal_manager.apply_calibration_to_signal(test_raw_signal)
            logger.info(f"Media señal cruda (antes de aplicar): {np.mean(test_raw_signal, axis=0)}")
            logger.info(f"Media señal calibrada: {np.mean(calibrated_signal, axis=0)}") # Debería estar cerca de cero

            # Guardar como referencia
            cal_manager.save_signal_as_reference(calibrated_signal, "mvc_calibrated_ref", sim_acquirer.processor.config.sample_rate)
            
            # Comparar
            slightly_different_signal = calibrated_signal * 1.1 + np.random.normal(0, 0.05, calibrated_signal.shape)
            comparison = cal_manager.compare_signal_with_reference(slightly_different_signal, "mvc_calibrated_ref")
            if comparison:
                logger.info(f"Comparación con referencia: {comparison}")

    sim_acquirer.close()
    # Limpiar directorio temporal
    if dummy_data_manager.BASE_DATA_DIR.exists():
        shutil.rmtree(dummy_data_manager.BASE_DATA_DIR)