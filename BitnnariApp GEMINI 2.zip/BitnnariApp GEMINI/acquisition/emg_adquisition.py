      """
emg_adquisition.py

Módulo completo para adquisición y procesamiento de señales EMG desde un dispositivo
externo (e.g., Arduino), diseñado para ser robusto, configurable y extensible.

Características Principales:
- Comunicación Serial: Gestión de conexión, desconexión y reconexión automática.
- Detección Automática de Puerto: Intenta encontrar el puerto del dispositivo.
- Protocolo de Paquetes: Lectura de tramas de bytes con cabecera, contador de canales,
  timestamp, datos de múltiples canales y checksum CRC8 para integridad.
- Comandos al Dispositivo: Envío de comandos para configurar modo de adquisición
  (continuo/por tiempo), delay entre muestras y número de canales.
- Procesamiento de Señal: Integración con EMGDataProcessor para aplicar filtros
  (Notch, Pasa-Banda Butterworth) en tiempo real.
- Detección de Paquetes Perdidos: Basado en la diferencia de timestamps de Arduino.
- Registro de Datos (Logging):
    - DataLogger: Guarda datos crudos, filtrados, timestamps y paquetes perdidos.
    - Formatos Soportados: CSV y JSON.
    - Nomenclatura de Archivos: Timestamps para unicidad.
- Modo Simulación: Permite probar la funcionalidad sin hardware conectado.
- Threading (PyQt6): Uso de QThread para operaciones de adquisición sin bloquear la UI.
- Callbacks: Sistema para registrar funciones que se ejecutarán con cada nuevo dato.
- Configuración Detallada: Uso de dataclasses para una configuración clara y tipada
  (Serial, Filtros, Adquisición en dispositivo, Logs).
- Manejo de Errores: Logging detallado de eventos y errores.
"""
import serial
import serial.tools.list_ports
import struct
import json
import logging
import time
import csv
import numpy as np
from scipy import signal
from typing import Optional, Dict, Any, List, Callable, Union
from PyQt6.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker, QObject
from datetime import datetime
from collections import deque
import threading
from dataclasses import dataclass, field

# Dependencia externa: crcmod (pip install crcmod)
try:
    import crcmod.predefined
    # Usar un polinomio común para CRC-8, por ejemplo, CRC-8-ATM (0x07) o CRC-8-MAXIM (0x31)
    # El polinomio 0x07 es X^8 + X^2 + X + 1
    crc8_func = crcmod.predefined.mkPredefinedCrcFun('crc-8')
except ImportError:
    logging.warning("Librería 'crcmod' no encontrada. Usando CRC dummy (siempre retorna 0). "
                    "La verificación de integridad de paquetes estará desactivada.")
    crc8_func = lambda data: 0 # type: ignore

# Configuración de logging
logger = logging.getLogger(__name__) # Usar __name__ para el logger del módulo
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Constantes del Protocolo y Dispositivo
PACKET_HEADER = 0xAA
MAX_CHANNELS_HW = 8  # Máximo número de canales que el hardware puede enviar en un paquete
# Tamaño esperado del paquete: Header(1) + NumActiveChannels(1) + Timestamp(4) + Data(MAX_CHANNELS_HW * 2 bytes/canal) + CRC(1)
EXPECTED_PACKET_SIZE_BASE = 1 + 1 + 4 # Header, NumActiveChannels, Timestamp
EXPECTED_PACKET_CRC_SIZE = 1

def calculate_expected_packet_size(max_channels_hw: int) -> int:
    """Calcula el tamaño esperado del paquete basado en MAX_CHANNELS_HW."""
    return EXPECTED_PACKET_SIZE_BASE + (max_channels_hw * 2) + EXPECTED_PACKET_CRC_SIZE

EXPECTED_PACKET_SIZE = calculate_expected_packet_size(MAX_CHANNELS_HW)

# Clases de Configuración (Dataclasses)
@dataclass
class SerialConfig:
    """Configuración de la conexión serial."""
    port: Optional[str] = None
    baud_rate: int = 115200
    timeout: float = 1.0  # Segundos
    auto_connect: bool = True
    reconnect_delay: float = 5.0  # Segundos
    arduino_identifiers: List[str] = field(default_factory=lambda: ["Arduino", "USB-SERIAL CH340", "QinHeng Electronics CH340"])


@dataclass
class FilterConfig:
    """Configuración de los filtros de procesamiento de señal."""
    sample_rate: float = 1000.0  # Hz
    notch_freq: Optional[float] = 50.0  # Hz (e.g., 50Hz o 60Hz para interferencia de red)
    notch_quality: float = 30.0
    bandpass_low_freq: Optional[float] = 20.0  # Hz
    bandpass_high_freq: Optional[float] = 450.0  # Hz
    bandpass_order: int = 4
    enabled: bool = True


@dataclass
class AcquisitionConfig:
    """Configuración de la adquisición en el dispositivo (e.g., Arduino)."""
    delay_ms: int = 10  # Delay entre muestras en el Arduino (ms)
    num_channels_active: int = 1  # Número de canales activos que se espera leer
    mode: str = 'continuous'  # 'continuous' o 'request'


@dataclass
class LogConfig:
    """Configuración del registro de datos."""
    log_path: str = "emg_data_logs"  # Carpeta para guardar logs
    log_filename_prefix: str = "emg_session"
    log_format: str = "csv"  # 'csv' o 'json'
    log_raw_data: bool = True
    log_filtered_data: bool = True
    enabled: bool = True
    max_buffer_size: int = 10000 # Número máximo de registros en buffer si el archivo no está abierto


# Procesamiento de Datos EMG
class EMGDataProcessor:
    """Clase para el procesamiento de señales EMG, incluyendo diseño y aplicación de filtros."""
    def __init__(self, config: FilterConfig):
        self.config = config
        self._sos_notch: Optional[np.ndarray] = None
        self._sos_bandpass: Optional[np.ndarray] = None
        self._zi_notch: Optional[np.ndarray] = None
        self._zi_bandpass: Optional[np.ndarray] = None
        self._num_channels_processed_state: int = 0 # Para reinicializar zi si cambian los canales
        self._design_filters()

    def update_config(self, new_config: FilterConfig):
        """Actualiza la configuración del filtro y rediseña los filtros."""
        self.config = new_config
        self._design_filters()
        # Forzar reinicio de estados zi
        self._num_channels_processed_state = 0

    def _design_filters(self):
        """Diseña los filtros Notch y Pasa-Banda basados en la configuración."""
        fs = self.config.sample_rate
        if fs <= 0:
            logger.error("Frecuencia de muestreo debe ser positiva para diseñar filtros.")
            self._sos_notch = None
            self._sos_bandpass = None
            return

        # Filtro Notch
        if self.config.notch_freq is not None and self.config.notch_freq > 0:
            w0 = self.config.notch_freq / (fs / 2)
            if 0 < w0 < 1:
                self._sos_notch = signal.iirnotch(w0, self.config.notch_quality, fs=fs) # scipy >=1.8.0
                # For older scipy: self._sos_notch = signal.iirnotch(w0, self.config.notch_quality)
            else:
                logger.warning(f"Frecuencia Notch ({self.config.notch_freq} Hz) inválida para fs={fs} Hz. Desactivando Notch.")
                self._sos_notch = None
        else:
            self._sos_notch = None

        # Filtro Pasa-Banda (o Pasa-Alto/Pasa-Bajo si solo una frecuencia está definida)
        low = self.config.bandpass_low_freq / (fs / 2) if self.config.bandpass_low_freq is not None else None
        high = self.config.bandpass_high_freq / (fs / 2) if self.config.bandpass_high_freq is not None else None

        if low is not None and high is not None:
            if 0 < low < high < 1:
                self._sos_bandpass = signal.butter(self.config.bandpass_order, [low, high], btype='bandpass', output='sos')
            else:
                logger.warning(f"Frecuencias Pasa-Banda ({self.config.bandpass_low_freq}, {self.config.bandpass_high_freq} Hz) inválidas para fs={fs} Hz. Desactivando Pasa-Banda.")
                self._sos_bandpass = None
        elif low is not None: # Solo Pasa-Alto
            if 0 < low < 1:
                self._sos_bandpass = signal.butter(self.config.bandpass_order, low, btype='highpass', output='sos')
            else:
                logger.warning(f"Frecuencia Pasa-Alto ({self.config.bandpass_low_freq} Hz) inválida para fs={fs} Hz. Desactivando.")
                self._sos_bandpass = None
        elif high is not None: # Solo Pasa-Bajo
            if 0 < high < 1:
                self._sos_bandpass = signal.butter(self.config.bandpass_order, high, btype='lowpass', output='sos')
            else:
                logger.warning(f"Frecuencia Pasa-Bajo ({self.config.bandpass_high_freq} Hz) inválida para fs={fs} Hz. Desactivando.")
                self._sos_bandpass = None
        else:
            self._sos_bandpass = None

    def apply_filters(self, data: np.ndarray) -> np.ndarray:
        """
        Aplica los filtros diseñados a los datos EMG.
        Maneja datos de múltiples canales (espera forma [n_samples, n_channels]).
        """
        if not self.config.enabled or (self._sos_notch is None and self._sos_bandpass is None):
            return data
        
        if data.ndim == 1: # Si es un solo canal o una sola muestra multicanal
            if data.shape[0] == self._num_channels_processed_state and self._num_channels_processed_state > 0 : # Una muestra multicanal
                 data_proc = data.reshape(1, -1) # Asumir [1, n_channels]
            else: # Un solo canal con múltiples muestras
                 data_proc = data[:, np.newaxis] # Asumir [n_samples, 1]
        elif data.ndim == 2:
            data_proc = data
        else:
            logger.error(f"Formato de datos inesperado: {data.shape}. Se esperan 1D o 2D.")
            return data

        num_samples, num_channels = data_proc.shape

        # Re-inicializar estados de filtro si el número de canales cambia
        if num_channels != self._num_channels_processed_state:
            self._zi_notch = None
            self._zi_bandpass = None
            self._num_channels_processed_state = num_channels

        # Inicializar estados de filtro (zi) si es necesario
        if self._sos_notch is not None and self._zi_notch is None:
            zi_single_channel = signal.sosfilt_zi(self._sos_notch)
            self._zi_notch = np.repeat(zi_single_channel[:, np.newaxis, :], num_channels, axis=1)

        if self._sos_bandpass is not None and self._zi_bandpass is None:
            zi_single_channel = signal.sosfilt_zi(self._sos_bandpass)
            self._zi_bandpass = np.repeat(zi_single_channel[:, np.newaxis, :], num_channels, axis=1)

        # Aplicar filtros (canal por canal para manejar estados zi correctamente)
        data_filt = np.zeros_like(data_proc)
        for i in range(num_channels):
            channel_data = data_proc[:, i]
            if self._sos_notch is not None and self._zi_notch is not None:
                channel_data, self._zi_notch[:, i, :] = signal.sosfilt(self._sos_notch, channel_data, zi=self._zi_notch[:, i, :])
            if self._sos_bandpass is not None and self._zi_bandpass is not None:
                channel_data, self._zi_bandpass[:, i, :] = signal.sosfilt(self._sos_bandpass, channel_data, zi=self._zi_bandpass[:, i, :])
            data_filt[:, i] = channel_data
        
        return data_filt.squeeze() # Retornar con la misma dimensionalidad que la entrada si es posible


# Registro de Datos
class DataLogger:
    """Gestiona el registro de datos EMG en archivos CSV o JSON."""
    def __init__(self, config: LogConfig):
        self.config = config
        self.log_file: Optional[Any] = None # Puede ser TextIOWrapper o similar
        self.csv_writer: Optional[csv.writer] = None
        self._json_first_record = True
        self._active = False
        self._buffer: List[Dict[str, Any]] = deque(maxlen=self.config.max_buffer_size) # type: ignore
        self._lock = threading.Lock()

        if self.config.enabled:
            self._start_logging()

    def update_config(self, new_config: LogConfig):
        """Actualiza la configuración del logger."""
        with self._lock:
            was_enabled = self.config.enabled
            self.config = new_config
            if self.config.enabled and not was_enabled:
                self._start_logging()
            elif not self.config.enabled and was_enabled:
                self._stop_logging()

    def _start_logging(self):
        """Inicia el archivo de log."""
        if not self.config.enabled or self._active:
            return

        os.makedirs(self.config.log_path, exist_ok=True)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.config.log_path, f"{self.config.log_filename_prefix}_{timestamp_str}.{self.config.log_format}")
        
        try:
            self.log_file = open(filename, 'w', newline='', encoding='utf-8')
            if self.config.log_format == 'csv':
                self.csv_writer = None  # Se inicializará con el primer registro
            elif self.config.log_format == 'json':
                self.log_file.write('[\n')
                self._json_first_record = True
            
            self._active = True
            logger.info(f"Logging iniciado en {filename}")
            
            # Escribir buffer si hay datos pendientes
            for record in list(self._buffer): # Iterar sobre una copia
                self.add_record(record)
            self._buffer.clear()

        except IOError as e:
            logger.error(f"No se pudo abrir el archivo de log '{filename}': {e}")
            self._active = False
            self.log_file = None

    def add_record(self, record: Dict[str, Any]):
        """Añade un registro al log o al buffer si el log no está activo."""
        if not self.config.enabled:
            return

        with self._lock:
            if not self._active:
                self._buffer.append(record)
                return

            if self.log_file is None: # Intentar reabrir si se cerró por error
                self._start_logging()
                if not self._active: # Si sigue sin poder abrirse
                    self._buffer.append(record)
                    return
            
            try:
                if self.config.log_format == 'csv':
                    if self.csv_writer is None: # Escribir cabeceras en el primer registro
                        num_ch_raw = len(record.get('raw_data', []))
                        num_ch_filt = len(record.get('filtered_data', []))
                        
                        headers = ['python_timestamp', 'arduino_ms', 'lost_frames']
                        if self.config.log_raw_data:
                            headers += [f'raw_ch_{i+1}' for i in range(num_ch_raw)]
                        if self.config.log_filtered_data:
                            headers += [f'filt_ch_{i+1}' for i in range(num_ch_filt)]
                        
                        self.csv_writer = csv.writer(self.log_file)
                        self.csv_writer.writerow(headers)
                    
                    # Escribir fila de datos
                    row = [record.get('python_timestamp'), record.get('arduino_ms'), record.get('lost_frames', 0)]
                    if self.config.log_raw_data:
                        row += record.get('raw_data', [])
                    if self.config.log_filtered_data:
                        row += record.get('filtered_data', [])
                    self.csv_writer.writerow(row)

                elif self.config.log_format == 'json':
                    if not self._json_first_record:
                        self.log_file.write(',\n')
                    
                    log_entry = {
                        'python_timestamp': record.get('python_timestamp'),
                        'arduino_ms': record.get('arduino_ms'),
                        'lost_frames': record.get('lost_frames', 0),
                    }
                    if self.config.log_raw_data:
                        log_entry['raw_data'] = record.get('raw_data')
                    if self.config.log_filtered_data:
                        log_entry['filtered_data'] = record.get('filtered_data')
                    
                    json.dump(log_entry, self.log_file, ensure_ascii=False)
                    self._json_first_record = False
                
                if hasattr(self.log_file, 'flush'):
                    self.log_file.flush()

            except IOError as e:
                logger.error(f"Error al escribir en el log: {e}")
                self._stop_logging() # Detener logging si hay error de escritura
                self._buffer.append(record) # Guardar en buffer

    def _stop_logging(self):
        """Cierra el archivo de log."""
        if self._active and self.log_file:
            try:
                if self.config.log_format == 'json' and not self._json_first_record:
                    self.log_file.write('\n]')
                self.log_file.close()
            except IOError as e:
                logger.error(f"Error al cerrar el log: {e}")
            finally:
                self.log_file = None
                self.csv_writer = None
                self._active = False
                logger.info("Logging detenido.")
    
    def close(self):
        """Método público para cerrar el logger explícitamente."""
        with self._lock:
            self._stop_logging()


# Clase Principal de Adquisición
class EMGAcquisition:
    """
    Clase para la adquisición de señales EMG desde un dispositivo serial (e.g., Arduino).
    Gestiona la conexión, lectura de datos, procesamiento básico y logging.
    """
    def __init__(self,
                 serial_config: SerialConfig,
                 acq_config: AcquisitionConfig,
                 filter_config: FilterConfig,
                 log_config: LogConfig,
                 simulate: bool = False):
        self.serial_config = serial_config
        self.acq_config = acq_config
        # self.filter_config = filter_config # EMGDataProcessor maneja su propia config
        # self.log_config = log_config       # DataLogger maneja su propia config
        self.simulate = simulate

        self.ser: Optional[serial.Serial] = None
        self._connected = False
        self._lock = threading.Lock() # Lock para proteger acceso a self.ser y self._connected
        self._read_buffer = bytearray()
        
        self.processor = EMGDataProcessor(filter_config)
        self.data_logger = DataLogger(log_config)
        
        self.callbacks: List[Callable[[Dict[str, Any]], None]] = []
        self._last_arduino_ms: int = 0
        self._total_lost_frames: int = 0
        self._expected_packet_size = calculate_expected_packet_size(MAX_CHANNELS_HW)


        if self.simulate:
            self._connected = True
            logger.info("Modo simulación activado. No se intentará conexión serial.")
        elif self.serial_config.auto_connect:
            self.connect()

    def update_configs(self, 
                       serial_config: Optional[SerialConfig] = None,
                       acq_config: Optional[AcquisitionConfig] = None,
                       filter_config: Optional[FilterConfig] = None,
                       log_config: Optional[LogConfig] = None):
        """Actualiza las configuraciones y aplica los cambios necesarios."""
        if serial_config:
            self.serial_config = serial_config
            # Podría requerir reconexión si el puerto o baudrate cambian
        if acq_config:
            self.acq_config = acq_config
            self.update_arduino_config() # Enviar nueva config al Arduino
        if filter_config:
            self.processor.update_config(filter_config)
        if log_config:
            self.data_logger.update_config(log_config)
        logger.info("Configuraciones actualizadas.")


    def connect(self) -> bool:
        """
        Establece la conexión con el dispositivo serial.
        Intenta detectar el puerto automáticamente si no se especifica.
        """
        if self.simulate:
            logger.info("Simulación: Conexión establecida (virtual).")
            self._connected = True
            return True
        
        with self._lock:
            if self._connected and self.ser and self.ser.is_open:
                logger.info("Ya conectado.")
                return True

            if not self.serial_config.port:
                try:
                    self.serial_config.port = self._autodetect_port()
                    if not self.serial_config.port: # Si sigue siendo None después de autodetect
                         logger.error("No se pudo autodetectar el puerto del dispositivo.")
                         return False
                except ValueError as e:
                    logger.error(f"Error en autodetección de puerto: {e}")
                    return False
            
            try:
                logger.info(f"Intentando conectar a {self.serial_config.port} @ {self.serial_config.baud_rate} bps...")
                self.ser = serial.Serial(
                    self.serial_config.port,
                    self.serial_config.baud_rate,
                    timeout=self.serial_config.timeout
                )
                # Esperar un momento para que la conexión serial se estabilice (especialmente para Arduinos)
                time.sleep(2.0)
                self.ser.flushInput()
                self.ser.flushOutput()
                self._connected = True
                logger.info(f"Conectado exitosamente a {self.serial_config.port}.")
                self.update_arduino_config() # Enviar configuración inicial al Arduino
                return True
            except serial.SerialException as e:
                logger.error(f"Error al conectar al puerto {self.serial_config.port}: {e}")
                self.ser = None
                self._connected = False
                return False

    def _autodetect_port(self) -> Optional[str]:
        """
        Detecta automáticamente el puerto del dispositivo (e.g., Arduino).
        Busca dispositivos que coincidan con identificadores comunes.
        """
        ports = serial.tools.list_ports.comports()
        if not ports:
            logger.warning("No se encontraron puertos seriales.")
            return None

        for p in ports:
            for identifier in self.serial_config.arduino_identifiers:
                if p.description and identifier in p.description:
                    logger.info(f"Puerto detectado: {p.device} ({p.description})")
                    return p.device
                if p.manufacturer and identifier in p.manufacturer:
                    logger.info(f"Puerto detectado por fabricante: {p.device} ({p.manufacturer})")
                    return p.device
        
        logger.warning(f"No se detectó un dispositivo con identificadores {self.serial_config.arduino_identifiers}. Probando el primer puerto disponible si existe.")
        # Fallback: si no se encuentra por descripción/fabricante, y hay puertos, devolver el primero
        # Esto es menos fiable y podría necesitar ajuste manual por el usuario.
        if ports:
            logger.info(f"Usando el primer puerto disponible como fallback: {ports[0].device}")
            return ports[0].device
            
        return None


    def disconnect(self):
        """Cierra la conexión serial."""
        with self._lock:
            if self.ser and self.ser.is_open:
                try:
                    self.ser.close()
                    logger.info(f"Desconectado del puerto {self.serial_config.port}.")
                except Exception as e:
                    logger.error(f"Error al cerrar puerto serial: {e}")
            self.ser = None
            self._connected = False
        if self.simulate: # En modo simulación, solo marcamos como desconectado
            self._connected = False
            logger.info("Simulación: Desconexión (virtual).")

    def update_arduino_config(self):
        """Envía la configuración actual de adquisición al Arduino."""
        if not self.is_connected() or self.simulate:
            return
        
        success_delay = self.set_delay(self.acq_config.delay_ms)
        success_channels = self.set_num_channels(self.acq_config.num_channels_active)
        success_mode = self.set_mode(self.acq_config.mode)
        
        if not (success_delay and success_channels and success_mode):
            logger.error("Fallo al enviar una o más configuraciones al Arduino.")
        else:
            logger.info("Configuración enviada al Arduino correctamente.")

    def set_delay(self, ms: int) -> bool:
        """Configura el delay entre muestras en el Arduino."""
        if not (1 <= ms <= 255): # Arduino suele usar byte para delay
            logger.error(f"Delay inválido: {ms} ms. Debe estar entre 1 y 255.")
            return False
        return self._send_command(b'D' + struct.pack('!B', ms)) # '!' para network order (big-endian)

    def set_num_channels(self, n: int) -> bool:
        """Configura el número de canales activos en el Arduino."""
        if not (1 <= n <= MAX_CHANNELS_HW):
            logger.error(f"Número de canales inválido: {n}. Debe estar entre 1 y {MAX_CHANNELS_HW}.")
            return False
        return self._send_command(b'C' + struct.pack('!B', n))

    def set_mode(self, mode: str) -> bool:
        """Configura el modo de adquisición en el Arduino ('continuous' o 'request')."""
        mode_val = mode.lower()
        if mode_val not in ('continuous', 'request'):
            logger.error(f"Modo de adquisición inválido: {mode}. Use 'continuous' o 'request'.")
            return False
        cmd_char = b'c' if mode_val == 'continuous' else b'r'
        return self._send_command(b'M' + cmd_char)

    def _send_command(self, cmd: bytes) -> bool:
        """Envía un comando al Arduino."""
        if not self.is_connected() or self.simulate or self.ser is None:
            logger.warning("No conectado o en simulación, comando no enviado.")
            return False
        
        with self._lock: # Asegurar acceso exclusivo a self.ser
            try:
                self.ser.write(cmd)
                self.ser.flush() # Asegurar que el comando se envíe inmediatamente
                logger.info(f"Comando enviado al Arduino: {cmd!r}")
                # Opcional: esperar y leer confirmación del Arduino
                # response = self.ser.readline().decode().strip()
                # logger.info(f"Respuesta del Arduino: {response}")
                # return "OK" in response 
                return True
            except serial.SerialException as e:
                logger.error(f"Error al enviar comando {cmd!r}: {e}")
                self._handle_serial_error()
                return False
            except Exception as e: # Captura otros posibles errores (e.g. si el puerto se cierra inesperadamente)
                logger.error(f"Error inesperado al enviar comando {cmd!r}: {e}")
                self._handle_serial_error()
                return False

    def _handle_serial_error(self):
        """Maneja errores seriales, intentando reconectar si es necesario."""
        logger.warning("Error serial detectado.")
        self.disconnect() # Cierra la conexión actual
        if self.serial_config.auto_connect:
            logger.info(f"Intentando reconectar en {self.serial_config.reconnect_delay} segundos...")
            time.sleep(self.serial_config.reconnect_delay)
            self.connect()


    def read_data(self) -> Optional[Dict[str, Any]]:
        """
        Lee y procesa un paquete de datos del puerto serial o genera datos simulados.
        Retorna un diccionario con los datos o None si no hay datos completos/válidos.
        """
        if not self.is_connected():
            if self.serial_config.auto_connect and not self.simulate:
                self._handle_serial_error() # Intenta reconectar
            return None

        if self.simulate:
            return self._generate_simulated_data()

        # Lectura de datos reales
        with self._lock: # Proteger acceso a self.ser y self._read_buffer
            if self.ser is None or not self.ser.is_open:
                return None
            try:
                if self.ser.in_waiting > 0:
                    self._read_buffer.extend(self.ser.read(self.ser.in_waiting))
            except serial.SerialException as e:
                logger.error(f"Error leyendo del puerto serial: {e}")
                self._handle_serial_error()
                return None
            except Exception as e: # Otros errores inesperados
                logger.error(f"Error inesperado durante la lectura serial: {e}")
                self._handle_serial_error()
                return None

        # Procesar el buffer para encontrar paquetes
        while len(self._read_buffer) >= self._expected_packet_size:
            header_index = self._read_buffer.find(PACKET_HEADER)
            if header_index == -1: # No se encontró cabecera, limpiar buffer
                self._read_buffer.clear()
                return None
            if header_index > 0: # Descartar bytes antes de la cabecera
                self._read_buffer = self._read_buffer[header_index:]
            
            if len(self._read_buffer) < self._expected_packet_size: # No hay suficientes datos para un paquete completo
                break 

            packet = self._read_buffer[:self._expected_packet_size]
            
            # Verificar CRC
            payload = packet[:-1] # Todo excepto el CRC byte
            received_crc = packet[-1]
            calculated_crc = crc8_func(payload)

            if calculated_crc != received_crc:
                logger.warning(f"Error de CRC. Recibido: {received_crc}, Calculado: {calculated_crc}. Paquete descartado: {packet.hex()}")
                self._read_buffer = self._read_buffer[1:] # Descartar cabecera y reintentar
                continue # Buscar el siguiente paquete

            # Desempaquetar datos
            try:
                # Formato: Header(ignorado aquí) + NumActiveChannels(B) + Timestamp(L) + Data(MAX_CHANNELS_HW * h)
                # Nota: 'h' es short (2 bytes). Arduino debe enviar int16_t.
                #       '>' indica big-endian.
                #       El primer byte del paquete (PACKET_HEADER) ya fue validado.
                #       El último byte (CRC) ya fue validado.
                #       Por lo tanto, desempaquetamos desde packet[1] hasta packet[-2].
                
                # El primer byte después del header es num_active_channels
                num_ch_active_from_packet = struct.unpack('!B', packet[1:2])[0]
                
                # El timestamp es los siguientes 4 bytes
                arduino_ts_ms = struct.unpack('!L', packet[2:6])[0]
                
                # Los datos de los canales son los siguientes MAX_CHANNELS_HW * 2 bytes
                channel_data_raw = struct.unpack(f'!{MAX_CHANNELS_HW}h', packet[6:-1])
                
                # Usar solo los canales activos según lo que indica el paquete
                # y no más de lo que la configuración Python espera.
                num_channels_to_use = min(num_ch_active_from_packet, self.acq_config.num_channels_active, MAX_CHANNELS_HW)
                raw_data_values = list(channel_data_raw[:num_channels_to_use])

                self._read_buffer = self._read_buffer[self._expected_packet_size:] # Consumir paquete del buffer

                data_array = np.array(raw_data_values, dtype=float)
                filtered_data_array = self.processor.apply_filters(data_array.reshape(1, -1) if data_array.ndim == 1 else data_array) # Asegurar 2D para el procesador
                
                lost_frames = self._detect_lost_frames(arduino_ts_ms)
                
                result = {
                    "arduino_ms": arduino_ts_ms,
                    "raw_data": data_array.tolist(), # Convertir a lista para JSON y callbacks
                    "filtered_data": filtered_data_array.squeeze().tolist(), # Convertir a lista
                    "lost_frames": lost_frames,
                    "python_timestamp": datetime.now().isoformat(),
                    "num_channels_active": num_channels_to_use
                }
                
                self.data_logger.add_record(result)
                for callback in self.callbacks:
                    try:
                        callback(result)
                    except Exception as e:
                        logger.error(f"Error en callback: {e}")
                return result

            except struct.error as e:
                logger.error(f"Error al desempaquetar datos: {e}. Paquete: {packet.hex()}")
                self._read_buffer = self._read_buffer[1:] # Descartar cabecera y reintentar
                continue
        
        return None # No hay paquete completo o válido en el buffer

    def _generate_simulated_data(self) -> Dict[str, Any]:
        """Genera un paquete de datos simulados."""
        current_time_ms = int(time.time() * 1000)
        
        # Simular datos crudos
        raw_data_values = [np.sin(current_time_ms / (1000.0 + i*100)) * 500 + np.random.normal(0, 50)
                           for i in range(self.acq_config.num_channels_active)]
        
        data_array = np.array(raw_data_values, dtype=float)
        filtered_data_array = self.processor.apply_filters(data_array.reshape(1, -1) if data_array.ndim == 1 else data_array)
        
        lost_frames = self._detect_lost_frames(current_time_ms)

        result = {
            "arduino_ms": current_time_ms,
            "raw_data": data_array.tolist(),
            "filtered_data": filtered_data_array.squeeze().tolist(),
            "lost_frames": lost_frames,
            "python_timestamp": datetime.now().isoformat(),
            "num_channels_active": self.acq_config.num_channels_active
        }
        
        self.data_logger.add_record(result)
        for callback in self.callbacks:
            try:
                callback(result)
            except Exception as e:
                logger.error(f"Error en callback de simulación: {e}")
        return result

    def _detect_lost_frames(self, current_ts_ms: int) -> int:
        """Detecta paquetes perdidos basados en timestamps del Arduino."""
        if self._last_arduino_ms == 0: # Primer paquete recibido
            self._last_arduino_ms = current_ts_ms
            return 0

        time_diff_ms = current_ts_ms - self._last_arduino_ms
        
        # Si el timestamp es menor (e.g., reinicio del Arduino), resetear
        if time_diff_ms < 0:
            logger.warning("Timestamp del Arduino retrocedió. Posible reinicio del dispositivo.")
            self._last_arduino_ms = current_ts_ms
            self._total_lost_frames = 0 # Opcional: resetear contador total
            return 0

        expected_diff_ms = float(self.acq_config.delay_ms)
        if expected_diff_ms <= 0: # Evitar división por cero
            self._last_arduino_ms = current_ts_ms
            return 0
            
        # Tolerancia para variaciones de tiempo (e.g., 20% del delay esperado)
        tolerance_ms = expected_diff_ms * 0.5 

        lost_count = 0
        if time_diff_ms > (expected_diff_ms + tolerance_ms):
            lost_count = round(time_diff_ms / expected_diff_ms) - 1
            if lost_count > 0:
                self._total_lost_frames += lost_count
                logger.warning(f"Detectados ~{lost_count} paquetes perdidos. Diferencia: {time_diff_ms}ms, Esperado: {expected_diff_ms}ms. Total perdidos: {self._total_lost_frames}")
        
        self._last_arduino_ms = current_ts_ms
        return lost_count

    def register_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """Registra una función callback para ser llamada con cada nuevo dato procesado."""
        if callback not in self.callbacks:
            self.callbacks.append(callback)
            logger.info(f"Callback {callback.__name__} registrado.")

    def unregister_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """Elimina un callback de la lista."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
            logger.info(f"Callback {callback.__name__} eliminado.")

    def is_connected(self) -> bool:
        """Verifica el estado de la conexión serial."""
        if self.simulate:
            return self._connected
        with self._lock:
            return self._connected and self.ser is not None and self.ser.is_open

    def close(self):
        """Cierra la conexión serial y el logger de datos."""
        logger.info("Cerrando EMGAcquisition...")
        self.disconnect()
        self.data_logger.close()


# Hilo de Adquisición para integración con PyQt6
class AcquisitionWorker(QObject): # Heredar de QObject para usar señales en el hilo correcto
    """Worker para ejecutar la adquisición en un hilo separado."""
    data_signal = pyqtSignal(dict)
    finished_signal = pyqtSignal()
    error_signal = pyqtSignal(str)

    def __init__(self, emg_acq_instance: EMGAcquisition):
        super().__init__()
        self.emg = emg_acq_instance
        self._stop_event = threading.Event() # Usar threading.Event para compatibilidad

    def run(self):
        """Bucle principal del worker, se ejecuta en el hilo."""
        logger.info("Hilo de adquisición iniciado.")
        if not self.emg.is_connected():
            if not self.emg.connect(): # Intentar conectar si no está conectado
                self.error_signal.emit("No se pudo conectar al dispositivo EMG.")
                self.finished_signal.emit()
                return

        while not self._stop_event.is_set():
            try:
                data = self.emg.read_data()
                if data:
                    self.data_signal.emit(data)
                # Pequeña pausa para no saturar la CPU si no hay datos o el delay es muy bajo
                # El delay principal lo maneja el Arduino con `delay_ms`
                time.sleep(0.001) # 1 ms
            except Exception as e:
                error_msg = f"Error en el hilo de adquisición: {e}"
                logger.error(error_msg)
                self.error_signal.emit(error_msg)
                # Decidir si detener el hilo en caso de error o intentar continuar
                # self._stop_event.set() # Descomentar para detener en error
        
        self.emg.close() # Asegurar que se cierre la conexión al finalizar el hilo
        self.finished_signal.emit()
        logger.info("Hilo de adquisición finalizado.")

    def stop(self):
        """Solicita la detención del hilo."""
        logger.info("Solicitando detención del hilo de adquisición...")
        self._stop_event.set()


# Ejemplo de Uso (puede ser ejecutado como script independiente para pruebas)
if __name__ == "__main__":
    # Configuración de ejemplo
    serial_cfg = SerialConfig(port=None, auto_connect=True) # Intentará autodetectar
    acq_cfg = AcquisitionConfig(delay_ms=20, num_channels_active=2, mode='continuous') # 50 Hz
    filter_cfg = FilterConfig(sample_rate=1000.0/acq_cfg.delay_ms, # 50 Hz
                              notch_freq=50.0,
                              bandpass_low_freq=10.0, bandpass_high_freq=20.0)
    log_cfg = LogConfig(log_path='emg_logs_main_test', log_filename_prefix='test_session', log_format='csv', enabled=True)

    # Crear instancia de EMGAcquisition (en modo simulación o real)
    # Para prueba real, cambiar simulate=False y asegurar que el puerto sea correcto o autodetectable
    emg_system = EMGAcquisition(serial_cfg, acq_cfg, filter_cfg, log_cfg, simulate=True)

    if not emg_system.is_connected():
        logger.error("No se pudo conectar al sistema EMG. Terminando ejemplo.")
        exit()

    # --- Ejemplo de uso con QThread (requiere una QApplication si se usan señales PyQt) ---
    # from PyQt6.QtWidgets import QApplication
    # app = QApplication([]) # Necesario para que las señales PyQt funcionen

    # worker = AcquisitionWorker(emg_system)
    # thread = QThread()
    # worker.moveToThread(thread)

    # # Conectar señales
    # worker.data_signal.connect(lambda data: logger.info(f"Dato recibido (Thread): {data['arduino_ms']}"))
    # worker.finished_signal.connect(thread.quit)
    # worker.finished_signal.connect(worker.deleteLater)
    # thread.finished.connect(thread.deleteLater)
    # thread.started.connect(worker.run)
    
    # thread.start()
    
    # logger.info("Hilo de adquisición iniciado. Presione Ctrl+C para detener.")
    # try:
    #     # Mantener el script principal vivo durante 10 segundos
    #     # En una app GUI, el bucle de eventos de Qt haría esto.
    #     time.sleep(10)
    # except KeyboardInterrupt:
    #     logger.info("Interrupción de teclado recibida.")
    # finally:
    #     logger.info("Deteniendo hilo de adquisición...")
    #     worker.stop()
    #     thread.wait() # Esperar a que el hilo termine limpiamente
    #     logger.info("Ejemplo finalizado.")
    #     if 'app' in locals():
    #          app.quit()
    
    # --- Ejemplo de uso sin QThread (bucle simple) ---
    logger.info("Adquisición en bucle simple. Presione Ctrl+C para detener.")
    try:
        for _ in range(500): # Adquirir 500 paquetes
            data_packet = emg_system.read_data()
            if data_packet:
                logger.info(f"Dato recibido (Bucle): ArduinoTS={data_packet['arduino_ms']}, Raw0={data_packet['raw_data'][0]:.2f} (Canales: {data_packet['num_channels_active']})")
            time.sleep(acq_cfg.delay_ms / 1000.0) # Simular el delay del Arduino
    except KeyboardInterrupt:
        logger.info("Interrupción de teclado recibida.")
    finally:
        emg_system.close()
        logger.info("Ejemplo finalizado.")
    
