"""
gestor_datos.py

Este módulo actúa como una capa de abstracción y orquestación para la gestión de datos.
Combina la persistencia local (a través de LocalFileRepository) con la comunicación
con un backend API (simulada en esta versión, pero con hooks para una implementación real).

Responsabilidades:
- Proporcionar una API unificada para la GUI y otros módulos para acceder y modificar datos.
- Intentar operaciones primero contra el backend API y, en caso de fallo (o modo offline),
  recurrir al LocalFileRepository.
- Sincronizar datos: si una operación tiene éxito en el backend, replicarla localmente.
- Manejar la lógica de "paciente actual" para la aplicación.
- Cargar datos iniciales o de ejemplo si es necesario (seeding).
- Emitir señales (si se usa en un contexto Qt) cuando los datos se actualizan.
"""
import os
import json
import logging
import requests # Para interactuar con el backend API
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable

# Importaciones de modelos de dominio y repositorio local
from BitnnariApp.data.models.patient import PatientModel
from BitnnariApp.data.models.calibration_params import CalibrationParamsModel
from BitnnariApp.data.models.emg_record import EmgRecordModel
from BitnnariApp.data.repository import LocalFileRepository

# PyQtSignal para notificar actualizaciones (si se usa en una app Qt)
try:
    from PyQt6.QtCore import QObject, pyqtSignal
    HAS_QT = True
except ImportError:
    HAS_QT = False
    # Definir dummies si Qt no está disponible, para que el código no falle
    class QObject: pass
    class pyqtSignal:
        def __init__(self, *args, **kwargs): pass
        def emit(self, *args, **kwargs): pass

logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Configuración del Backend API (ejemplo, se cargaría de una config real)
API_BASE_URL = os.getenv("BITNNARI_API_URL", "http://localhost:8000/api/v1") # Ejemplo
API_TIMEOUT_SECONDS = 5 # Timeout para las peticiones HTTP

# Nombres de los tipos de datos para consistencia
DATA_TYPE_PATIENT_INFO = "patient_info"
DATA_TYPE_CALIBRATION_PARAMS = "calibration_params"
DATA_TYPE_EMG_SESSION = "emg_session" # Para un EmgRecordModel completo
DATA_TYPE_APP_CONFIG = "app_config" # Configuración general de la app
DATA_TYPE_PROCESSING_CONFIG = "processing_config" # Configuración del módulo de procesamiento
DATA_TYPE_ACQUISITION_CONFIG = "acquisition_config" # Configuración del módulo de adquisición
DATA_TYPE_TRAINING_CONFIG = "training_config" # Configuración del módulo de entrenamiento
DATA_TYPE_ML_MODEL_INFO = "ml_model_info" # Metadatos sobre un modelo de ML entrenado

class GestorDatos(QObject if HAS_QT else object):
    """
    Gestor de Datos que interactúa con el backend API y el repositorio local.
    """
    if HAS_QT:
        # Señal emitida cuando los datos de un paciente se actualizan significativamente
        datos_paciente_actualizados = pyqtSignal(str) # Emite el DNI del paciente
        # Señal emitida cuando la lista de pacientes cambia
        lista_pacientes_actualizada = pyqtSignal()
        # Señal para notificar errores de backend
        error_backend = pyqtSignal(str)
        # Señal para notificar estado de conexión
        estado_conexion_backend = pyqtSignal(bool) # True si conectado, False si offline

    def __init__(self, local_repo_base_dir: Optional[str] = None, api_base_url: Optional[str] = None):
        super().__init__()
        self.repo = LocalFileRepository(base_data_dir=local_repo_base_dir)
        self.api_base_url = api_base_url or API_BASE_URL
        self.api_token: Optional[str] = None # Para autenticación con el backend
        self.paciente_actual_dni: Optional[str] = None
        self._backend_online = self._check_backend_status() # Estado inicial
        
        self._update_callbacks: List[Callable[[str], None]] = [] # Callbacks genéricos

    def registrar_callback(self, callback: Callable[[str], None]):
        """Registra un callback genérico para ser llamado cuando los datos se actualizan."""
        if callback not in self._update_callbacks:
            self._update_callbacks.append(callback)

    def _notify_updates(self, dni: str):
        """Notifica a todos los callbacks registrados."""
        if HAS_QT:
            self.datos_paciente_actualizados.emit(dni)
        for callback in self._update_callbacks:
            try:
                callback(dni)
            except Exception as e:
                logger.error(f"Error ejecutando callback de actualización: {e}")

    def _check_backend_status(self) -> bool:
        """Verifica si el backend está accesible."""
        try:
            # Un endpoint simple como /health o /status sería ideal
            response = requests.get(f"{self.api_base_url}/health", timeout=API_TIMEOUT_SECONDS / 2)
            is_online = response.status_code == 200
        except requests.exceptions.RequestException:
            is_online = False
        
        if HAS_QT:
            self.estado_conexion_backend.emit(is_online)
        logger.info(f"Estado del backend: {'Online' if is_online else 'Offline'}")
        return is_online

    def set_api_token(self, token: Optional[str]):
        """Establece el token de autenticación para las llamadas API."""
        self.api_token = token
        logger.info("Token API actualizado." if token else "Token API eliminado.")

    def _get_api_headers(self) -> Dict[str, str]:
        """Construye los encabezados para las peticiones API, incluyendo autenticación."""
        headers = {"Content-Type": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
        return headers

    def seleccionar_paciente_actual(self, dni: str) -> bool:
        """Establece el paciente activo para la sesión actual."""
        # Verificar si el paciente existe (localmente o en backend)
        if self.obtener_paciente(dni):
            self.paciente_actual_dni = dni.upper()
            logger.info(f"Paciente actual seleccionado: {self.paciente_actual_dni}")
            self._notify_updates(self.paciente_actual_dni)
            return True
        else:
            logger.warning(f"No se pudo seleccionar paciente: DNI {dni} no encontrado.")
            self.paciente_actual_dni = None
            return False

    @property
    def paciente_actual(self) -> Optional[PatientModel]:
        """Devuelve el objeto PatientModel del paciente actual, si está seleccionado."""
        if self.paciente_actual_dni:
            return self.obtener_paciente(self.paciente_actual_dni)
        return None

    # --- Operaciones con Pacientes ---
    def registrar_nuevo_paciente(self, patient_data: Dict[str, Any]) -> Optional[PatientModel]:
        """
        Registra un nuevo paciente. Intenta primero con el backend.
        Si tiene éxito, guarda localmente. Si falla, guarda solo localmente.
        """
        try:
            patient = PatientModel(**patient_data) # Validar datos con Pydantic
        except Exception as e: # Captura ValidationError
            logger.error(f"Datos de paciente inválidos para registro: {e}")
            if HAS_QT: self.error_backend.emit(f"Datos de paciente inválidos: {e}")
            return None

        if self._backend_online:
            try:
                response = requests.post(
                    f"{self.api_base_url}/pacientes",
                    json=patient.to_dict(),
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                response.raise_for_status() # Lanza HTTPError para 4xx/5xx
                created_patient_data = response.json()
                created_patient = PatientModel.from_dict(created_patient_data)
                self.repo.save_patient(created_patient) # Sincronizar localmente
                logger.info(f"Paciente {patient.dni} registrado en backend y localmente.")
                if HAS_QT: self.lista_pacientes_actualizada.emit()
                self._notify_updates(patient.dni)
                return created_patient
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al registrar paciente {patient.dni}: {e}. Guardando localmente.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al registrar: {e}")
                self._backend_online = False # Asumir offline
                if HAS_QT: self.estado_conexion_backend.emit(False)
        
        # Fallback a guardado local si backend falla o está offline
        if self.repo.save_patient(patient):
            logger.info(f"Paciente {patient.dni} registrado localmente (backend offline o error).")
            if HAS_QT: self.lista_pacientes_actualizada.emit()
            self._notify_updates(patient.dni)
            return patient
        else:
            logger.error(f"Fallo crítico al registrar paciente {patient.dni} localmente.")
            return None

    def obtener_paciente(self, dni: str) -> Optional[PatientModel]:
        """
        Obtiene datos de un paciente. Intenta backend, luego local.
        """
        dni_upper = dni.upper()
        if self._backend_online:
            try:
                response = requests.get(
                    f"{self.api_base_url}/pacientes/{dni_upper}",
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                if response.status_code == 200:
                    patient_data = response.json()
                    patient = PatientModel.from_dict(patient_data)
                    self.repo.save_patient(patient) # Actualizar caché local
                    logger.debug(f"Paciente {dni_upper} obtenido del backend.")
                    return patient
                elif response.status_code == 404:
                    logger.info(f"Paciente {dni_upper} no encontrado en backend.")
                    # No necesariamente un error, podría no existir. Intentar local.
                else:
                    response.raise_for_status() # Otros errores HTTP
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al obtener paciente {dni_upper}: {e}. Intentando local.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al obtener paciente: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)
        
        # Fallback a repositorio local
        patient = self.repo.get_patient(dni_upper)
        if patient:
            logger.debug(f"Paciente {dni_upper} obtenido del repositorio local.")
        else:
            logger.info(f"Paciente {dni_upper} no encontrado localmente.")
        return patient

    def actualizar_paciente(self, dni: str, updated_data: Dict[str, Any]) -> Optional[PatientModel]:
        """
        Actualiza datos de un paciente. Intenta backend, luego local.
        """
        dni_upper = dni.upper()
        current_patient = self.obtener_paciente(dni_upper) # Obtener para tener todos los campos
        if not current_patient:
            logger.error(f"No se puede actualizar: Paciente {dni_upper} no encontrado.")
            return None
        
        # Crear un PatientModel con los datos actualizados para validación
        try:
            # Pydantic v2: model_copy y model_validate
            # patient_to_validate_dict = current_patient.model_copy(update=updated_data).model_dump()
            # Pydantic v1:
            patient_to_validate_dict = current_patient.dict()
            patient_to_validate_dict.update(updated_data)

            updated_patient_obj = PatientModel.from_dict(patient_to_validate_dict)
            updated_patient_obj.update_timestamp() # Marcar como actualizado
        except Exception as e: # Captura ValidationError
            logger.error(f"Datos de actualización inválidos para paciente {dni_upper}: {e}")
            if HAS_QT: self.error_backend.emit(f"Datos de actualización inválidos: {e}")
            return None

        if self._backend_online:
            try:
                response = requests.put(
                    f"{self.api_base_url}/pacientes/{dni_upper}",
                    json=updated_patient_obj.to_dict(), # Enviar el objeto completo validado
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                response.raise_for_status()
                # Asumir que el backend devuelve el paciente actualizado
                final_patient_data = response.json()
                final_patient = PatientModel.from_dict(final_patient_data)
                self.repo.save_patient(final_patient)
                logger.info(f"Paciente {dni_upper} actualizado en backend y localmente.")
                self._notify_updates(dni_upper)
                return final_patient
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al actualizar paciente {dni_upper}: {e}. Actualizando localmente.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al actualizar: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)

        if self.repo.save_patient(updated_patient_obj):
            logger.info(f"Paciente {dni_upper} actualizado localmente (backend offline o error).")
            self._notify_updates(dni_upper)
            return updated_patient_obj
        else:
            logger.error(f"Fallo crítico al actualizar paciente {dni_upper} localmente.")
            return None

    def eliminar_paciente(self, dni: str) -> bool:
        """Elimina un paciente. Intenta backend, luego local."""
        dni_upper = dni.upper()
        backend_deleted = False
        if self._backend_online:
            try:
                response = requests.delete(
                    f"{self.api_base_url}/pacientes/{dni_upper}",
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                if response.status_code == 200 or response.status_code == 204: # 204 No Content también es éxito
                    logger.info(f"Paciente {dni_upper} eliminado del backend.")
                    backend_deleted = True
                elif response.status_code == 404:
                    logger.info(f"Paciente {dni_upper} no encontrado en backend para eliminar (puede que ya no exista).")
                    backend_deleted = True # Considerar como éxito si no estaba
                else:
                    response.raise_for_status()
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al eliminar paciente {dni_upper}: {e}. Procediendo con eliminación local.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al eliminar: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)
        
        local_deleted = self.repo.delete_patient(dni_upper)
        if local_deleted:
            logger.info(f"Paciente {dni_upper} eliminado localmente.")
            if HAS_QT: self.lista_pacientes_actualizada.emit()
            if self.paciente_actual_dni == dni_upper:
                self.paciente_actual_dni = None # Limpiar paciente actual si fue eliminado
            self._notify_updates(dni_upper) # Notificar que este DNI ya no es válido
        
        return backend_deleted or local_deleted # Éxito si se eliminó en al menos un lugar

    def listar_todos_pacientes(self) -> List[PatientModel]:
        """Lista todos los pacientes. Intenta backend, luego local."""
        if self._backend_online:
            try:
                response = requests.get(
                    f"{self.api_base_url}/pacientes",
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                response.raise_for_status()
                patients_data = response.json()
                patients = [PatientModel.from_dict(p_data) for p_data in patients_data]
                # Opcional: Sincronizar/actualizar todos estos pacientes localmente
                for p in patients: self.repo.save_patient(p)
                logger.info(f"Listados {len(patients)} pacientes desde el backend.")
                return patients
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al listar pacientes: {e}. Usando datos locales.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al listar pacientes: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)

        dnis = self.repo.list_patient_dnis()
        patients = []
        for dni_repo in dnis:
            p = self.repo.get_patient(dni_repo)
            if p:
                patients.append(p)
        logger.info(f"Listados {len(patients)} pacientes desde el repositorio local.")
        return patients

    # --- Operaciones con Datos Específicos del Paciente (Calibraciones, Sesiones, Configs) ---
    # Estos métodos siguen un patrón similar: intentar backend, luego local.
    # Por brevedad, se muestra un ejemplo para guardar/cargar datos genéricos.
    # Se deben crear métodos específicos para CalibrationParamsModel, EmgRecordModel, etc.

    def guardar_datos_paciente(self, patient_dni: str, data_type: str, data: Dict[str, Any]) -> bool:
        """
        Guarda datos específicos (calibración, sesión, config) para un paciente.
        `data_type` se usa para la ruta en backend y el nombre del archivo/subdirectorio local.
        `data` debe ser un diccionario serializable a JSON.
        """
        # Aquí, `data` ya debería ser un diccionario (e.g., de `model.to_dict()`)
        patient_dni_upper = patient_dni.upper()
        
        # Determinar el modelo Pydantic correcto basado en data_type para validación/serialización
        model_instance: Optional[Any] = None
        if data_type == DATA_TYPE_CALIBRATION_PARAMS:
            model_instance = CalibrationParamsModel(**data)
        elif data_type == DATA_TYPE_EMG_SESSION:
            model_instance = EmgRecordModel(**data)
        # Añadir más tipos según sea necesario
        
        data_to_send = model_instance.to_dict() if model_instance else data

        if self._backend_online:
            try:
                # El endpoint del backend podría ser /pacientes/{dni}/{data_type} o /data/{data_type} con patient_dni en el cuerpo
                # Asumimos un endpoint como /pacientes/{dni}/data/{data_type}
                # Si el dato tiene su propio ID (e.g., calibration_id, record_id), se podría usar PUT para actualizar
                # o POST para crear. Aquí simplificamos con POST.
                response = requests.post(
                    f"{self.api_base_url}/pacientes/{patient_dni_upper}/data/{data_type}",
                    json=data_to_send,
                    headers=self._get_api_headers(),
                    timeout=API_TIMEOUT_SECONDS
                )
                response.raise_for_status()
                # Guardar localmente también si el backend tuvo éxito
                self._save_specific_data_locally(patient_dni_upper, data_type, data_to_send)
                logger.info(f"Datos tipo '{data_type}' para paciente {patient_dni_upper} guardados en backend y localmente.")
                self._notify_updates(patient_dni_upper)
                return True
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al guardar datos '{data_type}' para {patient_dni_upper}: {e}. Guardando localmente.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al guardar {data_type}: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)
        
        if self._save_specific_data_locally(patient_dni_upper, data_type, data_to_send):
            logger.info(f"Datos tipo '{data_type}' para paciente {patient_dni_upper} guardados localmente.")
            self._notify_updates(patient_dni_upper)
            return True
        return False

    def cargar_datos_paciente(self, patient_dni: str, data_type: str, item_id: Optional[str] = None) -> Optional[Any]:
        """
        Carga datos específicos de un paciente.
        Si `item_id` se proporciona, se busca un ítem específico (e.g., una calibración o sesión).
        Devuelve el objeto Pydantic deserializado.
        """
        patient_dni_upper = patient_dni.upper()
        raw_data: Optional[Dict[str, Any]] = None

        if self._backend_online:
            try:
                endpoint = f"{self.api_base_url}/pacientes/{patient_dni_upper}/data/{data_type}"
                if item_id:
                    endpoint += f"/{item_id}"
                response = requests.get(endpoint, headers=self._get_api_headers(), timeout=API_TIMEOUT_SECONDS)
                if response.status_code == 200:
                    raw_data = response.json()
                    # Actualizar caché local
                    self._save_specific_data_locally(patient_dni_upper, data_type, raw_data, item_id)
                    logger.debug(f"Datos '{data_type}' (ID: {item_id or 'N/A'}) para {patient_dni_upper} obtenidos del backend.")
                elif response.status_code != 404: # No es error si no se encuentra, podría estar solo local
                    response.raise_for_status()
            except requests.exceptions.RequestException as e:
                logger.warning(f"Error de backend al cargar datos '{data_type}' para {patient_dni_upper}: {e}. Intentando local.")
                if HAS_QT: self.error_backend.emit(f"Fallo de conexión al cargar {data_type}: {e}")
                self._backend_online = False
                if HAS_QT: self.estado_conexion_backend.emit(False)
        
        if raw_data is None: # Si no se obtuvo del backend (o error, o 404)
            raw_data = self._load_specific_data_locally(patient_dni_upper, data_type, item_id)
            if raw_data:
                 logger.debug(f"Datos '{data_type}' (ID: {item_id or 'N/A'}) para {patient_dni_upper} obtenidos localmente.")

        if raw_data:
            try:
                if data_type == DATA_TYPE_CALIBRATION_PARAMS:
                    return CalibrationParamsModel.from_dict(raw_data)
                elif data_type == DATA_TYPE_EMG_SESSION:
                    return EmgRecordModel.from_dict(raw_data)
                # Añadir más deserializadores según el tipo
                return raw_data # Devolver como dict si no hay modelo específico
            except Exception as e: # Captura ValidationError
                logger.error(f"Error al deserializar datos '{data_type}' para {patient_dni_upper}: {e}")
                return None
        return None

    def _save_specific_data_locally(self, patient_dni: str, data_type: str, data: Dict[str, Any], item_id: Optional[str] = None):
        """Método helper para guardar datos específicos en el repositorio local."""
        # El repositorio maneja la lógica de dónde guardar según el tipo y el ID
        if data_type == DATA_TYPE_CALIBRATION_PARAMS and item_id:
            # Asumimos que 'data' ya es un dict validado o proviene de CalibrationParamsModel.to_dict()
            # y que item_id es calibration_id
            cal_params = CalibrationParamsModel.from_dict({**data, "calibration_id": item_id, "patient_dni": patient_dni})
            return self.repo.save_calibration_params(cal_params)
        elif data_type == DATA_TYPE_EMG_SESSION and item_id:
            emg_rec = EmgRecordModel.from_dict({**data, "record_id": item_id, "patient_dni": patient_dni})
            return self.repo.save_emg_record(emg_rec)
        elif data_type in [DATA_TYPE_ACQUISITION_CONFIG, DATA_TYPE_PROCESSING_CONFIG, DATA_TYPE_TRAINING_CONFIG]:
            # Estos son configuraciones, se guardan con un nombre (que es data_type)
            self.repo.save_configuration(config_name=data_type, config_data=data, patient_dni=patient_dni)
            return True
        # Añadir más casos según sea necesario
        logger.warning(f"Guardado local no implementado para data_type '{data_type}' con item_id '{item_id}'.")
        return False

    def _load_specific_data_locally(self, patient_dni: str, data_type: str, item_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Método helper para cargar datos específicos del repositorio local."""
        if data_type == DATA_TYPE_CALIBRATION_PARAMS and item_id:
            model = self.repo.get_calibration_params(patient_dni, item_id)
            return model.to_dict() if model else None
        elif data_type == DATA_TYPE_EMG_SESSION and item_id:
            model = self.repo.get_emg_record(patient_dni, item_id)
            return model.to_dict() if model else None
        elif data_type in [DATA_TYPE_ACQUISITION_CONFIG, DATA_TYPE_PROCESSING_CONFIG, DATA_TYPE_TRAINING_CONFIG]:
            return self.repo.load_configuration(config_name=data_type, patient_dni=patient_dni)
        # Añadir más casos
        logger.warning(f"Carga local no implementada para data_type '{data_type}' con item_id '{item_id}'.")
        return None

    def listar_calibraciones_paciente(self, patient_dni: str) -> List[CalibrationParamsModel]:
        """Lista todas las calibraciones de un paciente."""
        # Similar a obtener_paciente, intentar backend y luego local.
        # El backend debería tener un endpoint /pacientes/{dni}/calibraciones
        # Por ahora, solo implementamos la parte local.
        cal_ids = self.repo.list_calibration_ids_for_patient(patient_dni)
        calibrations = []
        for cal_id in cal_ids:
            cal = self.repo.get_calibration_params(patient_dni, cal_id)
            if cal:
                calibrations.append(cal)
        calibrations.sort(key=lambda c: c.timestamp, reverse=True)
        return calibrations
        
    def listar_sesiones_emg_paciente(self, patient_dni: str) -> List[EmgRecordModel]:
        """Lista todas las sesiones EMG de un paciente."""
        return self.repo.get_all_emg_records_for_patient(patient_dni)

    # --- Exportación de Datos ---
    def export_all_patient_data(self, patient_dni: str, filepath: str) -> bool:
        """Exporta todos los datos de un paciente a un único archivo JSON."""
        patient = self.obtener_paciente(patient_dni)
        if not patient:
            logger.error(f"No se puede exportar: Paciente {patient_dni} no encontrado.")
            return False

        all_data = {"patient_info": patient.to_dict()}
        
        calibrations = self.listar_calibraciones_paciente(patient_dni)
        all_data["calibrations"] = [cal.to_dict() for cal in calibrations]
        
        sessions = self.listar_sesiones_emg_paciente(patient_dni)
        all_data["emg_sessions"] = [sess.to_dict() for sess in sessions]
        
        # Cargar y añadir configuraciones específicas del paciente
        for config_type in [DATA_TYPE_ACQUISITION_CONFIG, DATA_TYPE_PROCESSING_CONFIG, DATA_TYPE_TRAINING_CONFIG]:
            config = self.cargar_datos_paciente(patient_dni, config_type)
            if config: # config puede ser un dict directamente si no hay modelo Pydantic
                all_data[config_type] = config 

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(all_data, f, indent=4, ensure_ascii=False)
            logger.info(f"Todos los datos del paciente {patient_dni} exportados a {filepath}.")
            return True
        except IOError as e:
            logger.error(f"Error al exportar datos del paciente {patient_dni} a {filepath}: {e}")
            return False

    # --- Seeding (Datos Iniciales) ---
    def seed_local_repository_from_initial_data(self, initial_data_dir: str = "BitnnariApp/data/initial_data"):
        """
        Carga datos iniciales desde una estructura de carpetas y archivos JSON.
        Esto es útil para poblar el repositorio local la primera vez o para pruebas.
        """
        initial_data_path = Path(initial_data_dir)
        if not initial_data_path.is_dir():
            logger.warning(f"Directorio de datos iniciales no encontrado: {initial_data_path}")
            return

        logger.info(f"Iniciando seeding del repositorio local desde: {initial_data_path}")
        
        # Asumimos que initial_data_dir puede tener un archivo como 'pacientes_index.json'
        # o subdirectorios por DNI.
        # Ejemplo simple: cargar un archivo 'all_patients_seed.json'
        seed_file = initial_data_path / "all_patients_seed.json" # Nombre de archivo de ejemplo
        if seed_file.exists():
            try:
                with open(seed_file, 'r', encoding='utf-8') as f:
                    seed_data_list = json.load(f) # Espera una lista de diccionarios de pacientes
                
                if not isinstance(seed_data_list, list):
                    logger.error("El archivo de seed debe contener una lista de pacientes.")
                    return

                for patient_data_dict in seed_data_list:
                    try:
                        patient = PatientModel.from_dict(patient_data_dict)
                        self.repo.save_patient(patient)
                        logger.info(f"Paciente {patient.dni} cargado desde seed.")
                        
                        # Cargar otros datos asociados si están en el mismo dict (simplificado)
                        if "calibrations" in patient_data_dict and isinstance(patient_data_dict["calibrations"], list):
                            for cal_data in patient_data_dict["calibrations"]:
                                cal_data["patient_dni"] = patient.dni # Asegurar DNI
                                try:
                                    cal_param = CalibrationParamsModel.from_dict(cal_data)
                                    self.repo.save_calibration_params(cal_param)
                                except Exception as e_cal:
                                    logger.error(f"Error al cargar calibración seed para {patient.dni}: {e_cal}")

                        if "emg_sessions" in patient_data_dict and isinstance(patient_data_dict["emg_sessions"], list):
                            for sess_data in patient_data_dict["emg_sessions"]:
                                sess_data["patient_dni"] = patient.dni # Asegurar DNI
                                try:
                                    emg_rec = EmgRecordModel.from_dict(sess_data)
                                    self.repo.save_emg_record(emg_rec)
                                except Exception as e_sess:
                                    logger.error(f"Error al cargar sesión EMG seed para {patient.dni}: {e_sess}")
                                    
                    except Exception as e_pat: # Captura ValidationError
                        logger.error(f"Error al procesar datos de paciente en seed: {e_pat} - Datos: {patient_data_dict.get('dni')}")
                
                if HAS_QT: self.lista_pacientes_actualizada.emit()
                logger.info("Seeding del repositorio local completado.")

            except (IOError, json.JSONDecodeError) as e:
                logger.error(f"Error al leer o parsear archivo de seed {seed_file}: {e}")
        else:
            logger.info(f"No se encontró archivo de seed general ({seed_file}). Buscando por DNI...")
            # Lógica alternativa: buscar archivos individuales por DNI en initial_data_dir/patients/DNI/patient_info.json
            patients_seed_path = initial_data_path / self.repo.PATIENTS_DIR_NAME
            if patients_seed_path.is_dir():
                for dni_dir in patients_seed_path.iterdir():
                    if dni_dir.is_dir():
                        patient_info_file = dni_dir / "patient_info.json"
                        if patient_info_file.exists():
                            try:
                                with open(patient_info_file, 'r', encoding='utf-8') as f:
                                    patient_data_dict = json.load(f)
                                patient = PatientModel.from_dict(patient_data_dict)
                                self.repo.save_patient(patient)
                                logger.info(f"Paciente {patient.dni} cargado desde seed individual.")
                                # Aquí se podría añadir lógica para cargar calibraciones y sesiones de subcarpetas
                            except Exception as e:
                                logger.error(f"Error procesando seed para {dni_dir.name}: {e}")
                if HAS_QT: self.lista_pacientes_actualizada.emit()


# Ejemplo de uso
if __name__ == "__main__":
    # Crear directorio de datos iniciales de ejemplo
    initial_data_example_dir = Path("./temp_initial_data")
    initial_data_example_dir.mkdir(parents=True, exist_ok=True)
    
    # Crear un archivo de seed de ejemplo
    seed_content = [
        {
            "dni": "SEED001", "nombre": "Paciente Seed Uno", "fecha_nacimiento": "1970-01-01",
            "contacto": {"email": "seed1@example.com"},
            "calibrations": [
                {"calibration_id": "cal_s1_001", "num_channels": 1, "offset_values": [0.01], "timestamp": datetime.now().isoformat()}
            ],
            "emg_sessions": [
                {"record_id": "rec_s1_001", "duration_s": 10, "sampling_rate_hz": 500, "num_channels": 1, "raw_data": [[0.1]*100], "label": "reposo", "timestamp": datetime.now().isoformat()}
            ]
        },
        {"dni": "SEED002", "nombre": "Paciente Seed Dos", "fecha_nacimiento": "1975-05-05"}
    ]
    with open(initial_data_example_dir / "all_patients_seed.json", 'w') as f_seed:
        json.dump(seed_content, f_seed, indent=4)

    # Crear instancia del gestor (usará el repo singleton)
    repo_test_dir = Path("./temp_gestor_repo_data")
    if repo_test_dir.exists():
        shutil.rmtree(repo_test_dir)

    gestor = GestorDatos(local_repo_base_dir=repo_test_dir)
    
    # Cargar datos iniciales
    gestor.seed_local_repository_from_initial_data(initial_data_dir=str(initial_data_example_dir))

    # Probar obtener un paciente cargado desde seed
    p_seed1 = gestor.obtener_paciente("SEED001")
    if p_seed1:
        logger.info(f"Paciente SEED001 obtenido: {p_seed1.nombre}")
        cals_seed1 = gestor.listar_calibraciones_paciente("SEED001")
        if cals_seed1:
            logger.info(f"Calibración para SEED001: {cals_seed1[0].calibration_id}")
    else:
        logger.error("Paciente SEED001 no encontrado después del seed.")

    # Registrar un nuevo paciente (simulando que el backend está offline)
    gestor._backend_online = False # Forzar modo offline para prueba
    new_patient_data = {"dni": "NEW001", "nombre": "Nuevo Paciente Local", "fecha_nacimiento": "2000-10-10"}
    created_p = gestor.registrar_nuevo_paciente(new_patient_data)
    if created_p:
        logger.info(f"Nuevo paciente registrado localmente: {created_p.nombre}")

    # Listar todos
    todos_los_pacientes = gestor.listar_todos_pacientes()
    logger.info(f"Total pacientes listados: {len(todos_los_pacientes)}")
    for p_list in todos_los_pacientes:
        logger.info(f" - {p_list.dni}: {p_list.nombre}")

    # Limpiar directorios de prueba
    shutil.rmtree(initial_data_example_dir)
    shutil.rmtree(repo_test_dir)
    logger.info("Directorios de prueba eliminados.")
    
