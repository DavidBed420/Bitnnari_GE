"""
repository.py

Implementa la capa de persistencia local para la aplicaci�n EMG.
Utiliza archivos JSON para almacenar datos de pacientes, calibraciones,
registros EMG y configuraciones. Sigue el patr�n Singleton para asegurar
una �nica instancia gestionando los datos locales.

Responsabilidades:
- Cargar y guardar datos de pacientes (PatientModel).
- Cargar y guardar par�metros de calibraci�n (CalibrationParamsModel).
- Cargar y guardar registros de sesiones EMG (EmgRecordModel).
- Cargar y guardar configuraciones generales de la aplicaci�n o espec�ficas de m�dulos.
- Gestionar la estructura de carpetas para la organizaci�n de los datos locales.
- Proporcionar una interfaz para listar entidades disponibles.
"""
import os
import json
import logging
import shutil
from datetime import datetime
from typing import Optional, List, Dict, Any, Type, TypeVar, Generic
from pathlib import Path

# Importar modelos de dominio
from BitnnariApp.data.models.patient import PatientModel
from BitnnariApp.data.models.calibration_params import CalibrationParamsModel
from BitnnariApp.data.models.emg_record import EmgRecordModel

logger = logging.getLogger(__name__)
if not logger.handlers:
   handler = logging.StreamHandler()
   handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
   logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Tipo gen�rico para los modelos Pydantic
T = TypeVar('T', bound='BaseModel') # Pydantic v1, para v2 ser�a from pydantic import BaseModel

# Definici�n de la estructura de directorios base
# Se puede configurar externamente si es necesario
DEFAULT_BASE_DATA_DIR = Path.home() / ".BitnnariApp" / "data_storage"

class LocalFileRepository:
   """
   Repositorio para la persistencia de datos en archivos locales (JSON).
   Implementa el patr�n Singleton.
   """
   _instance: Optional['LocalFileRepository'] = None
   _lock = threading.Lock() # Para asegurar la creaci�n segura del Singleton en entornos multihilo

   BASE_DATA_DIR: Path
   PATIENTS_DIR_NAME = "patients"
   SESSIONS_DIR_NAME = "emg_sessions"
   CALIBRATIONS_DIR_NAME = "calibrations"
   CONFIGS_DIR_NAME = "configurations"
   MODELS_DIR_NAME = "ml_models" # Para modelos de ML serializados

   def __new__(cls, base_data_dir: Optional[Union[str, Path]] = None) -> 'LocalFileRepository':
       if cls._instance is None:
           with cls._lock:
               if cls._instance is None: # Doble verificaci�n por si otro hilo esperaba
                   cls._instance = super().__new__(cls)
                   cls._instance._initialized = False
       return cls._instance

   def __init__(self, base_data_dir: Optional[Union[str, Path]] = None):
       if self._initialized:
           return

       with self._lock:
           if self._initialized: # Doble verificaci�n
               return

           self.BASE_DATA_DIR = Path(base_data_dir) if base_data_dir else DEFAULT_BASE_DATA_DIR
           logger.info(f"Directorio base de datos local inicializado en: {self.BASE_DATA_DIR}")

           self._patients_path = self.BASE_DATA_DIR / self.PATIENTS_DIR_NAME
           self._sessions_path = self.BASE_DATA_DIR / self.SESSIONS_DIR_NAME
           self._calibrations_path = self.BASE_DATA_DIR / self.CALIBRATIONS_DIR_NAME
           self._configs_path = self.BASE_DATA_DIR / self.CONFIGS_DIR_NAME
           self._ml_models_path = self.BASE_DATA_DIR / self.MODELS_DIR_NAME

           self._ensure_base_directories()
           self._initialized = True
           logger.info("LocalFileRepository inicializado y directorios base asegurados.")

   def _ensure_base_directories(self):
       """Asegura que todos los directorios base para el almacenamiento existan."""
       dirs_to_create = [
           self.BASE_DATA_DIR,
           self._patients_path,
           self._sessions_path,
           self._calibrations_path,
           self._configs_path,
           self._ml_models_path
       ]
       for dir_path in dirs_to_create:
           try:
               dir_path.mkdir(parents=True, exist_ok=True)
           except OSError as e:
               logger.error(f"Error al crear el directorio {dir_path}: {e}")
               # Podr�a lanzar una excepci�n m�s espec�fica si la creaci�n es cr�tica
               raise

   def _get_patient_dir(self, patient_dni: str, ensure_exists: bool = True) -> Path:
       """Obtiene y opcionalmente crea el directorio espec�fico para un paciente."""
       patient_dir = self._patients_path / patient_dni.strip().upper()
       if ensure_exists:
           try:
               patient_dir.mkdir(parents=True, exist_ok=True)
           except OSError as e:
               logger.error(f"Error al crear directorio para paciente {patient_dni} en {patient_dir}: {e}")
               raise
       return patient_dir

   def _get_patient_data_filepath(self, patient_dni: str) -> Path:
       """Devuelve la ruta al archivo de datos personales de un paciente."""
       return self._get_patient_dir(patient_dni) / "patient_info.json"

   def _get_calibration_filepath(self, patient_dni: str, calibration_id: str) -> Path:
       """Devuelve la ruta al archivo de una calibraci�n espec�fica de un paciente."""
       patient_cal_dir = self._get_patient_dir(patient_dni) / self.CALIBRATIONS_DIR_NAME
       patient_cal_dir.mkdir(parents=True, exist_ok=True)
       return patient_cal_dir / f"{calibration_id}.json"

   def _get_session_filepath(self, patient_dni: str, record_id: str) -> Path:
       """Devuelve la ruta al archivo de un registro EMG espec�fico de un paciente."""
       patient_sess_dir = self._get_patient_dir(patient_dni) / self.SESSIONS_DIR_NAME
       patient_sess_dir.mkdir(parents=True, exist_ok=True)
       return patient_sess_dir / f"{record_id}.json"

   def _get_config_filepath(self, config_name: str, patient_dni: Optional[str] = None) -> Path:
       """
       Devuelve la ruta a un archivo de configuraci�n.
       Si patient_dni es provisto, es una config espec�fica del paciente.
       Sino, es una config general de la aplicaci�n.
       """
       if patient_dni:
           config_dir = self._get_patient_dir(patient_dni) / self.CONFIGS_DIR_NAME
       else:
           config_dir = self._configs_path
       config_dir.mkdir(parents=True, exist_ok=True)
       return config_dir / f"{config_name}.json"

   def _save_json(self, filepath: Path, data: Dict[str, Any]):
       """Guarda un diccionario como archivo JSON."""
       try:
           with open(filepath, 'w', encoding='utf-8') as f:
               json.dump(data, f, indent=4, ensure_ascii=False)
           logger.debug(f"Datos guardados exitosamente en: {filepath}")
       except IOError as e:
           logger.error(f"Error al guardar archivo JSON en {filepath}: {e}")
           raise
       except TypeError as e:
           logger.error(f"Error de tipo al serializar JSON para {filepath}: {e}")
           raise

   def _load_json(self, filepath: Path) -> Optional[Dict[str, Any]]:
       """Carga datos desde un archivo JSON."""
       if not filepath.exists():
           logger.debug(f"Archivo no encontrado: {filepath}")
           return None
       try:
           with open(filepath, 'r', encoding='utf-8') as f:
               data = json.load(f)
           logger.debug(f"Datos cargados exitosamente desde: {filepath}")
           return data
       except (IOError, json.JSONDecodeError) as e:
           logger.error(f"Error al cargar archivo JSON desde {filepath}: {e}")
           return None

   # --- M�todos para Pacientes ---
   def save_patient(self, patient: PatientModel) -> bool:
       """Guarda los datos de un paciente."""
       filepath = self._get_patient_data_filepath(patient.dni)
       try:
           patient.update_timestamp() # Actualizar updated_at antes de guardar
           self._save_json(filepath, patient.to_dict())
           logger.info(f"Paciente {patient.dni} guardado localmente.")
           return True
       except Exception as e:
           logger.error(f"Fallo al guardar paciente {patient.dni}: {e}")
           return False

   def get_patient(self, patient_dni: str) -> Optional[PatientModel]:
       """Obtiene los datos de un paciente por su DNI."""
       filepath = self._get_patient_data_filepath(patient_dni)
       data = self._load_json(filepath)
       if data:
           try:
               return PatientModel.from_dict(data)
           except Exception as e: # Captura ValidationError de Pydantic u otros
               logger.error(f"Error al deserializar datos del paciente {patient_dni} desde {filepath}: {e}")
               return None
       return None

   def delete_patient(self, patient_dni: str) -> bool:
       """Elimina todos los datos de un paciente (directorio completo)."""
       patient_dir = self._get_patient_dir(patient_dni, ensure_exists=False)
       if patient_dir.exists():
           try:
               shutil.rmtree(patient_dir)
               logger.info(f"Todos los datos del paciente {patient_dni} eliminados localmente.")
               return True
           except OSError as e:
               logger.error(f"Error al eliminar directorio del paciente {patient_dni}: {e}")
               return False
       logger.warning(f"Intento de eliminar paciente {patient_dni} que no existe localmente.")
       return False

   def list_patient_dnis(self) -> List[str]:
       """Lista los DNIs de todos los pacientes almacenados localmente."""
       if not self._patients_path.exists():
           return []
       return [d.name for d in self._patients_path.iterdir() if d.is_dir()]

   # --- M�todos para Par�metros de Calibraci�n ---
   def save_calibration_params(self, params: CalibrationParamsModel) -> bool:
       """Guarda un conjunto de par�metros de calibraci�n."""
       filepath = self._get_calibration_filepath(params.patient_dni, params.calibration_id)
       try:
           self._save_json(filepath, params.to_dict())
           logger.info(f"Par�metros de calibraci�n {params.calibration_id} para paciente {params.patient_dni} guardados.")
           return True
       except Exception as e:
           logger.error(f"Fallo al guardar par�metros de calibraci�n {params.calibration_id}: {e}")
           return False

   def get_calibration_params(self, patient_dni: str, calibration_id: str) -> Optional[CalibrationParamsModel]:
       """Obtiene un conjunto espec�fico de par�metros de calibraci�n."""
       filepath = self._get_calibration_filepath(patient_dni, calibration_id)
       data = self._load_json(filepath)
       if data:
           try:
               return CalibrationParamsModel.from_dict(data)
           except Exception as e:
               logger.error(f"Error al deserializar CalibrationParams {calibration_id} para {patient_dni}: {e}")
               return None
       return None

   def list_calibration_ids_for_patient(self, patient_dni: str) -> List[str]:
       """Lista los IDs de todas las calibraciones guardadas para un paciente."""
       patient_cal_dir = self._get_patient_dir(patient_dni, ensure_exists=False) / self.CALIBRATIONS_DIR_NAME
       if not patient_cal_dir.exists():
           return []
       return [f.stem for f in patient_cal_dir.glob("*.json")] # f.stem es el nombre sin extensi�n

   def get_latest_calibration_params(self, patient_dni: str) -> Optional[CalibrationParamsModel]:
       """Obtiene los par�metros de calibraci�n m�s recientes para un paciente."""
       cal_ids = self.list_calibration_ids_for_patient(patient_dni)
       if not cal_ids:
           return None
       
       latest_cal: Optional[CalibrationParamsModel] = None
       latest_timestamp: Optional[datetime] = None

       for cal_id in cal_ids:
           params = self.get_calibration_params(patient_dni, cal_id)
           if params:
               if latest_timestamp is None or params.timestamp > latest_timestamp:
                   latest_timestamp = params.timestamp
                   latest_cal = params
       return latest_cal

   # --- M�todos para Registros EMG (Sesiones) ---
   def save_emg_record(self, record: EmgRecordModel) -> bool:
       """Guarda un registro EMG."""
       filepath = self._get_session_filepath(record.patient_dni, record.record_id)
       try:
           self._save_json(filepath, record.to_dict())
           logger.info(f"Registro EMG {record.record_id} para paciente {record.patient_dni} guardado.")
           return True
       except Exception as e:
           logger.error(f"Fallo al guardar registro EMG {record.record_id}: {e}")
           return False

   def get_emg_record(self, patient_dni: str, record_id: str) -> Optional[EmgRecordModel]:
       """Obtiene un registro EMG espec�fico."""
       filepath = self._get_session_filepath(patient_dni, record_id)
       data = self._load_json(filepath)
       if data:
           try:
               return EmgRecordModel.from_dict(data)
           except Exception as e:
               logger.error(f"Error al deserializar EmgRecord {record_id} para {patient_dni}: {e}")
               return None
       return None

   def list_emg_record_ids_for_patient(self, patient_dni: str) -> List[str]:
       """Lista los IDs de todos los registros EMG para un paciente."""
       patient_sess_dir = self._get_patient_dir(patient_dni, ensure_exists=False) / self.SESSIONS_DIR_NAME
       if not patient_sess_dir.exists():
           return []
       return [f.stem for f in patient_sess_dir.glob("*.json")]

   def get_all_emg_records_for_patient(self, patient_dni: str) -> List[EmgRecordModel]:
       """Obtiene todos los registros EMG para un paciente, ordenados por timestamp descendente."""
       record_ids = self.list_emg_record_ids_for_patient(patient_dni)
       records: List[EmgRecordModel] = []
       for rec_id in record_ids:
           record = self.get_emg_record(patient_dni, rec_id)
           if record:
               records.append(record)
       # Ordenar por timestamp, m�s reciente primero
       records.sort(key=lambda r: r.timestamp, reverse=True)
       return records

   # --- M�todos para Configuraciones Gen�ricas ---
   def save_configuration(self, config_name: str, config_data: Dict[str, Any], patient_dni: Optional[str] = None):
       """Guarda un archivo de configuraci�n."""
       filepath = self._get_config_filepath(config_name, patient_dni)
       self._save_json(filepath, config_data)
       scope = f"paciente {patient_dni}" if patient_dni else "global"
       logger.info(f"Configuraci�n '{config_name}' ({scope}) guardada.")

   def load_configuration(self, config_name: str, patient_dni: Optional[str] = None) -> Optional[Dict[str, Any]]:
       """Carga un archivo de configuraci�n."""
       filepath = self._get_config_filepath(config_name, patient_dni)
       return self._load_json(filepath)

   # --- M�todos para Modelos de Machine Learning (b�sico, solo rutas) ---
   def get_ml_model_path(self, model_name: str, patient_dni: Optional[str] = None, version: Optional[str] = None) -> Path:
       """
       Construye la ruta para un archivo de modelo de ML.
       Los modelos pueden ser globales o espec�ficos del paciente.
       """
       if patient_dni:
           model_dir = self._get_patient_dir(patient_dni) / self.MODELS_DIR_NAME
       else:
           model_dir = self._ml_models_path
       
       model_dir.mkdir(parents=True, exist_ok=True)
       
       filename = model_name
       if version:
           filename += f"_v{version}"
       filename += ".pkl" # Asumiendo formato pickle por defecto, podr�a ser .h5, .onnx, etc.
       
       return model_dir / filename

   def model_exists(self, model_name: str, patient_dni: Optional[str] = None, version: Optional[str] = None) -> bool:
       """Verifica si un archivo de modelo de ML existe."""
       return self.get_ml_model_path(model_name, patient_dni, version).exists()

# Ejemplo de uso e inicializaci�n
if __name__ == "__main__":
   # Crear una instancia del repositorio (Singleton)
   # Se puede pasar un directorio base customizado para pruebas
   test_data_dir = Path("./temp_bitnari_repo_data")
   if test_data_dir.exists():
       shutil.rmtree(test_data_dir) # Limpiar directorio de pruebas anterior

   repo = LocalFileRepository(base_data_dir=test_data_dir)
   logger.info(f"Repositorio de prueba usando directorio: {repo.BASE_DATA_DIR}")

   # Crear y guardar un paciente
   patient1_data = {
       "dni": "12345678Z", "nombre": "Juan Test", "fecha_nacimiento": "1980-01-01",
       "contacto": {"email": "juan.test@example.com"}
   }
   patient1 = PatientModel(**patient1_data)
   repo.save_patient(patient1)

   # Recuperar el paciente
   retrieved_patient1 = repo.get_patient("12345678Z")
   if retrieved_patient1:
       logger.info(f"Paciente recuperado: {retrieved_patient1.nombre}, Email: {retrieved_patient1.contacto.get('email')}")
   else:
       logger.error("No se pudo recuperar el paciente.")

   # Guardar una calibraci�n para el paciente
   cal_id = f"cal_{datetime.now().strftime('%Y%m%d%H%M%S')}"
   calibration1_data = {
       "calibration_id": cal_id, "patient_dni": "12345678Z", "num_channels": 2,
       "offset_values": [0.1, -0.05], "gain_values": [1.0, 1.02]
   }
   calibration1 = CalibrationParamsModel(**calibration1_data)
   repo.save_calibration_params(calibration1)

   # Listar calibraciones y obtener la m�s reciente
   cal_ids = repo.list_calibration_ids_for_patient("12345678Z")
   logger.info(f"IDs de calibraci�n para 12345678Z: {cal_ids}")
   latest_cal = repo.get_latest_calibration_params("12345678Z")
   if latest_cal:
       logger.info(f"�ltima calibraci�n: ID {latest_cal.calibration_id}, Offset CH1: {latest_cal.offset_values[0] if latest_cal.offset_values else 'N/A'}")

   # Guardar un registro EMG
   rec_id = f"rec_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
   emg_data_ch1 = np.sin(np.linspace(0, 10, 100)).tolist()
   emg_data_ch2 = np.cos(np.linspace(0, 10, 100)).tolist()
   record1_data = {
       "record_id": rec_id, "patient_dni": "12345678Z", "duration_s": 0.1,
       "sampling_rate_hz": 1000.0, "num_channels": 2,
       "raw_data": [emg_data_ch1, emg_data_ch2], # [[ch1_samples], [ch2_samples]]
       "label": "test_contraction"
   }
   record1 = EmgRecordModel(**record1_data)
   repo.save_emg_record(record1)

   # Listar todos los registros EMG para el paciente
   all_records = repo.get_all_emg_records_for_patient("12345678Z")
   logger.info(f"N�mero de registros EMG para 12345678Z: {len(all_records)}")
   if all_records:
       logger.info(f"�ltimo registro EMG ID: {all_records[0].record_id}, Label: {all_records[0].label}")

   # Guardar una configuraci�n global
   app_config = {"theme": "dark", "last_used_port": "COM3"}
   repo.save_configuration("app_settings", app_config)
   loaded_app_config = repo.load_configuration("app_settings")
   if loaded_app_config:
       logger.info(f"Configuraci�n de app cargada: Theme = {loaded_app_config.get('theme')}")

   # Guardar una configuraci�n espec�fica de paciente
   patient_module_config = {"window_size": 256, "feature_set": "standard"}
   repo.save_configuration("processing_prefs", patient_module_config, patient_dni="12345678Z")
   loaded_patient_config = repo.load_configuration("processing_prefs", patient_dni="12345678Z")
   if loaded_patient_config:
       logger.info(f"Configuraci�n de procesamiento para 12345678Z: Window Size = {loaded_patient_config.get('window_size')}")

   # Obtener ruta de un modelo de ML
   model_path = repo.get_ml_model_path("emg_classifier_svm", patient_dni="12345678Z", version="1.0")
   logger.info(f"Ruta para modelo de ML: {model_path}")
   # Aqu� se podr�a guardar un modelo real usando joblib.dump(model, model_path)

   # Limpiar directorio de prueba despu�s de la ejecuci�n
   # shutil.rmtree(test_data_dir)
   # logger.info(f"Directorio de prueba {test_data_dir} eliminado.")
   
