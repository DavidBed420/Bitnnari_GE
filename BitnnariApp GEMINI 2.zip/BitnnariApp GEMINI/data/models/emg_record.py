"""
emg_record.py

Define la clase de dominio EmgRecord, que representa una sesi�n o un fragmento
de datos de se�al EMG capturados.
"""
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import numpy as np
from pydantic import BaseModel, Field, validator

logger = logging.getLogger(__name__)

class EmgRecordModel(BaseModel):
   """
   Modelo Pydantic para un Registro de Se�al EMG.
   Representa una captura de datos EMG, que puede incluir datos crudos, procesados,
   etiquetas y metadatos asociados.
   """
   record_id: str = Field(..., description="Identificador �nico para este registro EMG.")
   patient_dni: str = Field(..., description="DNI del paciente al que pertenece este registro.")
   session_id: Optional[str] = Field(None, description="Identificador de la sesi�n de adquisici�n m�s amplia, si aplica.")
   timestamp: datetime = Field(default_factory=datetime.utcnow, description="Fecha y hora de la captura del registro.")
   
   duration_s: float = Field(..., gt=0, description="Duraci�n de este registro de se�al en segundos.")
   sampling_rate_hz: float = Field(..., gt=0, description="Frecuencia de muestreo utilizada para esta se�al (Hz).")
   num_channels: int = Field(..., gt=0, description="N�mero de canales en este registro.")
   
   # Datos de la se�al
   # Se almacenan como List[List[float]] ([canal, muestra] o [muestra, canal])
   # o List[float] si es un solo canal.
   # Al cargar, se pueden convertir a NumPy arrays.
   raw_data: Optional[List[List[float]]] = Field(None, description="Datos EMG crudos. Formato: lista de listas (canales x muestras o muestras x canales).")
   processed_data: Optional[List[List[float]]] = Field(None, description="Datos EMG procesados, si aplica.")
   
   # Metadatos y caracter�sticas
   label: Optional[str] = Field(None, description="Etiqueta asociada al movimiento o estado durante la captura (e.g., 'pu�o', 'reposo').")
   features_extracted: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Caracter�sticas extra�das de esta se�al.")
   
   # Configuraci�n utilizada (snapshots)
   acquisition_settings_snapshot: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Snapshot de la configuraci�n de adquisici�n.")
   calibration_id_used: Optional[str] = Field(None, description="ID de los par�metros de calibraci�n aplicados, si alguno.")
   processing_config_snapshot: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Snapshot de la configuraci�n de procesamiento aplicada.")
   
   notes: Optional[str] = Field(None, description="Notas adicionales sobre este registro.")

   @validator('raw_data', 'processed_data', pre=True, always=True)
   def validate_signal_data_format(cls, v: Optional[Union[List[List[float]], np.ndarray]], values: Dict[str, Any]) -> Optional[List[List[float]]]:
       """
       Valida que los datos de la se�al (si se proporcionan) tengan la forma correcta
       en relaci�n con num_channels y duration_s * sampling_rate_hz.
       Convierte NumPy arrays a listas de listas para la serializaci�n.
       """
       if v is None:
           return None

       data_list: List[List[float]]
       if isinstance(v, np.ndarray):
           # Asegurar que sea 2D [canales, muestras] o [muestras, canales]
           if v.ndim == 1: # Asumir un solo canal
               if values.get('num_channels') != 1:
                   raise ValueError("Si la se�al es 1D, num_channels debe ser 1.")
               data_list = [v.tolist()] # Convertir a lista de listas: [[muestra1, muestra2, ...]]
           elif v.ndim == 2:
               # Decidir si es [canales, muestras] o [muestras, canales]
               # Si num_channels coincide con v.shape[0], asumir [canales, muestras]
               # Si num_channels coincide con v.shape[1], asumir [muestras, canales] y transponer si es necesario para consistencia.
               # Por convenci�n, podr�amos decidir almacenar siempre como [canales, muestras].
               if values.get('num_channels') == v.shape[0]: # [canales, muestras]
                   data_list = v.tolist()
               elif values.get('num_channels') == v.shape[1]: # [muestras, canales], transponer para [canales, muestras]
                   data_list = v.T.tolist()
               else:
                   raise ValueError(f"Forma del array ({v.shape}) no coincide con num_channels ({values.get('num_channels')}).")
           else:
               raise ValueError("El array de la se�al debe ser 1D o 2D.")
       elif isinstance(v, list):
           if not v: # Lista vac�a
               data_list = []
           elif all(isinstance(sublist, list) for sublist in v): # Ya es lista de listas
               data_list = v
           elif all(isinstance(item, (float, int)) for item in v): # Lista 1D, asumir un solo canal
                if values.get('num_channels') != 1:
                   raise ValueError("Si la se�al es una lista 1D, num_channels debe ser 1.")
                data_list = [v]
           else:
               raise ValueError("Formato de lista de se�al no soportado.")
       else:
           raise TypeError("Los datos de la se�al deben ser un NumPy array o una lista (de listas).")

       # Validar consistencia de num_channels
       if data_list and len(data_list) != values.get('num_channels'):
           raise ValueError(f"El n�mero de listas internas ({len(data_list)}) debe coincidir con num_channels ({values.get('num_channels')}).")

       # Validar consistencia de n�mero de muestras (opcional, pero bueno para integridad)
       # num_expected_samples = int(values.get('duration_s', 0) * values.get('sampling_rate_hz', 0))
       # if data_list and num_expected_samples > 0:
       #     for channel_data in data_list:
       #         if len(channel_data) != num_expected_samples:
       #             logger.warning(f"Longitud de canal ({len(channel_data)}) no coincide con muestras esperadas ({num_expected_samples}).")
       
       return data_list

   def to_dict(self) -> Dict[str, Any]:
       """Convierte el modelo a un diccionario, formateando fechas a ISO string."""
       data = self.model_dump(exclude_none=True)
       data['timestamp'] = self.timestamp.isoformat()
       return data

   @classmethod
   def from_dict(cls, data: Dict[str, Any]) -> 'EmgRecordModel':
       """Crea una instancia de EmgRecordModel desde un diccionario."""
       if 'timestamp' in data and isinstance(data['timestamp'], str):
           data['timestamp'] = datetime.fromisoformat(data['timestamp'])
       return cls(**data)

   def get_raw_data_as_array(self, orientation: str = 'channels_x_samples') -> Optional[np.ndarray]:
       """
       Devuelve los datos crudos como un NumPy array.
       
       Args:
           orientation (str): 'channels_x_samples' (default) o 'samples_x_channels'.
       
       Returns:
           Optional[np.ndarray]: Array con los datos, o None si no hay datos.
       """
       if self.raw_data is None:
           return None
       arr = np.array(self.raw_data, dtype=float) # Asume que raw_data est� como [canales, muestras]
       if orientation == 'samples_x_channels':
           return arr.T
       return arr

   def get_processed_data_as_array(self, orientation: str = 'channels_x_samples') -> Optional[np.ndarray]:
       """
       Devuelve los datos procesados como un NumPy array.

       Args:
           orientation (str): 'channels_x_samples' (default) o 'samples_x_channels'.

       Returns:
           Optional[np.ndarray]: Array con los datos, o None si no hay datos.
       """
       if self.processed_data is None:
           return None
       arr = np.array(self.processed_data, dtype=float) # Asume que processed_data est� como [canales, muestras]
       if orientation == 'samples_x_channels':
           return arr.T
       return arr

# Ejemplo de uso
if __name__ == "__main__":
   try:
       record_id_ex = f"rec_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
       # Ejemplo de datos: 2 canales, 1000 muestras (1 segundo a 1000 Hz)
       example_raw_data_np = np.random.rand(2, 1000) # [canales, muestras]

       record_data = {
           "record_id": record_id_ex,
           "patient_dni": "12345678Z",
           "session_id": "sess_abc123",
           "duration_s": 1.0,
           "sampling_rate_hz": 1000.0,
           "num_channels": 2,
           "raw_data": example_raw_data_np, # Pasa el NumPy array
           "label": "contraccion_pu�o",
           "acquisition_settings_snapshot": {"port": "COM3", "gain": 100}
       }
       emg_record1 = EmgRecordModel(**record_data)
       logger.info(f"Registro EMG creado: ID {emg_record1.record_id}, Paciente {emg_record1.patient_dni}")
       
       raw_array_retrieved = emg_record1.get_raw_data_as_array()
       if raw_array_retrieved is not None:
           logger.info(f"Forma del array de datos crudos recuperado: {raw_array_retrieved.shape}") # Deber�a ser (2, 1000)

       record_dict = emg_record1.to_dict()
       logger.info(f"Diccionario del registro (primeras 5 muestras del primer canal): {record_dict['raw_data'][0][:5] if record_dict.get('raw_data') else 'N/A'}")

       record_reloaded = EmgRecordModel.from_dict(record_dict)
       logger.info(f"Registro recargado: ID {record_reloaded.record_id}, Label: {record_reloaded.label}")

       # Ejemplo con datos 1D (un solo canal)
       example_raw_data_1d_np = np.random.rand(500) # 0.5 segundos a 1000 Hz
       record_data_1d = {
           "record_id": f"rec1D_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
           "patient_dni": "12345678Z",
           "duration_s": 0.5,
           "sampling_rate_hz": 1000.0,
           "num_channels": 1,
           "raw_data": example_raw_data_1d_np.tolist(), # Pasa como lista
       }
       emg_record_1d = EmgRecordModel(**record_data_1d)
       logger.info(f"Registro EMG 1D creado: ID {emg_record_1d.record_id}")
       raw_array_1d_retrieved = emg_record_1d.get_raw_data_as_array()
       if raw_array_1d_retrieved is not None:
            logger.info(f"Forma del array 1D recuperado: {raw_array_1d_retrieved.shape}") # Deber�a ser (1, 500)


   except Exception as e: # Captura ValidationError de Pydantic u otros
       logger.error(f"Error durante el ejemplo de EmgRecordModel: {e}", exc_info=True)
   
