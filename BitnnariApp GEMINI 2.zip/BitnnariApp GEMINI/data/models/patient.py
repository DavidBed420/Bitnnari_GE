"""
patient.py

Define la clase de dominio Patient, que representa a un paciente en el sistema.
Esta clase es utilizada tanto por el backend como por la aplicaci�n de escritorio
para asegurar la consistencia de la estructura de datos.
"""
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, validator, EmailStr

logger = logging.getLogger(__name__)

class PatientModel(BaseModel):
   """
   Modelo Pydantic para un Paciente.
   Utiliza Pydantic para validaci�n de datos y serializaci�n.
   """
   dni: str = Field(..., min_length=1, description="Documento Nacional de Identidad del paciente.")
   nombre: str = Field(..., min_length=1, description="Nombre completo del paciente.")
   fecha_nacimiento: Optional[datetime] = Field(None, description="Fecha de nacimiento del paciente.")
   contacto: Dict[str, Optional[str]] = Field(default_factory=dict, description="Informaci�n de contacto (tel�fono, email).")
   foto_path: Optional[str] = Field(None, description="Ruta al archivo de la foto del paciente.")
   patologias: List[str] = Field(default_factory=list, description="Lista de patolog�as o condiciones m�dicas.")
   factores_riesgo: List[str] = Field(default_factory=list, description="Factores de riesgo asociados.")
   factores_predisponentes: List[str] = Field(default_factory=list, description="Factores predisponentes.")
   diagnostico_amputacion: Optional[str] = Field(None, description="Diagn�stico relacionado con amputaci�n, si aplica.")
   direccion: Optional[str] = Field(None, description="Direcci�n postal del paciente.")
   modelo_ml_preferido: Optional[str] = Field(None, description="Modelo de Machine Learning preferido para este paciente.")
   historial_sesiones_ids: List[str] = Field(default_factory=list, description="IDs de las sesiones EMG asociadas.")
   historial_calibraciones_ids: List[str] = Field(default_factory=list, description="IDs de los par�metros de calibraci�n asociados.")
   notas_adicionales: Optional[str] = Field(None, description="Notas adicionales sobre el paciente.")
   created_at: datetime = Field(default_factory=datetime.utcnow, description="Fecha y hora de creaci�n del registro.")
   updated_at: datetime = Field(default_factory=datetime.utcnow, description="Fecha y hora de la �ltima actualizaci�n.")

   @validator('dni')
   def dni_alphanumeric_and_format(cls, v: str) -> str:
       """Valida y formatea el DNI (permite n�meros, letras, guiones y puntos)."""
       # Permitir DNI con letras (ej. pasaporte) y normalizar a may�sculas
       # Eliminar puntos y guiones solo para validaci�n de longitud si es necesario,
       # pero se guarda con el formato original ingresado si es v�lido.
       # Aqu�, solo normalizamos a may�sculas y verificamos que no est� vac�o.
       if not v.strip():
           raise ValueError('El DNI no puede estar vac�o.')
       return v.strip().upper()

   @validator('nombre')
   def nombre_not_empty(cls, v: str) -> str:
       if not v.strip():
           raise ValueError('El nombre no puede estar vac�o.')
       # Podr�a a�adirse una regex para validar caracteres permitidos si es necesario.
       return v.strip()

   @validator('fecha_nacimiento', pre=True, always=True)
   def parse_fecha_nacimiento(cls, v: Any) -> Optional[datetime]:
       if v is None:
           return None
       if isinstance(v, datetime):
           return v
       if isinstance(v, str):
           try:
               # Intentar parsear formatos comunes
               return datetime.strptime(v, '%Y-%m-%d')
           except ValueError:
               try:
                   return datetime.strptime(v, '%d/%m/%Y')
               except ValueError:
                   raise ValueError("Formato de fecha de nacimiento inv�lido. Usar YYYY-MM-DD o DD/MM/YYYY.")
       raise TypeError("Tipo de fecha de nacimiento no soportado.")

   @validator('contacto')
   def validate_contacto_email(cls, v: Dict[str, Optional[str]]) -> Dict[str, Optional[str]]:
       if 'email' in v and v['email']:
           # Pydantic tiene EmailStr para validaci�n de email, pero aqu� lo hacemos manual
           # para mostrar un ejemplo de validaci�n custom dentro del dict.
           # En una implementaci�n real, se podr�a usar un submodelo Pydantic para 'contacto'.
           email = v['email']
           if '@' not in email or '.' not in email.split('@')[-1]:
               raise ValueError(f"Direcci�n de correo electr�nico inv�lida: {email}")
       return v

   def to_dict(self) -> Dict[str, Any]:
       """Convierte el modelo a un diccionario, formateando fechas a ISO string."""
       data = self.model_dump(exclude_none=True) # Pydantic v2
       # data = self.dict(exclude_none=True) # Pydantic v1
       if self.fecha_nacimiento:
           data['fecha_nacimiento'] = self.fecha_nacimiento.isoformat()
       data['created_at'] = self.created_at.isoformat()
       data['updated_at'] = self.updated_at.isoformat()
       return data

   @classmethod
   def from_dict(cls, data: Dict[str, Any]) -> 'PatientModel':
       """Crea una instancia de PatientModel desde un diccionario."""
       # Convertir fechas de string ISO a datetime si es necesario
       if 'fecha_nacimiento' in data and isinstance(data['fecha_nacimiento'], str):
           try:
               data['fecha_nacimiento'] = datetime.fromisoformat(data['fecha_nacimiento'])
           except ValueError: # Podr�a venir en otro formato desde una fuente antigua
               try:
                   data['fecha_nacimiento'] = datetime.strptime(data['fecha_nacimiento'], '%Y-%m-%d')
               except ValueError:
                    data['fecha_nacimiento'] = None # o manejar el error
       if 'created_at' in data and isinstance(data['created_at'], str):
           data['created_at'] = datetime.fromisoformat(data['created_at'])
       if 'updated_at' in data and isinstance(data['updated_at'], str):
           data['updated_at'] = datetime.fromisoformat(data['updated_at'])
       
       return cls(**data)

   def update_timestamp(self):
       """Actualiza el campo updated_at a la hora actual."""
       self.updated_at = datetime.utcnow()

   def calculate_age(self) -> Optional[int]:
       """Calcula la edad del paciente."""
       if not self.fecha_nacimiento:
           return None
       today = datetime.utcnow()
       age = today.year - self.fecha_nacimiento.year - \
             ((today.month, today.day) < (self.fecha_nacimiento.month, self.fecha_nacimiento.day))
       return age

# Ejemplo de uso
if __name__ == "__main__":
   try:
       patient_data_valid = {
           "dni": "12345678Z",
           "nombre": "Juan P�rez Garc�a",
           "fecha_nacimiento": "1990-05-15",
           "contacto": {"email": "juan.perez@example.com", "telefono": "+34600123456"},
           "patologias": ["Hipertensi�n", "Diabetes tipo 2"],
           "modelo_ml_preferido": "random_forest"
       }
       patient1 = PatientModel(**patient_data_valid)
       logger.info(f"Paciente v�lido creado: {patient1.nombre}, DNI: {patient1.dni}, Edad: {patient1.calculate_age()}")
       logger.info(f"Diccionario del paciente: {patient1.to_dict()}")

       patient_dict_from_db = patient1.to_dict()
       patient_reloaded = PatientModel.from_dict(patient_dict_from_db)
       logger.info(f"Paciente recargado: {patient_reloaded.nombre}, Fecha Nacimiento: {patient_reloaded.fecha_nacimiento}")

       patient_data_invalid_dni = {"dni": "", "nombre": "Ana"}
       # patient2 = PatientModel(**patient_data_invalid_dni) # Esto lanzar� un ValidationError

   except Exception as e: # Captura ValidationError de Pydantic u otros
       logger.error(f"Error durante el ejemplo de PatientModel: {e}")

   # Ejemplo con fecha en otro formato
   patient_data_date_format = {
       "dni": "ABC987", "nombre": "Maria Lopez", "fecha_nacimiento": "20/07/1985"
   }
   patient3 = PatientModel(**patient_data_date_format)
   logger.info(f"Paciente con fecha DD/MM/YYYY: {patient3.nombre}, Nacimiento: {patient3.fecha_nacimiento}")
   logger.info(f"Edad: {patient3.calculate_age()}")
   

