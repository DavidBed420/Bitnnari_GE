"""
calibration_params.py

Define la clase de dominio CalibrationParams, que representa los par�metros
resultantes de un proceso de calibraci�n de se�ales EMG.
"""
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import numpy as np
from pydantic import BaseModel, Field, validator

logger = logging.getLogger(__name__)

class CalibrationParamsModel(BaseModel):
   """
   Modelo Pydantic para los Par�metros de Calibraci�n EMG.
   Almacena los resultados de un proceso de calibraci�n, como offset y ganancia por canal.
   """
   calibration_id: str = Field(..., description="Identificador �nico para esta calibraci�n.")
   patient_dni: str = Field(..., description="DNI del paciente al que pertenece esta calibraci�n.")
   timestamp: datetime = Field(default_factory=datetime.utcnow, description="Fecha y hora en que se realiz� la calibraci�n.")
   
   num_channels: int = Field(..., gt=0, description="N�mero de canales para los cuales se calcularon estos par�metros.")
   
   # Par�metros de offset (l�nea base)
   offset_values: Optional[List[float]] = Field(None, description="Valores de offset calculados para cada canal.")
   
   # Par�metros de ganancia (escalado)
   gain_values: Optional[List[float]] = Field(None, description="Valores de ganancia calculados para cada canal.")
   
   # Configuraci�n utilizada para esta calibraci�n (opcional pero �til)
   acquisition_settings_snapshot: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Snapshot de la configuraci�n de adquisici�n usada.")
   filter_settings_snapshot: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Snapshot de la configuraci�n de filtros usada.")
   calibration_run_config_snapshot: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Snapshot de la configuraci�n de la ejecuci�n de calibraci�n.")

   # M�tricas o estad�sticas de la calibraci�n (opcional)
   raw_data_mean_during_cal: Optional[List[float]] = Field(None, description="Media de la se�al cruda durante la calibraci�n de offset.")
   raw_data_std_during_cal: Optional[List[float]] = Field(None, description="Desviaci�n est�ndar de la se�al cruda durante la calibraci�n de offset.")
   mvc_peak_values: Optional[List[float]] = Field(None, description="Valores pico de MVC si se us� para calibrar ganancia.")

   notes: Optional[str] = Field(None, description="Notas adicionales sobre esta calibraci�n espec�fica.")

   @validator('offset_values', 'gain_values', 'raw_data_mean_during_cal', 'raw_data_std_during_cal', 'mvc_peak_values', pre=True, always=True)
   def ensure_list_length_matches_channels(cls, v: Optional[Union[List[float], np.ndarray]], values: Dict[str, Any]) -> Optional[List[float]]:
       """Valida que las listas de par�metros tengan la longitud correcta seg�n num_channels."""
       if v is None:
           return None
       
       num_channels = values.get('num_channels')
       if num_channels is None: # num_channels a�n no est� disponible en `values` si este validador corre antes
           # En Pydantic v2, `values` es `ValidationInfo` y se puede acceder a `values.data['num_channels']`
           # Para Pydantic v1, este validador podr�a necesitar ejecutarse despu�s de num_channels o
           # se podr�a pasar num_channels de otra forma.
           # Por ahora, si num_channels no est�, no podemos validar longitud.
           if isinstance(v, np.ndarray):
               return v.tolist()
           return v

       current_list = v
       if isinstance(v, np.ndarray):
           current_list = v.tolist()
       
       if not isinstance(current_list, list):
           raise ValueError("El valor debe ser una lista de floats o un NumPy array.")

       if len(current_list) != num_channels:
           raise ValueError(f"La longitud de la lista ({len(current_list)}) debe coincidir con num_channels ({num_channels}).")
       return current_list

   def to_dict(self) -> Dict[str, Any]:
       """Convierte el modelo a un diccionario, formateando fechas a ISO string."""
       data = self.model_dump(exclude_none=True)
       data['timestamp'] = self.timestamp.isoformat()
       return data

   @classmethod
   def from_dict(cls, data: Dict[str, Any]) -> 'CalibrationParamsModel':
       """Crea una instancia de CalibrationParamsModel desde un diccionario."""
       if 'timestamp' in data and isinstance(data['timestamp'], str):
           data['timestamp'] = datetime.fromisoformat(data['timestamp'])
       return cls(**data)

   def get_offset_array(self) -> Optional[np.ndarray]:
       """Devuelve los valores de offset como un NumPy array."""
       return np.array(self.offset_values) if self.offset_values is not None else None

   def get_gain_array(self) -> Optional[np.ndarray]:
       """Devuelve los valores de ganancia como un NumPy array."""
       return np.array(self.gain_values) if self.gain_values is not None else None

# Ejemplo de uso
if __name__ == "__main__":
   try:
       cal_id_example = f"cal_{datetime.now().strftime('%Y%m%d%H%M%S')}"
       params_data = {
           "calibration_id": cal_id_example,
           "patient_dni": "12345678Z",
           "num_channels": 2,
           "offset_values": [0.05, -0.02],
           "gain_values": [0.98, 1.02],
           "acquisition_settings_snapshot": {"sample_rate": 1000, "duration_s": 5},
           "notes": "Calibraci�n de offset en reposo."
       }
       cal_params1 = CalibrationParamsModel(**params_data)
       logger.info(f"Par�metros de calibraci�n creados: ID {cal_params1.calibration_id} para paciente {cal_params1.patient_dni}")
       logger.info(f"Offset: {cal_params1.get_offset_array()}, Ganancia: {cal_params1.get_gain_array()}")

       params_dict = cal_params1.to_dict()
       logger.info(f"Diccionario de par�metros: {params_dict}")

       params_reloaded = CalibrationParamsModel.from_dict(params_dict)
       logger.info(f"Par�metros recargados: ID {params_reloaded.calibration_id}, Timestamp: {params_reloaded.timestamp}")

       # Ejemplo con error de validaci�n (longitud de offset incorrecta)
       invalid_params_data = {
           "calibration_id": "cal_error",
           "patient_dni": "87654321X",
           "num_channels": 3,
           "offset_values": [0.1, 0.2] # Solo 2 valores para 3 canales
       }
       # cal_params_invalid = CalibrationParamsModel(**invalid_params_data) # Esto lanzar� ValidationError

   except Exception as e: # Captura ValidationError de Pydantic u otros
       logger.error(f"Error durante el ejemplo de CalibrationParamsModel: {e}")
   
