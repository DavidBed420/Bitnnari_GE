"""
test_classification.py

Pruebas unitarias y de integración para el módulo emg_classification.py,
específicamente para la clase EMGClassificationEngine y el modelo TorchModel.
"""

import os
import json
import shutil
import tempfile
import logging
import time
from typing import Dict, Any, List, Optional, Union
from unittest.mock import MagicMock, patch, call

import numpy as np
import pytest
import joblib
import torch

# Módulos a probar y dependencias
from BitnnariApp.classification.emg_classification import (
    EMGClassificationEngine, TorchModel, DEFAULT_CLASSIFICATION_CONFIG
)
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition, SerialConfig, AcquisitionConfig as EMGDeviceAcqConfig
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager
from BitnnariApp.processing.emg_processing import EMGProcessingEngine

# Modelos de Scikit-learn para instanciar
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


# Configurar un logger para las pruebas
logger = logging.getLogger("TestEMGClassification")
logger.setLevel(logging.DEBUG)
# logging.getLogger("EMGClassificationEngine").setLevel(logging.DEBUG)

# --- Fixtures ---
@pytest.fixture(scope="function")
def temp_project_dirs() -> Dict[str, str]:
    """Crea directorios temporales para modelos, métricas, etc., y los limpia."""
    base_path = tempfile.mkdtemp(prefix="bitnariapp_test_classif_")
    paths = {
        "models_dir": os.path.join(base_path, "trained_models"),
        "metrics_dir": os.path.join(base_path, "training_metrics"),
        "tensorboard_log_dir": os.path.join(base_path, "runs", "classification"),
        "data_root_for_dm": os.path.join(base_path, "app_data") # Para el mock de GestorDatos
    }
    for path_val in paths.values():
        os.makedirs(path_val, exist_ok=True)
    
    yield paths # Proporciona las rutas al test
    
    shutil.rmtree(base_path)

@pytest.fixture
def mock_data_manager(temp_project_dirs: Dict[str, str]) -> MagicMock:
    mock_dm = MagicMock(spec=GestorDatos)
    mock_dm_storage: Dict[str, Any] = {} # Simulación de almacenamiento en memoria

    def mock_guardar_datos(patient_id: str, data_type_key: str, data_content: Any, filename_suffix: Optional[str] = None):
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        mock_dm_storage[storage_key] = data_content
        # logger.debug(f"[MockDM Classif] Guardado: {storage_key}")
        return True

    def mock_cargar_datos(patient_id: str, data_type_key: str, filename_suffix: Optional[str] = None) -> Optional[Any]:
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        # logger.debug(f"[MockDM Classif] Cargando: {storage_key}")
        return mock_dm_storage.get(storage_key)

    mock_dm.guardar_datos.side_effect = mock_guardar_datos
    mock_dm.cargar_datos.side_effect = mock_cargar_datos
    # Simular que el paciente activo está seteado
    mock_dm.paciente_actual = {"dni": "test_patient_classif", "nombre": "Test Patient Classif"}
    return mock_dm

@pytest.fixture
def mock_emg_acquirer() -> MagicMock:
    mock_acq = MagicMock(spec=EMGAcquisition)
    mock_acq.is_connected.return_value = True
    mock_acq.connect.return_value = True
    mock_acq.acq_config = EMGDeviceAcqConfig(num_channels_active=2, delay_ms=10) # 100 Hz
    
    # Simular read_data para devolver paquetes de datos crudos
    def read_data_side_effect():
        time.sleep(0.01) # Simular el delay_ms
        return {
            "raw_data": (np.random.rand(mock_acq.acq_config.num_channels_active) * 100).tolist(),
            "arduino_ms": int(time.time() * 1000),
            "num_channels_active": mock_acq.acq_config.num_channels_active
        }
    mock_acq.read_data.side_effect = read_data_side_effect
    return mock_acq

@pytest.fixture
def mock_calibration_manager() -> MagicMock:
    mock_cm = MagicMock(spec=EMGCalibrationManager)
    mock_cm.offset_params = np.array([0.0, 0.0]) # Asumir 2 canales
    mock_cm.gain_params = np.array([1.0, 1.0])
    mock_cm.apply_calibration.side_effect = lambda data: data # Por defecto, no hace nada
    return mock_cm

@pytest.fixture
def mock_processing_engine() -> MagicMock:
    mock_pe = MagicMock(spec=EMGProcessingEngine)
    # Simular que extract_all_features devuelve un vector de N características por canal
    # y que el engine ya está configurado con un sampling_rate
    mock_pe.sampling_rate = 1000.0
    N_FEATURES_PER_CHANNEL = 5 
    def extract_features_side_effect(signal_data_window: np.ndarray):
        # signal_data_window es [n_samples_in_window, n_channels]
        num_channels = signal_data_window.shape[1]
        # Devolver una lista de dicts, uno por canal
        # O, si el engine ya devuelve un vector aplanado:
        # return (np.random.rand(num_channels * N_FEATURES_PER_CHANNEL) * 10).tolist()
        # La implementación actual de EMGClassificationEngine espera que X ya sean las features
        # o que este mock devuelva features.
        # Si X es señal cruda, y el engine las extrae:
        # Vamos a hacer que devuelva un vector de features por cada muestra de la ventana,
        # luego EMGClassificationEngine las promediará o usará tal cual.
        # No, train_model espera X,y. X son las features.
        # Así que este mock, si se llama, debe devolver las features de la *ventana completa*.
        
        # Si el mock es para la parte de _preprocess_data_for_training:
        # X_total = np.array([processor.extract_features(x) for x in X_total])
        # Esto implica que `extract_features` (no `extract_all_features`) es llamado por muestra.
        # Y `extract_features` en `EMGProcessingEngine` toma una señal y devuelve un dict.
        
        # Para simplificar el mock, asumimos que X ya son features y este mock no se usa,
        # O si se usa, que X es una señal y este mock devuelve features.
        # Si `apply_feature_processing` es True, se llamará a esto.
        # Asumamos que X es [n_samples, n_timesteps_per_channel] o [n_samples, n_channels, n_timesteps_per_channel]
        # y este mock devuelve [n_samples, n_extracted_features]
        
        # Si X es [n_samples, n_features_input], y este es llamado para transformar X:
        # return signal_data_window * 0.8 + 0.1 # Simular alguna transformación
        
        # Si X es señal cruda [n_samples, n_timesteps, n_channels] y se espera [n_samples, n_features]
        # Este mock es para `self.processing_engine.extract_all_features(X[i, :].reshape(1, -1))`
        # dentro de `_get_training_data` si `apply_feature_processing` es True.
        # O para `self.processing_engine.extract_all_features(processed_filtered_signal)` en RT prediction.
        # En ese caso, `signal_data_window` es una ventana [window_len, n_channels].
        # `extract_all_features` devuelve List[Dict].
        
        # Para el test, hagamos que devuelva un dict si la entrada es 1D, o lista de dicts si es 2D.
        if signal_data_window.ndim == 1: # [n_timesteps]
            return {f"feat{j}": np.random.rand() for j in range(N_FEATURES_PER_CHANNEL)}
        elif signal_data_window.ndim == 2: # [n_timesteps, n_channels] o [1, n_timesteps]
            if signal_data_window.shape[0] == 1: # [1, n_timesteps]
                 return {f"feat{j}": np.random.rand() for j in range(N_FEATURES_PER_CHANNEL)}
            else: # [n_timesteps, n_channels]
                n_ch = signal_data_window.shape[1]
                return [{f"feat_ch{ch}_{j}": np.random.rand() for j in range(N_FEATURES_PER_CHANNEL)} for ch in range(n_ch)]
        return {}


    mock_pe.extract_all_features.side_effect = extract_features_side_effect
    # Si el modelo es una NN que toma la señal procesada directamente:
    mock_pe.process_signal.side_effect = lambda data, cal_mgr: data * 0.9 # Simular filtrado
    return mock_pe


@pytest.fixture
def classification_engine(mock_data_manager: MagicMock, temp_project_dirs: Dict[str, str]) -> EMGClassificationEngine:
    """Retorna una instancia de EMGClassificationEngine con config apuntando a dirs temporales."""
    # Crear un archivo de config temporal
    config_content = DEFAULT_CLASSIFICATION_CONFIG.copy()
    config_content["paths"]["models_dir"] = temp_project_dirs["models_dir"]
    config_content["paths"]["metrics_dir"] = temp_project_dirs["metrics_dir"]
    config_content["paths"]["tensorboard_log_dir"] = temp_project_dirs["tensorboard_log_dir"]
    
    temp_config_file = os.path.join(temp_project_dirs["data_root_for_dm"], "temp_classif_conf.json") # Ponerlo en un dir temporal
    with open(temp_config_file, "w") as f:
        json.dump(config_content, f)
        
    engine = EMGClassificationEngine(data_manager=mock_data_manager, config_filepath=temp_config_file, patient_id="test_patient_classif")
    return engine

# --- Datos de Prueba Sintéticos ---
N_SAMPLES_TRAIN = 200
N_FEATURES_TRAIN = 10
N_CLASSES_TRAIN = 3

@pytest.fixture
def synthetic_training_data() -> Tuple[np.ndarray, np.ndarray]:
    X = np.random.rand(N_SAMPLES_TRAIN, N_FEATURES_TRAIN)
    y = np.random.randint(0, N_CLASSES_TRAIN, N_SAMPLES_TRAIN)
    return X, y

@pytest.fixture
def synthetic_binary_training_data() -> Tuple[np.ndarray, np.ndarray]:
    X = np.random.rand(N_SAMPLES_TRAIN, N_FEATURES_TRAIN)
    y = np.random.randint(0, 2, N_SAMPLES_TRAIN) # Binario
    return X, y

# --- Pruebas para EMGClassificationEngine ---

class TestEMGClassificationEngine:

    def test_initialization_and_config_loading(self, classification_engine: EMGClassificationEngine, temp_project_dirs: Dict[str, str]):
        """Verifica la inicialización y que la configuración se cargue correctamente."""
        assert classification_engine.data_manager is not None
        assert classification_engine.patient_id == "test_patient_classif"
        assert classification_engine.config["paths"]["models_dir"] == temp_project_dirs["models_dir"]
        assert "random_forest" in classification_engine.config["model_hyperparameters"]

    def test_get_training_data_saved(self, classification_engine: EMGClassificationEngine, mock_data_manager: MagicMock, synthetic_training_data: Tuple[np.ndarray, np.ndarray]):
        """Prueba obtener datos de entrenamiento del modo 'saved_data'."""
        X_syn, y_syn = synthetic_training_data
        # Simular que GestorDatos devuelve estos datos
        mock_data_manager.cargar_datos.return_value = [
            {"features_array": X_syn.tolist(), "labels_array": y_syn.tolist()}
        ]
        
        opts = {"acquisition_mode": "saved_data"}
        X, y = classification_engine._get_training_data(opts)
        
        mock_data_manager.cargar_datos.assert_called_with("test_patient_classif", "training_data_sessions")
        assert X is not None and y is not None
        assert X.shape == X_syn.shape
        assert y.shape == y_syn.shape
        np.testing.assert_array_almost_equal(X, X_syn)

    def test_get_training_data_real_time(self, classification_engine: EMGClassificationEngine, mock_emg_acquirer: MagicMock):
        """Prueba obtener datos de entrenamiento del modo 'real_time_fixed'."""
        classification_engine.set_dependencies(emg_acquirer=mock_emg_acquirer) # Asignar el mock
        
        opts = {
            "acquisition_mode": "real_time_fixed",
            "acquisition_duration_s": 0.1, # Muy corto para el test
            "current_label_for_acquisition": 1
        }
        # El mock_emg_acquirer.read_data simula 100Hz (delay 10ms)
        # 0.1s -> 10 muestras
        expected_samples = int(0.1 * (1000.0 / mock_emg_acquirer.acq_config.delay_ms))

        X, y = classification_engine._get_training_data(opts)
        
        assert X is not None and y is not None
        assert X.shape[0] == expected_samples
        assert X.shape[1] == mock_emg_acquirer.acq_config.num_channels_active
        assert all(label == 1 for label in y)

    def test_preprocess_data_smote(self, classification_engine: EMGClassificationEngine, synthetic_binary_training_data: Tuple[np.ndarray, np.ndarray]):
        """Prueba el preprocesamiento con SMOTE."""
        X, y_orig = synthetic_binary_training_data
        # Crear desbalance artificialmente
        y_imbalanced = np.concatenate([y_orig[y_orig == 0][:10], y_orig[y_orig == 1]]) # Clase 0 con solo 10 muestras
        
        opts = {"apply_smote": True}
        X_res, y_res = classification_engine._preprocess_data_for_training(X[:len(y_imbalanced)], y_imbalanced, opts)
        
        # Verificar que las clases estén más balanceadas (o igual si ya lo estaban)
        # SMOTE puede no igualar perfectamente si una clase es muy pequeña.
        unique_original, counts_original = np.unique(y_imbalanced, return_counts=True)
        unique_resampled, counts_resampled = np.unique(y_res, return_counts=True)
        
        if len(counts_original) > 1 and min(counts_original) < classification_engine.config["common_training_params"]["cv_folds"]:
             logger.warning("SMOTE podría no haber funcionado idealmente debido a pocas muestras en una clase.")
        else:
            assert counts_resampled[0] > counts_original[np.where(unique_original == 0)[0][0]] # La clase minoritaria debe aumentar
            assert counts_resampled[0] == pytest.approx(counts_resampled[1], rel=0.1) # Deben ser aproximadamente iguales


    @pytest.mark.parametrize("model_name", ["random_forest", "svm", "mlp"]) # XGBoost es opcional
    def test_train_sklearn_models(self, classification_engine: EMGClassificationEngine, 
                                  synthetic_training_data: Tuple[np.ndarray, np.ndarray],
                                  model_name: str):
        """Prueba el entrenamiento de modelos scikit-learn."""
        X, y = synthetic_training_data
        # Simular que GestorDatos devuelve estos datos para el modo "saved_data"
        classification_engine.data_manager.cargar_datos.return_value = [
             {"features_array": X.tolist(), "labels_array": y.tolist()}
        ]
        
        # Usar una configuración mínima de hiperparámetros para acelerar el test
        original_hyperparams = classification_engine.config["model_hyperparameters"].get(model_name, {}).copy()
        if model_name == "random_forest":
            classification_engine.config["model_hyperparameters"][model_name] = {"model__n_estimators": [10], "model__max_depth": [3]}
        elif model_name == "svm":
            classification_engine.config["model_hyperparameters"][model_name] = {"model__C": [0.1], "model__kernel": ["linear"]}
        elif model_name == "mlp":
             classification_engine.config["model_hyperparameters"][model_name] = {"model__hidden_layer_sizes": [(10,)], "model__max_iter": [50]}


        opts = {"acquisition_mode": "saved_data", "apply_calibration": False, "apply_feature_processing": False}
        success, msg, metrics, best_params = classification_engine.train_model(model_name, opts)

        assert success is True, f"Entrenamiento de {model_name} falló: {msg}"
        assert model_name in classification_engine.trained_models
        assert metrics is not None and "accuracy" in metrics
        assert metrics["accuracy"] >= 0.0 # Solo verificar que se calculó
        assert best_params is not None
        
        # Verificar que el modelo se guardó
        assert model_name in classification_engine.model_filepaths
        assert os.path.exists(classification_engine.model_filepaths[model_name])
        
        # Verificar que las métricas se guardaron (mockeado)
        classification_engine.data_manager.guardar_datos.assert_any_call(
            "test_patient_classif", f"training_metrics_{model_name}", pytest.anything()
        )
        # Restaurar hiperparámetros originales para no afectar otros tests
        classification_engine.config["model_hyperparameters"][model_name] = original_hyperparams


    def test_train_pytorch_model(self, classification_engine: EMGClassificationEngine, synthetic_binary_training_data: Tuple[np.ndarray, np.ndarray]):
        """Prueba el entrenamiento del modelo PyTorch."""
        X, y = synthetic_binary_training_data # Usar binario para ROC
        classification_engine.data_manager.cargar_datos.return_value = [
             {"features_array": X.tolist(), "labels_array": y.tolist()}
        ]
        
        # Usar una config de PyTorch más rápida para el test
        original_torch_params = classification_engine.config["model_hyperparameters"]["dnn_torch"].copy()
        classification_engine.config["model_hyperparameters"]["dnn_torch"].update({
            "epochs": 3, "hidden_sizes": [16], "patience_early_stopping": 2
        })

        opts = {"acquisition_mode": "saved_data", "apply_calibration": False, "apply_feature_processing": False}
        success, msg, metrics, best_params = classification_engine.train_model("dnn_torch", opts)

        assert success is True, f"Entrenamiento de dnn_torch falló: {msg}"
        assert "dnn_torch" in classification_engine.trained_models
        assert isinstance(classification_engine.trained_models["dnn_torch"], TorchModel)
        assert metrics is not None and "accuracy" in metrics
        assert metrics["accuracy"] >= 0.0
        
        assert os.path.exists(classification_engine.model_filepaths["dnn_torch"])
        classification_engine.config["model_hyperparameters"]["dnn_torch"] = original_torch_params # Restaurar

    def test_predict_and_load_model(self, classification_engine: EMGClassificationEngine, synthetic_training_data: Tuple[np.ndarray, np.ndarray]):
        """Prueba la predicción y la carga de un modelo guardado."""
        X, y = synthetic_training_data
        classification_engine.data_manager.cargar_datos.return_value = [
             {"features_array": X.tolist(), "labels_array": y.tolist()}
        ]
        model_name = "random_forest"
        classification_engine.config["model_hyperparameters"][model_name] = {"model__n_estimators": [10]} # Rápido
        
        classification_engine.train_model(model_name, {"acquisition_mode": "saved_data"})
        
        # Probar predicción con modelo en memoria
        predictions_mem = classification_engine.predict(X[:5], model_name)
        assert predictions_mem is not None
        assert len(predictions_mem) == 5

        # Limpiar modelos en memoria y cargar desde archivo
        model_path_to_load = classification_engine.model_filepaths[model_name]
        classification_engine.trained_models.clear() 
        assert model_name not in classification_engine.trained_models

        assert classification_engine.load_model(model_name, model_path_to_load) is True
        assert model_name in classification_engine.trained_models
        
        predictions_loaded = classification_engine.predict(X[:5], model_name)
        assert predictions_loaded is not None
        np.testing.assert_array_equal(predictions_mem, predictions_loaded)

    def test_calculate_metrics_robustness(self, classification_engine: EMGClassificationEngine):
        """Prueba _calculate_metrics con casos borde."""
        y_true_empty = np.array([])
        y_pred_empty = np.array([])
        metrics_empty = classification_engine._calculate_metrics(y_true_empty, y_pred_empty)
        assert metrics_empty["accuracy"] == 0.0

        y_true_single_class = np.array([0,0,0,0])
        y_pred_single_class = np.array([0,0,0,0])
        metrics_single = classification_engine._calculate_metrics(y_true_single_class, y_pred_single_class)
        assert metrics_single["accuracy"] == 1.0
        assert metrics_single["precision"] == 1.0 # Para clase 0
        assert metrics_single["recall"] == 1.0
        assert metrics_single["f1"] == 1.0
        assert len(metrics_single["confusion_matrix"]) > 0

        y_true_mismatch = np.array([0,1,0,1])
        y_pred_only_one_class = np.array([0,0,0,0]) # Modelo predice solo clase 0
        metrics_mismatch = classification_engine._calculate_metrics(y_true_mismatch, y_pred_only_one_class)
        assert metrics_mismatch["accuracy"] == 0.5
        # Precision para clase 0 es 2/4=0.5. Recall para clase 0 es 2/2=1.0.
        # Precision para clase 1 es 0/0=0 (zero_division=0). Recall para clase 1 es 0/2=0.
        # El reporte de clasificación lo mostraría, y el F1 ponderado se calcularía.
        assert "0" in metrics_mismatch["classification_report"]
        assert "1" in metrics_mismatch["classification_report"]
        assert metrics_mismatch["classification_report"]["1"]["recall"] == 0.0
    
