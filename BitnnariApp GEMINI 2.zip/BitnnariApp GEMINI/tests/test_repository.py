"""
test_repository.py

Pruebas unitarias para la clase LocalFileRepository, que gestiona la persistencia
local de datos de la aplicación EMG.
"""
import unittest
import os
import json
import shutil
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any

# Módulos a probar
from BitnnariApp.data.repository import LocalFileRepository
from BitnnariApp.data.models.patient import PatientModel
from BitnnariApp.data.models.calibration_params import CalibrationParamsModel
from BitnnariApp.data.models.emg_record import EmgRecordModel

# Configuración de un directorio base temporal para las pruebas
TEST_BASE_DIR = Path("./temp_test_data_storage_repository")

class TestLocalFileRepository(unittest.TestCase):
    """
    Suite de pruebas para LocalFileRepository.
    """
    repo: LocalFileRepository

    @classmethod
    def setUpClass(cls):
        """Se ejecuta una vez antes de todas las pruebas de la clase."""
        # Limpiar directorio de prueba si existe de una ejecución anterior
        if TEST_BASE_DIR.exists():
            shutil.rmtree(TEST_BASE_DIR)
        TEST_BASE_DIR.mkdir(parents=True, exist_ok=True)
        # Crear la instancia Singleton para todas las pruebas de esta clase
        cls.repo = LocalFileRepository(base_data_dir=TEST_BASE_DIR)

    @classmethod
    def tearDownClass(cls):
        """Se ejecuta una vez después de todas las pruebas de la clase."""
        # Limpiar el directorio de prueba
        if TEST_BASE_DIR.exists():
            shutil.rmtree(TEST_BASE_DIR)

    def setUp(self):
        """Se ejecuta antes de cada método de prueba."""
        # Asegurar que los directorios base del repo estén limpios para cada test,
        # excepto el directorio base principal que se maneja en setUpClass/tearDownClass.
        # Esto es para evitar interferencias entre tests si alguno crea subdirectorios específicos.
        # Sin embargo, dado que el repo es un Singleton, su estado persiste.
        # La limpieza en tearDownClass es la principal.
        # Podríamos optar por recrear subdirectorios específicos si es necesario.
        self.repo._ensure_base_directories() # Asegura que existan para el test actual

    def tearDown(self):
        """Se ejecuta después de cada método de prueba."""
        # Limpiar archivos específicos creados por un test si es necesario,
        # pero la limpieza general se hace en tearDownClass.
        # Por ejemplo, si un test crea un paciente "temp_dni", se podría borrar aquí.
        # Para este caso, la limpieza de tearDownClass es suficiente.
        pass

    def test_singleton_instance(self):
        """Verifica que LocalFileRepository sea un Singleton."""
        repo1 = LocalFileRepository()
        repo2 = LocalFileRepository()
        self.assertIs(repo1, repo2, "LocalFileRepository no está devolviendo la misma instancia (Singleton falló).")
        self.assertEqual(repo1.BASE_DATA_DIR, self.repo.BASE_DATA_DIR, "Instancias Singleton no comparten el mismo BASE_DATA_DIR.")

    def test_base_directory_creation(self):
        """Verifica que los directorios base se creen correctamente."""
        self.assertTrue(self.repo.BASE_DATA_DIR.exists(), "El directorio base principal no fue creado.")
        self.assertTrue((self.repo.BASE_DATA_DIR / self.repo.PATIENTS_DIR_NAME).exists(), "Directorio de pacientes no creado.")
        self.assertTrue((self.repo.BASE_DATA_DIR / self.repo.SESSIONS_DIR_NAME).exists(), "Directorio de sesiones no creado.")
        self.assertTrue((self.repo.BASE_DATA_DIR / self.repo.CALIBRATIONS_DIR_NAME).exists(), "Directorio de calibraciones no creado.")
        self.assertTrue((self.repo.BASE_DATA_DIR / self.repo.CONFIGS_DIR_NAME).exists(), "Directorio de configuraciones no creado.")
        self.assertTrue((self.repo.BASE_DATA_DIR / self.repo.MODELS_DIR_NAME).exists(), "Directorio de modelos ML no creado.")

    # --- Pruebas de Pacientes ---
    def test_save_and_get_patient(self):
        """Prueba guardar y recuperar un PatientModel."""
        patient_data = {
            "dni": "PAT001", "nombre": "Paciente Uno Test", "fecha_nacimiento": "1990-01-01",
            "contacto": {"email": "p1@test.com"}
        }
        patient = PatientModel(**patient_data)
        
        save_success = self.repo.save_patient(patient)
        self.assertTrue(save_success, "Fallo al guardar el paciente.")

        retrieved_patient = self.repo.get_patient("PAT001")
        self.assertIsNotNone(retrieved_patient, "No se pudo recuperar el paciente guardado.")
        self.assertEqual(retrieved_patient.nombre, "Paciente Uno Test") # type: ignore
        self.assertEqual(retrieved_patient.contacto.get("email"), "p1@test.com") # type: ignore
        self.assertIsInstance(retrieved_patient.updated_at, datetime) # type: ignore

        # Verificar que el archivo JSON existe y contiene los datos correctos
        filepath = self.repo._get_patient_data_filepath("PAT001")
        self.assertTrue(filepath.exists())
        with open(filepath, 'r') as f:
            data_on_disk = json.load(f)
        self.assertEqual(data_on_disk["nombre"], "Paciente Uno Test")

    def test_get_non_existent_patient(self):
        """Prueba obtener un paciente que no existe."""
        retrieved_patient = self.repo.get_patient("NONEXISTENT_DNI")
        self.assertIsNone(retrieved_patient, "Se obtuvo un paciente cuando no debería existir.")

    def test_list_and_delete_patient(self):
        """Prueba listar DNIs y eliminar un paciente."""
        p2_data = {"dni": "PAT002", "nombre": "Paciente Dos"}
        p3_data = {"dni": "PAT003", "nombre": "Paciente Tres"}
        self.repo.save_patient(PatientModel(**p2_data))
        self.repo.save_patient(PatientModel(**p3_data))

        dnis = self.repo.list_patient_dnis()
        self.assertIn("PAT001", dnis) # Del test anterior
        self.assertIn("PAT002", dnis)
        self.assertIn("PAT003", dnis)

        delete_success = self.repo.delete_patient("PAT002")
        self.assertTrue(delete_success, "Fallo al eliminar paciente PAT002.")
        
        dnis_after_delete = self.repo.list_patient_dnis()
        self.assertNotIn("PAT002", dnis_after_delete)
        self.assertIsNone(self.repo.get_patient("PAT002"), "Paciente PAT002 todavía existe después de eliminar.")
        
        # Verificar que el directorio del paciente fue eliminado
        patient_dir_pat002 = self.repo._get_patient_dir("PAT002", ensure_exists=False)
        self.assertFalse(patient_dir_pat002.exists(), "El directorio del paciente PAT002 no fue eliminado.")

    def test_delete_non_existent_patient(self):
        """Prueba eliminar un paciente que no existe."""
        delete_success = self.repo.delete_patient("NONEXISTENT_FOR_DELETE")
        self.assertFalse(delete_success, "delete_patient debería devolver False para un DNI no existente.")

    # --- Pruebas de Parámetros de Calibración ---
    def test_save_and_get_calibration_params(self):
        """Prueba guardar y recuperar CalibrationParamsModel."""
        patient_dni = "CALPAT001"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="Cal Patient")) # Asegurar que el paciente exista

        cal_id1 = f"cal_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        cal_params_data1 = {
            "calibration_id": cal_id1, "patient_dni": patient_dni, "num_channels": 2,
            "offset_values": [0.1, 0.2], "gain_values": [1.0, 0.9]
        }
        cal_params1 = CalibrationParamsModel(**cal_params_data1)
        save_success = self.repo.save_calibration_params(cal_params1)
        self.assertTrue(save_success)

        retrieved_cal1 = self.repo.get_calibration_params(patient_dni, cal_id1)
        self.assertIsNotNone(retrieved_cal1)
        self.assertEqual(retrieved_cal1.calibration_id, cal_id1) # type: ignore
        self.assertListEqual(retrieved_cal1.offset_values, [0.1, 0.2]) # type: ignore

    def test_list_and_get_latest_calibration(self):
        """Prueba listar IDs de calibración y obtener la más reciente."""
        patient_dni = "CALPAT002"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="Cal Patient Two"))

        cal_id_old = "cal_old_one"
        cal_data_old = {
            "calibration_id": cal_id_old, "patient_dni": patient_dni, "num_channels": 1,
            "offset_values": [0.5], "timestamp": (datetime.utcnow() - timedelta(days=1)).isoformat()
        }
        self.repo.save_calibration_params(CalibrationParamsModel.from_dict(cal_data_old))

        cal_id_new = "cal_new_one"
        cal_data_new = {
            "calibration_id": cal_id_new, "patient_dni": patient_dni, "num_channels": 1,
            "offset_values": [0.3], "timestamp": datetime.utcnow().isoformat() # Más reciente
        }
        self.repo.save_calibration_params(CalibrationParamsModel.from_dict(cal_data_new))

        cal_ids = self.repo.list_calibration_ids_for_patient(patient_dni)
        self.assertIn(cal_id_old, cal_ids)
        self.assertIn(cal_id_new, cal_ids)

        latest_cal = self.repo.get_latest_calibration_params(patient_dni)
        self.assertIsNotNone(latest_cal)
        self.assertEqual(latest_cal.calibration_id, cal_id_new) # type: ignore
        self.assertEqual(latest_cal.offset_values, [0.3]) # type: ignore

    # --- Pruebas de Registros EMG (Sesiones) ---
    def test_save_and_get_emg_record(self):
        """Prueba guardar y recuperar un EmgRecordModel."""
        patient_dni = "EMGPAT001"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="EMG Patient"))

        rec_id1 = f"rec_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        record_data1 = {
            "record_id": rec_id1, "patient_dni": patient_dni, "duration_s": 1.0,
            "sampling_rate_hz": 1000.0, "num_channels": 1,
            "raw_data": [[float(i/100.0) for i in range(1000)]], # 1 canal, 1000 muestras
            "label": "flexion_test"
        }
        record1 = EmgRecordModel(**record_data1)
        save_success = self.repo.save_emg_record(record1)
        self.assertTrue(save_success)

        retrieved_rec1 = self.repo.get_emg_record(patient_dni, rec_id1)
        self.assertIsNotNone(retrieved_rec1)
        self.assertEqual(retrieved_rec1.record_id, rec_id1) # type: ignore
        self.assertEqual(retrieved_rec1.label, "flexion_test") # type: ignore
        self.assertEqual(len(retrieved_rec1.raw_data[0]), 1000) # type: ignore

    def test_get_all_emg_records_for_patient(self):
        """Prueba obtener todos los registros EMG para un paciente, ordenados."""
        patient_dni = "EMGPAT002"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="EMG Patient Two"))

        rec_id_old = "rec_old_emg"
        rec_data_old = {
            "record_id": rec_id_old, "patient_dni": patient_dni, "duration_s": 0.5, "sampling_rate_hz": 100, "num_channels": 1,
            "raw_data": [[1.0,2.0]], "timestamp": (datetime.utcnow() - timedelta(hours=1)).isoformat()
        }
        self.repo.save_emg_record(EmgRecordModel.from_dict(rec_data_old))

        rec_id_new = "rec_new_emg"
        rec_data_new = {
            "record_id": rec_id_new, "patient_dni": patient_dni, "duration_s": 0.5, "sampling_rate_hz": 100, "num_channels": 1,
            "raw_data": [[3.0,4.0]], "timestamp": datetime.utcnow().isoformat()
        }
        self.repo.save_emg_record(EmgRecordModel.from_dict(rec_data_new))

        all_records = self.repo.get_all_emg_records_for_patient(patient_dni)
        self.assertEqual(len(all_records), 2)
        self.assertEqual(all_records[0].record_id, rec_id_new) # El más reciente primero
        self.assertEqual(all_records[1].record_id, rec_id_old)

    # --- Pruebas de Configuraciones ---
    def test_save_and_load_global_configuration(self):
        """Prueba guardar y cargar una configuración global."""
        config_name = "app_preferences"
        config_data = {"theme": "dark_blue", "auto_save_interval_min": 5}
        self.repo.save_configuration(config_name, config_data)

        loaded_config = self.repo.load_configuration(config_name)
        self.assertIsNotNone(loaded_config)
        self.assertEqual(loaded_config.get("theme"), "dark_blue") # type: ignore

    def test_save_and_load_patient_configuration(self):
        """Prueba guardar y cargar una configuración específica de paciente."""
        patient_dni = "CONFTEST001"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="Config Test Patient"))
        
        config_name = "processing_pipeline_v1"
        config_data = {"filter_order": 4, "features_to_extract": ["RMS", "MAV"]}
        self.repo.save_configuration(config_name, config_data, patient_dni=patient_dni)

        loaded_config = self.repo.load_configuration(config_name, patient_dni=patient_dni)
        self.assertIsNotNone(loaded_config)
        self.assertEqual(loaded_config.get("filter_order"), 4) # type: ignore

    def test_load_non_existent_configuration(self):
        """Prueba cargar una configuración que no existe."""
        loaded_config = self.repo.load_configuration("non_existent_global_config")
        self.assertIsNone(loaded_config)
        loaded_config_patient = self.repo.load_configuration("non_existent_patient_config", patient_dni="CONFTEST001")
        self.assertIsNone(loaded_config_patient)

    # --- Pruebas de Rutas de Modelos ML ---
    def test_get_ml_model_path(self):
        """Prueba la generación de rutas para modelos de ML."""
        global_model_path = self.repo.get_ml_model_path("global_svm_classifier", version="1.2")
        self.assertTrue(str(global_model_path).endswith("_v1.2.pkl"))
        self.assertIn(self.repo.MODELS_DIR_NAME, str(global_model_path))
        self.assertNotIn(self.repo.PATIENTS_DIR_NAME, str(global_model_path)) # Global

        patient_dni = "MLPAT001"
        self.repo.save_patient(PatientModel(dni=patient_dni, nombre="ML Patient"))
        patient_model_path = self.repo.get_ml_model_path("patient_cnn_gestures", patient_dni=patient_dni, timestamp=False)
        self.assertTrue(str(patient_model_path).endswith(".pth")) # Asume .pth para cnn
        self.assertIn(patient_dni, str(patient_model_path))
        self.assertIn(self.repo.MODELS_DIR_NAME, str(patient_model_path))

        # Verificar que el directorio se crea
        self.assertTrue(patient_model_path.parent.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)