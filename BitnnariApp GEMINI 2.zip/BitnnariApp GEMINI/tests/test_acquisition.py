"""
test_acquisition.py

Pruebas unitarias y de integración para el módulo emg_adquisition.py.
Cubre EMGAcquisition, EMGDataProcessor y DataLogger.
"""

import os
import json
import csv
import time
import shutil
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List
from unittest.mock import patch, MagicMock

import numpy as np
import pytest
from scipy.signal import welch

# Módulos a probar
from BitnnariApp.acquisition.emg_adquisition import (
    EMGAcquisition, EMGDataProcessor, DataLogger,
    SerialConfig, AcquisitionConfig as DeviceAcqConfig,
    FilterConfig as DeviceFilterConfig, LogConfig as DeviceLogConfig,
    PACKET_HEADER, MAX_CHANNELS_HW, calculate_expected_packet_size, crc8_func
)
# crc8_func puede ser un dummy si crcmod no está instalado, las pruebas de CRC lo tendrán en cuenta.

# Configurar un logger para las pruebas
logger = logging.getLogger("TestEMGAcquisition")
logger.setLevel(logging.DEBUG)
# logging.getLogger("EMGAcquisition").setLevel(logging.DEBUG) # Para ver logs del módulo probado

@pytest.fixture(scope="function")
def temp_log_dir() -> str:
    """Crea un directorio temporal para los archivos de log."""
    path = tempfile.mkdtemp(prefix="bitnariapp_test_log_acq_")
    yield path
    shutil.rmtree(path)

@pytest.fixture
def default_serial_config() -> SerialConfig:
    return SerialConfig(port="DUMMY_PORT", auto_connect=False) # No conectar realmente

@pytest.fixture
def default_acq_config() -> DeviceAcqConfig:
    return DeviceAcqConfig(delay_ms=20, num_channels_active=2, mode='continuous') # 50 Hz

@pytest.fixture
def default_filter_config(default_acq_config: DeviceAcqConfig) -> DeviceFilterConfig:
    return DeviceFilterConfig(
        sample_rate=(1000.0 / default_acq_config.delay_ms),
        notch_freq=50.0,
        bandpass_low_freq=10.0,
        bandpass_high_freq=200.0, # Ancho de banda razonable
        enabled=True
    )

@pytest.fixture
def default_log_config(temp_log_dir: str) -> DeviceLogConfig:
    return DeviceLogConfig(
        log_path=temp_log_dir,
        log_filename_prefix="test_acq_session",
        log_format="csv",
        enabled=True,
        log_raw_data=True,
        log_filtered_data=True
    )

class TestEMGDataProcessor:
    """Pruebas para la clase EMGDataProcessor."""

    def test_filter_design_and_application(self, default_filter_config: DeviceFilterConfig):
        """Prueba el diseño de filtros y su aplicación a una señal."""
        processor = EMGDataProcessor(default_filter_config)
        fs = default_filter_config.sample_rate
        t = np.linspace(0, 1, int(fs), endpoint=False)
        
        # Señal con componente DC, ruido de 50Hz y señal de interés a 30Hz y 70Hz
        signal_50hz = np.sin(2 * np.pi * 50 * t)
        signal_30hz = 0.5 * np.sin(2 * np.pi * 30 * t)
        signal_70hz = 0.3 * np.sin(2 * np.pi * 70 * t)
        signal_high_freq_noise = 0.1 * np.sin(2 * np.pi * 200 * t) # Ruido fuera de banda
        dc_offset = 2.0
        
        test_signal_1ch = dc_offset + signal_30hz + signal_70hz + signal_50hz + signal_high_freq_noise
        test_signal_2ch = np.array([test_signal_1ch, test_signal_1ch * 0.8 + 0.1]).T # [n_samples, n_channels]

        # Verificar que los filtros se hayan diseñado
        assert processor._sos_notch is not None, "Filtro Notch no se diseñó."
        assert processor._sos_bandpass is not None, "Filtro Pasa-Banda no se diseñó."

        # Aplicar filtros a señal de 1 canal
        filtered_1ch = processor.apply_filters(test_signal_1ch)
        assert filtered_1ch.shape == test_signal_1ch.shape

        # Aplicar filtros a señal de 2 canales
        filtered_2ch = processor.apply_filters(test_signal_2ch)
        assert filtered_2ch.shape == test_signal_2ch.shape

        # Análisis espectral básico para verificar el efecto de los filtros
        freqs_orig_1ch, psd_orig_1ch = welch(test_signal_1ch, fs, nperseg=int(fs/2))
        freqs_filt_1ch, psd_filt_1ch = welch(filtered_1ch, fs, nperseg=int(fs/2))

        # Verificar atenuación de 50Hz (Notch)
        idx_50hz_orig = np.argmin(np.abs(freqs_orig_1ch - 50))
        idx_50hz_filt = np.argmin(np.abs(freqs_filt_1ch - 50))
        assert psd_filt_1ch[idx_50hz_filt] < psd_orig_1ch[idx_50hz_orig] * 0.1, "Notch no atenuó 50Hz significativamente."

        # Verificar atenuación de DC (implícito por el pasa-alto del pasa-banda)
        idx_dc_orig = np.argmin(np.abs(freqs_orig_1ch - 0)) # Frecuencia cercana a DC
        idx_dc_filt = np.argmin(np.abs(freqs_filt_1ch - 0))
        if freqs_orig_1ch[idx_dc_orig] < 1.0 and freqs_filt_1ch[idx_dc_filt] < 1.0: # Solo si la resolución de FFT lo permite
             assert psd_filt_1ch[idx_dc_filt] < psd_orig_1ch[idx_dc_orig] * 0.1, "Pasa-banda no atenuó DC significativamente."

        # Verificar que la señal de interés (30Hz, 70Hz) no se atenúe demasiado
        idx_30hz_filt = np.argmin(np.abs(freqs_filt_1ch - 30))
        idx_70hz_filt = np.argmin(np.abs(freqs_filt_1ch - 70))
        assert psd_filt_1ch[idx_30hz_filt] > psd_orig_1ch[np.argmin(np.abs(freqs_orig_1ch - 30))] * 0.5, "Pasa-banda atenuó demasiado 30Hz."
        assert psd_filt_1ch[idx_70hz_filt] > psd_orig_1ch[np.argmin(np.abs(freqs_orig_1ch - 70))] * 0.5, "Pasa-banda atenuó demasiado 70Hz."
        
        # Verificar atenuación de alta frecuencia (ruido a 200Hz, si el pasa-banda es hasta 200Hz)
        # Si el bandpass_high_freq es, por ejemplo, 150Hz
        if default_filter_config.bandpass_high_freq < 190:
            idx_200hz_orig = np.argmin(np.abs(freqs_orig_1ch - 200))
            idx_200hz_filt = np.argmin(np.abs(freqs_filt_1ch - 200))
            assert psd_filt_1ch[idx_200hz_filt] < psd_orig_1ch[idx_200hz_orig] * 0.1, "Pasa-banda no atenuó ruido de alta frecuencia."

    def test_processor_config_update(self, default_filter_config: DeviceFilterConfig):
        """Prueba la actualización de la configuración del procesador."""
        processor = EMGDataProcessor(default_filter_config)
        original_notch_sos = processor._sos_notch
        
        new_filter_config = DeviceFilterConfig(
            sample_rate=default_filter_config.sample_rate,
            notch_freq=60.0, # Cambiar frecuencia del notch
            bandpass_low_freq=30.0,
            bandpass_high_freq=100.0,
            enabled=True
        )
        processor.update_config(new_filter_config)
        assert processor.config.notch_freq == 60.0
        assert processor._sos_notch is not None
        # Comprobar que los coeficientes del filtro hayan cambiado (difícil sin conocerlos exactamente)
        # Una forma es verificar que no sean iguales a los originales si los parámetros cambiaron
        if original_notch_sos is not None:
            assert not np.array_equal(processor._sos_notch, original_notch_sos), "Coeficientes Notch no cambiaron tras update_config."

    def test_processor_disabled(self, default_filter_config: DeviceFilterConfig):
        """Prueba que si los filtros están deshabilitados, la señal no cambia."""
        disabled_config = default_filter_config
        disabled_config.enabled = False
        processor = EMGDataProcessor(disabled_config)
        
        test_signal = np.random.rand(100)
        filtered_signal = processor.apply_filters(test_signal)
        assert np.array_equal(test_signal, filtered_signal), "Señal modificada aunque filtros estaban deshabilitados."


class TestDataLogger:
    """Pruebas para la clase DataLogger."""

    def test_log_csv_creation_and_content(self, temp_log_dir: str):
        """Prueba la creación y contenido de un archivo CSV."""
        log_conf = DeviceLogConfig(log_path=temp_log_dir, log_filename_prefix="csv_test", log_format="csv", enabled=True)
        logger_instance = DataLogger(log_conf)
        
        num_channels = 2
        sample_data1 = {
            "python_timestamp": datetime.now().isoformat(), "arduino_ms": 1000, "lost_frames": 0,
            "raw_data": [1.0, 2.0][:num_channels], "filtered_data": [0.5, 1.5][:num_channels]
        }
        sample_data2 = {
            "python_timestamp": datetime.now().isoformat(), "arduino_ms": 1020, "lost_frames": 1,
            "raw_data": [1.1, 2.1][:num_channels], "filtered_data": [0.6, 1.6][:num_channels]
        }
        logger_instance.add_record(sample_data1)
        logger_instance.add_record(sample_data2)
        logger_instance.close() # Cierra el archivo

        # Verificar archivo
        log_files = os.listdir(temp_log_dir)
        assert len(log_files) == 1
        filepath = os.path.join(temp_log_dir, log_files[0])
        assert "csv_test" in log_files[0] and log_files[0].endswith(".csv")

        with open(filepath, "r", newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)
        
        assert len(rows) == 3 # Cabecera + 2 filas de datos
        expected_headers = ['python_timestamp', 'arduino_ms', 'lost_frames'] + \
                           [f'raw_ch_{i+1}' for i in range(num_channels)] + \
                           [f'filt_ch_{i+1}' for i in range(num_channels)]
        assert rows[0] == expected_headers
        assert rows[1][1] == str(sample_data1["arduino_ms"]) # arduino_ms
        assert float(rows[2][3]) == sample_data2["raw_data"][0] # raw_ch_1 de la segunda muestra

    def test_log_json_creation_and_content(self, temp_log_dir: str):
        """Prueba la creación y contenido de un archivo JSON."""
        log_conf = DeviceLogConfig(log_path=temp_log_dir, log_filename_prefix="json_test", log_format="json", enabled=True)
        logger_instance = DataLogger(log_conf)
        
        sample_data = {
            "python_timestamp": datetime.now().isoformat(), "arduino_ms": 2000, "lost_frames": 0,
            "raw_data": [3.0, 4.0], "filtered_data": [2.5, 3.5]
        }
        logger_instance.add_record(sample_data)
        logger_instance.add_record(sample_data) # Añadir dos registros
        logger_instance.close()

        log_files = os.listdir(temp_log_dir)
        assert len(log_files) == 1
        filepath = os.path.join(temp_log_dir, log_files[0])
        assert "json_test" in log_files[0] and log_files[0].endswith(".json")

        with open(filepath, "r") as f:
            content_str = f.read()
        # Verificar que sea un JSON array válido
        try:
            data_list = json.loads(content_str)
            assert isinstance(data_list, list)
            assert len(data_list) == 2
            assert data_list[0]["arduino_ms"] == 2000
            assert data_list[1]["filtered_data"][1] == 3.5
        except json.JSONDecodeError as e:
            pytest.fail(f"El archivo JSON no es válido: {e}\nContenido:\n{content_str}")
            
    def test_log_buffering_when_not_active(self, temp_log_dir: str):
        """Prueba que los datos se guarden en buffer si el log no está activo y se escriban al activarse."""
        log_conf = DeviceLogConfig(log_path=temp_log_dir, log_filename_prefix="buffer_test", log_format="csv", enabled=False) # Inicia deshabilitado
        logger_instance = DataLogger(log_conf)

        sample_data_buffered = {
            "python_timestamp": "buffered_ts", "arduino_ms": 500, "lost_frames": 0,
            "raw_data": [10.0], "filtered_data": [9.0]
        }
        logger_instance.add_record(sample_data_buffered) # Debería ir al buffer
        assert len(logger_instance._buffer) == 1
        assert not os.listdir(temp_log_dir) # No se debe crear archivo

        # Activar logging
        log_conf.enabled = True
        logger_instance.update_config(log_conf) # Esto debería llamar a _start_logging y escribir el buffer
        
        assert len(logger_instance._buffer) == 0 # Buffer debería estar vacío
        log_files = os.listdir(temp_log_dir)
        assert len(log_files) == 1
        filepath = os.path.join(temp_log_dir, log_files[0])

        with open(filepath, "r", newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)
        assert len(rows) == 2 # Cabecera + 1 dato del buffer
        assert rows[1][0] == "buffered_ts"
        logger_instance.close()


class TestEMGAcquisitionSimulated:
    """Pruebas para EMGAcquisition en modo simulación."""

    @pytest.fixture
    def sim_emg_acq(self, default_serial_config, default_acq_config, default_filter_config, default_log_config) -> EMGAcquisition:
        # Asegurar que log_config use un directorio temporal para esta prueba
        default_log_config.log_path = default_log_config.log_path + "_sim" 
        return EMGAcquisition(default_serial_config, default_acq_config, default_filter_config, default_log_config, simulate=True)

    def test_simulated_connection(self, sim_emg_acq: EMGAcquisition):
        """Verifica que la conexión simulada funcione."""
        assert sim_emg_acq.is_connected() is True
        sim_emg_acq.disconnect()
        assert sim_emg_acq.is_connected() is False
        assert sim_emg_acq.connect() is True # Debería reconectar en simulación
        sim_emg_acq.close()

    def test_simulated_data_generation(self, sim_emg_acq: EMGAcquisition):
        """Verifica que se generen datos simulados con el formato correcto."""
        data_packet = sim_emg_acq.read_data()
        assert data_packet is not None
        assert "arduino_ms" in data_packet
        assert "raw_data" in data_packet
        assert "filtered_data" in data_packet
        assert "lost_frames" in data_packet
        assert "python_timestamp" in data_packet
        assert "num_channels_active" in data_packet
        
        num_ch = sim_emg_acq.acq_config.num_channels_active
        assert len(data_packet["raw_data"]) == num_ch
        assert len(data_packet["filtered_data"]) == num_ch
        assert data_packet["num_channels_active"] == num_ch
        sim_emg_acq.close()

    def test_simulated_lost_frames_detection(self, sim_emg_acq: EMGAcquisition):
        """Prueba la detección de paquetes perdidos en modo simulación."""
        sim_emg_acq._last_arduino_ms = 0 # Reset
        sim_emg_acq.acq_config.delay_ms = 10 # 10ms delay esperado

        ts1 = 1000
        lost1 = sim_emg_acq._detect_lost_frames(ts1) # Primer paquete
        assert lost1 == 0
        assert sim_emg_acq._last_arduino_ms == ts1

        ts2 = 1010 # Siguiente paquete, sin pérdida
        lost2 = sim_emg_acq._detect_lost_frames(ts2)
        assert lost2 == 0
        
        ts3 = 1035 # Salto de 25ms (10ms + 15ms). Espera 10ms. 25/10 = 2.5. round(2.5)-1 = 2-1 = 1 perdido.
                   # Con tolerancia de 0.5*10=5ms. 10+5=15. 25 > 15.
        lost3 = sim_emg_acq._detect_lost_frames(ts3)
        assert lost3 >= 1, f"Se esperaban frames perdidos, se obtuvieron {lost3} para diff {ts3-ts2}" 
        
        ts4 = 1000 # Timestamp retrocede (reinicio simulado)
        lost4 = sim_emg_acq._detect_lost_frames(ts4)
        assert lost4 == 0
        assert sim_emg_acq._last_arduino_ms == ts4
        sim_emg_acq.close()

    def test_simulated_callbacks(self, sim_emg_acq: EMGAcquisition):
        """Prueba el registro y ejecución de callbacks en modo simulación."""
        callback_data_store: List[Dict] = []
        def test_cb(data: Dict[str, Any]):
            callback_data_store.append(data)
        
        sim_emg_acq.register_callback(test_cb)
        sim_emg_acq.read_data() # Generar un dato
        assert len(callback_data_store) == 1
        assert callback_data_store[0]["arduino_ms"] > 0

        sim_emg_acq.unregister_callback(test_cb)
        sim_emg_acq.read_data() # Generar otro dato
        assert len(callback_data_store) == 1, "Callback no debería haberse ejecutado tras unregister."
        sim_emg_acq.close()


# Pruebas para EMGAcquisition con Mock Serial (más complejo, para lógica de protocolo)
# Estas pruebas son más difíciles de hacer completamente unitarias sin un dispositivo real
# o un mock muy sofisticado del comportamiento del puerto serial.
# Aquí se enfoca en el parseo de paquetes si se puede simular la entrada de bytes.

@patch('BitnnariApp.acquisition.emg_adquisition.serial.Serial') # Mockear la clase serial.Serial
def test_emg_acquisition_packet_parsing_logic(MockSerial, default_serial_config, default_acq_config, default_filter_config, default_log_config):
    """
    Prueba la lógica de parseo de paquetes de EMGAcquisition.
    Simula la recepción de bytes en el puerto serial mockeado.
    """
    # Configurar el mock para el puerto serial
    mock_serial_instance = MagicMock()
    MockSerial.return_value = mock_serial_instance # Cuando se llame a serial.Serial(...), devolverá nuestro mock

    # Simular que hay bytes esperando ser leídos
    # Crear un paquete de bytes válido según el protocolo
    num_ch_test = 2
    default_acq_config.num_channels_active = num_ch_test
    expected_size = calculate_expected_packet_size(MAX_CHANNELS_HW)

    # Header(1) + NumActive(1) + Timestamp(4) + Data(MAX_CH_HW * 2) + CRC(1)
    # Data: [ch1, ch2, 0, 0, 0, 0, 0, 0] si MAX_CHANNELS_HW = 8 y num_ch_test = 2
    header = bytes([PACKET_HEADER])
    num_active_ch_byte = num_ch_test.to_bytes(1, 'big')
    timestamp_bytes = (12345).to_bytes(4, 'big') # Little endian en el prompt original, pero python usa '!' (network=big)
    
    ch_data_values = [100, -200] + [0]*(MAX_CHANNELS_HW - num_ch_test) # Llenar con ceros los no usados
    data_bytes = b''.join([val.to_bytes(2, 'big', signed=True) for val in ch_data_values])
    
    payload_for_crc = header + num_active_ch_byte + timestamp_bytes + data_bytes
    crc_byte = crc8_func(payload_for_crc).to_bytes(1, 'big')
    
    valid_packet_bytes = payload_for_crc + crc_byte
    assert len(valid_packet_bytes) == expected_size, "El paquete simulado no tiene el tamaño esperado."

    # Configurar el mock para devolver estos bytes cuando se llame a read()
    # y para simular in_waiting
    
    # Lista de fragmentos de bytes a devolver en llamadas sucesivas a read()
    # Esto simula cómo podrían llegar los datos.
    byte_chunks = [
        valid_packet_bytes[:5], # Parte 1
        valid_packet_bytes[5:10], # Parte 2
        valid_packet_bytes[10:], # Parte 3 (completa el paquete)
        bytes([0xAB, 0xBC]), # Basura entre paquetes
        valid_packet_bytes # Otro paquete completo
    ]
    
    # Hacer que in_waiting devuelva la longitud del siguiente chunk
    mock_serial_instance.in_waiting = MagicMock(side_effect=[len(c) for c in byte_chunks] + [0]) # Terminar con 0 para salir del bucle
    mock_serial_instance.read = MagicMock(side_effect=byte_chunks)
    mock_serial_instance.is_open = True # Simular que el puerto está abierto

    # Crear EMGAcquisition (no en modo simulación para que use el mock)
    default_serial_config.auto_connect = True # Para que intente conectar y use el mock
    emg = EMGAcquisition(default_serial_config, default_acq_config, default_filter_config, default_log_config, simulate=False)
    
    assert emg.is_connected(), "EMGAcquisition no se 'conectó' usando el mock."

    # Leer el primer paquete (llegará en fragmentos)
    packet1 = None
    for _ in range(len(byte_chunks) + 5): # Intentar leer varias veces para asegurar que el buffer se llene
        packet1 = emg.read_data()
        if packet1: break
        time.sleep(0.01) # Pequeña pausa
    
    assert packet1 is not None, "No se parseó el primer paquete válido."
    assert packet1["arduino_ms"] == 12345
    assert len(packet1["raw_data"]) == num_ch_test
    assert packet1["raw_data"][0] == 100
    assert packet1["raw_data"][1] == -200
    assert packet1["lost_frames"] == 0 # Primer paquete

    # Leer el segundo paquete (debería saltar la basura)
    packet2 = None
    for _ in range(len(byte_chunks) + 5):
        packet2 = emg.read_data()
        if packet2: break
        time.sleep(0.01)

    assert packet2 is not None, "No se parseó el segundo paquete válido después de la basura."
    assert packet2["arduino_ms"] == 12345 # Mismo timestamp en este ejemplo
    assert len(packet2["raw_data"]) == num_ch_test
    # Aquí lost_frames podría ser > 0 si el timestamp no cambió y el delay es pequeño.
    # Para esta prueba, lo importante es que el paquete se parseó.

    emg.close()
    
