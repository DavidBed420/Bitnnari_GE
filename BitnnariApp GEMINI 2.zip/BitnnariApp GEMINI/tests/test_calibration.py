"""
test_calibration.py

Pruebas unitarias y de integración para el módulo emg_calibration.py,
específicamente para la clase EMGCalibrationManager y sus funcionalidades.
"""

import os
import json
import shutil
import tempfile
import logging
import time
from typing import Dict, Any, List, Optional
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

# Módulos a probar y dependencias
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager, CalibrationRunConfig
from BitnnariApp.acquisition.emg_adquisition import EMGAcquisition, SerialConfig, AcquisitionConfig as EMGDeviceAcqConfig, FilterConfig as EMGFilterConfig, EMGDataProcessor
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.utils.constants import DATA_DIR_ROOT as APP_DATA_DIR_ROOT

# Configurar un logger para las pruebas
logger = logging.getLogger("TestEMGCalibration")
logger.setLevel(logging.DEBUG)
# logging.getLogger("EMGCalibrationManager").setLevel(logging.DEBUG)
# logging.getLogger("EMGAcquisition").setLevel(logging.DEBUG)


@pytest.fixture(scope="function")
def temp_data_root_calib() -> str:
    """Crea un directorio raíz temporal para los datos de prueba de calibración."""
    path = tempfile.mkdtemp(prefix="bitnariapp_test_calib_data_")
    yield path
    shutil.rmtree(path)

@pytest.fixture
def mock_data_manager(temp_data_root_calib: str) -> MagicMock:
    """Crea un mock para GestorDatos."""
    mock_dm = MagicMock(spec=GestorDatos)
    # Simular el comportamiento de guardado/carga para que los tests puedan verificarlo
    # Usaremos un dict en memoria para simular la base de datos del mock
    mock_dm_storage: Dict[str, Dict[str, Any]] = {}

    def mock_guardar_datos(patient_id: str, data_type_key: str, data_content: Dict[str, Any], filename_suffix: Optional[str] = None):
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        mock_dm_storage[storage_key] = data_content
        logger.debug(f"[MockDM] Guardado: {storage_key} -> {list(data_content.keys())}")
        return True

    def mock_cargar_datos(patient_id: str, data_type_key: str, filename_suffix: Optional[str] = None) -> Optional[Dict[str, Any]]:
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        logger.debug(f"[MockDM] Cargando: {storage_key}")
        return mock_dm_storage.get(storage_key)

    mock_dm.guardar_datos.side_effect = mock_guardar_datos
    mock_dm.cargar_datos.side_effect = mock_cargar_datos
    
    # Simular la estructura de carpetas para las referencias
    mock_dm.BASE_DIR = temp_data_root_calib # Para _get_reference_data_path
    os.makedirs(os.path.join(temp_data_root_calib, EMGCalibrationManager.REFERENCE_DATA_SUBDIR), exist_ok=True)
    
    return mock_dm

@pytest.fixture
def mock_emg_acquirer() -> MagicMock:
    """Crea un mock para EMGAcquisition."""
    mock_acq = MagicMock(spec=EMGAcquisition)
    mock_acq.is_connected.return_value = True
    mock_acq.connect.return_value = True
    
    # Configuración por defecto para el mock
    mock_acq.acq_config = EMGDeviceAcqConfig(num_channels_active=2, delay_ms=10) # 100 Hz
    mock_acq.serial_config = SerialConfig(port="MOCK_PORT")
    
    # Simular el procesador interno de EMGAcquisition
    # Esto es importante si calibrate_offset usa filtros del acquirer
    mock_processor = MagicMock(spec=EMGDataProcessor)
    mock_processor.apply_filters.side_effect = lambda data: data # Por defecto, no filtra
    mock_processor.config = EMGFilterConfig(sample_rate=100.0) # Default
    def update_proc_config(new_conf): mock_processor.config = new_conf
    mock_processor.update_config.side_effect = update_proc_config
    mock_acq.processor = mock_processor
    
    return mock_acq

@pytest.fixture
def calibration_manager(mock_data_manager: MagicMock, mock_emg_acquirer: MagicMock) -> EMGCalibrationManager:
    """Retorna una instancia de EMGCalibrationManager con dependencias mockeadas."""
    return EMGCalibrationManager(
        data_manager=mock_data_manager,
        emg_acquirer=mock_emg_acquirer,
        patient_id="test_patient_01"
    )

# --- Pruebas para EMGCalibrationManager ---
class TestEMGCalibrationManager:

    def test_initialization_and_patient_set(self, mock_data_manager: MagicMock):
        """Prueba la inicialización y el establecimiento del ID de paciente."""
        cal_man = EMGCalibrationManager(data_manager=mock_data_manager)
        assert cal_man.patient_id is None
        assert cal_man.offset_params is None
        
        patient_id = "patient_cal_test"
        # Simular que hay datos de calibración guardados para este paciente
        mock_data_manager.cargar_datos.return_value = {
            "offset": [0.1, 0.2], "gain": [0.9, 1.1], "num_channels": 2
        }
        cal_man.set_patient_id(patient_id)
        assert cal_man.patient_id == patient_id
        mock_data_manager.cargar_datos.assert_called_once_with(patient_id, "calibration_params")
        assert cal_man.offset_params is not None and len(cal_man.offset_params) == 2
        assert cal_man.gain_params is not None and len(cal_man.gain_params) == 2

    def test_calibrate_offset_no_filter(self, calibration_manager: EMGCalibrationManager, mock_emg_acquirer: MagicMock):
        """Prueba la calibración de offset sin aplicar filtros durante la calibración."""
        patient_id = "offset_test_nf"
        calibration_manager.set_patient_id(patient_id)
        
        num_channels = 2
        mock_emg_acquirer.acq_config.num_channels_active = num_channels
        mock_emg_acquirer.acq_config.delay_ms = 10 # 100 Hz
        
        # Simular datos de EMGAcquisition.read_data()
        # 1 segundo de datos (100 muestras por canal), con un offset conocido
        sim_offset = np.array([0.5, -0.3])
        sim_data_list = []
        for _ in range(100): # 100 paquetes de datos
            # Cada paquete tiene 'raw_data' como una lista de floats
            sample = (np.random.randn(num_channels) * 0.1 + sim_offset).tolist()
            sim_data_list.append({"raw_data": sample, "num_channels_active": num_channels})
        sim_data_list.append(None) # Para terminar el bucle en _acquire_calibration_data
        
        mock_emg_acquirer.read_data.side_effect = sim_data_list
        
        run_config = CalibrationRunConfig(
            duration_s=1.0, # 1 segundo de datos
            apply_filter_during_offset_cal=False # NO aplicar filtros
        )
        
        assert calibration_manager.calibrate_offset(run_config) is True
        assert calibration_manager.offset_params is not None
        assert calibration_manager.offset_params.shape == (num_channels,)
        # El offset calculado debería ser cercano al offset simulado
        np.testing.assert_allclose(calibration_manager.offset_params, sim_offset, atol=0.05)
        
        # Verificar que se guardaron los parámetros
        calibration_manager.data_manager.guardar_datos.assert_called_with(
            patient_id, "calibration_params", pytest.approx({ # pytest.approx para dicts con floats
                "offset": sim_offset.tolist(), "gain": [1.0, 1.0], "num_channels": num_channels
            }, abs=0.05) # Comparación aproximada
        )

    def test_calibrate_offset_with_filter(self, calibration_manager: EMGCalibrationManager, mock_emg_acquirer: MagicMock):
        """Prueba la calibración de offset aplicando filtros durante la calibración."""
        patient_id = "offset_test_wf"
        calibration_manager.set_patient_id(patient_id)
        
        num_channels = 1
        sampling_rate = 100.0 # Hz
        mock_emg_acquirer.acq_config.num_channels_active = num_channels
        mock_emg_acquirer.acq_config.delay_ms = int(1000.0 / sampling_rate)
        
        # Simular datos con un componente DC y ruido de alta frecuencia
        t = np.linspace(0, 2, int(sampling_rate * 2), endpoint=False)
        dc_offset_val = 1.5
        signal_clean = np.zeros_like(t) # Reposo
        noise_hf = 0.2 * np.sin(2 * np.pi * 40 * t) # Ruido a 40Hz (fuera de la banda de interés para offset)
        raw_signal_for_cal = dc_offset_val + signal_clean + noise_hf
        
        sim_data_list = [{"raw_data": [sample], "num_channels_active": num_channels} for sample in raw_signal_for_cal]
        sim_data_list.append(None)
        mock_emg_acquirer.read_data.side_effect = sim_data_list
        
        # Configurar el mock del procesador para que realmente filtre
        filter_for_cal = EMGFilterConfig(
            sample_rate=sampling_rate,
            notch_freq=None, # Sin notch para esta prueba
            bandpass_low_freq=0.5, # Pasa-alto muy bajo para quitar DC
            bandpass_high_freq=5.0,  # Pasa-bajo para quitar ruido HF
            bandpass_order=4, enabled=True
        )
        # El procesador real se crea dentro de EMGAcquisition.
        # Necesitamos que el mock_emg_acquirer.processor use este config.
        real_processor = EMGDataProcessor(filter_for_cal)
        mock_emg_acquirer.processor.apply_filters.side_effect = real_processor.apply_filters
        mock_emg_acquirer.processor.update_config.side_effect = real_processor.update_config # Para que se use el config correcto

        run_config = CalibrationRunConfig(
            duration_s=2.0,
            apply_filter_during_offset_cal=True,
            filter_config=filter_for_cal # Esta config se pasará al procesador
        )
        
        assert calibration_manager.calibrate_offset(run_config) is True
        assert calibration_manager.offset_params is not None
        # Después del filtro pasa-alto, el offset DC debería ser cercano a 0, no a dc_offset_val
        np.testing.assert_allclose(calibration_manager.offset_params, [0.0], atol=0.1)


    def test_apply_calibration(self, calibration_manager: EMGCalibrationManager):
        """Prueba la aplicación de parámetros de calibración a una señal."""
        num_channels = 2
        calibration_manager.offset_params = np.array([0.5, -0.2])
        calibration_manager.gain_params = np.array([1.0, 2.0]) # Ganancia diferente para el canal 2
        calibration_manager.num_channels = num_channels

        raw_data = np.array([[1.0, 2.0], [1.5, 1.8], [0.8, 2.2]]) # [n_samples, n_channels]
        
        expected_calibrated_data = np.array([
            [(1.0 - 0.5) * 1.0, (2.0 - (-0.2)) * 2.0],
            [(1.5 - 0.5) * 1.0, (1.8 - (-0.2)) * 2.0],
            [(0.8 - 0.5) * 1.0, (2.2 - (-0.2)) * 2.0]
        ])
        
        calibrated_data = calibration_manager.apply_calibration(raw_data)
        np.testing.assert_allclose(calibrated_data, expected_calibrated_data, atol=1e-6)

        # Probar con una sola muestra (1D)
        raw_sample_1d = np.array([1.0, 2.0])
        expected_calibrated_sample_1d = np.array([(1.0 - 0.5) * 1.0, (2.0 - (-0.2)) * 2.0])
        calibrated_sample_1d = calibration_manager.apply_calibration(raw_sample_1d)
        np.testing.assert_allclose(calibrated_sample_1d, expected_calibrated_sample_1d, atol=1e-6)

    def test_apply_calibration_no_params(self, calibration_manager: EMGCalibrationManager):
        """Prueba que aplicar calibración falle si no hay parámetros."""
        calibration_manager.offset_params = None # Asegurar que no hay offset
        raw_data = np.random.rand(10, 2)
        # No debería fallar, sino devolver los datos originales o loguear un warning.
        # La implementación actual de apply_calibration devuelve la data original si los params son None.
        calibrated_data = calibration_manager.apply_calibration(raw_data)
        np.testing.assert_array_equal(calibrated_data, raw_data)


    def test_save_and_load_calibration_params(self, calibration_manager: EMGCalibrationManager, mock_data_manager: MagicMock):
        """Prueba el guardado y carga de parámetros de calibración."""
        patient_id = "cal_saveload_test"
        calibration_manager.set_patient_id(patient_id)
        
        calibration_manager.offset_params = np.array([0.11, 0.22])
        calibration_manager.gain_params = np.array([1.1, 0.9])
        calibration_manager.num_channels = 2
        
        calibration_manager.save_calibration_params(patient_id)
        # Verificar que mock_data_manager.guardar_datos fue llamado con los datos correctos
        args, kwargs = mock_data_manager.guardar_datos.call_args
        assert args[0] == patient_id
        assert args[1] == "calibration_params"
        saved_data = args[2]
        assert "offset" in saved_data and "gain" in saved_data
        np.testing.assert_allclose(saved_data["offset"], [0.11, 0.22])
        np.testing.assert_allclose(saved_data["gain"], [1.1, 0.9])
        assert saved_data["num_channels"] == 2

        # Resetear y cargar
        calibration_manager.reset_calibration()
        assert calibration_manager.offset_params is None
        
        # Configurar el mock para devolver los datos guardados
        mock_data_manager.cargar_datos.return_value = saved_data # Lo que se guardó
        
        assert calibration_manager.load_calibration_params(patient_id) is True
        assert calibration_manager.offset_params is not None
        np.testing.assert_allclose(calibration_manager.offset_params, [0.11, 0.22])
        np.testing.assert_allclose(calibration_manager.gain_params, [1.1, 0.9])
        assert calibration_manager.num_channels == 2

    def test_load_calibration_params_non_existent(self, calibration_manager: EMGCalibrationManager, mock_data_manager: MagicMock):
        """Prueba cargar parámetros para un paciente sin calibración guardada."""
        mock_data_manager.cargar_datos.return_value = None # Simular que no hay datos
        assert calibration_manager.load_calibration_params("new_patient_no_calib") is False
        assert calibration_manager.offset_params is None
        assert calibration_manager.gain_params is None

    def test_reference_signal_management(self, calibration_manager: EMGCalibrationManager, temp_data_root_calib: str):
        """Prueba el guardado y carga de señales de referencia."""
        # Necesitamos que data_manager use el directorio temporal real para esta prueba de archivos
        real_gd = GestorDatos(data_root_path=temp_data_root_calib)
        calibration_manager.data_manager = real_gd # Reemplazar el mock por uno real para esta prueba
        
        reference_id = "test_ref_signal_01"
        signal_data = np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]) # 2 muestras, 3 canales
        
        calibration_manager.save_signal_as_reference(signal_data, reference_id)
        
        # Verificar que el archivo se creó
        expected_ref_path = os.path.join(temp_data_root_calib, EMGCalibrationManager.REFERENCE_DATA_SUBDIR, f"{reference_id}.json")
        assert os.path.exists(expected_ref_path)

        loaded_signal = calibration_manager.load_reference_signal(reference_id)
        assert loaded_signal is not None
        np.testing.assert_allclose(loaded_signal, signal_data)

        # Probar cargar referencia no existente
        assert calibration_manager.load_reference_signal("non_existent_ref") is None

    def test_compare_with_reference(self, calibration_manager: EMGCalibrationManager, temp_data_root_calib: str):
        """Prueba la comparación de una señal con una referencia."""
        real_gd = GestorDatos(data_root_path=temp_data_root_calib)
        calibration_manager.data_manager = real_gd
        calibration_manager.num_channels = 2 # Asumir 2 canales para esta prueba

        ref_id = "comparison_ref"
        # Referencia es un vector de offset
        reference_offset_vector = np.array([0.1, 0.15])
        calibration_manager.save_signal_as_reference(reference_offset_vector, ref_id)

        # Establecer un offset actual en el manager
        calibration_manager.offset_params = np.array([0.12, 0.18])
        calibration_manager.gain_params = np.ones(2) # Ganancia unitaria

        # La función compare_with_reference toma una *nueva señal* y la calibra antes de comparar.
        # Para probar la comparación de offset, la "nueva señal" debe ser tal que después de
        # la calibración, resulte en el offset que queremos comparar.
        # Si la nueva señal es el offset_params actual, y apply_calibration resta el offset,
        # la señal calibrada será cero. Esto no es lo que queremos comparar con el ref_offset_vector.
        
        # La intención de compare_with_reference es más para una señal temporal.
        # Vamos a reinterpretar: si queremos comparar el *offset actual* con una *referencia de offset*,
        # debemos pasar el offset actual como la "nueva señal" y asegurar que apply_calibration
        # no lo altere si ya es un offset (o mockear apply_calibration).
        
        # Para esta prueba, vamos a comparar el offset_params actual directamente.
        # La función original `compare_with_reference` espera una `new_signal` que es una *señal temporal*,
        # no un vector de offset. Modifiquemos la prueba para que sea más coherente o
        # asumamos que la referencia guardada es una señal temporal.

        # Caso 1: La referencia es una señal temporal, y la nueva señal también.
        ref_signal_temporal = np.random.rand(100, 2) + reference_offset_vector
        calibration_manager.save_signal_as_reference(ref_signal_temporal, "temporal_ref")
        
        new_signal_temporal = ref_signal_temporal * 1.1 # Señal similar
        
        # Asegurar que el calibration_manager tenga parámetros de calibración para aplicar
        calibration_manager.offset_params = np.array([0.05, 0.05]) # Un pequeño offset
        calibration_manager.gain_params = np.ones(2)

        results = calibration_manager.compare_with_reference(new_signal_temporal, "temporal_ref")
        assert results is not None
        assert "mse" in results and "similarity_percent" in results
        assert results["mse"] > 0 # Deberían ser diferentes
        logger.info(f"Comparación con referencia temporal: {results}")

        # Caso 2: Comparar directamente vectores de offset (esto no usa compare_with_reference directamente)
        mse_offsets = EMGCalibrationManager.calculate_mse(calibration_manager.offset_params, reference_offset_vector)
        assert mse_offsets > 0 

    def test_adjust_signal_to_reference(self):
        """Prueba el ajuste de una señal a una referencia."""
        # No depende de la instancia de calibration_manager ya que es estático
        reference_signal = np.array([0.0, 0.5, 1.0, 0.5, 0.0] * 20) # Señal periódica
        new_signal = (reference_signal * 2.0) + 1.0 # Misma forma, diferente amplitud y offset

        adjusted_signal = EMGCalibrationManager.adjust_signal_to_reference(new_signal, reference_signal)
        
        # El MSE después del ajuste debería ser mucho menor
        mse_before = EMGCalibrationManager.calculate_mse(new_signal, reference_signal)
        mse_after = EMGCalibrationManager.calculate_mse(adjusted_signal, reference_signal)
        
        logger.info(f"MSE antes de ajuste: {mse_before:.4f}, MSE después de ajuste: {mse_after:.4f}")
        assert mse_after < mse_before * 0.1 # Esperar una reducción significativa del MSE
        
        # Verificar que la media y std de la ajustada estén más cerca de la referencia
        # (Esto depende de si el ajuste re-escala al rango original de la referencia)
        # La implementación actual de adjust_signal_to_reference re-escala al rango de la referencia.
        np.testing.assert_allclose(np.mean(adjusted_signal, axis=0), np.mean(reference_signal, axis=0), atol=1e-1)
        np.testing.assert_allclose(np.std(adjusted_signal, axis=0), np.std(reference_signal, axis=0), atol=1e-1)
    
