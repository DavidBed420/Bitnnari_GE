"""
test_gestor_datos.py

Pruebas unitarias y de integración para la clase GestorDatos.
Utiliza pytest para la ejecución de pruebas y el manejo de fixtures.
Cubre la creación, lectura, actualización y eliminación (CRUD) de datos de pacientes,
así como la gestión de configuraciones y sesiones específicas del paciente,
y el manejo del índice de pacientes.
"""

import os
import json
import shutil
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List, Tuple

import pytest
from PyQt6.QtCore import QObject, pyqtSignal # Necesario si GestorDatos emite señales Qt

# Módulo a probar
from BitnnariApp.data.gestor_datos import GestorDatos, ensure_patient_data_structure
from BitnnariApp.utils.constants import (
    DATA_DIR_ROOT as APP_DATA_DIR_ROOT, # Renombrar para evitar conflicto con fixture
    PATIENT_INDEX_FILENAME,
    PATIENT_DATA_SUBDIRS,
    KEY_LAST_UPDATE
)

# Configurar un logger específico para las pruebas o silenciar logs de la app
logger = logging.getLogger("TestGestorDatos")
logger.setLevel(logging.DEBUG) # Mostrar todos los logs durante las pruebas
# Evitar que los logs de la app interfieran con la salida de pytest si no se configuran bien
# logging.getLogger("GestorDatos").setLevel(logging.CRITICAL)


@pytest.fixture(scope="function") # Se ejecuta para cada función de test
def temp_data_root() -> str:
    """
    Crea un directorio raíz temporal para los datos de prueba.
    Se limpia después de que cada test que lo usa finaliza.
    """
    path = tempfile.mkdtemp(prefix="bitnariapp_test_data_")
    logger.info(f"Directorio de datos temporal creado para test: {path}")
    yield path # Proporciona la ruta al test
    logger.info(f"Limpiando directorio de datos temporal: {path}")
    shutil.rmtree(path)


@pytest.fixture
def gestor_datos_instance(temp_data_root: str) -> GestorDatos:
    """
    Retorna una instancia de GestorDatos configurada para usar el directorio temporal.
    """
    # Asegurarse que las constantes apunten al directorio temporal para esta instancia de test
    # Esto es un poco un hack; idealmente, GestorDatos tomaría data_root en __init__
    # y no dependería de constantes globales para su ruta base.
    # La versión actual de GestorDatos ya toma data_root_path.
    return GestorDatos(data_root_path=temp_data_root)

@pytest.fixture
def sample_patient_data_1() -> Dict[str, Any]:
    return {
        "dni": "TEST001Z", # DNI limpio
        "dni_display_format": "TEST.001-Z",
        "nombre": "Paciente de Prueba Uno",
        "fecha_nacimiento": "1980-01-15",
        "contacto": {"email": "test1@example.com", "telefono": "600111222"},
        "patologias": ["Migraña Crónica", "Astigmatismo"],
        "modelo_ml_preferido": "random_forest"
    }

@pytest.fixture
def sample_patient_data_2() -> Dict[str, Any]:
    return {
        "dni": "TEST002Y",
        "dni_display_format": "TEST.002-Y",
        "nombre": "Segunda Paciente Test",
        "fecha_nacimiento": "1995-11-02",
        "contacto": {"email": "test2@example.com"},
        "patologias": [],
    }

class TestGestorDatosOperations:
    """Grupo de tests para las operaciones CRUD y de gestión de GestorDatos."""

    def test_initialization(self, gestor_datos_instance: GestorDatos, temp_data_root: str):
        """Verifica la inicialización correcta y la creación de archivos/carpetas base."""
        gd = gestor_datos_instance
        assert gd.data_root == temp_data_root
        assert os.path.exists(gd.data_root)
        assert os.path.exists(gd.patient_index_path)
        assert isinstance(gd.pacientes_index, dict)

    def test_ensure_patient_data_structure(self, temp_data_root: str):
        """Verifica que la estructura de carpetas del paciente se cree correctamente."""
        patient_id = "PATSTRUCT01"
        patient_base_path = ensure_patient_data_structure(patient_id, data_root=temp_data_root) # Pasar data_root
        
        expected_patient_path = os.path.join(temp_data_root, "patients", patient_id)
        assert patient_base_path == expected_patient_path
        assert os.path.isdir(expected_patient_path)
        
        for subdir_key, subdir_name in PATIENT_DATA_SUBDIRS.items():
            assert os.path.isdir(os.path.join(expected_patient_path, subdir_name)), f"Subdirectorio {subdir_name} no creado."

    def test_register_new_patient(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba el registro de un nuevo paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]

        assert gd.registrar_nuevo_paciente(dni, sample_patient_data_1) is True
        assert dni in gd.pacientes_index
        assert gd.pacientes_index[dni]["nombre"] == sample_patient_data_1["nombre"]
        
        # Verificar que el archivo de datos personales se haya creado
        personal_info_path = gd._get_patient_data_filepath(dni, "personal_info", "datos_personales.json")
        assert os.path.exists(personal_info_path)
        with open(personal_info_path, "r") as f:
            data_on_disk = json.load(f)
        assert data_on_disk["nombre"] == sample_patient_data_1["nombre"]
        assert KEY_LAST_UPDATE in data_on_disk

    def test_register_existing_patient_fails(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba que registrar un paciente existente falle."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1) # Registrar primero
        
        assert gd.registrar_nuevo_paciente(dni, sample_patient_data_1) is False # Intentar registrar de nuevo

    def test_load_patient(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba la carga de datos de un paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        loaded_data = gd.cargar_paciente(dni)
        assert loaded_data is not None
        assert loaded_data["dni"] == dni # GestorDatos añade DNI si no está
        assert loaded_data["nombre"] == sample_patient_data_1["nombre"]
        assert loaded_data["contacto"]["email"] == sample_patient_data_1["contacto"]["email"]

    def test_load_non_existing_patient(self, gestor_datos_instance: GestorDatos):
        """Prueba que cargar un paciente no existente devuelva None."""
        gd = gestor_datos_instance
        assert gd.cargar_paciente("NONEXISTENT_DNI") is None

    def test_update_patient(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba la actualización de los datos de un paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        updated_data = sample_patient_data_1.copy()
        updated_data["nombre"] = "Juan Pérez Actualizado"
        updated_data["patologias"].append("Hipercolesterolemia")
        original_update_ts_str = updated_data.get(KEY_LAST_UPDATE)


        assert gd.actualizar_paciente(dni, updated_data) is True
        
        reloaded_data = gd.cargar_paciente(dni)
        assert reloaded_data is not None
        assert reloaded_data["nombre"] == "Juan Pérez Actualizado"
        assert "Hipercolesterolemia" in reloaded_data["patologias"]
        assert KEY_LAST_UPDATE in reloaded_data
        # Verificar que el timestamp de actualización haya cambiado
        if original_update_ts_str: # Si existía antes de la actualización de GestorDatos
            assert reloaded_data[KEY_LAST_UPDATE] != original_update_ts_str 
        
        # Verificar que el índice también se actualice si el nombre cambia
        assert gd.pacientes_index[dni]["nombre"] == "Juan Pérez Actualizado"

    def test_update_non_existing_patient(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba que actualizar un paciente no existente falle."""
        gd = gestor_datos_instance
        assert gd.actualizar_paciente("NONEXISTENT_DNI", sample_patient_data_1) is False

    def test_update_patient_field(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba la actualización de un campo específico del paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        new_phone = "555-0001"
        assert gd.actualizar_campo_paciente(dni, "contacto.telefono", new_phone) is True
        reloaded_data = gd.cargar_paciente(dni)
        assert reloaded_data["contacto"]["telefono"] == new_phone

        new_pathology_list = ["Asma Grave"]
        assert gd.actualizar_campo_paciente(dni, "patologias", new_pathology_list) is True
        reloaded_data_2 = gd.cargar_paciente(dni)
        assert reloaded_data_2["patologias"] == new_pathology_list
        
        # Probar actualizar un campo inexistente (debería crearlo)
        assert gd.actualizar_campo_paciente(dni, "metadata.preferencias.color_tema", "oscuro") is True
        reloaded_data_3 = gd.cargar_paciente(dni)
        assert reloaded_data_3["metadata"]["preferencias"]["color_tema"] == "oscuro"


    def test_delete_patient(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba la eliminación completa de un paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)
        
        patient_folder_path = os.path.join(gd.data_root, "patients", dni)
        assert os.path.isdir(patient_folder_path) # Verificar que la carpeta existe

        assert gd.eliminar_paciente_completo(dni) is True
        assert dni not in gd.pacientes_index
        assert gd.cargar_paciente(dni) is None
        assert not os.path.exists(patient_folder_path) # Verificar que la carpeta fue eliminada

    def test_delete_non_existing_patient(self, gestor_datos_instance: GestorDatos):
        """Prueba que eliminar un paciente no existente no cause error y devuelva False."""
        gd = gestor_datos_instance
        assert gd.eliminar_paciente_completo("NONEXISTENT_DNI") is False

    def test_list_all_patients(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any], sample_patient_data_2: Dict[str, Any]):
        """Prueba la lista de todos los pacientes."""
        gd = gestor_datos_instance
        gd.registrar_nuevo_paciente(sample_patient_data_1["dni"], sample_patient_data_1)
        gd.registrar_nuevo_paciente(sample_patient_data_2["dni"], sample_patient_data_2)

        lista_pacientes = gd.listar_todos_los_pacientes()
        assert len(lista_pacientes) == 2
        dnis_listados = [p["dni"] for p in lista_pacientes]
        assert sample_patient_data_1["dni"] in dnis_listados
        assert sample_patient_data_2["dni"] in dnis_listados
        nombres_listados = [p["nombre"] for p in lista_pacientes]
        assert sample_patient_data_1["nombre"] in nombres_listados

    def test_save_and_load_generic_data(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba guardar y cargar datos genéricos (e.g., configuraciones de página)."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        data_type_key = "page_configs" # Debe ser una clave válida de PATIENT_DATA_SUBDIRS
        config_name = "adquisicion_settings"
        config_content = {"theme": "dark_blue", "plot_lines": 3, "autosave": True}

        assert gd.guardar_datos(dni, data_type_key, config_content, filename_suffix=config_name) is True
        
        loaded_config = gd.cargar_datos(dni, data_type_key, filename_suffix=config_name)
        assert loaded_config is not None
        assert loaded_config["theme"] == "dark_blue"
        assert loaded_config["autosave"] is True
        assert KEY_LAST_UPDATE in loaded_config

    def test_load_non_existing_generic_data(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba cargar datos genéricos que no existen."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)
        
        assert gd.cargar_datos(dni, "page_configs", "non_existent_config") is None

    def test_save_and_list_sessions(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba guardar, listar y cargar datos de sesión."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        session_type_key = "acquisition_sessions" # Clave válida de PATIENT_DATA_SUBDIRS
        
        session1_name = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}_ch2"
        session1_data = {"duration": 120, "samples": 120000, "channels_used": [0, 1]}
        assert gd.guardar_datos_sesion(dni, session_type_key, session1_name, session1_data) is True

        # Pequeña pausa para asegurar nombres de archivo diferentes si se generan por timestamp
        try:
            import time
            time.sleep(0.01) 
        except: pass

        session2_name = f"calibration_attempt_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        session2_data = {"type": "offset", "offset_values": [0.1, 0.2, 0.15]}
        # Usar una clave diferente para el tipo de sesión de calibración
        calib_session_type_key = "calibration_params" # O podría ser "calibration_sessions"
        assert gd.guardar_datos_sesion(dni, calib_session_type_key, session2_name, session2_data) is True

        # Listar sesiones de adquisición
        acq_sessions = gd.listar_sesiones(dni, session_type_key)
        assert len(acq_sessions) == 1
        assert acq_sessions[0][0] == session1_name # Nombre sin el prefijo del tipo
        
        # Cargar sesión de adquisición
        loaded_session1 = gd.cargar_datos_sesion(dni, session_type_key, session1_name)
        assert loaded_session1 is not None
        assert loaded_session1["duration"] == 120

        # Listar sesiones de calibración
        calib_sessions = gd.listar_sesiones(dni, calib_session_type_key)
        assert len(calib_sessions) == 1
        assert calib_sessions[0][0] == session2_name

    def test_export_all_patient_data(self, gestor_datos_instance: GestorDatos, temp_data_root: str, sample_patient_data_1: Dict[str, Any]):
        """Prueba la exportación completa de los datos de un paciente."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)
        
        # Añadir algunos datos adicionales para exportar
        gd.guardar_datos(dni, "page_configs", {"theme": "light"}, "main_settings")
        gd.guardar_datos_sesion(dni, "acquisition_sessions", "session_export_test", {"data_points": 100})

        export_filepath = os.path.join(temp_data_root, f"{dni}_full_export.json")
        assert gd.exportar_datos_paciente_a_json(dni, export_filepath) is True
        assert os.path.exists(export_filepath)

        with open(export_filepath, "r") as f:
            exported_data = json.load(f)
        
        assert "metadata" in exported_data
        assert "datos_personales_completos" in exported_data
        assert exported_data["datos_personales_completos"]["nombre"] == sample_patient_data_1["nombre"]
        assert "page_configs" in exported_data # Este es el que guardamos como archivo único
        assert isinstance(exported_data["page_configs"], dict) 
        assert exported_data["page_configs"]["theme"] == "light"

        assert "acquisition_sessions" in exported_data # Este es una lista de sesiones
        assert isinstance(exported_data["acquisition_sessions"], list)
        assert len(exported_data["acquisition_sessions"]) == 1
        assert exported_data["acquisition_sessions"][0]["session_id_suffix"] == "session_export_test"
        assert exported_data["acquisition_sessions"][0]["data_points"] == 100
        
    def test_active_patient_management(self, gestor_datos_instance: GestorDatos, sample_patient_data_1: Dict[str, Any]):
        """Prueba la gestión del paciente activo."""
        gd = gestor_datos_instance
        dni = sample_patient_data_1["dni"]
        gd.registrar_nuevo_paciente(dni, sample_patient_data_1)

        assert gd.paciente_actual_dni is None
        assert gd.paciente_actual_data is None

        # Simular la señal que se conectaría en la UI
        signal_fired_patient_id = None
        def on_patient_updated(updated_dni):
            nonlocal signal_fired_patient_id
            signal_fired_patient_id = updated_dni
        
        gd.datos_paciente_actualizados.connect(on_patient_updated)

        gd.set_active_patient(sample_patient_data_1)
        assert gd.paciente_actual_dni == dni
        assert gd.paciente_actual_data["nombre"] == sample_patient_data_1["nombre"]
        assert signal_fired_patient_id == dni
        signal_fired_patient_id = None # Reset para la próxima prueba de señal

        active_data = gd.get_active_patient_data()
        assert active_data is not None and active_data["dni"] == dni

        gd.clear_active_patient()
        assert gd.paciente_actual_dni is None
        assert gd.paciente_actual_data is None
        assert signal_fired_patient_id == "" # Emitido con DNI vacío

        gd.datos_paciente_actualizados.disconnect(on_patient_updated) # Limpiar conexión