  """
test_processing.py

Pruebas unitarias y de integración para el módulo emg_processing.py,
específicamente para la clase EMGProcessingEngine.
"""

import os
import json
import shutil
import tempfile
import logging
from typing import Dict, Any, List, Optional
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
from scipy.signal import welch, periodogram

# Módulos a probar y dependencias
from BitnnariApp.processing.emg_processing import EMGProcessingEngine
from BitnnariApp.data.gestor_datos import GestorDatos
from BitnnariApp.calibration.emg_calibration import EMGCalibrationManager
from BitnnariApp.utils.constants import DATA_DIR_ROOT as APP_DATA_DIR_ROOT

# Configurar un logger para las pruebas
logger = logging.getLogger("TestEMGProcessing")
logger.setLevel(logging.DEBUG)
# logging.getLogger("EMGProcessingEngine").setLevel(logging.DEBUG)

@pytest.fixture(scope="function")
def temp_data_root_proc() -> str:
    """Crea un directorio raíz temporal para los datos de prueba de procesamiento."""
    path = tempfile.mkdtemp(prefix="bitnariapp_test_proc_data_")
    yield path
    shutil.rmtree(path)

@pytest.fixture
def mock_data_manager_proc(temp_data_root_proc: str) -> MagicMock:
    """Crea un mock para GestorDatos para el módulo de procesamiento."""
    mock_dm = MagicMock(spec=GestorDatos)
    mock_dm_storage: Dict[str, Dict[str, Any]] = {}

    def mock_guardar_datos(patient_id: str, data_type_key: str, data_content: Dict[str, Any], filename_suffix: Optional[str] = None):
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        mock_dm_storage[storage_key] = data_content
        return True

    def mock_cargar_datos(patient_id: str, data_type_key: str, filename_suffix: Optional[str] = None) -> Optional[Dict[str, Any]]:
        storage_key = f"{patient_id}_{data_type_key}{'_' + filename_suffix if filename_suffix else ''}"
        return mock_dm_storage.get(storage_key)

    mock_dm.guardar_datos.side_effect = mock_guardar_datos
    mock_dm.cargar_datos.side_effect = mock_cargar_datos
    return mock_dm

@pytest.fixture
def mock_calibration_manager() -> MagicMock:
    """Crea un mock para EMGCalibrationManager."""
    mock_cm = MagicMock(spec=EMGCalibrationManager)
    mock_cm.offset_params = None # Por defecto, sin offset
    mock_cm.gain_params = None   # Por defecto, sin ganancia
    # Simular apply_calibration para que devuelva la señal original si no hay params
    mock_cm.apply_calibration.side_effect = lambda data: data 
    return mock_cm

@pytest.fixture
def processing_engine_instance(mock_data_manager_proc: MagicMock) -> EMGProcessingEngine:
    """Retorna una instancia de EMGProcessingEngine con un DataManager mockeado."""
    return EMGProcessingEngine(sampling_rate=1000.0, data_manager=mock_data_manager_proc, patient_id="proc_test_patient")

# --- Datos de Prueba de Señal ---
FS_TEST = 1000.0 # Hz
DURATION_TEST = 2.0 # segundos
N_SAMPLES_TEST = int(FS_TEST * DURATION_TEST)
TIME_VECTOR_TEST = np.linspace(0, DURATION_TEST, N_SAMPLES_TEST, endpoint=False)

@pytest.fixture
def sample_emg_signal_1ch() -> np.ndarray:
    """Genera una señal EMG de un canal con varios componentes."""
    s_clean = 0.7 * np.sin(2 * np.pi * 30 * TIME_VECTOR_TEST) + 0.3 * np.sin(2 * np.pi * 80 * TIME_VECTOR_TEST)
    noise_50hz = 0.5 * np.sin(2 * np.pi * 50 * TIME_VECTOR_TEST)
    noise_white = 0.1 * np.random.randn(N_SAMPLES_TEST)
    dc_offset = 1.0
    return s_clean + noise_50hz + noise_white + dc_offset

@pytest.fixture
def sample_emg_signal_2ch(sample_emg_signal_1ch: np.ndarray) -> np.ndarray:
    """Genera una señal EMG de dos canales."""
    ch2 = sample_emg_signal_1ch * 0.7 + 0.2 * np.sin(2 * np.pi * 120 * TIME_VECTOR_TEST) - 0.5
    return np.vstack((sample_emg_signal_1ch, ch2)).T # Shape [N_SAMPLES, 2]


class TestEMGProcessingEngineCore:
    """Pruebas para las funcionalidades centrales de EMGProcessingEngine."""

    def test_initialization_and_config_management(self, processing_engine_instance: EMGProcessingEngine, mock_data_manager_proc: MagicMock):
        """Prueba la inicialización y la carga/guardado de configuración."""
        engine = processing_engine_instance
        patient_id = "config_test_patient"
        engine.patient_id = patient_id

        # Verificar config por defecto
        assert engine.filters_config["notch"]["freq_hz"] == 50.0

        # Modificar y guardar config
        engine.configure_filter("notch", {"enabled": True, "freq_hz": 60.0, "quality_factor": 35.0})
        engine.configure_filter("highpass", {"enabled": True, "cutoff_hz": 25.0})
        engine.save_processing_config(patient_id)
        
        mock_data_manager_proc.guardar_datos.assert_called_once()
        args_save, _ = mock_data_manager_proc.guardar_datos.call_args
        assert args_save[0] == patient_id
        assert args_save[1] == "processing_config"
        assert args_save[2]["notch"]["freq_hz"] == 60.0

        # Crear nueva instancia y cargar config
        mock_data_manager_proc.cargar_datos.return_value = args_save[2] # Devolver la config guardada
        new_engine = EMGProcessingEngine(sampling_rate=FS_TEST, data_manager=mock_data_manager_proc, patient_id=patient_id)
        
        assert new_engine.filters_config["notch"]["freq_hz"] == 60.0
        assert new_engine.filters_config["highpass"]["cutoff_hz"] == 25.0
        assert new_engine.filters_config["lowpass"]["cutoff_hz"] == EMGProcessingEngine.DEFAULT_FILTER_CONFIG["lowpass"]["cutoff_hz"] # No se modificó

    def test_update_sampling_rate(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        engine.update_sampling_rate(2000.0)
        assert engine.sampling_rate == 2000.0
        with pytest.raises(ValueError): # No debería ser posible con la validación actual
            engine.update_sampling_rate(0)


class TestEMGProcessingFilters:
    """Pruebas específicas para cada filtro en EMGProcessingEngine."""

    def test_baseline_correction(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        signal_with_dc = np.ones(100) * 5.0 + np.random.randn(100) * 0.1
        
        engine.configure_filter("baseline_correction", {"enabled": True, "method": "mean"})
        # Para llamar a process_signal, deshabilitamos otros filtros para aislar este
        for f_name in engine.filters_config: engine.filters_config[f_name]["enabled"] = False
        engine.filters_config["baseline_correction"]["enabled"] = True
        
        corrected_mean = engine.process_signal(signal_with_dc.copy())
        assert np.mean(corrected_mean) == pytest.approx(0.0, abs=1e-6)

        engine.configure_filter("baseline_correction", {"method": "initial_segment"})
        # Asegurar que n_initial sea menor que la longitud de la señal
        n_initial = int(engine.sampling_rate * 0.01) # 10ms = 10 muestras a 1000Hz
        if len(signal_with_dc) > n_initial:
            corrected_initial = engine.process_signal(signal_with_dc.copy())
            # El offset global no será necesariamente cero, pero el inicio sí
            assert np.mean(corrected_initial[:n_initial]) == pytest.approx(0.0, abs=1e-1) # Más tolerancia por ruido

    def test_hpf_lpf_notch_filters(self, processing_engine_instance: EMGProcessingEngine, sample_emg_signal_1ch: np.ndarray):
        engine = processing_engine_instance # FS=1000Hz
        raw_signal = sample_emg_signal_1ch # Contiene DC, 30Hz, 50Hz, 80Hz, ruido HF

        # Deshabilitar todos los filtros excepto los que se prueban
        for f_name in engine.filters_config: engine.filters_config[f_name]["enabled"] = False
        
        # 1. Probar HPF
        engine.configure_filter("highpass", {"enabled": True, "cutoff_hz": 20.0, "order": 4})
        signal_hpf_only = engine.process_signal(raw_signal.copy())
        freq_raw, psd_raw = welch(raw_signal, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        freq_hpf, psd_hpf = welch(signal_hpf_only, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        assert psd_hpf[freq_hpf < 10].mean() < psd_raw[freq_raw < 10].mean() * 0.1, "HPF no atenuó bajas frecuencias."
        engine.filters_config["highpass"]["enabled"] = False # Deshabilitar para la siguiente prueba

        # 2. Probar LPF
        engine.configure_filter("lowpass", {"enabled": True, "cutoff_hz": 100.0, "order": 4})
        signal_lpf_only = engine.process_signal(raw_signal.copy()) # raw_signal tiene componentes hasta 150Hz (ruido 50Hz)
        freq_lpf, psd_lpf = welch(signal_lpf_only, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        assert psd_lpf[freq_lpf > 150].mean() < psd_raw[freq_raw > 150].mean() * 0.1, "LPF no atenuó altas frecuencias."
        engine.filters_config["lowpass"]["enabled"] = False

        # 3. Probar Notch
        engine.configure_filter("notch", {"enabled": True, "freq_hz": 50.0, "quality_factor": 30.0})
        signal_notch_only = engine.process_signal(raw_signal.copy())
        freq_notch, psd_notch = welch(signal_notch_only, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        idx_50_raw = np.argmin(np.abs(freq_raw - 50))
        idx_50_notch = np.argmin(np.abs(freq_notch - 50))
        assert psd_notch[idx_50_notch] < psd_raw[idx_50_raw] * 0.01, "Notch no atenuó 50Hz." # Atenuación fuerte esperada

    def test_savitzky_golay_filter(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        # Señal con ruido de alta frecuencia sobre una tendencia suave
        t = np.linspace(0, 1, 100)
        smooth_trend = np.sin(2 * np.pi * 1 * t)
        noise = np.random.randn(100) * 0.2
        test_signal = smooth_trend + noise
        
        for f_name in engine.filters_config: engine.filters_config[f_name]["enabled"] = False
        engine.configure_filter("savitzky_golay", {"enabled": True, "window_length": 11, "polyorder": 3})
        
        filtered_signal = engine.process_signal(test_signal.copy())
        # SavGol debería reducir la varianza (ruido) sin distorsionar demasiado la tendencia
        assert np.var(filtered_signal) < np.var(test_signal)
        assert np.corrcoef(smooth_trend, filtered_signal)[0,1] > 0.9, "SavGol distorsionó demasiado la tendencia."

    # Pruebas similares para Moving Average, Hilbert, EMD...

    def test_full_processing_pipeline(self, processing_engine_instance: EMGProcessingEngine, 
                                      sample_emg_signal_1ch: np.ndarray, 
                                      mock_calibration_manager: MagicMock):
        """Prueba la cadena completa de procesamiento con varios filtros habilitados."""
        engine = processing_engine_instance
        raw_signal = sample_emg_signal_1ch # Contiene DC, 30Hz, 50Hz, 80Hz, ruido HF

        # Configurar una cadena de filtros
        engine.configure_filter("baseline_correction", {"enabled": True, "method": "mean"})
        engine.configure_filter("highpass", {"enabled": True, "cutoff_hz": 20.0, "order": 4})
        engine.configure_filter("notch", {"enabled": True, "freq_hz": 50.0, "quality_factor": 30.0})
        engine.configure_filter("lowpass", {"enabled": True, "cutoff_hz": 150.0, "order": 4}) # Cortar por encima de 80Hz
        engine.configure_filter("amplification", {"enabled": True, "factor": 2.0})
        engine.configure_filter("normalization", {"enabled": True, "method": "z-score"})

        # Simular calibración
        mock_calibration_manager.offset_params = np.array([0.5]) # Simular un offset
        mock_calibration_manager.gain_params = np.array([1.0])
        mock_calibration_manager.apply_calibration.side_effect = lambda data: (data - 0.5) * 1.0

        processed_signal = engine.process_signal(raw_signal.copy(), calibration_manager=mock_calibration_manager)
        
        # Verificaciones cualitativas
        # 1. Media cercana a cero (por Z-score y corrección de baseline)
        assert np.mean(processed_signal) == pytest.approx(0.0, abs=0.1)
        # 2. Desviación estándar cercana a 1 (por Z-score)
        assert np.std(processed_signal) == pytest.approx(1.0, abs=0.1)

        # 3. Análisis espectral
        freq_raw, psd_raw = welch(raw_signal, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        freq_proc, psd_proc = welch(processed_signal, FS_TEST, nperseg=N_SAMPLES_TEST//4)
        
        # Componente de 50Hz debería estar muy atenuado
        idx_50_proc = np.argmin(np.abs(freq_proc - 50))
        assert psd_proc[idx_50_proc] < psd_raw[np.argmin(np.abs(freq_raw - 50))] * 0.01
        
        # Componentes de 30Hz y 80Hz deberían estar presentes (relativamente)
        idx_30_proc = np.argmin(np.abs(freq_proc - 30))
        idx_80_proc = np.argmin(np.abs(freq_proc - 80))
        # Es difícil hacer aserciones cuantitativas exactas de amplitud después de Z-score y múltiples filtros
        # pero deberían ser picos significativos en el espectro procesado.
        assert psd_proc[idx_30_proc] > np.mean(psd_proc) * 2 # Al menos el doble de la media del PSD
        assert psd_proc[idx_80_proc] > np.mean(psd_proc) * 2


class TestEMGProcessingFeaturesAndTransforms:
    """Pruebas para extracción de características y transformadas."""

    def test_temporal_features(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        signal = np.array([1, 2, 3, 2, 1, 0, -1, -2, -1, 0] * 10, dtype=float) # Señal simple
        features = engine.extract_temporal_features(signal)
        assert "MAV" in features and "RMS" in features and "IEMG" in features
        assert features["MAV"] == pytest.approx(1.2)
        assert features["RMS"] == pytest.approx(np.sqrt(np.mean(signal**2)))
        assert features["ZeroCrossings"] == 2 * 10 # 2 cruces por ciclo * 10 ciclos

    def test_frequency_features(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance # FS=1000Hz
        t = np.linspace(0, 1, 1000, endpoint=False)
        signal_25hz = np.sin(2 * np.pi * 25 * t)
        
        features = engine.extract_frequency_features(signal_25hz)
        assert "TotalPower" in features and "MeanFrequency" in features and "MedianFrequency" in features
        assert features["MeanFrequency"] == pytest.approx(25.0, abs=1.0)
        assert features["MedianFrequency"] == pytest.approx(25.0, abs=1.0)

    def test_stft_features(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        t = np.linspace(0, 1, 1000, endpoint=False)
        signal_freq_sweep = signal.chirp(t, f0=10, f1=100, t1=1, method='linear') # Chirp de 10 a 100 Hz

        features = engine.extract_time_frequency_features_stft(signal_freq_sweep)
        assert "STFT_DominantFreq" in features and "STFT_Bandwidth" in features
        # Frecuencia dominante promedio debería estar entre 10 y 100 Hz, e.g., alrededor de 55Hz
        assert 40 < features["STFT_DominantFreq"] < 70
        assert features["STFT_Bandwidth"] > 0 # Debería haber un ancho de banda

    def test_extract_all_features_multichannel(self, processing_engine_instance: EMGProcessingEngine, sample_emg_signal_2ch: np.ndarray):
        engine = processing_engine_instance
        all_features = engine.extract_all_features(sample_emg_signal_2ch)
        assert isinstance(all_features, list)
        assert len(all_features) == 2 # Para 2 canales
        assert isinstance(all_features[0], dict)
        assert "MAV" in all_features[0] and "MAV" in all_features[1]
        assert "MeanFrequency" in all_features[0]

    def test_fourier_transform(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        t = np.linspace(0, 1, int(FS_TEST), endpoint=False)
        signal_mix = np.sin(2 * np.pi * 50 * t) + 0.5 * np.sin(2 * np.pi * 120 * t)
        
        freqs, amps = engine.fourier_transform(signal_mix)
        assert freqs.ndim == 1 and amps.ndim == 1
        assert len(freqs) == len(amps)
        
        idx_50hz = np.argmin(np.abs(freqs - 50))
        idx_120hz = np.argmin(np.abs(freqs - 120))
        
        assert amps[idx_50hz] > amps[idx_120hz] # Componente de 50Hz es más fuerte
        # Verificar que los picos estén donde se esperan
        assert np.max(amps[np.logical_and(freqs > 45, freqs < 55)]) == pytest.approx(amps[idx_50hz])
        assert np.max(amps[np.logical_and(freqs > 115, freqs < 125)]) == pytest.approx(amps[idx_120hz])

    def test_segment_signal(self, processing_engine_instance: EMGProcessingEngine):
        engine = processing_engine_instance
        signal_1d = np.arange(100) # 100 muestras
        window = 20
        overlap = 10
        step = window - overlap # 10

        segments = engine.segment_signal(signal_1d, window, overlap)
        # (100 - 20) / 10 + 1 = 80 / 10 + 1 = 8 + 1 = 9 segmentos
        assert len(segments) == 9
        assert all(seg.shape == (window, 1) for seg in segments) # EMGProcessingEngine lo hace 2D
        np.testing.assert_array_equal(segments[0].ravel(), np.arange(0, 20))
        np.testing.assert_array_equal(segments[1].ravel(), np.arange(10, 30))

        signal_2d = np.array([np.arange(100), np.arange(100,200)]).T # [100, 2]
        segments_2d = engine.segment_signal(signal_2d, window, overlap)
        assert len(segments_2d) == 9
        assert all(seg.shape == (window, 2) for seg in segments_2d)
        np.testing.assert_array_equal(segments_2d[0][:,0], np.arange(0, 20))
        np.testing.assert_array_equal(segments_2d[1][:,1], np.arange(110, 130))

    def test_generate_and_save_report(self, processing_engine_instance: EMGProcessingEngine, 
                                      sample_emg_signal_1ch: np.ndarray, 
                                      mock_data_manager_proc: MagicMock):
        engine = processing_engine_instance
        patient_id = "report_test_patient"
        engine.patient_id = patient_id
        
        # Aplicar algunos filtros para tener una señal procesada
        engine.configure_filter("highpass", {"enabled": True, "cutoff_hz": 10.0})
        engine.configure_filter("notch", {"enabled": True, "freq_hz": 50.0})
        processed_signal = engine.process_signal(sample_emg_signal_1ch.copy())

        engine.save_processed_data(patient_id, sample_emg_signal_1ch, processed_signal)
        
        # Verificar que mock_data_manager.guardar_datos fue llamado
        mock_data_manager_proc.guardar_datos.assert_called_once()
        args, _ = mock_data_manager_proc.guardar_datos.call_args
        assert args[0] == patient_id
        assert args[1] == "processed_emg_session" # Clave para datos de sesión procesados
        saved_content = args[2]
        
        assert "raw_signal_samples" in saved_content
        assert "processed_signal_samples" in saved_content
        assert "processing_report" in saved_content
        
        report = saved_content["processing_report"]
        assert "timestamp" in report
        assert "sampling_rate_hz" in report
        assert "filters_applied_config" in report
        assert "highpass" in report["filters_applied_config"] # Verificamos que se guardó la config del filtro aplicado
        assert "raw_signal_stats" in report and len(report["raw_signal_stats"]) == 1 # 1 canal
        assert "processed_signal_stats" in report and len(report["processed_signal_stats"]) == 1
        assert "MAV" in report["processed_signal_stats"][0]
        assert "raw_signal_fft_per_channel" in report and len(report["raw_signal_fft_per_channel"]) == 1
        assert "processed_signal_fft_per_channel" in report and len(report["processed_signal_fft_per_channel"]) == 1
        assert "frequencies_hz" in report["processed_signal_fft_per_channel"][0]
    