      # BitnariApp EMG Suite - Versión Profesional

**BitnariApp EMG Suite** es una aplicación de escritorio avanzada diseñada para la adquisición, procesamiento, calibración, clasificación y análisis integral de señales electromiográficas (EMG). Esta herramienta está orientada tanto a investigadores como a profesionales en el campo de la biomecánica, rehabilitación, y neurociencia.

![BitnariApp Screenshot Placeholder](resources/screenshots/main_window_placeholder.png) 
*(Reemplazar con una captura de pantalla real de la aplicación)*

## Características Principales

*   **Adquisición de Señal EMG:**
    *   Conexión robusta a dispositivos de adquisición (e.g., Arduino) vía puerto serial.
    *   Autodetección de puerto y configuración flexible de parámetros de adquisición (baud rate, canales, delay/frecuencia de muestreo).
    *   Protocolo de comunicación con validación de integridad de datos (CRC8).
    *   Modo de simulación para desarrollo y pruebas sin hardware.
*   **Calibración de Señal:**
    *   Calibración de offset (línea base) para remover derivas.
    *   (Opcional) Calibración de ganancia mediante protocolos como Contracción Voluntaria Máxima (MVC).
    *   Persistencia de parámetros de calibración por paciente.
    *   Comparación con señales de referencia.
*   **Procesamiento Avanzado de Señal:**
    *   Cadena de filtros digitales configurables:
        *   Pasa-alto, Pasa-bajo, Pasa-banda (Butterworth).
        *   Notch para eliminar interferencia de la red eléctrica (50/60 Hz).
        *   Filtros de suavizado: Mediana, Savitzky-Golay, Media Móvil.
    *   Transformadas de señal: FFT, Envolvente de Hilbert, Descomposición Modal Empírica (EMD), Wavelet.
    *   Normalización y escalado de datos (Min-Max, Z-Score, Robust Scaler).
*   **Clasificación de Movimientos/Gestos:**
    *   Soporte para múltiples modelos de Machine Learning:
        *   Clásicos: Random Forest, SVM, MLP, XGBoost.
        *   Redes Neuronales: Implementación personalizable con PyTorch (DNN).
    *   Entrenamiento de modelos con optimización de hiperparámetros (GridSearchCV) y validación cruzada.
    *   Early stopping para entrenamiento de redes neuronales.
    *   Preprocesamiento configurable: SMOTE para balanceo de clases, selección de características.
    *   Evaluación exhaustiva de modelos: Accuracy, Precision, Recall, F1-score, Matriz de Confusión, Curva ROC.
    *   Persistencia de modelos entrenados y métricas.
*   **Gestión Integral de Pacientes:**
    *   Registro y edición de datos demográficos, de contacto y clínicos.
    *   Historial clínico detallado por paciente.
    *   Visualización de la evolución de parámetros.
*   **Interfaz Gráfica de Usuario (GUI) Moderna:**
    *   Desarrollada con PyQt6 para una experiencia de escritorio nativa.
    *   Diseño intuitivo con navegación clara mediante pestañas y un panel lateral.
    *   Visualización de señales en tiempo real y de datos guardados con `pyqtgraph`.
    *   Gráficos 2D y 3D (para representación de mano/movimiento).
    *   Tema oscuro personalizable mediante hojas de estilo QSS.
    *   Internacionalización (soporte para múltiples idiomas - *planificado*).
*   **Gestión de Datos Local:**
    *   Almacenamiento de datos de pacientes, sesiones, configuraciones y modelos en archivos JSON organizados en una estructura de carpetas local.
    *   Exportación de datos y reportes en formatos comunes (CSV, JSON, PDF - *parcialmente implementado*).
*   **Calidad y Robustez:**
    *   Arquitectura modular con separación de preocupaciones.
    *   Logging detallado de eventos y errores.
    *   Manejo de excepciones y validación de entradas.

## Estructura del Proyecto
```
BitnnariApp/
│
├── .vscode/
│   ├── launch.json
│   ├── settings.json
│   └── tasks.json
│
├── venv/                        ← Entorno virtual (no versionar, agregar a .gitignore)
│   └── ...
│
├── acquisition/
│   ├── __init__.py
│   ├── ArduinoCode/
│   │   ├── platformio.ini
│   │   └── src/ArduinoCode.ino
│   └── emg_adquisition.py
│
├── backend/
│   ├── .env
│   ├── Dockerfile
│   ├── docker-compose.yaml
│   ├── gestor_datos_completo.py
│   └── seed_mongo.py
│
├── classification/
│   ├── __init__.py
│   ├── emg_classification.py
│   ├── model_factory.py
│   ├── strategies/
│   │   ├── __init__.py
│   │   ├── cnn_strategy.py
│   │   ├── rf_strategy.py
│   │   └── svm_strategy.py
│   └── training_utils.py
│
├── calibration/
│   ├── __init__.py
│   ├── emg_calibration.py
│   ├── normalization.py
│   └── adaptive_filter.py
│
├── data/
│   ├── __init__.py
│   ├── gestor_datos.py
│   ├── repository.py
│   ├── base_de_datos/
│   │   └── emg_project/
│   │       └── base_de_datos/
│   │           ├── pacientes_index.json
│   │           ├── metadata.db
│   │           └── pacientes/
│   │               ├── 12345678/
│   │               │   ├── datos_personales/datos_personales.json
│   │               │   ├── configuracion/calibracion/calibracion_config.json
│   │               │   └── sesiones/SESION_001/sesion.json
│   │               └── … (otros pacientes, colaboradores, etc.)
│   └── models/
│       ├── __init__.py
│       ├── patient.py
│       ├── calibration_params.py
│       └── emg_record.py
│
├── gui/
│   ├── __init__.py
│   ├── main_window.py
│   ├── run_app.py
│   ├── ventana_inicio.py
│   ├── ventana_principal.py
│   ├── pagina_adquisicion.py
│   ├── pagina_procesamiento.py
│   ├── pagina_entrenamiento.py
│   ├── pagina_prediccion.py
│   ├── pagina_calibracion.py
│   ├── pagina_paciente.py
│   ├── ui/
│   │   ├── ui_adquisicion.ui
│   │   └── ui_calibracion.ui
│   └── forms/
│       ├── ui_adquisicion.py
│       └── ui_calibracion.py
│
├── models/
│   ├── cnn_model.h5
│   └── svm_model.pkl
│
├── processing/
│   ├── __init__.py
│   ├── emg_processing.py
│   ├── filters.py
│   └── features.py
│
├── resources/
│   ├── icons/
│   │   ├── icon_button_play.svg
│   │   └── logo_bitnnari.png
│   └── qss/
│       ├── estilo_adquisicion.qss
│       ├── estilo_moderno.qss
│       └── hestilo_adquisicion.qss
│
├── run_app.py
├── requirements.txt
├── setup.py
│
├── tests/
│   ├── __init__.py
│   ├── test_acquisition.py
│   ├── test_calibration.py
│   ├── test_classification.py
│   ├── test_processing.py
│   └── test_repository.py
│
├── utils/
│   ├── __init__.py
│   ├── constants.py
│   └── logging_config.py
│
└── README.md
```
##instalacion

### Prerrequisitos

*   Python 3.9 o superior.
*   `pip` (gestor de paquetes de Python).
*   (Opcional) Git para clonar el repositorio.
*   (Opcional, para desarrollo) Entorno virtual (e.g., `venv`, `conda`).

### Pasos de Instalación

1.  **Clonar el Repositorio (Opcional):**
    ```bash
    git clone https://github.com/yourusername/BitnariApp.git
    cd BitnariApp
    ```

2.  **Crear un Entorno Virtual (Recomendado):**
    ```bash
    python -m venv venv
    # Activar el entorno:
    # Windows:
    # venv\Scripts\activate
    # macOS/Linux:
    # source venv/bin/activate
    ```

3.  **Instalar Dependencias:**
    El archivo principal de dependencias para la aplicación de escritorio es `BitnariApp/requirements.txt`.
    ```bash
    pip install -r requirements.txt
    ```
    Si planea usar funcionalidades que dependen de paquetes opcionales (como XGBoost o TensorBoard para desarrollo), puede instalarlos adicionalmente:
    ```bash
    pip install xgboost tensorboard
    # O si se definen en extras_require en setup.py:
    # pip install .[xgboost,tensorboard]
    ```

4.  **(Opcional) Instalar el Paquete Localmente (para desarrollo):**
    Si desea instalar la aplicación como un paquete editable en su entorno, puede ejecutar desde el directorio raíz `BitnariApp/`:
    ```bash
    pip install -e .
    ```
    Esto es útil si está desarrollando activamente la aplicación.

## Uso

Para ejecutar la aplicación de escritorio, navegue al directorio raíz `BitnariApp/` y ejecute:

```bash
python run_app.py
```
Si instaló el paquete usando pip install . o pip install -e ., y el entry_point está configurado en setup.py, también podría ejecutarla directamente con el comando:
      bitnariapp
    
Primeros Pasos
Al iniciar, se presentará la Ventana de Inicio.
Ingrese el DNI de un paciente existente para buscarlo o haga clic en "Registrar Nuevo Paciente".
Si registra un nuevo paciente, complete el formulario en la Ventana de Registro.
Una vez que un paciente es seleccionado o registrado, y se elige un modelo de ML (si aplica), se accederá a la Ventana Principal de la aplicación.
Utilice el panel de navegación lateral para moverse entre las diferentes secciones: Adquisición, Calibración, Procesamiento, Entrenamiento, Predicción e Información del Paciente.
Consulte la pestaña "Ayuda" en cada sección o en el panel inferior para obtener instrucciones específicas.
Configuración
Configuración de Logging: Se gestiona en BitnariApp/utils/logging_config.py. Los logs se guardan por defecto en BitnariApp/data/app_data/logs/.
Constantes de la Aplicación: Valores globales y rutas se definen en BitnariApp/utils/constants.py.
Configuraciones Específicas de Módulos:
Clasificación: BitnariApp/classification_engine_config.json (o el nombre definido en EMGClassificationEngine).
Configuraciones de página (GUI): Se guardan por paciente en su respectivo directorio de datos bajo configuraciones_gui_paginas.
Desarrollo y Pruebas
Estructura de Pruebas
Los tests se encuentran en el directorio BitnariApp/tests/. Se recomienda usar pytest.
Ejecutar Pruebas
Para ejecutar todos los tests (asumiendo que pytest y las dependencias de desarrollo están instaladas):
      pytest
    
O para un archivo específico:
      pytest tests/models/test_emg_acquisition.py
    
Linters y Formateadores
Se recomienda usar flake8 para linting y black para formateo de código para mantener la consistencia.
      flake8 BitnariApp/
black BitnariApp/
    
Type Checking
Usar mypy para verificación estática de tipos:
      mypy BitnariApp/
    

Empaquetado y Distribución (Placeholder)
(Esta sección se completaría con instrucciones detalladas una vez que se elija una herramienta como PyInstaller o cx_Freeze).
Para crear un ejecutable standalone de la aplicación, se pueden usar herramientas como:

PyInstaller:       # Ejemplo básico
pyinstaller --name BitnariApp --onefile --windowed run_app.py \
            --add-data "BitnariApp/resources:BitnariApp/resources" \
            --add-data "BitnariApp/gui/ui:BitnariApp/gui/ui" \
            --hidden-import="scipy.signal.windows.windows" \
            --hidden-import="sklearn.utils._typedefs" \
            --hidden-import="sklearn.utils._heap" \
            --hidden-import="sklearn.utils._sorting" \
            # ... (añadir otros hidden imports y data files necesarios)
           
cx_Freeze: Requiere un script setup_cx.py.
Es importante asegurarse de que todos los recursos (QSS, iconos, archivos .ui, modelos de datos si no se descargan) y las dependencias ocultas se incluyan correctamente en el ejecutable empaquetado.
Contribuciones
Las contribuciones son bienvenidas. Por favor, siga las guías de estilo de código y asegúrese de que todos los tests pasen antes de enviar un Pull Request.
Licencia
Este proyecto está licenciado bajo la Licencia MIT. Ver el archivo LICENSE para más detalles. (Asegurarse de que exista un archivo LICENSE si se especifica una licencia)
