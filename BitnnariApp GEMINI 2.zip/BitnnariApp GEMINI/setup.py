      """
setup.py

Archivo de configuración para setuptools, utilizado para construir,
distribuir e instalar el paquete BitnariApp.
"""

import os
from setuptools import setup, find_packages

# Leer el contenido del archivo README.md para la descripción larga
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
README_PATH = os.path.join(BASE_DIR, "README.md")

try:
    with open(README_PATH, "r", encoding="utf-8") as f:
        LONG_DESCRIPTION = f.read()
except FileNotFoundError:
    LONG_DESCRIPTION = "BitnariApp: Aplicación avanzada para adquisición, procesamiento y clasificación de señales EMG."

# Leer el contenido del archivo requirements.txt para las dependencias
REQUIREMENTS_PATH = os.path.join(BASE_DIR, "requirements.txt") # Asumiendo que está en la raíz del proyecto BitnnariApp
# Si está en backend/, la ruta sería os.path.join(BASE_DIR, "backend", "requirements.txt")

INSTALL_REQUIRES = []
if os.path.exists(REQUIREMENTS_PATH):
    with open(REQUIREMENTS_PATH, "r", encoding="utf-8") as f:
        INSTALL_REQUIRES = [line.strip() for line in f if line.strip() and not line.startswith("#")]
else:
    print(f"ADVERTENCIA: El archivo {REQUIREMENTS_PATH} no se encontró. Las dependencias no se listarán automáticamente.")
    # Se podrían listar dependencias clave manualmente aquí como fallback,
    # pero es mejor mantenerlas en requirements.txt.
    # INSTALL_REQUIRES = ["PyQt6", "numpy", "scipy", "pyqtgraph", "pyserial", "crcmod", ...]


# Definir la versión de la aplicación
# Se puede obtener de un archivo VERSION, de una variable de entorno, o definir aquí.
# Para un enfoque más robusto, se podría leer de BitnnariApp/__version__.py
APP_VERSION = "1.0.0" # Actualizar según sea necesario

setup(
    name="BitnariApp",
    version=APP_VERSION,
    author="BitnariTech Development Team", # Reemplazar con el autor/equipo real
    author_email="soporte@bitnaritech.example.com", # Reemplazar
    description="Aplicación para adquisición, análisis y clasificación de señales EMG.",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/BitnariApp", # Reemplazar con la URL del repositorio
    license="MIT", # O la licencia que aplique
    
    # Encuentra automáticamente todos los paquetes dentro del directorio BitnnariApp
    # Asegúrate de que cada directorio que es un paquete tenga un archivo __init__.py
    packages=find_packages(
        exclude=["*.tests", "*.tests.*", "tests.*", "tests", "*.backend_tests", "docs", "examples"]
    ),
    
    # Incluir archivos que no son de Python (datos, recursos, etc.)
    # Esto es crucial para que QSS, iconos, archivos .ui, etc., se incluyan en la distribución.
    include_package_data=True, # Busca un archivo MANIFEST.in o usa información de SCM
    # Alternativamente, o en conjunto, se puede usar package_data o data_files:
    package_data={
        # Si los recursos están dentro de un paquete (e.g., BitnnariApp/resources)
        "BitnariApp": [
            "resources/qss/*.qss",
            "resources/icons/*.png", # Añadir otros formatos de icono si se usan (svg, ico)
            "gui/ui/*.ui", # Incluir archivos .ui si se cargan dinámicamente
            # "data/initial_data/*.json", # Si hay datos iniciales que empaquetar
            # "config/*.json", # Si hay archivos de configuración por defecto
        ],
        # Si los modelos pre-entrenados deben incluirse (puede hacer el paquete grande):
        # "BitnariApp.models": ["*.pkl", "*.h5", "*.pth"],
    },
    # data_files se usa para archivos que van fuera de los directorios de paquetes,
    # como archivos de configuración globales en /etc (más común para paquetes de sistema Linux).
    # Para la mayoría de las aplicaciones, package_data es suficiente.

    # Dependencias de instalación
    install_requires=INSTALL_REQUIRES,
    
    # Dependencias opcionales (e.g., para desarrollo, testing, o funcionalidades extra)
    extras_require={
        "dev": ["pytest", "mypy", "flake8", "pylint", "black", "ipykernel", "twine", "wheel", "build"],
        "docs": ["sphinx", "sphinx-rtd-theme"],
        "xgboost": ["xgboost>=1.0.0"], # Si XGBoost es opcional
        "tensorboard": ["tensorboard>=2.0.0"], # Si TensorBoard es opcional
    },

    # Punto de entrada para la aplicación ejecutable (si se instala con pip)
    # Esto crea un script que llama a main() en BitnnariApp.run_app
    entry_points={
        "gui_scripts": [
            "bitnariapp = BitnariApp.run_app:main",
        ],
        # "console_scripts": [ # Si hubiera una CLI
        #     "bitnariapp-cli = BitnariApp.cli:main_cli",
        # ]
    },

    # Clasificadores para PyPI
    classifiers=[
        "Development Status :: 5 - Production/Stable", # O 4 - Beta si aún no es estable
        "Intended Audience :: Healthcare Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License", # Ajustar si es otra licencia
        "Operating System :: OS Independent", # O especificar (Windows, MacOS, Linux)
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Software Development :: User Interfaces",
        "Framework :: Qt",
    ],
    
    python_requires=">=3.9", # Versión mínima de Python requerida
    
    # Palabras clave para búsqueda en PyPI
    keywords="emg signal-processing machine-learning qt pyqt6 biomedical",

    # Para MANIFEST.in si se usa include_package_data=True y no se usa SCM para inferir
    # (Si se usa git, setuptools-scm puede ser útil para versionado y archivos)
    # manifest_in = "MANIFEST.in" # Descomentar si se usa MANIFEST.in explícitamente
)

# Nota sobre MANIFEST.in:
# Si `include_package_data=True` no captura todos los archivos necesarios
# (especialmente si no se usa un SCM como Git, o si los archivos están en lugares inusuales),
# se puede crear un archivo MANIFEST.in en el mismo directorio que setup.py.
# Ejemplo de MANIFEST.in:
#
# include README.md
# include requirements.txt
# recursive-include BitnariApp/resources *
# recursive-include BitnariApp/gui/ui *.ui
# recursive-include BitnariApp/data/initial_data *.json
# global-exclude *.py[cod] __pycache__ *.so *.dylib
    